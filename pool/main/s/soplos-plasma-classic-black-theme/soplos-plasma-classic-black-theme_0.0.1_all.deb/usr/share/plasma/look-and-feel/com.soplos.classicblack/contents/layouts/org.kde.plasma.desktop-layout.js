var plasma = getApiVersion(1);

// === CONFIGURACIONES SEGURAS PARA X11/WAYLAND ===
function isWayland() {
    return typeof sessionType !== 'undefined' && sessionType === 'wayland';
}

// === PRESERVAR APLICACIONES DEL USUARIO ===
var userLaunchers = [];
var userPanelConfigs = {};
var existingPanels = panelIds;

// Preservar configuraciones de paneles existentes
for (var p = 0; p < existingPanels.length; p++) {
    var panel = panelById(existingPanels[p]);
    if (panel) {
        userPanelConfigs[existingPanels[p]] = {
            thickness: panel.readConfig("thickness", 44),
            floating: panel.readConfig("floating", true),
            opacity: panel.readConfig("panelOpacity", 2)
        };

        var widgets = panel.widgets();
        for (var w = 0; w < widgets.length; w++) {
            if (widgets[w].type === "org.kde.plasma.icontasks") {
                var launchers = widgets[w].readConfig("launchers", []);
                for (var l = 0; l < launchers.length; l++) {
                    if (userLaunchers.indexOf(launchers[l]) === -1) {
                        userLaunchers.push(launchers[l]);
                    }
                }
            }
        }
    }
}

// Cargar plantilla solo si no hay paneles configurados
if (existingPanels.length === 0) {
    loadTemplate("org.kde.plasma.desktop.defaultPanel");
}

// === CONFIGURAR ESCRITORIO ROBUSTO ===
function configureDesktop() {
    var desktopsArray = desktopsForActivity(currentActivity());
    for (var j = 0; j < desktopsArray.length; j++) {
        var desktop = desktopsArray[j];

        // Wallpaper con fallback
        try {
            desktop.wallpaperPlugin = 'org.kde.image';
            desktop.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];

            // Usar ruta absoluta universal
            var wallpaperPath = "file:///usr/share/wallpapers/soplos/006.jpg";
            desktop.writeConfig("Image", wallpaperPath);
            desktop.writeConfig("PreviewImage", wallpaperPath);
            desktop.writeConfig("FillMode", "2");
            desktop.writeConfig("SlidePaths", "file:///usr/share/wallpapers/soplos/");
        } catch (e) {
            print("Error configurando wallpaper: " + e);
        }

        // Configuración de iconos
        desktop.currentConfigGroup = ["General"];
        desktop.writeConfig("arrangement", 1);
        desktop.writeConfig("iconSize", 2);
        desktop.writeConfig("sortMode", -1);

        // Posiciones robustas para iconos
        var iconPositions = {};
        var resolutions = ["1366x768", "1440x900", "1600x900", "1680x1050", "1920x1080", "2560x1440", "3840x2160"];

        resolutions.forEach(function(resolution) {
            iconPositions[resolution] = [
                "1", "9",
                "desktop:/home.desktop", "0", "0",
                "desktop:/trash:⁄.desktop", "0", "1",
                "desktop:/calamares-install-soplos.desktop", "0", "2"
            ];
        });

        desktop.writeConfig("positions", JSON.stringify(iconPositions));

        // Acciones del ratón
        desktop.currentConfigGroup = ["ActionPlugins", "0"];
        desktop.writeConfig("MiddleButton;NoModifier", "org.kde.paste");
        desktop.writeConfig("RightButton;NoModifier", "org.kde.contextmenu");

        desktop.currentConfigGroup = ["ActionPlugins", "1"];
        desktop.writeConfig("RightButton;NoModifier", "org.kde.contextmenu");

        desktop.reloadConfig();
    }
}

// === CONFIGURAR PANELES ROBUSTO ===
function configurePanels() {
    var panels = panelIds;
    for (var i = 0; i < panels.length; i++) {
        var panel = panelById(panels[i]);
        if (!panel) continue;

        // Preservar configuraciones del usuario o usar predeterminadas
        var panelConfig = userPanelConfigs[panels[i]] || {
            thickness: 44,
            floating: true,
            opacity: 2
        };

        // Aplicar tema del panel
        panel.currentConfigGroup = ["Configuration"];
        panel.writeConfig("theme", "soplos-black");
        panel.writeConfig("thickness", panelConfig.thickness);
        panel.writeConfig("floating", panelConfig.floating);
        panel.writeConfig("panelOpacity", panelConfig.opacity);

        var widgets = panel.widgets();
        for (var w = 0; w < widgets.length; w++) {
            // Configurar Kickoff/Kicker
            if (widgets[w].type === "org.kde.plasma.kickoff" || widgets[w].type === "org.kde.plasma.kicker") {
                widgets[w].currentConfigGroup = ["General"];
                widgets[w].writeConfig("icon", "/usr/share/branding-soplos/soplos/menusoplos.png");
                widgets[w].writeConfig("alphaSort", true);

                widgets[w].currentConfigGroup = ["Configuration", "General"];
                widgets[w].writeConfig("favoritesPortedToKAstats", true);
                widgets[w].writeConfig("switchCategoryOnHover", true);
                widgets[w].reloadConfig();
            }

            // Configurar SystemTray
            if (widgets[w].type === "org.kde.plasma.systemtray") {
                var systrayId = widgets[w].readConfig("SystrayContainmentId");
                if (systrayId) {
                    var systrayContainer = desktopById(systrayId);
                    if (systrayContainer) {
                        systrayContainer.currentConfigGroup = ["General"];
                        var extraItems = "org.kde.plasma.brightness,org.kde.plasma.keyboardindicator,org.kde.plasma.keyboardlayout,org.kde.plasma.mediacontroller,org.kde.plasma.manage-inputmethod,org.kde.plasma.battery,org.kde.plasma.cameraindicator,org.kde.kupapplet,org.kde.plasma.clipboard,org.kde.plasma.vault,org.kde.plasma.printmanager,org.kde.plasma.volume,org.kde.kscreen,org.kde.plasma.devicenotifier,org.kde.plasma.bluetooth,org.kde.plasma.networkmanagement,org.kde.plasma.notifications";
                        systrayContainer.writeConfig("extraItems", extraItems);
                        systrayContainer.writeConfig("knownItems", extraItems);
                    }
                }
            }

            // Configurar IconTasks preservando launchers del usuario
            if (widgets[w].type === "org.kde.plasma.icontasks") {
                widgets[w].currentConfigGroup = ["General"];

                var defaultLaunchers = [
                    "applications:firefox.desktop",
                    "applications:org.kde.dolphin.desktop",
                    "applications:org.kde.discover.desktop",
                    "applications:systemsettings.desktop",
                    "applications:org.kde.konsole.desktop"
                ];

                var allLaunchers = [];

                // Agregar launchers predeterminados
                for (var d = 0; d < defaultLaunchers.length; d++) {
                    if (allLaunchers.indexOf(defaultLaunchers[d]) === -1) {
                        allLaunchers.push(defaultLaunchers[d]);
                    }
                }

                // Preservar launchers del usuario
                for (var u = 0; u < userLaunchers.length; u++) {
                    if (allLaunchers.indexOf(userLaunchers[u]) === -1) {
                        allLaunchers.push(userLaunchers[u]);
                    }
                }

                widgets[w].writeConfig("launchers", allLaunchers);
                widgets[w].writeConfig("groupingStrategy", "0");
                widgets[w].writeConfig("maxStripes", 1);
                widgets[w].writeConfig("showOnlyCurrentDesktop", false);
                widgets[w].writeConfig("showOnlyCurrentScreen", false);
                widgets[w].reloadConfig();
            }
        }

        panel.reloadConfig();
    }
}

// === FUNCIÓN PARA APLICAR TEMA GLOBAL ===
function applyGlobalTheme() {
    try {
        // Configurar tema de plasma
        var themeConfig = ConfigFile("plasmarc");
        themeConfig.group = "Theme";
        themeConfig.writeEntry("name", "soplos-black");
        themeConfig.sync();

        // Configurar esquema de colores
        var colorSchemeConfig = ConfigFile("kdeglobals");
        colorSchemeConfig.group = "General";
        colorSchemeConfig.writeEntry("ColorScheme", "SoplosClassicDark");
        colorSchemeConfig.group = "KDE";
        colorSchemeConfig.writeEntry("ColorScheme", "SoplosClassicDark");
        colorSchemeConfig.writeEntry("LookAndFeelPackage", "com.soplos.classicblack");
        colorSchemeConfig.sync();

        // Configurar lockscreen (KScreenLocker)
        var lockscreenConfig = ConfigFile("kscreenlockerrc");
        lockscreenConfig.group = "Greeter";
        lockscreenConfig.writeEntry("WallpaperPlugin", "org.kde.image");

        lockscreenConfig.group = "Greeter";
        lockscreenConfig.group = "Wallpaper";
        lockscreenConfig.group = "org.kde.image";
        lockscreenConfig.group = "General";
        lockscreenConfig.writeEntry("Image", "/usr/share/wallpapers/soplos/006.jpg");
        lockscreenConfig.writeEntry("PreviewImage", "/usr/share/wallpapers/soplos/006.jpg");
        lockscreenConfig.writeEntry("FillMode", "2");
        lockscreenConfig.writeEntry("SlidePaths", "/usr/share/wallpapers/soplos/");
        lockscreenConfig.sync();

    } catch (e) {
        print("Error aplicando tema global: " + e);
    }
}

// === EJECUCIÓN PRINCIPAL ===
try {
    configureDesktop();
    configurePanels();
    applyGlobalTheme();

    // Recargar después de configurar
    sleep(500);

    var allPanels = panelIds;
    for (var i = 0; i < allPanels.length; i++) {
        var panel = panelById(allPanels[i]);
        if (panel) {
            panel.reloadConfig();
        }
    }

    // Aplicar tema una vez más para asegurar persistencia
    sleep(1000);
    applyGlobalTheme();

} catch (e) {
    print("Error en configuración: " + e);
}
