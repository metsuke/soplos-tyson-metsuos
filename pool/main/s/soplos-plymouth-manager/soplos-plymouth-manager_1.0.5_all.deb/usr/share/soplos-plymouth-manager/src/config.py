import os
import json

CONFIG_DIR = os.path.expanduser("~/.config/soplos-plymouth-manager")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

class Config:
    def __init__(self):
        self.data = {
            'last_theme': None,
            'window_size': (450, 800),
            'dark_mode': True
        }
        self.load()
    
    def load(self):
        """Carga la configuración desde el archivo"""
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    self.data.update(json.load(f))
            except Exception:
                pass
    
    def save(self):
        """Guarda la configuración en el archivo"""
        if not os.path.exists(CONFIG_DIR):
            os.makedirs(CONFIG_DIR)
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(self.data, f, indent=4)
        except Exception:
            pass
    
    def get(self, key, default=None):
        """Obtiene un valor de la configuración"""
        return self.data.get(key, default)
    
    def set(self, key, value):
        """Establece un valor en la configuración"""
        self.data[key] = value
        self.save()
