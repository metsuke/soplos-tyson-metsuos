import os

# Directorios base
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
ICONS_DIR = os.path.join(ASSETS_DIR, "icons")

# Paths for icons and logos
ICON_PATH = os.path.join(BASE_DIR, "assets/icons/com.soplos.plymouthmanager.png")
LOGO_PATH = os.path.join(BASE_DIR, "assets/icons/soplos-logo.png")

# Recursos
APP_ICON = os.path.join(ICONS_DIR, "com.soplos.plymouthmanager.png")  # Este es el icono del programa

# Application ID - Debe coincidir con el definido en main.py
APPLICATION_ID = "com.soplos.plymouthmanager"

# Configuración
CONFIG_DIR = os.path.expanduser("~/.config/soplos-plymouth-manager")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

# Logs
LOG_DIR = os.path.expanduser("~/.local/share/soplos-plymouth-manager/logs")

# Plymouth
PLYMOUTH_THEME_DIRS = [
    "/usr/share/plymouth/themes/",
    "/usr/local/share/plymouth/themes/"
]
