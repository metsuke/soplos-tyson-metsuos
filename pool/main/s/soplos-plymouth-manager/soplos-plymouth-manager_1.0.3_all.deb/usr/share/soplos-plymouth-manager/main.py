#!/usr/bin/env python3
import os
import sys
import configparser
from pathlib import Path
import gi

# Definir las constantes de identificación de manera consistente
APP_ID = "com.soplos.plymouthmanager"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

# Deshabilitar mensajes de accesibilidad
os.environ['NO_AT_BRIDGE'] = '1'

def detect_kde_theme():
    """Detecta el tema actual de KDE y devuelve el nombre de tema GTK equivalente"""
    # Ruta del archivo de configuración de KDE
    kde_config = Path(os.path.expanduser("~/.config/kdeglobals"))
    
    if not kde_config.exists():
        return None
    
    # Leer configuración
    config = configparser.ConfigParser()
    try:
        config.read(kde_config)
        
        # Verificar si hay sección de colores
        if 'Colors:Window' in config:
            # Verificar si se usa tema oscuro comprobando el color de fondo
            background = config['Colors:Window'].get('BackgroundNormal', '')
            # Convertir formato RRR,GGG,BBB a valores numéricos
            if background:
                try:
                    r, g, b = map(int, background.split(','))
                    # Si es oscuro (promedio < 128)
                    if (r + g + b) / 3 < 128:
                        return 'Breeze-Dark'
                    else:
                        return 'Breeze'
                except:
                    pass
        
        # Alternativa: buscar por nombre de esquema de colores
        if 'General' in config and 'ColorScheme' in config['General']:
            color_scheme = config['General']['ColorScheme'].lower()
            if 'dark' in color_scheme or 'negro' in color_scheme or 'oscuro' in color_scheme or 'breezedark' in color_scheme:
                return 'Breeze-Dark'
            else:
                return 'Breeze'
    except Exception as e:
        print(f"Error al leer la configuración de KDE: {e}")
    
    return None

def configure_environment():
    """Detecta y configura el entorno para asegurar coherencia de tema en Wayland/X11"""
    
    # Detectar si estamos en Wayland
    wayland_session = os.environ.get('XDG_SESSION_TYPE') == 'wayland'
    kde_desktop = os.environ.get('XDG_CURRENT_DESKTOP', '').lower().find('kde') >= 0
    
    if wayland_session and kde_desktop:
        # Estamos en KDE Plasma con Wayland
        # Intentar detectar el tema activo de KDE
        theme_name = detect_kde_theme()
        if theme_name:
            # Aplicar el tema GTK correspondiente
            os.environ['GTK_THEME'] = theme_name
            print(f"Plymouth Manager - Wayland + KDE detectado: Aplicando tema GTK '{theme_name}'")
        
        # Usar portal XDG para mejorar integración con Wayland
        os.environ['GTK_USE_PORTAL'] = '1'

# Configurar el entorno ANTES de importar GTK
configure_environment()

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

# Configuración para asegurar que GDK use el WMCLASS correcto
try:
    if hasattr(Gdk, 'set_program_class'):
        Gdk.set_program_class(WMCLASS)
except:
    pass

from src.app import PlymouthApp
from src.utils import show_error_dialog

def main():
    try:
        os.environ['GTK_CSD'] = '0'
        
        # Iniciar la aplicación usando las constantes definidas
        app = PlymouthApp()
        app.app_id = APP_ID
        app.wmclass = WMCLASS
        
        app.run()
    except Exception as e:
        show_error_dialog(None, f"Error al iniciar la aplicación: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
