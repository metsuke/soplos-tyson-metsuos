from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="soplos-plymouth-manager",
    version="1.0.1",  # Updated version
    description="Plymouth Theme Manager for SOPLOS Linux",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="SOPLOS Team",
    author_email="soporte@soplos.org",
    url="https://github.com/soplos/plymouth-manager",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: X11 Applications :: GTK",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Topic :: System :: Boot",
    ],
    python_requires=">=3.6",
    # plymouth-x11 se especifica en debian/control y en la documentación
    # ya que es una dependencia del sistema, no de Python
    package_data={
        'src': ['assets/icons/*.png'],
    },
    data_files=[
        ('share/applications', ['assets/com.soplos.plymouthmanager.desktop']),
        ('share/icons/hicolor/128x128/apps', ['assets/icons/com.soplos.plymouthmanager.png', 'assets/icons/soplos-logo.png']),
        ('share/polkit-1/actions', ['data/org.soplos.plymouthmanager.policy']),
    ],
    entry_points={
        'console_scripts': [
            'soplos-plymouth-manager=main:main',
        ],
    },
)
