# Soplos Plymouth Manager

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.3-green.svg)]()

Un gestor de temas Plymouth simple e intuitivo que te permite previsualizar, instalar y aplicar temas de arranque fácilmente.

*A simple and intuitive Plymouth theme manager that allows you to preview, install and apply boot splash themes easily.*

## 📝 Descripción

Soplos Plymouth Manager es un gestor de temas de arranque Plymouth para Soplos Linux que permite previsualizar, instalar y aplicar temas de arranque de forma sencilla e intuitiva.

## ✨ Características

- Previsualización de temas Plymouth
- Instalación sencilla de nuevos temas
- Aplicación inmediata de temas
- Configuración avanzada
- Interfaz gráfica intuitiva
- Soporte para múltiples idiomas
- **🆕 Detección automática de temas del sistema (Wayland/KDE)**
- **🆕 Integración mejorada con entornos de escritorio**

## 🆕 Novedades en v1.0.3

- 🛠️ **Correcciones finales en el metainfo**: Ahora la aplicación aparece correctamente en centros de software como AppStream, Discover y GNOME Software.

## 🆕 Novedades en v1.0.1

- ✅ **Detección automática de temas**: Detecta automáticamente el tema del sistema (KDE/Plasma)
- 🖥️ **Soporte mejorado para Wayland**: Mejor integración con sesiones Wayland
- 🎨 **Coherencia visual**: La aplicación respeta el tema del entorno de escritorio
- 🔧 **Estabilidad mejorada**: Correcciones de advertencias y mejoras de rendimiento
- 🌐 **Mejor integración**: Uso de portales XDG para mejor compatibilidad

## 📸 Capturas de pantalla

### Lista de temas disponibles
![Lista de temas disponibles](https://raw.githubusercontent.com/SoplosLinux/tyron/refs/heads/main/media/soplos-plymouth-manager/screenshots/screenshot1.png)

### Previsualización del tema
![Previsualización del tema](https://raw.githubusercontent.com/SoplosLinux/tyron/refs/heads/main/media/soplos-plymouth-manager/screenshots/screenshot2.png)

### Configuración avanzada
![Configuración avanzada](https://raw.githubusercontent.com/SoplosLinux/tyron/refs/heads/main/media/soplos-plymouth-manager/screenshots/screenshot3.png)

## 🔧 Instalación

```bash
# Clonar el repositorio
git clone https://github.com/SoplosLinux/soplos-plymouth-manager.git
cd soplos-plymouth-manager

# Instalar dependencias
sudo apt install python3-gi plymouth-x11 gir1.2-gtk-3.0

# Instalar usando setup.py
sudo python3 setup.py install
```

## 🌐 Idiomas soportados

- **Español** (es) - Idioma principal
- **English** (en) - Soporte completo
- **Français** (fr) - Soporte completo
- **Português** (pt) - Soporte completo
- **Deutsch** (de) - Soporte completo
- **Italiano** (it) - Soporte completo
- **Русский** (ru) - Soporte completo
- **Română** (ro) - Soporte completo

## 🖥️ Compatibilidad

- **Entornos de escritorio**: KDE Plasma, GNOME, XFCE, y otros
- **Protocolos de visualización**: X11 y Wayland
- **Distribuciones**: Soplos Linux (principal), Debian, Ubuntu y derivados

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)

## 📦 Historial de Versiones

### v1.0.3 (14/07/2025)
- Correcciones finales en el metainfo para garantizar la aparición en centros de software (AppStream/Discover/GNOME Software)

### v1.0.1 (15/01/2025)
- Implementación de detección automática de temas del sistema
- Soporte mejorado para Wayland y KDE Plasma
- Corrección de advertencias de GTK
- Mejor integración con entornos de escritorio
- Uso de portales XDG para compatibilidad con Wayland
- Mejoras en la estabilidad general

### v1.0.0 (08/05/2025)
- Versión inicial
- Funcionalidades básicas implementadas
- Soporte para múltiples idiomas
- Interfaz gráfica completa
