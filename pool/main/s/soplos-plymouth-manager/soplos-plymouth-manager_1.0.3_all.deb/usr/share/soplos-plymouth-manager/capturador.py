#!/usr/bin/env python3

import subprocess
import time
import os
import sys
import argparse

def check_root():
    if os.geteuid() != 0:
        print("Este script debe ejecutarse como root")
        sys.exit(1)

def check_dependencies():
    try:
        subprocess.run(['which', 'scrot'], check=True, capture_output=True)
    except subprocess.CalledProcessError:
        print("Error: scrot no está instalado. Instálalo con: sudo apt-get install scrot")
        sys.exit(1)

def get_current_theme():
    """Obtiene el nombre del tema actual de Plymouth"""
    try:
        result = subprocess.run(
            ['plymouth-set-default-theme'],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except:
        return None

def capture_plymouth_theme(output_path=None):
    try:
        # Si no se especifica ruta, usar la del tema actual
        if not output_path:
            current_theme = get_current_theme()
            if (current_theme):
                theme_dir = f"/usr/share/plymouth/themes/{current_theme}"
                output_path = os.path.join(theme_dir, "preview.png")
            else:
                output_path = '/tmp/plymouth-capture.png'

        # Si ya existe el archivo, eliminarlo primero
        if os.path.exists(output_path):
            os.remove(output_path)
            
        # Forzar terminación de Plymouth antes de empezar
        subprocess.run(['plymouth', 'quit'], check=False)
        subprocess.run(['plymouthd', '--quit'], check=False)
        subprocess.run(['pkill', '-9', 'plymouth'], check=False)
        subprocess.run(['pkill', '-9', 'plymouthd'], check=False)
        time.sleep(1)  # Esperar a que se detengan los procesos

        # Iniciar Plymouth en modo test
        subprocess.run(['plymouthd', '--mode=boot'], check=True)  # Quitamos --debug aquí
        subprocess.run(['plymouth', 'show-splash'], check=True)
        
        # Esperar a que Plymouth se cargue completamente
        time.sleep(3)
        
        # Tomar captura con scrot forzando la sobreescritura
        subprocess.run(['scrot', '-o', output_path], check=True)
        
    finally:
        # Asegurar que Plymouth se detenga siempre
        try:
            subprocess.run(['plymouth', 'quit'], check=False)
            subprocess.run(['plymouthd', '--quit'], check=False)
            subprocess.run(['pkill', '-9', 'plymouth'], check=False)
            subprocess.run(['pkill', '-9', 'plymouthd'], check=False)
            time.sleep(1)  # Esperar a que terminen los procesos
        except:
            pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Captura el tema actual de Plymouth')
    parser.add_argument('--output', '-o', 
                      help='Ruta donde guardar la captura (opcional)')
    
    args = parser.parse_args()
    check_root()
    check_dependencies()
    capture_plymouth_theme(args.output)
