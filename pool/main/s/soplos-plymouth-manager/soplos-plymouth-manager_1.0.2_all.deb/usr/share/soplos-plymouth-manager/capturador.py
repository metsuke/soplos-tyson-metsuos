#!/usr/bin/env python3

import subprocess
import time
import os
import sys
import argparse
import shutil
import tempfile

def check_root():
    if os.geteuid() != 0:
        print("Este script debe ejecutarse como root")
        sys.exit(1)

def check_dependencies():
    # Detectar si estamos en Wayland o X11
    session_type = os.environ.get('XDG_SESSION_TYPE', '').lower()
    
    if session_type == 'wayland':
        # Verificar si grim está instalado para Wayland
        if not shutil.which('grim'):
            print("Error: grim no está instalado. Instálalo con: sudo apt-get install grim")
            sys.exit(1)
    else:
        # Verificar si scrot está instalado para X11
        if not shutil.which('scrot'):
            print("Error: scrot no está instalado. Instálalo con: sudo apt-get install scrot")
            sys.exit(1)

def get_current_theme():
    """Obtiene el nombre del tema actual de Plymouth"""
    try:
        result = subprocess.run(
            ['plymouth-set-default-theme'],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except:
        return None

def get_screen_resolution():
    """Obtiene la resolución actual del sistema"""
    try:
        session_type = os.environ.get('XDG_SESSION_TYPE', '').lower()
        
        if session_type == 'wayland':
            # Intentar obtener resolución en Wayland
            if shutil.which('wlr-randr'):
                res = subprocess.check_output(['wlr-randr'], text=True)
                import re
                match = re.search(r'(\d+)x(\d+)', res)
                if match:
                    return int(match.group(1)), int(match.group(2))
            elif shutil.which('xrandr'):
                # Caída a xrandr si está disponible (podría funcionar en algunos entornos Wayland)
                pass  # Continúa con la lógica de xrandr abajo
        
        # Método para X11 y fallback para Wayland
        if shutil.which('xrandr'):
            res = subprocess.check_output(['xrandr'], text=True)
            import re
            match = re.search(r'current (\d+) x (\d+)', res)
            if match:
                return int(match.group(1)), int(match.group(2))
    except Exception as e:
        print(f"No se pudo determinar la resolución: {e}")
    
    # Valores por defecto si no podemos detectar
    return 1920, 1080

def create_undecorated_window_script():
    """Crea un script temporal para ejecutar Plymouth en una ventana sin decoración"""
    content = """#!/bin/bash
export DISPLAY="${DISPLAY:-:0}"
export XAUTHORITY="${XAUTHORITY:-$HOME/.Xauthority}"

# Detectar entorno
if [ "$XDG_SESSION_TYPE" = "wayland" ]; then
    # Para Wayland, usamos kwin_wayland si está disponible
    if command -v kwin_wayland >/dev/null 2>&1; then
        # Crear una ventana sin decoración usando kwin_wayland
        # y ejecutar plymouth dentro de ella
        kwin_wayland --xwayland --width $PLYMOUTH_WIDTH --height $PLYMOUTH_HEIGHT \
            --no-kactivities --no-global-shortcuts --virtual \
            --exit-with-session "plymouthd --mode=boot --no-daemon && plymouth show-splash && sleep 5"
    else
        # Si no hay kwin_wayland, usar método estándar
        plymouthd --mode=boot --no-daemon
        plymouth show-splash
        sleep 5
    fi
else
    # Para X11, intentar usar directamente xvfb o una ventana sin decoración
    if command -v xvfb-run >/dev/null 2>&1; then
        # Usar Xvfb para crear un framebuffer virtual sin decoración
        xvfb-run -a -s "-screen 0 ${PLYMOUTH_WIDTH}x${PLYMOUTH_HEIGHT}x24" \
            bash -c "plymouthd --mode=boot --no-daemon && plymouth show-splash && sleep 5"
    else
        # Último recurso: usar plymouthd directamente con parámetros especiales
        plymouthd --mode=boot --tty=current --framebuffer-width=$PLYMOUTH_WIDTH \
            --framebuffer-height=$PLYMOUTH_HEIGHT --fullscreen
        plymouth show-splash
        sleep 5
    fi
fi
"""
    
    fd, script_path = tempfile.mkstemp(suffix='.sh')
    with os.fdopen(fd, 'w') as f:
        f.write(content)
    os.chmod(script_path, 0o755)
    return script_path

def capture_plymouth_theme(output_path=None):
    try:
        # Si no se especifica ruta, usar la del tema actual
        if not output_path:
            current_theme = get_current_theme()
            if (current_theme):
                theme_dir = f"/usr/share/plymouth/themes/{current_theme}"
                output_path = os.path.join(theme_dir, "preview.png")
            else:
                output_path = '/tmp/plymouth-capture.png'

        # Si ya existe el archivo, eliminarlo primero
        if os.path.exists(output_path):
            os.remove(output_path)
            
        # Forzar terminación de Plymouth antes de empezar
        subprocess.run(['plymouth', 'quit'], check=False)
        subprocess.run(['plymouthd', '--quit'], check=False)
        subprocess.run(['pkill', '-9', 'plymouth'], check=False)
        subprocess.run(['pkill', '-9', 'plymouthd'], check=False)
        time.sleep(1)  # Esperar a que se detengan los procesos

        # Detectar si estamos en X11 o Wayland
        session_type = os.environ.get('XDG_SESSION_TYPE', '').lower()
        
        # Obtener la resolución de la pantalla
        width, height = get_screen_resolution()
        print(f"Usando resolución: {width}x{height}")
        
        # Configurar variables de entorno para forzar pantalla completa
        env = os.environ.copy()
        env['PLYMOUTH_FULLSCREEN'] = '1'
        env['PLYMOUTH_WIDTH'] = str(width)
        env['PLYMOUTH_HEIGHT'] = str(height)
        env['PLYMOUTH_NO_DECORATIONS'] = '1'  # Nueva variable para indicar sin decoración
        
        # Usar un enfoque específico para cada entorno
        if session_type == 'wayland':
            # Método para Wayland: crear un script especial
            script_path = create_undecorated_window_script()
            
            # Ejecutar el script para mostrar Plymouth sin bordes
            subprocess.run(['bash', script_path], env=env, check=True)
            
            # Esperar a que Plymouth esté completamente cargado
            time.sleep(3)
            
            # Intentar métodos alternativos para capturar en Wayland
            captured = False
            
            # Método 1: grim directamente
            try:
                print("Intentando captura con grim...")
                # Usar parámetros específicos para capturar toda la pantalla
                subprocess.run(['grim', '-o', 'eDP-1', output_path], env=env, check=True)
                
                # Verificar si la captura fue exitosa
                if os.path.exists(output_path) and os.path.getsize(output_path) > 10000:
                    captured = True
                    print("Captura exitosa con grim")
            except Exception as e:
                print(f"Error con grim: {e}")
            
            # Método 2: slurp + grim si está disponible y el método anterior falló
            if not captured and shutil.which('slurp'):
                try:
                    print("Intentando captura con slurp + grim...")
                    # Guardar el área de toda la pantalla en una variable
                    area = subprocess.check_output(['slurp', '-o'], text=True).strip()
                    subprocess.run(['grim', '-g', area, output_path], env=env, check=True)
                    
                    if os.path.exists(output_path) and os.path.getsize(output_path) > 10000:
                        captured = True
                        print("Captura exitosa con slurp + grim")
                except Exception as e:
                    print(f"Error con slurp + grim: {e}")
            
            # Método 3: wl-screenshot si está disponible y los anteriores fallaron
            if not captured and shutil.which('wl-screenshot'):
                try:
                    print("Intentando captura con wl-screenshot...")
                    subprocess.run(['wl-screenshot', '-f', output_path], env=env, check=True)
                    
                    if os.path.exists(output_path) and os.path.getsize(output_path) > 10000:
                        captured = True
                        print("Captura exitosa con wl-screenshot")
                except Exception as e:
                    print(f"Error con wl-screenshot: {e}")

            # Último recurso: intentar método genérico con grim
            if not captured:
                try:
                    print("Intentando último método con grim...")
                    subprocess.run(['grim', output_path], env=env, check=False)
                except:
                    pass
                    
            # Limpiar script temporal
            try:
                os.unlink(script_path)
            except:
                pass
        else:
            # Método para X11: usar parámetros especiales para plymouthd
            subprocess.run([
                'plymouthd',
                '--mode=boot',
                '--tty=current',
                f'--framebuffer-width={width}',
                f'--framebuffer-height={height}',
                '--fullscreen',
                '--no-daemon'  # Evitar modo demonio para mantener en primer plano
            ], env=env, check=True)
            
            subprocess.run(['plymouth', 'show-splash', '--retain-splash'], env=env, check=True)
            
            # Esperar a que Plymouth se cargue completamente
            time.sleep(3)
            
            # Capturar con scrot usando opciones para maximizar probabilidad de éxito
            try:
                # -z: sin ratón, -o: sobreescribir, -f: forzar, -u: ventana activa, -D: retraso
                subprocess.run(['scrot', '-z', '-o', '-f', '-u', '-D', '2', output_path], check=True)
                print("Captura realizada con scrot -u (ventana actual)")
            except Exception as e:
                print(f"Error en captura con scrot -u: {e}")
                try:
                    # Intentar capturar toda la pantalla si falló la ventana activa
                    subprocess.run(['scrot', '-z', '-o', '-f', output_path], check=False)
                    print("Captura realizada con scrot (pantalla completa)")
                except Exception as e2:
                    print(f"Error en captura con scrot: {e2}")
        
        # Verificar si la captura fue exitosa
        if os.path.exists(output_path):
            if os.path.getsize(output_path) > 5000:  # Asegurar que no sea una imagen vacía
                print(f"Captura exitosa guardada en: {output_path}")
                return True
            else:
                print("La captura parece vacía o demasiado pequeña")
                
        # Si llegamos aquí, la captura no fue exitosa
        return False
        
    finally:
        # Asegurar que Plymouth se detenga siempre
        try:
            subprocess.run(['plymouth', 'quit'], check=False)
            subprocess.run(['plymouthd', '--quit'], check=False)
            subprocess.run(['pkill', '-9', 'plymouth'], check=False)
            subprocess.run(['pkill', '-9', 'plymouthd'], check=False)
            time.sleep(1)  # Esperar a que terminen los procesos
        except:
            pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Captura el tema actual de Plymouth')
    parser.add_argument('--output', '-o', 
                      help='Ruta donde guardar la captura (opcional)')
    
    args = parser.parse_args()
    check_root()
    check_dependencies()
    result = capture_plymouth_theme(args.output)
    if not result:
        print("ADVERTENCIA: Posible error en la captura. Verifique la imagen resultante.")
