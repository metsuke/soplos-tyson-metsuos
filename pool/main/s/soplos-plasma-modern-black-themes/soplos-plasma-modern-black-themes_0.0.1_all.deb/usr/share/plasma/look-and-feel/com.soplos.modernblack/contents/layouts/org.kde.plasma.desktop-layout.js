// KDE Plasma 6 layout configuration script para Soplos Modern Black
// Layout universal adaptable a cualquier resolución

var desktopsArray = desktopsForActivity(currentActivity());
var desktop = desktopsArray[0];

// === ELIMINAR TODOS LOS PANELES EXISTENTES ANTES DE CREAR NUEVOS ===
while (panelIds.length > 0) {
    var panel = panelById(panelIds[0]);
    if (panel) {
        panel.remove();
    }
}

// === CONFIGURACIÓN DEL TEMA ===
// Configurar el tema específico Modern Black
desktop.currentConfigGroup = ["Theme"];
desktop.writeConfig("name", "soplos-black");

// Configurar el esquema de color
var colorSchemeConfig = ConfigFile("kdeglobals");
colorSchemeConfig.group = "General";
colorSchemeConfig.writeEntry("ColorScheme", "SoplosClassicDark");
colorSchemeConfig.group = "KDE";
colorSchemeConfig.writeEntry("ColorScheme", "SoplosClassicDark");

// === CONFIGURACIÓN DEL ESCRITORIO ===
desktop.wallpaperPlugin = "org.kde.image";
desktop.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
desktop.writeConfig("Image", "file:///usr/share/wallpapers/soplos/006.jpg");

// Configuración para iconos del escritorio - SOLUCIÓN DEFINITIVA
desktop.currentConfigGroup = ["General"];
desktop.writeConfig("arrangement", 1);  // Organización vertical
desktop.writeConfig("iconSize", 2);     // Tamaño de iconos
desktop.writeConfig("sortMode", -1);    // Ordenación manual - CRÍTICO PARA POSICIONES PERSONALIZADAS

// Crear múltiples configuraciones de posicionamiento para distintas resoluciones comunes
var iconPositions = {};

// Resoluciones comunes
var resolutions = ["1366x768", "1440x900", "1600x900", "1680x1050", "1920x1080", "2560x1440", "3840x2160"];

// Para cada resolución, definimos el mismo orden de iconos
resolutions.forEach(function(resolution) {
    iconPositions[resolution] = [
        "1", "9",  // Parámetros de cuadrícula
        "desktop:/home.desktop", "0", "0",          // Carpeta personal primero
        "desktop:/trash:⁄.desktop", "0", "1",       // Papelera segundo
        "desktop:/calamares-install-soplos.desktop", "0", "2"  // Instalador tercero
    ];
});

// Aplicar configuración
desktop.writeConfig("positions", JSON.stringify(iconPositions));

// === CONFIGURACIÓN DE ACCIONES DEL RATÓN ===
desktop.currentConfigGroup = ["ActionPlugins", "0"];
desktop.writeConfig("MiddleButton;NoModifier", "org.kde.paste");
desktop.writeConfig("RightButton;NoModifier", "org.kde.contextmenu");

desktop.currentConfigGroup = ["ActionPlugins", "1"];
desktop.writeConfig("RightButton;NoModifier", "org.kde.contextmenu");

// === PANEL SUPERIOR ===
var panelTop = new Panel;
panelTop.location = "top";
panelTop.height = 36;
panelTop.hiding = "none";

// Configurar tema del panel
panelTop.currentConfigGroup = ["Configuration"];
panelTop.writeConfig("theme", "soplos-black");

// Añadir widgets en orden
var kickoff = panelTop.addWidget("org.kde.plasma.kickoff");
kickoff.currentConfigGroup = ["Configuration", "General"];
kickoff.writeConfig("favoritesPortedToKAstats", true);
kickoff.writeConfig("icon", "/usr/share/branding-soplos/soplos/menusoplos.png");
kickoff.writeConfig("switchCategoryOnHover", true);
kickoff.writeConfig("alphaSort", true); // AÑADIR: Ordenación alfabética

panelTop.addWidget("org.kde.plasma.pager");
panelTop.addWidget("org.kde.plasma.marginsseparator");
panelTop.addWidget("org.kde.plasma.panelspacer");
var systray = panelTop.addWidget("org.kde.plasma.systemtray");
panelTop.addWidget("org.kde.plasma.digitalclock");
panelTop.addWidget("org.kde.plasma.showdesktop");

// Configuración de la bandeja del sistema
var systrayId = systray.readConfig("SystrayContainmentId");
if (systrayId) {
    var systrayContainer = desktopById(systrayId);
    if (systrayContainer) {
        systrayContainer.currentConfigGroup = ["General"];
        systrayContainer.writeConfig("extraItems", "org.kde.plasma.brightness,org.kde.plasma.vault,org.kde.plasma.devicenotifier,org.kde.plasma.battery,org.kde.plasma.cameraindicator,org.kde.plasma.bluetooth,org.kde.plasma.keyboardindicator,org.kde.kdeconnect,org.kde.plasma.networkmanagement,org.kde.plasma.keyboardlayout,org.kde.kupapplet,org.kde.plasma.manage-inputmethod,org.kde.plasma.printmanager,org.kde.kscreen,org.kde.plasma.volume,org.kde.plasma.mediacontroller,org.kde.plasma.clipboard,org.kde.plasma.notifications");
        systrayContainer.writeConfig("knownItems", "org.kde.plasma.brightness,org.kde.plasma.vault,org.kde.plasma.devicenotifier,org.kde.plasma.battery,org.kde.plasma.cameraindicator,org.kde.plasma.bluetooth,org.kde.plasma.keyboardindicator,org.kde.kdeconnect,org.kde.plasma.networkmanagement,org.kde.plasma.keyboardlayout,org.kde.kupapplet,org.kde.plasma.manage-inputmethod,org.kde.plasma.printmanager,org.kde.kscreen,org.kde.plasma.volume,org.kde.plasma.mediacontroller,org.kde.plasma.clipboard,org.kde.plasma.notifications");
    }
}

// === PANEL INFERIOR (DOCK) ===
var panelBottom = new Panel;
panelBottom.location = "bottom";
panelBottom.height = 54;
panelBottom.formfactor = 2;
panelBottom.immutability = 1;

// Configurar tema del panel inferior
panelBottom.currentConfigGroup = ["Configuration"];
panelBottom.writeConfig("theme", "soplos-black");

// Configuración básica
panelBottom.alignment = "center";
panelBottom.hiding = "dodgewindows";  // CAMBIO AQUÍ: de "windowsGoBelow" a "dodgewindows"
panelBottom.floating = true;
panelBottom.lengthMode = "fit"; // Ajustarse al contenido

// Añadir widgets en orden
panelBottom.addWidget("org.kde.plasma.showdesktop");
panelBottom.addWidget("org.kde.plasma.marginsseparator");

// Configurar el widget icontasks correctamente para funcionar como dock
var icontasks = panelBottom.addWidget("org.kde.plasma.icontasks");

// Configuración detallada del widget de tareas
icontasks.currentConfigGroup = ["General"];

// === SOLO ESTABLECER LAUNCHERS SI NO EXISTEN ===
var currentLaunchers = icontasks.readConfig("launchers");
if (!currentLaunchers || currentLaunchers.length === 0) {
    var defaultLaunchers = [
        "applications:firefox.desktop",
        "applications:org.kde.dolphin.desktop",
        "applications:org.kde.discover.desktop",
        "applications:systemsettings.desktop",
        "applications:org.kde.konsole.desktop"
    ];
    icontasks.writeConfig("launchers", defaultLaunchers);
}

// === FUNCIÓN PARA PRESERVAR TEMA Y WALLPAPER ===
function preserveThemeAndWallpaper() {
    // Forzar wallpaper en todos los escritorios
    var desktopsArray = desktopsForActivity(currentActivity());
    for (var d = 0; d < desktopsArray.length; d++) {
        var desktop = desktopsArray[d];
        desktop.wallpaperPlugin = "org.kde.image";
        desktop.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
        desktop.writeConfig("Image", "file:///usr/share/wallpapers/soplos/006.jpg");
        desktop.writeConfig("PreviewImage", "file:///usr/share/wallpapers/soplos/006.jpg");
        desktop.writeConfig("FillMode", "2");
        desktop.reloadConfig();
    }

    // Forzar tema en todos los paneles
    var allPanels = panelIds;
    for (var p = 0; p < allPanels.length; p++) {
        var panel = panelById(allPanels[p]);
        if (panel) {
            panel.currentConfigGroup = ["Configuration"];
            panel.writeConfig("theme", "soplos-black");
            panel.reloadConfig();
        }
    }

    // Aplicar tema global
    var themeConfig = ConfigFile("plasmarc");
    themeConfig.group = "Theme";
    themeConfig.writeEntry("name", "soplos-black");
    themeConfig.sync();

    var colorSchemeConfig = ConfigFile("kdeglobals");
    colorSchemeConfig.group = "General";
    colorSchemeConfig.writeEntry("ColorScheme", "SoplosClassicDark");
    colorSchemeConfig.group = "KDE";
    colorSchemeConfig.writeEntry("ColorScheme", "SoplosClassicDark");
    colorSchemeConfig.sync();

    // Configurar lockscreen (KScreenLocker)
    var lockscreenConfig = ConfigFile("kscreenlockerrc");
    lockscreenConfig.group = "Greeter";
    lockscreenConfig.writeEntry("WallpaperPlugin", "org.kde.image");

    lockscreenConfig.group = "Greeter";
    lockscreenConfig.group = "Wallpaper";
    lockscreenConfig.group = "org.kde.image";
    lockscreenConfig.group = "General";
    lockscreenConfig.writeEntry("Image", "/usr/share/wallpapers/soplos/006.jpg");
    lockscreenConfig.writeEntry("PreviewImage", "/usr/share/wallpapers/soplos/006.jpg");
    lockscreenConfig.writeEntry("FillMode", "2");
    lockscreenConfig.writeEntry("SlidePaths", "/usr/share/wallpapers/soplos/");
    lockscreenConfig.sync();
}

// Preservar tema después de cambios en launchers
preserveThemeAndWallpaper();

// Configuraciones esenciales para comportamiento de dock
icontasks.currentConfigGroup = ["Configuration", "General"];
// Opciones para agrupación y visualización
icontasks.writeConfig("groupingStrategy", "0"); // 0 = No agrupar
icontasks.writeConfig("groupedTaskVisualization", "1"); // 1 = Por tarea
icontasks.writeConfig("maxStripes", 1); // Solo una fila
icontasks.writeConfig("showOnlyCurrentDesktop", false); // Mostrar todas las ventanas
icontasks.writeConfig("showOnlyCurrentScreen", false); // Mostrar de todas las pantallas
icontasks.writeConfig("showToolTips", true); // Mostrar tooltips
icontasks.writeConfig("wheelEnabled", true); // Habilitar rueda del ratón

// El resto del panel
panelBottom.addWidget("org.kde.plasma.marginsseparator");
panelBottom.addWidget("org.kde.milou");
panelBottom.addWidget("org.kde.plasma.trash");

// Definir el orden de los applets
panelBottom.currentConfigGroup = ["General"];
panelBottom.writeConfig("AppletOrder", "org.kde.plasma.showdesktop,org.kde.plasma.marginsseparator,org.kde.plasma.icontasks,org.kde.plasma.marginsseparator,org.kde.milou,org.kde.plasma.trash");

// === FORZAR APLICACIÓN DEL TEMA ===
// Ejecutar preservación final
preserveThemeAndWallpaper();

// Aplicar cambios inmediatamente con delay para persistencia
desktop.reloadConfig();
panelTop.reloadConfig();
panelBottom.reloadConfig();

// Preservación final con delay
setTimeout(function() {
    preserveThemeAndWallpaper();
}, 1000);
icontasks.writeConfig("showToolTips", true); // Mostrar tooltips
icontasks.writeConfig("wheelEnabled", true); // Habilitar rueda del ratón

// El resto del panel
panelBottom.addWidget("org.kde.plasma.marginsseparator");
panelBottom.addWidget("org.kde.milou");
panelBottom.addWidget("org.kde.plasma.trash");

// Definir el orden de los applets
panelBottom.currentConfigGroup = ["General"];
panelBottom.writeConfig("AppletOrder", "org.kde.plasma.showdesktop,org.kde.plasma.marginsseparator,org.kde.plasma.icontasks,org.kde.plasma.marginsseparator,org.kde.milou,org.kde.plasma.trash");

// === FORZAR APLICACIÓN DEL TEMA ===
// Ejecutar preservación final
preserveThemeAndWallpaper();

// Aplicar cambios inmediatamente con delay para persistencia
desktop.reloadConfig();
panelTop.reloadConfig();
panelBottom.reloadConfig();

// Preservación final con delay
setTimeout(function() {
    preserveThemeAndWallpaper();
}, 1000);
