# Changelog

## v1.0.7 (07/10/2025)
### Added
- Soporte completo para subvolúmenes btrfs en la recuperación CHROOT

### Removed
- Eliminación completa de NumLockX

### Fixed
- Corrección y revisión de todas las cadenas de texto de los diccionarios

## v1.0.6 (06/24/2025)
### Added
- Now visible in Discover (AppStream integration)

## v1.0.5 (06/20/2025)
### Added
- Complete program internationalization
- Label refinement to English for better consistency

### Fixed
- Minor bug fixes
- General stability improvements

### Changed
- User interface optimizations
- Performance improvements

## v1.0.4 (Intermediate version)
### Fixed
- Minor interface fixes
- Improved stability

## v1.0.3 (01/27/2024)
### Added
- Initial release version
- Software Center integration
- Driver management
- System customization tools
- Recommended software installation
- Multi-language support (8 languages)
- Hardware detection and configuration
- Locale and keyboard layout configuration
- CHROOT recovery tools
- GParted integration for disk management
- Autostart control for welcome screen
- NumLock activation toggle
