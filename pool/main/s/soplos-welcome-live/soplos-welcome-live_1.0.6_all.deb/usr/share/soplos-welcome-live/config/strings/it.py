STRINGS_IT = {
    'welcome': 'Soplos Linux',
    'welcome_desc': 'La distribuzione Linux fatta per te!',
    'version': 'Tyron Live 2023.2',
    'buttons': {
        'exit': '_Uscire',
        'website': 'Sito Web',
        'forums': 'Forum',
        'wiki': 'Wiki',
        'donate': 'Donare',
        'install': 'Installa Soplos _Linux',
        'chroot': 'Recupera sistema con _CHROOT',
        'open_gparted': 'Apri _GParted',
        'close': '_Chiudi',
        'next': '_Avanti',
        'cancel': '_Annulla',
        'mount': '_Monta'
    },
    'dialog': {
        'exit_title': 'Sei sicuro di voler uscire?',
        'exit_desc': 'Il programma di benvenuto verrà chiuso.',
        'error': 'Errore',
        'select_disk': 'Per favore, seleziona un disco',
        'select_root': 'Devi selezionare una partizione root (/)',
        'no_partitions': 'Nessuna partizione trovata su questo disco',
        'partition_header': 'Seleziona le partizioni da montare:',
        'mounting': 'Montaggio partizioni',
        'invalid_partition': 'Partizione non valida',
        'invalid_partition_desc': 'La partizione selezionata non contiene un sistema Linux valido o è danneggiata.',
        'mount_error': 'Errore di montaggio',
        'mount_error_desc': 'Non è stato possibile montare le partizioni selezionate.'
    },
    'locale': {
        'error_generating': 'Errore durante la generazione delle locali:',
        'error_updating': 'Errore durante l\'impostazione della locale predefinita:',
        'error_restart': 'Errore durante il riavvio di SDDM',
        'not_found_locale_gen': 'Comando locale-gen non trovato.\nInstallare il pacchetto locales.',
        'not_found_update_locale': 'update-locale non trovato',
        'restart_session_title': 'Modifiche applicate',
        'restart_session_desc': 'Perché tutte le modifiche abbiano effetto completo, si consiglia di disconnettersi e riconnettersi.'
    },
    'chroot': {
        'title': 'Recupero CHROOT',
        'select_disk': 'Seleziona il disco di sistema',
        'open_gparted': 'Apri GParted',
        'select_partitions': 'Seleziona partizioni',
        'mount': 'Monta',
        'cancel': 'Annulla',
        'terminal_title': 'Ambiente di Recupero CHROOT Soplos Linux',
        'welcome_message': 'Sei entrato in un ambiente chroot per recuperare il tuo sistema.',
        'instructions': 'Puoi eseguire comandi come aggiornamenti, reinstallare\nil gestore di avvio o qualsiasi altra riparazione.',
        'exit_message': 'Per uscire dall\'ambiente chroot, scrivi \'exit\' o premi Ctrl+D.',
        'mounting_partitions': 'Montaggio partizioni...',
        'mounting_root': 'Montaggio partizione radice',
        'mounting_boot': 'Montaggio partizione /boot',
        'mounting_efi': 'Montaggio partizione EFI',
        'mounting_virtual': 'Montaggio sistemi di file virtuali',
        'exit_chroot': 'Sei uscito dall\'ambiente chroot.',
        'unmounting': 'Smontaggio',
        'unmount_complete': 'Tutte le partizioni sono state smontate correttamente.',
        'cleanup_question': 'Vuoi rimuovere la directory di montaggio {}? [s/N]: ',
        'process_complete': 'Processo chroot completato.',
        'chroot_started': 'Chroot avviato con successo',
        'mounting_content': 'Contenuto del punto di montaggio:',
        'using_shell': 'Usando shell:',
        'starting_chroot': 'Avvio ambiente chroot...',
        'mount_point_label': 'Punto di montaggio',
        'root_partition_label': 'Partizione radice',
        'creating_dirs': 'Creazione directory per bind mount',
        'creating_boot_dir': 'Creazione directory /boot',
        'creating_efi_dir': 'Creazione directory /boot/efi',
        'bin_content': 'Contenuto di /bin',
        'usr_bin_content': 'Contenuto di /usr/bin',
        'still_mounted': 'Sistemi di file ancora montati',
        'mount_boot_error': 'ERROR: Impossibile montare {} in {}/boot',
        'mount_efi_error': 'ERROR: Impossibile montare {} in {}/boot/efi'
    },
    'autostart': 'Mostra all\'avvio:',
    'labels': {
        'language': 'Lingua:',
        'show_startup': 'Mostra all\'avvio:',
        'device': 'Dispositivo',
        'size': 'Dimensione',
        'model': 'Modello',
        'filesystem': 'File system',
        'mountpoint': 'Punto di montaggio',
        'select_option': '-- Seleziona --',
        'unknown': 'Sconosciuto'
    },
    'live_iso': {
        'title': 'Live ISO',
        'description': 'Questa versione Live ti permette di provare Soplos Linux\nsenza installare nulla sul tuo computer.\nQuando sei pronto, usa il pulsante arancione per installarlo.'
    },
    'thanks': 'Grazie per aver provato Soplos Linux!',
    'messages': {
        'selected_disk': 'Disco selezionato: {}',
        'error_loading_disks': 'Errore durante il caricamento dei dischi',
        'error_loading_partitions': 'Errore durante l\'ottenimento delle partizioni',
        'error_mounting': 'Errore durante il montaggio delle partizioni',
        'error_unmounting': 'Errore durante lo smontaggio del sistema',
        'mount_point_error': 'ERROR: Impossibile creare il punto di montaggio',
        'mount_root_error': 'ERROR: Impossibile montare',
        'in': 'in',
        'completed': 'completato',
        'mount_dev_error': 'ERROR: Impossibile montare /dev in',
        'mount_proc_error': 'ERROR: Impossibile montare /proc in',
        'mount_sys_error': 'ERROR: Impossibile montare /sys in',
        'mount_pts_error': 'ERROR: Impossibile montare /dev/pts in',
        'resolv_copy_error': 'Impossibile copiare resolv.conf',
        'no_shell_error': 'ERROR: Nessuna shell valida trovata nel sistema montato',
        'unmount_warning': 'ATTENZIONE: Alcuni punti di montaggio non sono stati smontati.',
        'restart_needed': 'Potrebbe essere necessario riavviare il sistema per liberare queste risorse.',
        'directory_removed': 'Directory rimossa',
        'directory_remove_error': 'Impossibile rimuovere',
        'directory_kept': 'Directory mantenuta',
        'mount_point_missing': 'ERROR: Il punto di montaggio non esiste',
        'shell_not_found': 'ERROR: Nessuna shell valida trovata nel sistema montato',
        'lsblk_error': 'Errore durante l\'esecuzione di lsblk',
        'gparted_error': 'Errore durante l\'esecuzione di GParted',
        'mount_result': 'Risultato del montaggio:',
        'konsole_error': 'Errore durante l\'avvio di konsole',
        'xterm_error': 'Errore durante l\'avvio di xterm',
        'first_start_detected': 'Primo avvio rilevato, saltando verifica riavvio',
        'first_start_error': 'Errore nel segnare il primo avvio: {}',
        'restart_detected': 'Riavvio rilevato per cambio lingua, applicando configurazione...',
        'keyboard_config_warning': 'Avviso: Impossibile applicare configurazione tastiera/locale',
        'restarting_session': 'Riavvio sessione...',
        'restarting_sddm': 'Riavvio SDDM per applicare i cambiamenti di lingua...',
        'icon_error': 'Errore nell\'impostare l\'icona: {}',
        'desktop_info': 'Ambiente desktop: {}, Tipo di sessione: {}',
        'logo_error': 'Errore nel caricamento del logo: {}',
        'locale_config_error': 'Errore nella configurazione della locale di sistema',
        'robust_locale_error': 'Errore nella configurazione robusta della locale',
        'robust_autologin_error': 'Errore nella configurazione dell\'autologin robusto',
        'restarting_sddm_script': 'Riavvio di SDDM per applicare i cambiamenti di lingua...',
        'robust_restart_error': 'Errore nel riavvio robusto',
        'sddm_config_error': 'Errore nella modifica di /etc/sddm.conf',
        'kde_command_error': 'Errore nell\'esecuzione di {}: {}',
        'kde_config_error': 'Errore nel ricaricamento della configurazione KDE',
        'app_title': 'Soplos Welcome Live',
        'autostart_create_error': 'Errore: Impossibile creare il file di avvio automatico',
        'autostart_enable_error': 'Errore durante l\'attivazione dell\'avvio automatico: {}',
        'autostart_enabled': 'Avvio automatico abilitato: {} -> {}',
        'desktop_file_not_found': 'Errore: File .desktop non trovato in nessuna posizione nota',
        'basic_desktop_created': 'Creato file desktop di base come backup',
        'basic_desktop_error': 'Errore nella creazione del file desktop di base: {}',
        # New messages for desktop_detector.py
        'wayland_session': 'Sessione rilevata: Wayland',
        'x11_session': 'Sessione rilevata: X11',
        'unknown_session': 'Impossibile determinare il tipo di sessione, utilizzo di X11 come predefinito',
        'autologin_check_error': 'Errore durante il controllo dell\'autologin: {}',
        'autologin_found': 'Autologin trovato in {file_path} per l\'utente: {user}',
        'autologin_file_error': 'Errore durante la lettura di {file_path}: {error}',
        'kde_restore_error': 'Errore durante il ripristino della configurazione KDE: {}',
        'kde_backup_error': 'Errore durante il backup della configurazione KDE: {}',
        'backed_up': 'Backup di {src} -> {dst} completato',
        'restored': 'Ripristinato {src} -> {dst}'
    },
    'progress': {
        'configuring': 'Configurazione lingua...'
    },
    'commands': {
        'gparted': 'sudo gparted',
        'calamares_sudo': 'sudo',
        'calamares': 'calamares'
    },
    'errors': {
        'slide_load': 'Errore durante il caricamento della diapositiva',
        'language_config': 'Errore durante la configurazione della lingua'
    },
    'system': {
        'xorg_conf_dir': '/etc/X11/xorg.conf.d',
        'keyboard_conf_file': '/etc/X11/xorg.conf.d/00-keyboard.conf',
        'xorg_keyboard_template': """Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection"""
    },
    'templates': {
        'basic_desktop_file': """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Schermata di benvenuto per l'ambiente Live di Soplos Linux
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
"""
    },
    'session_manager': {
        'using_temp_dir': 'Utilizzo directory temporanea per la configurazione: {}',
        'error_creating_config_dir': 'Errore durante la creazione della directory di configurazione: {}',
        'first_run_marked': 'Primo avvio contrassegnato - il riavvio automatico verrà evitato',
        'error_first_run_marker': 'Errore durante la creazione del marcatore di primo avvio: {}',
        'error_configuring_autologin': 'Errore: Impossibile configurare l\'autologin',
        'saving_autostart_state': 'Salvataggio dello stato di avvio automatico abilitato per il ripristino dopo il riavvio',
        'restart_request_created': 'File di richiesta di riavvio creato con successo',
        'error_creating_restart_file': 'Errore durante la creazione del file di richiesta di riavvio: {}',
        'executing_sddm_restart': 'Esecuzione del riavvio di SDDM nella sessione {}...',
        'critical_sddm_restart_error': 'Errore critico durante il riavvio di SDDM: {}',
        'copying_dir': 'Copia della directory {} in {}',
        'error_reloading_kde': 'Errore durante il ricaricamento della configurazione KDE: {}',
        'error_restoring_theme': 'Errore durante il ripristino del tema da skel: {}',
        'error_configuring_locale': 'Errore durante la configurazione della locale di sistema: {}',
        # New strings added
        'no_restart_request': 'Nessuna richiesta esplicita di riavvio, evitando il riavvio automatico',
        'restoring_autostart': 'Ripristino dell\'avvio automatico dopo il riavvio...',
        'error_tmp_state': 'Errore durante il controllo dello stato in /tmp: {}',
        'locale_mismatch': 'La locale corrente ({}) non corrisponde a quella salvata ({})',
        'error_verifying_locale': 'Errore durante la verifica dell\'applicazione della locale: {}',
        'skel_dir_missing': 'La directory {} non esiste',
        'timeout_warning': 'Lo script di configurazione ha impiegato troppo tempo, ma potrebbe aver funzionato',
        'error_ensuring_autologin': 'Errore durante la configurazione dell\'autologin: {}'
    },
    'xdg': {
        'updating_directories': 'Aggiornamento delle directory XDG per locale: {}',
        'backup_created': 'Backup di user-dirs.dirs creato',
        'file_deleted': 'File user-dirs.dirs eliminato per rigenerazione',
        'running_update': 'Esecuzione di xdg-user-dirs-update --force...',
        'result': 'Risultato: {}',
        'errors': 'Errori: {}',
        'not_created': 'Errore: user-dirs.dirs non è stato creato',
        'restored_backup': 'Ripristinato dal backup',
        'updating_gtk': 'Aggiornamento della configurazione GTK...',
        'updating_references': 'Aggiornamento dei riferimenti delle directory nell\'ambiente desktop...',
        'file_content': 'Contenuto di user-dirs.dirs:\n{}',
        'error_updating': 'Errore durante l\'aggiornamento delle directory XDG: {}',
        'renaming_directories': 'Rinominazione delle directory per la lingua: {}',
        'no_mapping': 'Nessuna mappatura delle directory per la lingua: {}',
        'both_exist': 'Entrambe le directory esistono. Migrazione del contenuto: {} → {}',
        'content_migrated': 'Contenuto migrato e directory {} eliminata',
        'error_consolidating': 'Errore durante il consolidamento delle directory: {}',
        'renaming': 'Rinominazione: {} → {}',
        'error_renaming': 'Errore durante la rinominazione di {}: {}',
        'destination_exists': 'La directory di destinazione {} esiste già, rimane',
        'neither_exists': 'Nessuna directory exists: {} né {}',  
        'general_error': 'Errore generale nella rinominazione delle directory: {}',
        'error_kde_references': 'Errore durante l\'aggiornamento dei riferimenti KDE: {}',
        'generating_config': 'Generazione configurazione XDG per locale: {}',
        'config_generated': 'Configurazione XDG generata in: {}',
        'error_generating_config': 'Errore durante la generazione della configurazione XDG: {}'
    }
}
