STRINGS_PT = {
    'welcome': 'Soplos Linux',
    'welcome_desc': 'A distribuição Linux feita para você!',
    'version': 'Tyron Live 2023.2',
    'buttons': {
        'exit': '_Sair',
        'website': 'Site',
        'forums': 'Fóruns',
        'wiki': 'Wiki',
        'donate': 'Doar',
        'install': 'Instalar Soplos _Linux',
        'chroot': 'Recuperar sistema com _CHROOT',
        'open_gparted': 'Abrir _GParted',
        'close': '_Fechar',
        'next': '_Próximo',
        'cancel': '_Cancelar',
        'mount': '_Montar'
    },
    'dialog': {
        'exit_title': 'Tem certeza que deseja sair?',
        'exit_desc': 'O programa de boas-vindas será fechado.',
        'error': 'Erro',
        'select_disk': 'Por favor, selecione um disco',
        'select_root': 'Você deve selecionar uma partição raiz (/)',
        'no_partitions': 'Nenhuma partição encontrada neste disco',
        'partition_header': 'Selecione as partições a serem montadas:',
        'mounting': 'Montando partições',
        'invalid_partition': 'Partição não válida',
        'invalid_partition_desc': 'A partição selecionada não contém um sistema Linux válido ou está danificada.',
        'mount_error': 'Erro de montagem',
        'mount_error_desc': 'Não foi possível montar as partições selecionadas.'
    },
    'locale': {
        'error_generating': 'Erro ao gerar locales:',
        'error_updating': 'Erro ao definir o locale padrão:',
        'error_restart': 'Erro ao reiniciar o SDDM',
        'not_found_locale_gen': 'Comando locale-gen não encontrado.\nPor favor, instale o pacote locales.',
        'not_found_update_locale': 'update-locale não encontrado',
        'restart_session_title': 'Alterações aplicadas',
        'restart_session_desc': 'Para que todas as alterações tenham efeito total, é recomendável sair e entrar novamente.'
    },
    'chroot': {
        'title': 'Recuperação CHROOT',
        'select_disk': 'Selecione o disco do sistema',
        'open_gparted': 'Abrir GParted',
        'select_partitions': 'Selecionar partições',
        'mount': 'Montar',
        'cancel': 'Cancelar',
        'terminal_title': 'Ambiente de Recuperação CHROOT Soplos Linux',
        'welcome_message': 'Você entrou em um ambiente chroot para recuperar seu sistema.',
        'instructions': 'Você pode executar comandos como atualizações, reinstalar\no gerenciador de inicialização ou qualquer outro reparo.',
        'exit_message': 'Para sair do ambiente chroot, digite \'exit\' ou pressione Ctrl+D.',
        'mounting_partitions': 'Montando partições...',
        'mounting_root': 'Montando partição raiz',
        'mounting_boot': 'Montando partição /boot',
        'mounting_efi': 'Montando partição EFI',
        'mounting_virtual': 'Montando sistemas de arquivos virtuais',
        'exit_chroot': 'Você saiu do ambiente chroot.',
        'unmounting': 'Desmontando',
        'unmount_complete': 'Todas as partições foram desmontadas corretamente.',
        'cleanup_question': 'Deseja remover o diretório de montagem {}? [s/N]: ',
        'process_complete': 'Processo de chroot concluído.',
        'chroot_started': 'Chroot iniciado com sucesso',
        'mounting_content': 'Conteúdo do ponto de montagem:',
        'using_shell': 'Usando shell:',
        'starting_chroot': 'Iniciando ambiente chroot...',
        'mount_point_label': 'Ponto de montagem',
        'root_partition_label': 'Partição raiz',
        'creating_dirs': 'Criando diretórios para bind mounts',
        'creating_boot_dir': 'Criando diretório /boot',
        'creating_efi_dir': 'Criando diretório /boot/efi',
        'bin_content': 'Conteúdo de /bin',
        'usr_bin_content': 'Conteúdo de /usr/bin',
        'still_mounted': 'Sistemas de arquivos ainda montados',
        'mount_boot_error': 'ERROR: Não foi possível montar {} em {}/boot',
        'mount_efi_error': 'ERROR: Não foi possível montar {} em {}/boot/efi'
    },
    'autostart': 'Mostrar na inicialização:',
    'labels': {
        'language': 'Idioma:',
        'show_startup': 'Mostrar na inicialização:',
        'device': 'Dispositivo',
        'size': 'Tamanho',
        'model': 'Modelo',
        'filesystem': 'Sistema de arquivos',
        'mountpoint': 'Ponto de montagem',
        'select_option': '-- Selecionar --',
        'unknown': 'Desconhecido'
    },
    'live_iso': {
        'title': 'Live ISO',
        'description': 'Esta versão Live permite que você experimente o Soplos Linux\nsem instalar nada no seu computador.\nQuando estiver pronto, use o botão laranja para instalá-lo.'
    },
    'thanks': 'Obrigado por experimentar o Soplos Linux!',
    'messages': {
        'selected_disk': 'Disco selecionado: {}',
        'error_loading_disks': 'Erro ao carregar discos',
        'error_loading_partitions': 'Erro ao obter partições',
        'error_mounting': 'Erro ao montar partições',
        'error_unmounting': 'Erro ao desmontar o sistema',
        'mount_point_error': 'ERROR: Não foi possível criar o ponto de montagem',
        'mount_root_error': 'ERROR: Não foi possível montar',
        'in': 'em',
        'completed': 'completo',
        'mount_dev_error': 'ERROR: Não foi possível montar /dev em',
        'mount_proc_error': 'ERROR: Não foi possível montar /proc em',
        'mount_sys_error': 'ERROR: Não foi possível montar /sys em',
        'mount_pts_error': 'ERROR: Não foi possível montar /dev/pts em',
        'resolv_copy_error': 'Não foi possível copiar resolv.conf',
        'no_shell_error': 'ERROR: Não foi encontrado um shell válido no sistema montado',
        'unmount_warning': 'ADVERTÊNCIA: Alguns pontos de montagem não puderam ser desmontados.',
        'restart_needed': 'Pode ser necessário reiniciar o sistema para liberar esses recursos.',
        'directory_removed': 'Diretório removido',
        'directory_remove_error': 'Não foi possível remover',
        'directory_kept': 'Diretório mantido',
        'mount_point_missing': 'ERROR: O ponto de montagem não existe',
        'shell_not_found': 'ERROR: Não foi encontrado um shell válido no sistema montado',
        'lsblk_error': 'Erro executando lsblk',
        'gparted_error': 'Erro executando GParted',
        'mount_result': 'Resultado da montagem:',
        'konsole_error': 'Erro ao iniciar konsole',
        'xterm_error': 'Erro ao iniciar xterm',
        'first_start_detected': 'Primeiro início detectado, pulando verificação de reinício',
        'first_start_error': 'Erro ao marcar primeiro início: {}',
        'restart_detected': 'Reinício detectado para mudança de idioma, aplicando configuração...',
        'keyboard_config_warning': 'Aviso: Não foi possível aplicar configuração de teclado/locale',
        'restarting_session': 'Reiniciando sessão...',
        'restarting_sddm': 'Reiniciando SDDM para aplicar mudanças de idioma...',
        'icon_error': 'Erro ao definir ícone: {}',
        'desktop_info': 'Ambiente de desktop: {}, Tipo de sessão: {}',
        'logo_error': 'Erro ao carregar logo: {}',
        'locale_config_error': 'Erro configurando locale do sistema',
        'robust_locale_error': 'Erro na configuração robusta de locale',
        'robust_autologin_error': 'Erro configurando autologin robusto',
        'restarting_sddm_script': 'Reiniciando SDDM para aplicar mudanças de idioma...',
        'robust_restart_error': 'Erro no reinício robusto',
        'sddm_config_error': 'Erro modificando /etc/sddm.conf',
        'kde_command_error': 'Erro executando {}: {}',
        'kde_config_error': 'Erro recarregando configuração do KDE',
        'app_title': 'Soplos Welcome Live',
        'autostart_create_error': 'Erro: Não foi possível criar o arquivo de inicialização automática',
        'autostart_enable_error': 'Erro ao ativar inicialização automática: {}',
        'autostart_enabled': 'Inicialização automática ativada: {} -> {}',
        'desktop_file_not_found': 'Erro: Arquivo .desktop não encontrado em nenhum local conhecido',
        'basic_desktop_created': 'Arquivo desktop básico criado como backup',
        'basic_desktop_error': 'Erro ao criar arquivo desktop básico: {}',
        # New messages for desktop_detector.py
        'wayland_session': 'Sessão detectada: Wayland',
        'x11_session': 'Sessão detectada: X11',
        'unknown_session': 'Não foi possível determinar o tipo de sessão, usando X11 como padrão',
        'autologin_check_error': 'Erro ao verificar autologin: {}',
        'autologin_found': 'Autologin encontrado em {file_path} para o usuário: {user}',
        'autologin_file_error': 'Erro ao ler {file_path}: {error}',
        'kde_restore_error': 'Erro ao restaurar a configuração KDE: {}',
        'kde_backup_error': 'Erro ao fazer backup da configuração KDE: {}',
        'backed_up': 'Backup feito {src} -> {dst}',
        'restored': 'Restaurado {src} -> {dst}'
    },
    'progress': {
        'configuring': 'Configurando idioma...'
    },
    'commands': {
        'gparted': 'sudo gparted',
        'calamares_sudo': 'sudo',
        'calamares': 'calamares'
    },
    'errors': {
        'slide_load': 'Erro ao carregar slide',
        'language_config': 'Erro configurando idioma'
    },
    'system': {
        'xorg_conf_dir': '/etc/X11/xorg.conf.d',
        'keyboard_conf_file': '/etc/X11/xorg.conf.d/00-keyboard.conf',
        'xorg_keyboard_template': """Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection"""
    },
    'templates': {
        'basic_desktop_file': """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Tela de boas-vindas para o ambiente Live do Soplos Linux
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
"""
    },
    'session_manager': {
        'using_temp_dir': 'Usando diretório temporário para configuração: {}',
        'error_creating_config_dir': 'Erro ao criar diretório de configuração: {}',
        'first_run_marked': 'Primeira execução marcada - reinício automático será evitado',
        'error_first_run_marker': 'Erro ao criar marcador de primeira execução: {}',
        'error_configuring_autologin': 'Erro: Não foi possível configurar autologin',
        'saving_autostart_state': 'Salvando estado de autostart habilitado para restauração após reinício',
        'restart_request_created': 'Arquivo de solicitação de reinício criado com sucesso',
        'error_creating_restart_file': 'Erro ao criar arquivo de solicitação de reinício: {}',
        'executing_sddm_restart': 'Executando reinício do SDDM em sessão {}...',
        'critical_sddm_restart_error': 'Erro crítico ao reiniciar SDDM: {}',
        'copying_dir': 'Copiando diretório {} para {}',
        'error_reloading_kde': 'Erro ao recarregar configuração do KDE: {}',
        'error_restoring_theme': 'Erro ao restaurar tema do skel: {}',
        'error_configuring_locale': 'Erro ao configurar locale do sistema: {}',
        # New strings added
        'no_restart_request': 'Nenhuma solicitação explícita de reinício, evitando reinício automático',
        'restoring_autostart': 'Restaurando inicialização automática após reinício...',
        'error_tmp_state': 'Erro ao verificar estado em /tmp: {}',
        'locale_mismatch': 'O locale atual ({}) não corresponde ao salvo ({})',
        'error_verifying_locale': 'Erro ao verificar aplicação do locale: {}',
        'skel_dir_missing': 'O diretório {} não existe',
        'timeout_warning': 'O script de configuração demorou muito, mas pode ter funcionado',
        'error_ensuring_autologin': 'Erro ao garantir autologin: {}'
    },
    'xdg': {
        'updating_directories': 'Atualizando diretórios XDG para locale: {}',
        'backup_created': 'Backup de user-dirs.dirs criado',
        'file_deleted': 'Arquivo user-dirs.dirs eliminado para regeneração',
        'running_update': 'Executando xdg-user-dirs-update --force...',
        'result': 'Resultado: {}',
        'errors': 'Erros: {}',
        'not_created': 'Erro: user-dirs.dirs não foi criado',
        'restored_backup': 'Restaurado do backup',
        'updating_gtk': 'Atualizando configuração GTK...',
        'updating_references': 'Atualizando referências de diretórios no ambiente de desktop...',
        'file_content': 'Conteúdo de user-dirs.dirs:\n{}',
        'error_updating': 'Erro atualizando diretórios XDG: {}',
        'renaming_directories': 'Renomeando diretórios para o idioma: {}',
        'no_mapping': 'Nenhum mapeamento de diretórios para o idioma: {}',
        'both_exist': 'Ambos os diretórios existem. Migrando conteúdo: {} → {}',
        'content_migrated': 'Conteúdo migrado e diretório {} eliminado',
        'error_consolidating': 'Erro consolidando diretórios: {}',
        'renaming': 'Renomeando: {} → {}',
        'error_renaming': 'Erro renomeando {}: {}',
        'destination_exists': 'O diretório de destino {} já existe, permanece',
        'neither_exists': 'Nenhum diretório existe: {} nem {}',
        'general_error': 'Erro geral renomeando diretórios: {}',
        'error_kde_references': 'Erro atualizando referências KDE: {}',
        'generating_config': 'Gerando configuração XDG para locale: {}',
        'config_generated': 'Configuração XDG gerada em: {}',
        'error_generating_config': 'Erro gerando configuração XDG: {}'
    }
}
