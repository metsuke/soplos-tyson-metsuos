STRINGS_RU = {
    'welcome': 'Soplos Linux',
    'welcome_desc': 'Дистрибутив Linux, созданный для вас!',
    'version': 'Tyron Live 2023.2',
    'buttons': {
        'exit': '_Выход',
        'website': 'Сайт',
        'forums': 'Форумы',
        'wiki': 'Вики',
        'donate': 'Поддержать',
        'install': 'Установить Soplos _Linux',
        'chroot': 'Восстановить систему с _CHROOT',
        'open_gparted': 'Открыть _GParted',
        'close': '_Закрыть',
        'next': '_Далее',
        'cancel': '_Отмена',
        'mount': '_Монтировать'
    },
    'dialog': {
        'exit_title': 'Вы уверены, что хотите выйти?',
        'exit_desc': 'Программа приветствия будет закрыта.',
        'error': 'Ошибка',
        'select_disk': 'Пожалуйста, выберите диск',
        'select_root': 'Вы должны выбрать корневой раздел (/)',
        'no_partitions': 'На этом диске не найдено разделов',
        'partition_header': 'Выберите разделы для монтирования:',
        'mounting': 'Монтирование разделов',
        'invalid_partition': 'Неверный раздел',
        'invalid_partition_desc': 'Выбранный раздел не содержит допустимую систему Linux или поврежден.',
        'mount_error': 'Ошибка монтирования',
        'mount_error_desc': 'Не удалось смонтировать выбранные разделы.'
    },
    'locale': {
        'error_generating': 'Ошибка при генерации локалей:',
        'error_updating': 'Ошибка при установке локали по умолчанию:',
        'error_restart': 'Ошибка при перезапуске SDDM',
        'not_found_locale_gen': 'Команда locale-gen не найдена.\nПожалуйста, установите пакет locales.',
        'not_found_update_locale': 'update-locale не найден',
        'restart_session_title': 'Изменения применены',
        'restart_session_desc': 'Чтобы все изменения вступили в силу, рекомендуется выйти из системы и снова войти.'
    },
    'chroot': {
        'title': 'Восстановление CHROOT',
        'select_disk': 'Выберите системный диск',
        'open_gparted': 'Открыть GParted',
        'select_partitions': 'Выберите разделы',
        'mount': 'Монтировать',
        'cancel': 'Отмена',
        'terminal_title': 'Soplos Linux CHROOT - Среда восстановления',
        'welcome_message': 'Вы вошли в среду chroot для восстановления вашей системы.',
        'instructions': 'Вы можете выполнять команды, такие как обновления, переустановка\nменеджера загрузки или любое другое восстановление.',
        'exit_message': 'Чтобы выйти из среды chroot, введите \'exit\' или нажмите Ctrl+D.',
        'mounting_partitions': 'Монтирование разделов...',
        'mounting_root': 'Монтирование корневого раздела',
        'mounting_boot': 'Монтирование раздела /boot',
        'mounting_efi': 'Монтирование EFI-раздела',
        'mounting_virtual': 'Монтирование виртуальных файловых систем',
        'exit_chroot': 'Вы вышли из среды chroot.',
        'unmounting': 'Размонтирование',
        'unmount_complete': 'Все разделы были размонтированы корректно.',
        'cleanup_question': 'Вы хотите удалить каталог монтирования {}? [y/N]: ',
        'process_complete': 'Процесс chroot завершен.',
        'chroot_started': 'Chroot успешно запущен',
        'mounting_content': 'Содержимое точки монтирования:',
        'using_shell': 'Используется оболочка:',
        'starting_chroot': 'Запуск окружения chroot...',
        'mount_point_label': 'Точка монтирования',
        'root_partition_label': 'Корневой раздел',
        'creating_dirs': 'Создание каталогов для привязанных точек монтирования',
        'creating_boot_dir': 'Создание каталога /boot',
        'creating_efi_dir': 'Создание каталога /boot/efi',
        'bin_content': 'Содержимое /bin',
        'usr_bin_content': 'Содержимое /usr/bin',
        'still_mounted': 'Файловые системы все еще смонтированы',
        'mount_boot_error': 'ERROR: Не удалось смонтировать {} в {}/boot',
        'mount_efi_error': 'ERROR: Не удалось смонтировать {} в {}/boot/efi'
    },
    'autostart': 'Показывать при запуске:',
    'labels': {
        'language': 'Язык:',
        'show_startup': 'Показывать при запуске:',
        'device': 'Устройство',
        'size': 'Размер',
        'model': 'Модель',
        'filesystem': 'Файловая система',
        'mountpoint': 'Точка монтирования',
        'select_option': '-- Выбрать --',
        'unknown': 'Неизвестно'
    },
    'live_iso': {
        'title': 'Live ISO',
        'description': 'Эта версия Live позволяет вам попробовать Soplos Linux\nбез установки чего-либо на ваш компьютер.\nКогда будете готовы, используйте оранжевую кнопку для установки.'
    },
    'thanks': 'Спасибо, что попробовали Soplos Linux!',
    'messages': {
        'selected_disk': 'Выбранный диск: {}',
        'error_loading_disks': 'Ошибка при загрузке дисков',
        'error_loading_partitions': 'Ошибка при получении разделов',
        'error_mounting': 'Ошибка при монтировании разделов',
        'error_unmounting': 'Ошибка при размонтировании системы',
        'mount_point_error': 'ERROR: Не удалось создать точку монтирования',
        'mount_root_error': 'ERROR: Не удалось смонтировать',
        'in': 'в',
        'completed': 'завершено',
        'mount_dev_error': 'ERROR: Не удалось смонтировать /dev в',
        'mount_proc_error': 'ERROR: Не удалось смонтировать /proc в',
        'mount_sys_error': 'ERROR: Не удалось смонтировать /sys в',
        'mount_pts_error': 'ERROR: Не удалось смонтировать /dev/pts в',
        'resolv_copy_error': 'Не удалось скопировать resolv.conf',
        'no_shell_error': 'ERROR: В смонтированной системе не найдена действительная оболочка',
        'unmount_warning': 'ПРЕДУПРЕЖДЕНИЕ: Некоторые точки монтирования не были размонтированы.',
        'restart_needed': 'Возможно, потребуется перезагрузить систему, чтобы освободить эти ресурсы.',
        'directory_removed': 'Каталог удален',
        'directory_remove_error': 'Не удалось удалить',
        'directory_kept': 'Каталог сохранен',
        'mount_point_missing': 'ERROR: Точка монтирования не существует',
        'shell_not_found': 'ERROR: В смонтированной системе не найдена действительная оболочка',
        'lsblk_error': 'Ошибка при выполнении lsblk',
        'gparted_error': 'Ошибка при выполнении GParted',
        'mount_result': 'Результат монтирования:',
        'konsole_error': 'Ошибка при запуске konsole',
        'xterm_error': 'Ошибка при запуске xterm',
        'first_start_detected': 'Обнаружен первый запуск, пропускаем проверку перезапуска',
        'first_start_error': 'Ошибка при отметке первого запуска: {}',
        'restart_detected': 'Обнаружен перезапуск для смены языка, применяем конфигурацию...',
        'keyboard_config_warning': 'Предупреждение: Не удалось применить конфигурацию клавиатуры/локали',
        'restarting_session': 'Перезапуск сессии...',
        'restarting_sddm': 'Перезапуск SDDM для применения изменений языка...',
        'icon_error': 'Ошибка при установке иконки: {}',
        'desktop_info': 'Окружение рабочего стола: {}, Тип сессии: {}',
        'logo_error': 'Ошибка при загрузке логотипа: {}',
        'locale_config_error': 'Ошибка при настройке системной локали',
        'robust_locale_error': 'Ошибка в надежной настройке локали: {}',
        'sddm_config_error': 'Ошибка при изменении /etc/sddm.conf: {}',
        'robust_autologin_error': 'Ошибка при настройке надежного автологина: {}',
        'restarting_sddm_script': 'Перезапуск SDDM для применения изменений языка...',
        'robust_restart_error': 'Ошибка при надежном перезапуске: {}',
        'kde_command_error': 'Ошибка при выполнении {}: {}',
        'kde_config_error': 'Ошибка при перезагрузке конфигурации KDE: {}',
        'app_title': 'Soplos Welcome Live',
        'autostart_create_error': 'Ошибка: Не удалось создать файл автозапуска',
        'autostart_enable_error': 'Ошибка при активации автозапуска: {}',
        'autostart_enabled': 'Автозапуск включен: {} -> {}',
        'desktop_file_not_found': 'Ошибка: Файл .desktop не найден ни в одном из известных мест',
        'basic_desktop_created': 'Создан базовый файл desktop в качестве резервной копии',
        'basic_desktop_error': 'Ошибка при создании базового файла desktop: {}',
        # New messages for desktop_detector.py
        'wayland_session': 'Обнаружена сессия: Wayland',
        'x11_session': 'Обнаружена сессия: X11',
        'unknown_session': 'Не удалось определить тип сессии, используется X11 по умолчанию',
        'autologin_check_error': 'Ошибка при проверке автовхода: {}',
        'autologin_found': 'Автовход найден в {file_path} для пользователя: {user}',
        'autologin_file_error': 'Ошибка при чтении {file_path}: {error}',
        'kde_restore_error': 'Ошибка при восстановлении конфигурации KDE: {}',
        'kde_backup_error': 'Ошибка при резервном копировании конфигурации KDE: {}',
        'backed_up': 'Создана резервная копия {src} -> {dst}',
        'restored': 'Восстановлено {src} -> {dst}'
    },
    'progress': {
        'configuring': 'Настройка языка...'
    },
    'commands': {
        'gparted': 'sudo gparted',
        'calamares_sudo': 'sudo',
        'calamares': 'calamares'
    },
    'errors': {
        'slide_load': 'Ошибка при загрузке слайда',
        'language_config': 'Ошибка при настройке языка'
    },
    'system': {
        'xorg_conf_dir': '/etc/X11/xorg.conf.d',
        'keyboard_conf_file': '/etc/X11/xorg.conf.d/00-keyboard.conf',
        'xorg_keyboard_template': """Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection"""
    },
    'templates': {
        'basic_desktop_file': """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Экран приветствия для Live-окружения Soplos Linux
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
"""
    },
    'session_manager': {
        'using_temp_dir': 'Используется временный каталог для конфигурации: {}',
        'error_creating_config_dir': 'Ошибка при создании каталога конфигурации: {}',
        'first_run_marked': 'Отмечен первый запуск - автоматический перезапуск будет пропущен',
        'error_first_run_marker': 'Ошибка при создании маркера первого запуска: {}',
        'error_configuring_autologin': 'Ошибка: Не удалось настроить автологин',
        'saving_autostart_state': 'Сохранение включенного состояния автозапуска для восстановления после перезапуска',
        'restart_request_created': 'Файл запроса на перезапуск успешно создан',
        'error_creating_restart_file': 'Ошибка при создании файла запроса на перезапуск: {}',
        'executing_sddm_restart': 'Выполняется перезапуск SDDM в сессии {}...',
        'critical_sddm_restart_error': 'Критическая ошибка при перезапуске SDDM: {}',
        'copying_dir': 'Копирование каталога {} в {}',
        'error_reloading_kde': 'Ошибка при перезагрузке конфигурации KDE: {}',
        'error_restoring_theme': 'Ошибка при восстановлении темы из skel: {}',
        'error_configuring_locale': 'Ошибка при настройке локали системы: {}',
        # New strings added
        'no_restart_request': 'Нет явного запроса на перезапуск, автоматический перезапуск пропускается',
        'restoring_autostart': 'Восстановление автозапуска после перезапуска...',
        'error_tmp_state': 'Ошибка при проверке состояния в /tmp: {}',
        'locale_mismatch': 'Текущая локаль ({}) не соответствует сохраненной ({})',
        'error_verifying_locale': 'Ошибка при проверке применения локали: {}',
        'skel_dir_missing': 'Каталог {} не существует',
        'timeout_warning': 'Сценарий настройки занял слишком много времени, но возможно сработал',
        'error_ensuring_autologin': 'Ошибка при обеспечении автологина: {}'
    },
    'xdg': {
        'updating_directories': 'Обновление каталогов XDG для локали: {}',
        'backup_created': 'Резервная копия user-dirs.dirs создана',
        'file_deleted': 'Файл user-dirs.dirs удален для регенерации',
        'running_update': 'Выполнение xdg-user-dirs-update --force...',
        'result': 'Результат: {}',
        'errors': 'Ошибки: {}',
        'not_created': 'Ошибка: user-dirs.dirs не был создан',
        'restored_backup': 'Восстановлено из резервной копии',
        'updating_gtk': 'Обновление конфигурации GTK...',
        'updating_references': 'Обновление ссылок на каталоги в среде рабочего стола...',
        'file_content': 'Содержимое user-dirs.dirs:\n{}',
        'error_updating': 'Ошибка обновления каталогов XDG: {}',
        'renaming_directories': 'Переименование каталогов для языка: {}',
        'no_mapping': 'Нет отображения каталогов для языка: {}',
        'both_exist': 'Оба каталога существуют. Миграция содержимого: {} → {}',
        'content_migrated': 'Содержимое перенесено и каталог {} удален',
        'error_consolidating': 'Ошибка консолидации каталогов: {}',
        'renaming': 'Переименование: {} → {}',
        'error_renaming': 'Ошибка переименования {}: {}',
        'destination_exists': 'Целевой каталог {} уже существует, остается',
        'neither_exists': 'Ни один каталог не существует: {} ни {}',
        'general_error': 'Общая ошибка переименования каталогов: {}',
        'error_kde_references': 'Ошибка обновления ссылок KDE: {}',
        'generating_config': 'Генерация конфигурации XDG для локали: {}',
        'config_generated': 'Конфигурация XDG создана в: {}',
        'error_generating_config': 'Ошибка генерации конфигурации XDG: {}'
    }
}
