STRINGS_RO = {
    'welcome': 'Soplos Linux',
    'welcome_desc': 'Distribuția Linux făcută pentru tine!',
    'version': 'Tyron Live 2023.2',
    'buttons': {
        'exit': '_Ieșire',
        'website': 'Site Web',
        'forums': 'Forum',
        'wiki': 'Wiki',
        'donate': 'Donează',
        'install': 'Instalează Soplos _Linux',
        'chroot': 'Recuperează sistemul cu _CHROOT',
        'open_gparted': 'Deschide _GParted',
        'close': '_Închide',
        'next': '_Următorul',
        'cancel': '_Anulează',
        'mount': '_Montează'
    },
    'dialog': {
        'exit_title': 'Sigur doriți să ieșiți?',
        'exit_desc': 'Programul de bun venit se va închide.',
        'error': 'Eroare',
        'select_disk': 'Vă rugăm să selectați un disc',
        'select_root': 'Trebuie să selectați o partiție root (/)',
        'no_partitions': 'Nu s-au găsit partiții pe acest disc',
        'partition_header': 'Selectați partițiile de montat:',
        'mounting': 'Montarea partițiilor',
        'invalid_partition': 'Partiție nevalidă',
        'invalid_partition_desc': 'Partiția selectată nu conține un sistem Linux valid sau este deteriorată.',
        'mount_error': 'Eroare de montare',
        'mount_error_desc': 'Nu s-au putut monta partițiile selectate.'
    },
    'locale': {
        'error_generating': 'Eroare la generarea localelor:',
        'error_updating': 'Eroare la setarea localei implicite:',
        'error_restart': 'Eroare la repornirea SDDM',
        'not_found_locale_gen': 'Comanda locale-gen nu a fost găsită.\nVă rugăm să instalați pachetul locales.',
        'not_found_update_locale': 'update-locale nu a fost găsit',
        'restart_session_title': 'Modificări aplicate',
        'restart_session_desc': 'Pentru ca toate modificările să aibă efect complet, se recomandă să vă deconectați și să vă reconectați.'
    },
    'chroot': {
        'title': 'Recuperare CHROOT',
        'select_disk': 'Selectați discul sistem',
        'open_gparted': 'Deschide GParted',
        'select_partitions': 'Selectați partițiile',
        'mount': 'Montare',
        'cancel': 'Anulare',
        'terminal_title': 'Soplos Linux CHROOT - Mediu de recuperare',
        'welcome_message': 'Ați intrat într-un mediu chroot pentru a vă recupera sistemul.',
        'instructions': 'Puteți rula comenzi precum actualizări, reinstalare\nmanagerul de boot sau orice altă reparare.',
        'exit_message': 'Pentru a ieși din mediul chroot, tastați \'exit\' sau apăsați Ctrl+D.',
        'mounting_partitions': 'Montare partiții...',
        'mounting_root': 'Montare partiție rădăcină',
        'mounting_boot': 'Montare partiție /boot',
        'mounting_efi': 'Montare partiție EFI',
        'mounting_virtual': 'Montare sisteme de fișiere virtuale',
        'exit_chroot': 'Ați ieșit din mediul chroot.',
        'unmounting': 'Demontare',
        'unmount_complete': 'Toate partițiile au fost demontate corect.',
        'cleanup_question': 'Doriți să eliminați directorul de montare {}? [s/N]: ',
        'process_complete': 'Procesul de chroot s-a încheiat.',
        'chroot_started': 'Chroot pornit cu succes',
        'mounting_content': 'Conținutul punctului de montare:',
        'using_shell': 'Se folosește shell-ul:',
        'starting_chroot': 'Se pornește mediul chroot...',
        'mount_point_label': 'Punct de montare',
        'root_partition_label': 'Partiție rădăcină',
        'creating_dirs': 'Crearea directoarelor pentru montări legate',
        'creating_boot_dir': 'Crearea directorului /boot',
        'creating_efi_dir': 'Crearea directorului /boot/efi',
        'bin_content': 'Conținutul /bin',
        'usr_bin_content': 'Conținutul /usr/bin',
        'still_mounted': 'Sisteme de fișiere încă montate',
        'mount_boot_error': 'ERROR: Nu s-a putut monta {} în {}/boot',
        'mount_efi_error': 'ERROR: Nu s-a putut monta {} în {}/boot/efi'
    },
    'autostart': 'Arată la pornire:',
    'labels': {
        'language': 'Limbă:',
        'show_startup': 'Arată la pornire:',
        'device': 'Dispozitiv',
        'size': 'Dimensiune',
        'model': 'Model',
        'filesystem': 'Sistem de fișiere',
        'mountpoint': 'Punct de montare',
        'select_option': '-- Selectați --',
        'unknown': 'Necunoscut'
    },
    'live_iso': {
        'title': 'Live ISO',
        'description': 'Această versiune Live vă permite să încercați Soplos Linux\nfără a instala nimic pe computerul dvs.\nCând sunteți gata, utilizați butonul portocaliu pentru a-l instala.'
    },
    'thanks': 'Mulțumim că ați încercat Soplos Linux!',
    'messages': {
        'selected_disk': 'Disc selectat: {}',
        'error_loading_disks': 'Eroare la încărcarea discurilor',
        'error_loading_partitions': 'Eroare la obținerea partițiilor',
        'error_mounting': 'Eroare la montarea partițiilor',
        'error_unmounting': 'Eroare la demontarea sistemului',
        'mount_point_error': 'ERROR: Nu s-a putut crea punctul de montare',
        'mount_root_error': 'ERROR: Nu s-a putut monta',
        'in': 'în',
        'completed': 'completat',
        'mount_dev_error': 'ERROR: Nu s-a putut monta /dev în',
        'mount_proc_error': 'ERROR: Nu s-a putut monta /proc în',
        'mount_sys_error': 'ERROR: Nu s-a putut monta /sys în',
        'mount_pts_error': 'ERROR: Nu s-a putut monta /dev/pts în',
        'resolv_copy_error': 'Nu s-a putut copia resolv.conf',
        'no_shell_error': 'ERROR: Nu s-a găsit un shell valid în sistemul montat',
        'unmount_warning': 'AVERTISMENT: Unele puncte de montare nu au putut fi demontate.',
        'restart_needed': 'Este posibil să fie necesar să reporniți sistemul pentru a elibera aceste resurse.',
        'directory_removed': 'Director eliminat',
        'directory_remove_error': 'Nu s-a putut elimina',
        'directory_kept': 'Director păstrat',
        'mount_point_missing': 'ERROR: Punctul de montare nu există',
        'shell_not_found': 'ERROR: Nu s-a găsit un shell valid în sistemul montat',
        'lsblk_error': 'Eroare la executarea lsblk',
        'gparted_error': 'Eroare la executarea GParted',
        'mount_result': 'Rezultatul montării:',
        'konsole_error': 'Eroare la pornirea konsole',
        'xterm_error': 'Eroare la pornirea xterm',
        'first_start_detected': 'Prima pornire detectată, sărim verificarea de repornire',
        'first_start_error': 'Eroare la marcarea primei porniri',
        'restart_detected': 'Repornire detectată pentru schimbarea limbii, aplicând configurația...',
        'keyboard_config_warning': 'Avertisment: Nu s-a putut aplica configurația tastatură/locale',
        'restarting_session': 'Repornire sesiune...',
        'restarting_sddm': 'Repornire SDDM pentru aplicarea schimbărilor de limbă...',
        'icon_error': 'Eroare la setarea pictogramei: {}',
        'desktop_info': 'Mediu desktop: {}, Tip sesiune: {}',
        'logo_error': 'Eroare la încărcarea logo-ului: {}',
        'locale_config_error': 'Eroare la configurarea locale-ului de sistem',
        'robust_locale_error': 'Eroare în configurarea robustă a locale-ului',
        'robust_autologin_error': 'Eroare la configurarea autologin-ului robust',
        'restarting_sddm_script': 'Repornire SDDM pentru aplicarea schimbărilor de limbă...',
        'robust_restart_error': 'Eroare în repornirea robustă',
        'sddm_config_error': 'Eroare la modificarea /etc/sddm.conf',
        'kde_command_error': 'Eroare la executarea {}: {}',
        'kde_config_error': 'Eroare la reîncărcarea configurației KDE',
        'app_title': 'Soplos Welcome Live',
        'autostart_create_error': 'Eroare: Nu s-a putut crea fișierul de pornire automată',
        'autostart_enable_error': 'Eroare la activarea pornirii automate: {}',
        'autostart_enabled': 'Pornire automată activată: {} -> {}',
        'desktop_file_not_found': 'Eroare: Fișierul .desktop nu a fost găsit în nicio locație cunoscută',
        'basic_desktop_created': 'A fost creat un fișier desktop de bază ca rezervă',
        'basic_desktop_error': 'Eroare la crearea fișierului desktop de bază: {}',
        # New messages for desktop_detector.py
        'wayland_session': 'Sesiune detectată: Wayland',
        'x11_session': 'Sesiune detectată: X11',
        'unknown_session': 'Nu s-a putut determina tipul sesiunii, se folosește X11 ca implicit',
        'autologin_check_error': 'Eroare la verificarea autologin: {}',
        'autologin_found': 'Autologin găsit în {file_path} pentru utilizatorul: {user}',
        'autologin_file_error': 'Eroare la citirea {file_path}: {error}',
        'kde_restore_error': 'Eroare la restaurarea configurației KDE: {}',
        'kde_backup_error': 'Eroare la backup-ul configurației KDE: {}',
        'backed_up': 'Backup efectuat {src} -> {dst}',
        'restored': 'Restaurat {src} -> {dst}'
    },
    'progress': {
        'configuring': 'Configurare limbă...'
    },
    'commands': {
        'gparted': 'sudo gparted',
        'calamares_sudo': 'sudo',
        'calamares': 'calamares'
    },
    'errors': {
        'slide_load': 'Eroare la încărcarea slide-ului',
        'language_config': 'Eroare la configurarea limbii'
    },
    'system': {
        'xorg_conf_dir': '/etc/X11/xorg.conf.d',
        'keyboard_conf_file': '/etc/X11/xorg.conf.d/00-keyboard.conf',
        'xorg_keyboard_template': """Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection"""
    },
    'templates': {
        'basic_desktop_file': """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Ecran de întâmpinare pentru mediul Live Soplos Linux
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
"""
    },
    'session_manager': {
        'using_temp_dir': 'Se folosește directorul temporar pentru configurare: {}',
        'error_creating_config_dir': 'Eroare la crearea directorului de configurare: {}',
        'first_run_marked': 'Prima rulare marcată - repornirea automată va fi evitată',
        'error_first_run_marker': 'Eroare la crearea marcatorului pentru prima rulare: {}',
        'error_configuring_autologin': 'Eroare: Nu s-a putut configura autologin',
        'saving_autostart_state': 'Se salvează starea de autostart activat pentru restaurare după repornire',
        'restart_request_created': 'Fișierul de cerere de repornire a fost creat cu succes',
        'error_creating_restart_file': 'Eroare la crearea fișierului de cerere de repornire: {}',
        'executing_sddm_restart': 'Se execută repornirea SDDM în sesiunea {}...',
        'critical_sddm_restart_error': 'Eroare critică la repornirea SDDM: {}',
        'copying_dir': 'Se copiază directorul {} în {}',
        'error_reloading_kde': 'Eroare la reîncărcarea configurației KDE: {}',
        'error_restoring_theme': 'Eroare la restaurarea temei din skel: {}',
        'error_configuring_locale': 'Eroare la configurarea localei sistemului: {}',
        # New strings added
        'no_restart_request': 'Nicio solicitare explicită de repornire, evitând repornirea automată',
        'restoring_autostart': 'Se restaurează pornirea automată după repornire...',
        'error_tmp_state': 'Eroare la verificarea stării în /tmp: {}',
        'locale_mismatch': 'Locala curentă ({}) nu se potrivește cu cea salvată ({})',
        'error_verifying_locale': 'Eroare la verificarea aplicării localei: {}',
        'skel_dir_missing': 'Directorul {} nu există',
        'timeout_warning': 'Scriptul de configurare a durat prea mult, dar este posibil să fi funcționat',
        'error_ensuring_autologin': 'Eroare la asigurarea autologin: {}'
    },
    'xdg': {
        'updating_directories': 'Actualizare directoare XDG pentru locale: {}',
        'backup_created': 'Backup de user-dirs.dirs creat',
        'file_deleted': 'Fișierul user-dirs.dirs șters pentru regenerare',
        'running_update': 'Executare xdg-user-dirs-update --force...',
        'result': 'Rezultatul: {}',
        'errors': 'Erori: {}',
        'not_created': 'Eroare: user-dirs.dirs nu a fost creat',
        'restored_backup': 'Restaurat din backup',
        'updating_gtk': 'Actualizare configurație GTK...',
        'updating_references': 'Actualizare referințe directoare în mediul desktop...',
        'file_content': 'Conținutul user-dirs.dirs:\n{}',
        'error_updating': 'Eroare la actualizarea directoarelor XDG: {}',
        'renaming_directories': 'Redenumire directoare pentru limba: {}',
        'no_mapping': 'Nicio mapare a directoarelor pentru limba: {}',
        'both_exist': 'Ambele directoare există. Migrare conținut: {} → {}',
        'content_migrated': 'Conținut migrat și directorul {} șters',
        'error_consolidating': 'Eroare la consolidarea directoarelor: {}',
        'renaming': 'Redenumire: {} → {}',
        'error_renaming': 'Eroare la redenumirea {}: {}',
        'destination_exists': 'Directorul destinație {} există deja, rămâne',
        'neither_exists': 'Niciun director nu există: {} nici {}',
        'general_error': 'Eroare generală la redenumirea directoarelor: {}',
        'error_kde_references': 'Eroare la actualizarea referințelor KDE: {}',
        'generating_config': 'Generare configurație XDG pentru locale: {}',
        'config_generated': 'Configurație XDG generată în: {}',
        'error_generating_config': 'Eroare la generarea configurației XDG: {}'
    }
}
