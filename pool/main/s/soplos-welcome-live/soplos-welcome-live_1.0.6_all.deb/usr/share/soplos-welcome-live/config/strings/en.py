STRINGS_EN = {
    'welcome': 'Soplos Linux',
    'welcome_desc': 'The Linux distribution made for you!',
    'version': 'Tyron Live 2023.2',
    'buttons': {
        'exit': '_Exit',
        'website': 'Website',
        'forums': 'Forums',
        'wiki': 'Wiki',
        'donate': 'Donate',
        'install': 'Install Soplos _Linux',
        'chroot': 'Recover system with _CHROOT',
        'open_gparted': 'Open _GParted',
        'close': '_Close',
        'next': '_Next',
        'cancel': '_Cancel',
        'mount': '_Mount'
    },
    'dialog': {
        'exit_title': 'Are you sure you want to exit?',
        'exit_desc': 'The welcome program will close.',
        'error': 'Error',
        'select_disk': 'Please select a disk',
        'select_root': 'You must select a root partition (/)',
        'no_partitions': 'No partitions found on this disk',
        'partition_header': 'Select the partitions to mount:',
        'mounting': 'Mounting partitions',
        'invalid_partition': 'Invalid partition',
        'invalid_partition_desc': 'The selected partition does not contain a valid Linux system or is damaged.',
        'mount_error': 'Mount error',
        'mount_error_desc': 'Could not mount the selected partitions.'
    },
    'locale': {
        'error_generating': 'Error generating locales:',
        'error_updating': 'Error setting default locale:',
        'error_restart': 'Error restarting SDDM',
        'not_found_locale_gen': 'locale-gen command not found.\nPlease install locales package.',
        'not_found_update_locale': 'update-locale not found',
        'restart_session_title': 'Changes applied',
        'restart_session_desc': 'For all changes to take full effect, it is recommended to log out and log back in.'
    },
    'chroot': {
        'title': 'CHROOT Recovery',
        'select_disk': 'Select system disk',
        'open_gparted': 'Open GParted',
        'select_partitions': 'Select partitions',
        'mount': 'Mount',
        'cancel': 'Cancel',
        'terminal_title': 'Soplos Linux CHROOT Recovery Environment',
        'welcome_message': 'You have entered a chroot environment to recover your system.',
        'instructions': 'You can run commands like updates, reinstall\nthe boot manager or any other repair.',
        'exit_message': 'To exit the chroot environment, type \'exit\' or press Ctrl+D.',
        'mounting_partitions': 'Mounting partitions...',
        'mounting_root': 'Mounting root partition',
        'mounting_boot': 'Mounting /boot partition',
        'mounting_efi': 'Mounting EFI partition',
        'mounting_virtual': 'Mounting virtual filesystems',
        'exit_chroot': 'You have exited the chroot environment.',
        'unmounting': 'Unmounting',
        'unmount_complete': 'All partitions were unmounted correctly.',
        'cleanup_question': 'Do you want to remove the mount directory {}? [y/N]: ',
        'process_complete': 'Chroot process completed.',
        'chroot_started': 'Chroot started successfully',
        'mounting_content': 'Mount point contents:',
        'using_shell': 'Using shell:',
        'starting_chroot': 'Starting chroot environment...',
        'mount_point_label': 'Mount point',
        'root_partition_label': 'Root partition',
        'creating_dirs': 'Creating directories for bind mounts',
        'creating_boot_dir': 'Creating /boot directory',
        'creating_efi_dir': 'Creating /boot/efi directory',
        'bin_content': 'Contents of /bin',
        'usr_bin_content': 'Contents of /usr/bin',
        'still_mounted': 'File systems still mounted',
        'mount_boot_error': 'ERROR: Could not mount {} in {}/boot',
        'mount_efi_error': 'ERROR: Could not mount {} in {}/boot/efi'
    },
    'autostart': 'Show at startup:',
    'labels': {
        'language': 'Language:',
        'show_startup': 'Show at startup:',
        'device': 'Device',
        'size': 'Size',
        'model': 'Model',
        'filesystem': 'Filesystem',
        'mountpoint': 'Mountpoint',
        'select_option': '-- Select --',
        'unknown': 'Unknown'
    },
    'live_iso': {
        'title': 'Live ISO',
        'description': 'This Live version allows you to try Soplos Linux\nwithout installing anything on your computer.\nWhen you are ready, use the orange button to install it.'
    },
    'thanks': 'Thanks for trying Soplos Linux!',
    'messages': {
        'selected_disk': 'Selected disk: {}',
        'error_loading_disks': 'Error loading disks',
        'error_loading_partitions': 'Error getting partitions',
        'error_mounting': 'Error mounting partitions',
        'error_unmounting': 'Error unmounting the system',
        'mount_point_error': 'ERROR: Could not create mount point',
        'mount_root_error': 'ERROR: Could not mount',
        'in': 'in',
        'completed': 'completed',
        'mount_dev_error': 'ERROR: Could not mount /dev in',
        'mount_proc_error': 'ERROR: Could not mount /proc in',
        'mount_sys_error': 'ERROR: Could not mount /sys in',
        'mount_pts_error': 'ERROR: Could not mount /dev/pts in',
        'resolv_copy_error': 'Could not copy resolv.conf',
        'no_shell_error': 'ERROR: No valid shell found in mounted system',
        'unmount_warning': 'WARNING: Some mount points could not be unmounted.',
        'restart_needed': 'A system restart may be necessary to free these resources.',
        'directory_removed': 'Directory removed',
        'directory_remove_error': 'Could not remove',
        'directory_kept': 'Directory kept',
        'mount_point_missing': 'ERROR: Mount point does not exist',
        'shell_not_found': 'ERROR: No valid shell found in mounted system',
        'lsblk_error': 'Error executing lsblk',
        'gparted_error': 'Error executing GParted',
        'mount_result': 'Mount result:',
        'konsole_error': 'Error starting konsole',
        'xterm_error': 'Error starting xterm',
        'first_start_detected': 'First start detected, skipping restart verification',
        'first_start_error': 'Error marking first start: {}',
        'restart_detected': 'Restart detected for language change, applying configuration...',
        'keyboard_config_warning': 'Warning: Could not apply keyboard/locale configuration',
        'restarting_session': 'Restarting session...',
        'restarting_sddm': 'Restarting SDDM to apply language changes...',
        'icon_error': 'Error loading icon: {}',
        'desktop_info': 'Desktop environment: {}, Session type: {}',
        'logo_error': 'Error loading logo: {}',
        'locale_config_error': 'Error configuring system locale',
        'robust_locale_error': 'Error in robust locale configuration: {}',
        'sddm_config_error': 'Error modifying /etc/sddm.conf: {}',
        'robust_autologin_error': 'Error configuring robust autologin: {}',
        'restarting_sddm_script': 'Restarting SDDM to apply language changes...',
        'robust_restart_error': 'Error in robust restart: {}',
        'kde_command_error': 'Error executing {}: {}',
        'kde_config_error': 'Error reloading KDE configuration: {}',
        'app_title': 'Soplos Welcome Live',
        'autostart_create_error': 'Error: Could not create autostart file',
        'autostart_enable_error': 'Error enabling autostart: {}',
        'autostart_enabled': 'Autostart enabled: {} -> {}',
        'desktop_file_not_found': 'Error: .desktop file not found in any known location',
        'basic_desktop_created': 'Created basic desktop file as backup',
        'basic_desktop_error': 'Error creating basic desktop file: {}',
        # New messages for desktop_detector.py
        'wayland_session': 'Session detected: Wayland',
        'x11_session': 'Session detected: X11',
        'unknown_session': 'Could not determine session type, using X11 as default',
        'autologin_check_error': 'Error checking autologin: {}',
        'autologin_found': 'Autologin found in {file_path} for user: {user}',
        'autologin_file_error': 'Error reading {file_path}: {error}',
        'kde_restore_error': 'Error restoring KDE configuration: {}',
        'kde_backup_error': 'Error backing up KDE configuration: {}',
        'backed_up': 'Backed up {src} -> {dst}',
        'restored': 'Restored {src} -> {dst}'
    },
    'progress': {
        'configuring': 'Configuring language...'
    },
    'commands': {
        'gparted': 'sudo gparted',
        'calamares_sudo': 'sudo',
        'calamares': 'calamares'
    },
    'errors': {
        'slide_load': 'Error loading slide',
        'language_config': 'Error configuring language'
    },
    'system': {
        'xorg_conf_dir': '/etc/X11/xorg.conf.d',
        'keyboard_conf_file': '/etc/X11/xorg.conf.d/00-keyboard.conf',
        'xorg_keyboard_template': """Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection"""
    },
    'templates': {
        'basic_desktop_file': """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Welcome screen for Soplos Linux Live Environment
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
"""
    },
    'session_manager': {
        'using_temp_dir': 'Using temporary directory for configuration: {}',
        'error_creating_config_dir': 'Error creating configuration directory: {}',
        'first_run_marked': 'First run marked - automatic restart will be avoided',
        'error_first_run_marker': 'Error creating first run marker: {}',
        'error_configuring_autologin': 'Error: Could not configure autologin',
        'saving_autostart_state': 'Saving enabled autostart state for restoration after restart',
        'restart_request_created': 'Restart request file successfully created',
        'error_creating_restart_file': 'Error creating restart request file: {}',
        'executing_sddm_restart': 'Executing SDDM restart in {} session...',
        'critical_sddm_restart_error': 'Critical error restarting SDDM: {}',
        'copying_dir': 'Copying directory {} to {}',
        'error_reloading_kde': 'Error reloading KDE configuration: {}',
        'error_restoring_theme': 'Error restoring theme from skel: {}',
        'error_configuring_locale': 'Error configuring system locale: {}',
        # New strings added
        'no_restart_request': 'No explicit restart request, avoiding automatic restart',
        'restoring_autostart': 'Restoring autostart after restart...',
        'error_tmp_state': 'Error checking state in /tmp: {}',
        'locale_mismatch': 'Current locale ({}) does not match saved ({})',
        'error_verifying_locale': 'Error verifying locale application: {}',
        'skel_dir_missing': 'The directory {} does not exist',
        'timeout_warning': 'The configuration script took too long, but it may have worked',
        'error_ensuring_autologin': 'Error ensuring autologin: {}'
    },
    'xdg': {
        'updating_directories': 'Updating XDG directories for locale: {}',
        'backup_created': 'Backup of user-dirs.dirs created',
        'file_deleted': 'user-dirs.dirs file deleted for regeneration',
        'running_update': 'Running xdg-user-dirs-update --force...',
        'result': 'Result: {}',
        'errors': 'Errors: {}',
        'not_created': 'Error: user-dirs.dirs was not created',
        'restored_backup': 'Restored from backup',
        'updating_gtk': 'Updating GTK configuration...',
        'updating_references': 'Updating directory references in the desktop environment...',
        'file_content': 'Content of user-dirs.dirs:\n{}',
        'error_updating': 'Error updating XDG directories: {}',
        'renaming_directories': 'Renaming directories for language: {}',
        'no_mapping': 'No directory mapping for language: {}',
        'both_exist': 'Both directories exist. Migrating content: {} → {}',
        'content_migrated': 'Content migrated and directory {} deleted',
        'error_consolidating': 'Error consolidating directories: {}',
        'renaming': 'Renaming: {} → {}',
        'error_renaming': 'Error renaming {}: {}',
        'destination_exists': 'The destination directory {} already exists, it remains',
        'neither_exists': 'Neither directory exists: {} nor {}',
        'general_error': 'General error renaming directories: {}',
        'error_kde_references': 'Error updating KDE references: {}',
        'generating_config': 'Generating XDG configuration for locale: {}',
        'config_generated': 'XDG configuration generated at: {}',
        'error_generating_config': 'Error generating XDG configuration: {}'
    }
}
