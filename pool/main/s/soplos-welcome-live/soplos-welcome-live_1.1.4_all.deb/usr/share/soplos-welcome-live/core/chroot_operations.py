import subprocess
import os
import json
import shutil
import logging
from config.strings import STRINGS

class SystemOperations:
    def __init__(self):
        # Change from /mnt/soplos_rescue to simply /mnt/chroot
        self.mount_point = "/mnt/chroot"
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        # Get system language more robustly
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        # If it's C.UTF-8 or similar, use English by default
        if current_locale.startswith('C.') or current_locale == 'C':
            self.current_lang = 'en'
        else:
            self.current_lang = current_locale.split('_')[0]
            # If language doesn't exist in STRINGS, use English
            if self.current_lang not in STRINGS:
                self.current_lang = 'en'
        
        print(f"DEBUG: SystemOperations - Detected locale: {current_locale}, using language: {self.current_lang}")

    def format_size(self, size):
        """Convert byte sizes to readable format"""
        try:
            size = int(size)
            for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
                if size < 1024.0:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
            return f"{size:.1f} TB"
        except:
            return "Unknown"

    def get_disks(self):
        """Get list of available disks"""
        try:
            cmd = "lsblk -lnp -o NAME,SIZE,MODEL -d -I 8,259"
            output = subprocess.check_output(cmd.split()).decode()
            disks = []
            for line in output.splitlines():
                if line.strip():
                    parts = line.split()
                    device = parts[0]
                    size = parts[1]
                    model = ' '.join(parts[2:]) if len(parts) > 2 else STRINGS[self.current_lang]['labels']['device']
                    disks.append((device, size, model))
            return disks
        except Exception as e:
            self.logger.error(STRINGS[self.current_lang]['messages']['error_loading_disks'])
            return []

    def get_disk_partitions(self, disk_name):
        """Get disk partitions with improved btrfs detection"""
        try:
            cmd = ['lsblk', '-lnp', '-o', 'NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL,UUID', disk_name]
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                # CHANGED: error message to English and use STRINGS
                raise Exception(f"Error running lsblk: {result.stderr}")

            partitions = []
            used_suggestions = set()

            for line in result.stdout.strip().split('\n'):
                parts = line.split()
                if not parts or parts[0] == disk_name:
                    continue
                    
                device = parts[0]
                size = parts[1]
                fstype = parts[2] if len(parts) > 2 and parts[2] != '' else 'unknown'
                mount = parts[3] if len(parts) > 3 and parts[3] != '' else ''
                label = parts[4] if len(parts) > 4 and parts[4] != '' else ''
                uuid = parts[5] if len(parts) > 5 and parts[5] != '' else ''

                if self._is_mountable_filesystem(fstype):
                    btrfs_info = None
                    is_btrfs = False
                    
                    # FIX: Only detect btrfs if it really is btrfs
                    if fstype.lower() == 'btrfs':
                        is_btrfs = True
                        # print(f"DEBUG: Detecting btrfs subvolumes in {device}")
                        btrfs_info = self._detect_btrfs_subvolumes(device)
                        
                    suggested = self._suggest_mount_point_intelligent(fstype, label, mount, used_suggestions, btrfs_info)
                    if suggested:
                        used_suggestions.add(suggested)
                        
                    partition_data = {
                        'device': device,
                        'size': size,
                        'fstype': fstype,
                        'mountpoint': mount,
                        'label': label,
                        'uuid': uuid,
                        'suggested_mount': suggested,
                        'is_btrfs': is_btrfs
                    }
                    
                    if btrfs_info and btrfs_info.get('has_subvolumes'):
                        partition_data['btrfs_subvolumes'] = btrfs_info
                    
                    partitions.append(partition_data)

            return partitions
        except Exception as e:
            # CHANGED: error message to English and use STRINGS
            self.logger.error(STRINGS[self.current_lang]['messages']['error_loading_partitions'])
            raise

    def _detect_btrfs_subvolumes(self, device):
        """Detect btrfs subvolumes on a partition"""
        try:
            temp_mount = f"/tmp/btrfs_temp_{os.getpid()}"
            os.makedirs(temp_mount, exist_ok=True)
            
            try:
                mount_result = subprocess.run(
                    ['sudo', 'mount', '-t', 'btrfs', device, temp_mount],
                    capture_output=True, text=True, timeout=10
                )
                
                if mount_result.returncode != 0:
                    return None
                
                subvol_result = subprocess.run(
                    ['sudo', 'btrfs', 'subvolume', 'list', temp_mount],
                    capture_output=True, text=True, timeout=10
                )
                
                default_result = subprocess.run(
                    ['sudo', 'btrfs', 'subvolume', 'get-default', temp_mount],
                    capture_output=True, text=True, timeout=10
                )
                
                subvolumes = []
                default_subvol_id = None
                
                if default_result.returncode == 0:
                    for line in default_result.stdout.split('\n'):
                        if 'ID' in line:
                            try:
                                default_subvol_id = line.split()[1]
                            except:
                                pass
                
                if subvol_result.returncode == 0:
                    for line in subvol_result.stdout.split('\n'):
                        if line.strip() and 'ID' in line:
                            try:
                                parts = line.split()
                                if len(parts) >= 9:
                                    subvol_id = parts[1]
                                    subvol_path = parts[8]
                                    
                                    suggested_mount = self._suggest_btrfs_mount_point(subvol_path)
                                    
                                    subvolumes.append({
                                        'id': subvol_id,
                                        'path': subvol_path,
                                        'is_default': subvol_id == default_subvol_id,
                                        'suggested_mount': suggested_mount
                                    })
                            except:
                                continue
                
                return {
                    'subvolumes': subvolumes,
                    'default_subvolume_id': default_subvol_id,
                    'has_subvolumes': len(subvolumes) > 0
                }
                
            finally:
                subprocess.run(['sudo', 'umount', temp_mount], 
                             capture_output=True, timeout=5)
                try:
                    os.rmdir(temp_mount)
                except:
                    pass
                    
        except Exception as e:
            self.logger.error(f"Error detecting btrfs subvolumes: {str(e)}")
            return None

    def _suggest_btrfs_mount_point(self, subvol_path):
        """Suggest mount point based on btrfs subvolume name"""
        path_lower = subvol_path.lower()
        
        mount_patterns = {
            '@': '/',
            '@root': '/',
            '@home': '/home',
            '@var': '/var',
            '@tmp': '/tmp',
            '@opt': '/opt',
            '@srv': '/srv',
            '@usr': '/usr',
            '@boot': '/boot',
            'root': '/',
            'home': '/home',
            'var': '/var',
            'tmp': '/tmp'
        }
        
        if subvol_path in mount_patterns:
            return mount_patterns[subvol_path]
        
        for pattern, mount_point in mount_patterns.items():
            if pattern in path_lower:
                return mount_point
                
        return None

    def _suggest_mount_point_intelligent(self, fstype, label, current_mount, used_suggestions, btrfs_info=None):
        """Intelligent mount point suggestions including btrfs"""
        # Ignore current_mount if it contains our mount_point
        if current_mount and self.mount_point in current_mount:
            current_mount = None

        fstype = (fstype or '').lower()
        label = (label or '').lower()

        # EFI filesystems - FIX: Be VERY aggressive with detection
        if fstype in ['vfat', 'fat32', 'fat16', 'fat']:
            # If it's FAT and /boot/efi is not assigned, ASSUME it's EFI
            if '/boot/efi' not in used_suggestions:
                return '/boot/efi'
        
        # FIX: Btrfs filesystems - AUTO-DETECT @ subvolume
        elif fstype == 'btrfs':
            if btrfs_info and btrfs_info.get('has_subvolumes'):
                # Search for @ or @root subvolume for root
                for subvol in btrfs_info['subvolumes']:
                    if subvol['path'] in ['@', '@root'] and '/' not in used_suggestions:
                        # print(f"DEBUG: Automatically detected root subvolume: {subvol['path']}")
                        return '/'
                
                # If @ not found, search for default subvolume
                default_subvol = None
                for subvol in btrfs_info['subvolumes']:
                    if subvol.get('is_default'):
                        default_subvol = subvol
                        break
                
                if default_subvol and default_subvol.get('suggested_mount'):
                    suggested = default_subvol['suggested_mount']
                    if suggested not in used_suggestions:
                        return suggested
            
            # Fallback for btrfs without subvolumes
            if '/' not in used_suggestions:
                return '/'
        
        # Linux filesystems
        elif fstype in ['ext2', 'ext3', 'ext4', 'xfs', 'jfs', 'reiserfs', 'f2fs']:
            # Based on labels
            if 'root' in label or 'system' in label:
                if '/' not in used_suggestions:
                    return '/'
            elif 'home' in label:
                if '/home' not in used_suggestions:
                    return '/home'
            elif 'boot' in label and 'efi' not in label:
                if '/boot' not in used_suggestions:
                    return '/boot'
            
            # Based on current mount point
            elif current_mount == '/':
                if '/' not in used_suggestions:
                    return '/'
            elif current_mount == '/home':
                if '/home' not in used_suggestions:
                    return '/home'
            elif current_mount == '/boot':
                if '/boot' not in used_suggestions:
                    return '/boot'
            
            # Priority assignment if no clear labels
            elif '/' not in used_suggestions:
                return '/'
            elif '/boot' not in used_suggestions and fstype in ['ext2', 'ext3', 'ext4']:
                return '/boot'
            elif '/home' not in used_suggestions:
                return '/home'

        return None

    def execute_chroot(self):
        """Executes the chroot"""
        subprocess.run(['chroot', self.mount_point], check=True)

    def execute_gparted(self):
        """Executes GParted using the absolute path"""
        try:
            subprocess.Popen(['pkexec', '/usr/sbin/gparted'])
        except Exception as e:
            self.logger.error(STRINGS[self.current_lang]['messages'].get('gparted_error', f"Error executing GParted: {e}"))

    def _validate_mounted_system(self):
        """Checks if the mounted system is a valid Linux

        Returns:
            bool: True if the system looks like a valid Linux, False otherwise
        """
        # Check essential directories and files that should exist in a Linux system
        essential_paths = [
            '/bin', '/usr/bin', '/lib', '/usr/lib', 
            '/etc/fstab', '/etc/passwd', '/etc/shadow'
        ]
        
        # At least one shell must exist
        shell_paths = ['/bin/bash', '/bin/sh', '/usr/bin/bash', '/usr/bin/sh']
        
        # Verify essential directories
        essential_found = 0
        for path in essential_paths:
            full_path = os.path.join(self.mount_point, path.lstrip('/'))
            if os.path.exists(full_path):
                essential_found += 1
        
        # Verify if there is at least one shell
        shell_found = False
        for shell in shell_paths:
            full_path = os.path.join(self.mount_point, shell.lstrip('/'))
            if os.path.exists(full_path):
                shell_found = True
                break
        
        # We consider it valid if there are at least 3 essential directories/files and a shell
        return essential_found >= 3 and shell_found

    def unmount_all(self):
        """Unmounts all partitions and virtual filesystems"""
        try:
            # Create a script to safely unmount everything
            unmount_script = f"""#!/bin/bash
# Function to safely unmount a mount point
safe_umount() {{
    local mount_point="$1"
    if mount | grep -q " on $mount_point "; then
        echo "{STRINGS[self.current_lang]['chroot'].get('unmounting', 'Unmounting')} $mount_point..."
        umount -l "$mount_point" || umount -f "$mount_point" || true
    fi
}}

# Unmount virtual filesystems in reverse order
safe_umount {self.mount_point}/dev/pts
safe_umount {self.mount_point}/dev
safe_umount {self.mount_point}/proc
safe_umount {self.mount_point}/sys
safe_umount {self.mount_point}/boot/efi
safe_umount {self.mount_point}/boot
safe_umount {self.mount_point}

echo "{STRINGS[self.current_lang]['chroot'].get('unmount_complete', 'Unmount completed')}"
"""
            # Execute the unmount script
            with open('/tmp/unmount.sh', 'w') as f:
                f.write(unmount_script)
            os.chmod('/tmp/unmount.sh', 0o755)
            
            subprocess.run(['sudo', '/tmp/unmount.sh'], check=False)
            return True
        except Exception as e:
            # CHANGED: error message to English and use STRINGS
            self.logger.error(STRINGS[self.current_lang]['messages'].get('error_unmounting', f"Error unmounting the system: {e}"))
            return False

    def mount_and_chroot(self, root_part, boot_part=None, efi_part=None, root_subvol=None, home_part=None, home_subvol=None):
        """Mounts and chroots with improved debugging and error handling"""
        try:
            print(f"DEBUG: Starting mount - root={root_part}, boot={boot_part}, efi={efi_part}")
            print(f"DEBUG: Subvolumes - root_subvol={root_subvol}, home_subvol={home_subvol}")
            
            # Limpiar montajes previos
            self.unmount_all()
            
            # Crear directorio de montaje
            result = subprocess.run(['sudo', 'mkdir', '-p', self.mount_point], 
                                  capture_output=True, text=True)
            if result.returncode != 0:
                raise Exception(f"Could not create directory {self.mount_point}: {result.stderr}")
            print(f"DEBUG: Mounting root partition {root_part}")
            
            # ARREGLO: Montar partición raíz CON subvolumen si es btrfs
            if root_subvol:
                mount_cmd = ['sudo', 'mount', '-t', 'btrfs', '-o', f'subvol={root_subvol}', root_part, self.mount_point]
                print(f"DEBUG: Mounting with btrfs subvolume: {root_subvol}")
            else:
                mount_cmd = ['sudo', 'mount', root_part, self.mount_point]
                print(f"DEBUG: Mounting without subvolume")
            print(f"DEBUG: Root mount command: {' '.join(mount_cmd)}")
            result = subprocess.run(mount_cmd, capture_output=True, text=True)
            if result.returncode != 0:
                error_msg = f"Error mounting {root_part}: {result.stderr}"
                print(f"DEBUG: {error_msg}")
                raise Exception(error_msg)
            print(f"DEBUG: Root partition mounted successfully")
            
            # ARREGLO: Verificar contenido después del montaje
            print(f"DEBUG: Contenido de {self.mount_point}:")
            try:
                ls_result = subprocess.run(['ls', '-la', self.mount_point], capture_output=True, text=True)
                print(ls_result.stdout)
            except:
                pass

            # Montar /boot si existe
            if boot_part:
                print(f"DEBUG: Montando /boot {boot_part}")
                boot_dir = os.path.join(self.mount_point, 'boot')
                subprocess.run(['sudo', 'mkdir', '-p', boot_dir], check=True)
                result = subprocess.run(['sudo', 'mount', boot_part, boot_dir], 
                                      capture_output=True, text=True)
                if result.returncode != 0:
                    print(f"WARNING: Could not mount /boot {boot_part}: {result.stderr}")
            # Montar /boot/efi si existe
            if efi_part:
                print(f"DEBUG: Montando /boot/efi {efi_part}")
                efi_dir = os.path.join(self.mount_point, 'boot', 'efi')
                subprocess.run(['sudo', 'mkdir', '-p', efi_dir], check=True)
                result = subprocess.run(['sudo', 'mount', efi_part, efi_dir], 
                                      capture_output=True, text=True)
                if result.returncode != 0:
                    print(f"WARNING: Could not mount /boot/efi {efi_part}: {result.stderr}")
            # Montar /home si existe
            if home_part:
                print(f"DEBUG: Montando /home {home_part}")
                home_dir = os.path.join(self.mount_point, 'home')
                subprocess.run(['sudo', 'mkdir', '-p', home_dir], check=True)
                
                if home_subvol:
                    home_mount_cmd = ['sudo', 'mount', '-t', 'btrfs', '-o', f'subvol={home_subvol}', home_part, home_dir]
                else:
                    home_mount_cmd = ['sudo', 'mount', home_part, home_dir]
                    
                result = subprocess.run(home_mount_cmd, capture_output=True, text=True)
                if result.returncode != 0:
                    print(f"WARNING: Could not mount /home {home_part}: {result.stderr}")

            print(f"DEBUG: Mounting virtual filesystems")
            
            # Montar sistemas virtuales con mejor manejo de errores
            virtual_mounts = [
                ('/dev', 'dev'),
                ('/proc', 'proc'), 
                ('/sys', 'sys'),
                ('/dev/pts', 'dev/pts')
            ]
            
            for source, target in virtual_mounts:
                target_path = os.path.join(self.mount_point, target)
                subprocess.run(['sudo', 'mkdir', '-p', target_path], check=True)
                result = subprocess.run(['sudo', 'mount', '--bind', source, target_path], 
                                      capture_output=True, text=True)
                if result.returncode != 0:
                    print(f"WARNING: Could not mount {source}: {result.stderr}")

            # Copiar resolv.conf solo si existe /etc
            etc_path = os.path.join(self.mount_point, 'etc')
            if os.path.exists(etc_path):
                try:
                    subprocess.run(['sudo', 'cp', '/etc/resolv.conf', 
                                  os.path.join(self.mount_point, 'etc/resolv.conf')], 
                                  check=False)
                except:
                    pass
            else:
                print(f"WARNING: /etc directory does not exist in {self.mount_point}")
            print(f"DEBUG: Checking for valid system")
            # Verificar que el sistema es válido
            if not self._validate_mounted_system():
                print(f"DEBUG: Current contents of {self.mount_point}:")
                try:
                    ls_result = subprocess.run(['ls', '-la', self.mount_point], capture_output=True, text=True)
                    print(ls_result.stdout)
                except:
                    pass
                
                print(f"DEBUG: Checking essential paths:")
                essential_paths = ['/bin', '/usr/bin', '/lib', '/usr/lib', '/etc']
                for path in essential_paths:
                    full_path = os.path.join(self.mount_point, path.lstrip('/'))
                    exists = os.path.exists(full_path)
                    print(f"  {path}: {'✓' if exists else '✗'}")
                # CHANGED: error message to English and use STRINGS
                raise Exception(STRINGS[self.current_lang]['messages'].get('invalid_linux', "Mounted system does not appear to be a valid Linux - essential files not found"))
            print(f"DEBUG: Valid system, opening terminal")
            # Abrir terminal
            self._open_chroot_terminal()

        except Exception as e:
            print(f"DEBUG: Error in mount_and_chroot: {e}")
            self.unmount_all()
            raise e

    def _open_chroot_terminal(self):
        """Opens chroot terminal with improved detection - KONSOLE first in Tyson"""
        # Detectar idioma y textos
        lang = self.current_lang if self.current_lang in STRINGS else 'en'
        strings = STRINGS[lang]
        chroot_title = strings['chroot'].get('terminal_title', 'CHROOT Recovery Environment')
        mount_msg = strings['chroot'].get('mounting_content', 'Mount point contents:')
        exit_msg = strings['chroot'].get('exit_message', "Type 'exit' to leave")
        separator = '=' * 34

        # Script de chroot internacionalizado
        chroot_script = f"""#!/bin/bash
echo "{separator}"
echo "{chroot_title}"
echo "{mount_msg} {self.mount_point}"
echo "{exit_msg}"
echo "{separator}"

# Detectar shell disponible
if [ -x "{self.mount_point}/bin/bash" ]; then
    SHELL_CMD="/bin/bash"
elif [ -x "{self.mount_point}/usr/bin/bash" ]; then
    SHELL_CMD="/usr/bin/bash"
else
    SHELL_CMD="/bin/sh"
fi

# Entrar al chroot
sudo chroot {self.mount_point} $SHELL_CMD

# Limpiar al salir
echo "Limpiando montajes..."
sudo umount -l {self.mount_point}/dev/pts 2>/dev/null || true
sudo umount -l {self.mount_point}/dev 2>/dev/null || true
sudo umount -l {self.mount_point}/proc 2>/dev/null || true
sudo umount -l {self.mount_point}/sys 2>/dev/null || true
sudo umount -l {self.mount_point}/boot/efi 2>/dev/null || true
sudo umount -l {self.mount_point}/boot 2>/dev/null || true
sudo umount -l {self.mount_point}/home 2>/dev/null || true
sudo umount -l {self.mount_point} 2>/dev/null || true
echo "Limpieza completada"
"""
        
        # Escribir y ejecutar script
        with open('/tmp/chroot_recovery.sh', 'w') as f:
            f.write(chroot_script)
        os.chmod('/tmp/chroot_recovery.sh', 0o755)
        
        # ARREGLO: KITTY con variables de entorno para evitar errores de systemd
        env = os.environ.copy()
        env.update({
            'NO_AT_BRIDGE': '1',
            'DBUS_SESSION_BUS_ADDRESS': '',
            'XDG_RUNTIME_DIR': f"/run/user/{os.getuid()}",
            'DISPLAY': ':0'
        })
        
        terminals = [
            ['konsole', '--title', 'CHROOT Recovery', '-e', 'bash', '/tmp/chroot_recovery.sh'],
            ['xterm', '-title', 'CHROOT Recovery', '-e', 'bash', '/tmp/chroot_recovery.sh']
        ]
        
        for cmd in terminals:
            try:
                subprocess.Popen(cmd, start_new_session=True, env=env,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                print(f"Terminal abierto: {cmd[0]}")
                return
            except FileNotFoundError:
                continue
        
        # CHANGED: error message to English and use STRINGS
        raise Exception(STRINGS[self.current_lang]['messages'].get('no_terminal', "No available terminal found"))
            

    def _is_mountable_filesystem(self, fstype):
        """Check if a filesystem type is mountable for chroot"""
        mountable_fs = {
            'ext2', 'ext3', 'ext4', 'btrfs', 'xfs', 'jfs', 'reiserfs',
            'vfat', 'fat32', 'ntfs', 'exfat', 'f2fs'
        }
        non_mountable = {'swap', 'extended', 'LVM2_member', 'crypto_LUKS'}
        return fstype.lower() in mountable_fs and fstype.lower() not in non_mountable
