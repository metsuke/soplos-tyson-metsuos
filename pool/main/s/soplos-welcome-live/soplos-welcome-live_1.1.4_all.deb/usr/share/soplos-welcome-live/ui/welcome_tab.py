import gi
import webbrowser
import subprocess
import os
import sys

# Add the root directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf
from config.strings import STRINGS
from config.paths import SLIDE_PATH, WEBSITE_URL, FORUM_URL, WIKI_URL, DONATE_URL

# Dictionary of languages and their configurations
LANGUAGES = {
    STRINGS['es']['languages']['spanish']: {'locale': 'es_ES.UTF-8', 'layout': 'es'},
    STRINGS['en']['languages']['english']: {'locale': 'en_US.UTF-8', 'layout': 'us'},
    STRINGS['pt']['languages']['portuguese']: {'locale': 'pt_PT.UTF-8', 'layout': 'pt'},
    STRINGS['fr']['languages']['french']: {'locale': 'fr_FR.UTF-8', 'layout': 'fr'},
    STRINGS['de']['languages']['german']: {'locale': 'de_DE.UTF-8', 'layout': 'de'},
    STRINGS['it']['languages']['italian']: {'locale': 'it_IT.UTF-8', 'layout': 'it'},
    STRINGS['ro']['languages']['romanian']: {'locale': 'ro_RO.UTF-8', 'layout': 'ro'},
    STRINGS['ru']['languages']['russian']: {'locale': 'ru_RU.UTF-8', 'layout': 'ru'}
}

class WelcomeTab(Gtk.ScrolledWindow):
    def __init__(self, parent_window):
        Gtk.ScrolledWindow.__init__(self)
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        self.parent_window = parent_window  # Store reference to the main window
        self.current_lang = self.parent_window.current_lang  # Store language as instance attribute
        
        self._init_ui()
    
    def _init_ui(self):
        # Use language as instance attribute instead of local variable
        
        # Main container
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        main_box.set_border_width(0)

        try:
            # Use SLIDE_PATH instead of absolute path
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                filename=SLIDE_PATH,
                width=800,
                height=160,
                preserve_aspect_ratio=True
            )
            slide_image = Gtk.Image.new_from_pixbuf(pixbuf)
            main_box.pack_start(slide_image, False, False, 0)
        except Exception as e:
            print(f"{STRINGS[self.current_lang]['errors']['slide_load']}: {e}")
        
        # Welcome message without expand
        welcome_label = Gtk.Label()
        welcome_label.set_markup(
            f"<span size='xx-large' weight='bold'>{STRINGS[self.current_lang]['live_iso']['title']}</span>\n" +
            f"<span size='large'>{STRINGS[self.current_lang]['live_iso']['description']}</span>"
        )
        welcome_label.set_line_wrap(True)
        welcome_label.set_justify(Gtk.Justification.CENTER)
        welcome_label.set_margin_top(0)
        welcome_label.set_margin_bottom(0)
        main_box.pack_start(welcome_label, False, False, 0)  # expand and fill set to False

        # Container for buttons
        buttons_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        buttons_box.set_margin_top(20)
        buttons_box.set_homogeneous(True)
        main_box.pack_start(buttons_box, False, True, 0)

        # Link buttons with translated texts
        website_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['website'])
        website_button.connect("clicked", lambda x: webbrowser.open(WEBSITE_URL))
        buttons_box.pack_start(website_button, True, True, 10)

        forum_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['forums'])
        forum_button.connect("clicked", lambda x: webbrowser.open(FORUM_URL))
        buttons_box.pack_start(forum_button, True, True, 10)

        wiki_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['wiki'])
        wiki_button.connect("clicked", lambda x: webbrowser.open(WIKI_URL))
        buttons_box.pack_start(wiki_button, True, True, 10)

        donate_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['donate'])
        donate_button.connect("clicked", lambda x: webbrowser.open(DONATE_URL))
        buttons_box.pack_start(donate_button, True, True, 10)

        self.add(main_box)  # Only add main_box once to the ScrolledWindow

    def on_language_changed(self, combo):
        lang_name = combo.get_active_text()
        lang_config = LANGUAGES[lang_name]
        
        # Update current language when changed
        self.current_lang = lang_config['locale'].split('_')[0]
        
        try:
            # Generate and apply locale
            subprocess.run(['pkexec', 'locale-gen', lang_config['locale']], check=True)
            subprocess.run(['pkexec', 'update-locale', f"LANG={lang_config['locale']}"], check=True)
            
            # Configure keyboard layout
            # First for the current session
            subprocess.run(['setxkbmap', lang_config['layout']], check=True)
            
            # Make the change permanent
            xorg_conf = STRINGS[self.current_lang]['system']['xorg_keyboard_template'].format(layout=lang_config['layout'])
            
            # Create directory if it doesn't exist
            os.makedirs(STRINGS[self.current_lang]['system']['xorg_conf_dir'], exist_ok=True)
            
            # Write configuration
            subprocess.run(['pkexec', 'bash', '-c', 
                         f'echo \'{xorg_conf}\' > {STRINGS[self.current_lang]["system"]["keyboard_conf_file"]}'],
                       check=True)
            
            # Restart SDDM
            subprocess.run(['pkexec', 'systemctl', 'restart', 'sddm'], check=True)
            
        except subprocess.CalledProcessError as e:
            print(f"{STRINGS[self.current_lang]['errors']['language_config']}: {e}")
            subprocess.run(['pkexec', 'systemctl', 'restart', 'sddm'], check=True)
            
        except subprocess.CalledProcessError as e:
            print(f"{STRINGS[self.current_lang]['errors']['language_config']}: {e}")
