STRINGS_DE = {
    'welcome': 'Soplos Linux',
    'welcome_desc': 'Die Linux-Distribution für Sie!',
    'version': 'Tyron Live 2023.2',
    'buttons': {
        'exit': '_Beenden',
        'website': 'Webseite',
        'forums': 'Foren',
        'wiki': 'Wiki',
        'donate': 'Spenden',
        'install': 'Soplos _Linux installieren',
        'chroot': 'System mit _CHROOT wiederherstellen',
        'open_gparted': '_GParted öffnen',
        'close': '_Schließen',
        'next': '_Weiter',
        'cancel': '_Abbrechen',
        'mount': '_Einbinden'
    },
    'dialog': {
        'exit_title': 'Sind Sie sicher, dass Sie beenden möchten?',
        'exit_desc': 'Das Willkommensprogramm wird geschlossen.',
        'error': 'Fehler',
        'select_disk': 'Bitte wählen Sie eine Festplatte aus',
        'select_root': 'Sie müssen eine Root-Partition (/) auswählen',
        'no_partitions': 'Keine Partitionen auf dieser Festplatte gefunden',
        'partition_header': 'Wählen Sie die zu mountenden Partitionen aus:',
        'mounting': 'Einbinden der Partitionen',
        'invalid_partition': 'Ungültige Partition',
        'invalid_partition_desc': 'Die ausgewählte Partition enthält kein gültiges Linux-System oder ist beschädigt.',
        'mount_error': 'Mount-Fehler',
        'mount_error_desc': 'Die ausgewählten Partitionen konnten nicht eingebunden werden.'
    },
    'locale': {
        'error_generating': 'Fehler beim Generieren der Locales:',
        'error_updating': 'Fehler beim Setzen der Standard-Locale:',
        'error_restart': 'Fehler beim Neustart von SDDM',
        'not_found_locale_gen': 'locale-gen Befehl nicht gefunden.\nBitte installieren Sie das Paket locales.',
        'not_found_update_locale': 'update-locale nicht gefunden',
        'restart_session_title': 'Änderungen angewendet',
        'restart_session_desc': 'Damit alle Änderungen vollständig wirksam werden, wird empfohlen, sich abzumelden und erneut anzumelden.'
    },
    'chroot': {
        'title': 'CHROOT Wiederherstellung',
        'select_disk': 'Systemfestplatte auswählen',
        'open_gparted': 'GParted öffnen',
        'select_partitions': 'Partitionen auswählen',
        'mount': 'Einbinden',
        'cancel': 'Abbrechen',
        'terminal_title': 'Soplos Linux CHROOT-Wiederherstellungsumgebung',
        'welcome_message': 'Sie haben eine Chroot-Umgebung betreten, um Ihr System wiederherzustellen.',
        'instructions': 'Sie können Befehle wie Updates, Neuinstallation des Bootmanagers oder andere Reparaturen ausführen.',
        'exit_message': 'Um die Chroot-Umgebung zu verlassen, geben Sie \'exit\' ein oder drücken Sie Ctrl+D.',
        'mounting_partitions': 'Partitionen werden eingebunden...',
        'mounting_root': 'Einbinden der Root-Partition',
        'mounting_boot': 'Einbinden der /boot-Partition',
        'mounting_efi': 'Einbinden der EFI-Partition',
        'mounting_virtual': 'Einbinden virtueller Dateisysteme',
        'exit_chroot': 'Sie haben die Chroot-Umgebung verlassen.',
        'unmounting': 'Aushängen',
        'unmount_complete': 'Alle Partitionen wurden erfolgreich ausgehängt.',
        'cleanup_question': 'Möchten Sie das Verzeichnis {} entfernen? [j/N]: ',
        'process_complete': 'Chroot-Prozess abgeschlossen.',
        'chroot_started': 'Chroot erfolgreich gestartet',
        'mounting_content': 'Inhalt des Einhängepunkts:',
        'using_shell': 'Shell wird verwendet:',
        'starting_chroot': 'Chroot-Umgebung wird gestartet...',
        'mount_point_label': 'Einhängepunkt',
        'root_partition_label': 'Root-Partition',
        'creating_dirs': 'Erstellen von Verzeichnissen für Bind-Mounts',
        'creating_boot_dir': 'Erstellen des Verzeichnisses /boot',
        'creating_efi_dir': 'Erstellen des Verzeichnisses /boot/efi',
        'bin_content': 'Inhalt von /bin',
        'usr_bin_content': 'Inhalt von /usr/bin',
        'still_mounted': 'Dateisysteme noch eingehängt',
        'mount_boot_error': 'ERROR: Kann {} nicht in {}/boot einhängen',
        'mount_efi_error': 'ERROR: Kann {} nicht in {}/boot/efi einhängen'
    },
    'autostart': 'Beim Start anzeigen:',
    'labels': {
        'language': 'Sprache:',
        'show_startup': 'Beim Start anzeigen:',
        'device': 'Gerät',
        'size': 'Größe',
        'model': 'Modell',
        'filesystem': 'Dateisystem',
        'mountpoint': 'Einhängepunkt',
        'select_option': '-- Auswählen --',
        'unknown': 'Unbekannt'
    },
    'live_iso': {
        'title': 'Live ISO',
        'description': 'Diese Live-Version ermöglicht es Ihnen, Soplos Linux\nzu testen, ohne etwas auf Ihrem Computer zu installieren.\nWenn Sie bereit sind, verwenden Sie die orangefarbene Schaltfläche, um es zu installieren.'
    },
    'thanks': 'Danke, dass Sie Soplos Linux ausprobiert haben!',
    'messages': {
        'selected_disk': 'Ausgewählte Festplatte: {}',
        'error_loading_disks': 'Fehler beim Laden der Festplatten',
        'error_loading_partitions': 'Fehler beim Abrufen der Partitionen',
        'error_mounting': 'Fehler beim Einbinden der Partitionen',
        'error_unmounting': 'Fehler beim Aushängen des Systems',
        'mount_point_error': 'ERROR: Kann den Einhängepunkt nicht erstellen',
        'mount_root_error': 'ERROR: Kann nicht einhängen',
        'in': 'in',
        'completed': 'abgeschlossen',
        'mount_dev_error': 'ERROR: Kann /dev nicht einhängen in',
        'mount_proc_error': 'ERROR: Kann /proc nicht einhängen in',
        'mount_sys_error': 'ERROR: Kann /sys nicht einhängen in',
        'mount_pts_error': 'ERROR: Kann /dev/pts nicht einhängen in',
        'resolv_copy_error': 'Kann resolv.conf nicht kopieren',
        'no_shell_error': 'ERROR: Keine gültige Shell im gemounteten System gefunden',
        'unmount_warning': 'WARNUNG: Einige Einhängepunkte konnten nicht ausgehängt werden.',
        'restart_needed': 'Ein Neustart des Systems ist möglicherweise erforderlich, um diese Ressourcen freizugeben.',
        'directory_removed': 'Verzeichnis entfernt',
        'directory_remove_error': 'Kann nicht entfernen',
        'directory_kept': 'Verzeichnis behalten',
        'mount_point_missing': 'ERROR: Der Einhängepunkt existiert nicht',
        'shell_not_found': 'ERROR: Keine gültige Shell im gemounteten System gefunden',
        'lsblk_error': 'Fehler beim Ausführen von lsblk',
        'gparted_error': 'Fehler beim Ausführen von GParted',
        'mount_result': 'Ergebnis der Einbindung:',
        'konsole_error': 'Fehler beim Starten von konsole',
        'xterm_error': 'Fehler beim Starten von xterm',
        'first_start_detected': 'Erster Start erkannt, Neustart-Überprüfung übersprungen',
        'first_start_error': 'Fehler beim Markieren des ersten Starts: {}',
        'restart_detected': 'Neustart für Sprachänderung erkannt, Konfiguration wird angewendet...',
        'keyboard_config_warning': 'Warnung: Tastatur-/Locale-Konfiguration konnte nicht angewendet werden',
        'restarting_session': 'Sitzung wird neu gestartet...',
        'restarting_sddm': 'SDDM wird neu gestartet, um Sprachänderungen anzuwenden...',
        'icon_error': 'Fehler beim Setzen des Icons: {}',
        'desktop_info': 'Desktop-Umgebung: {}, Sitzungstyp: {}',
        'logo_error': 'Fehler beim Laden des Logos: {}',
        'locale_config_error': 'Fehler beim Konfigurieren der System-Locale',
        'robust_locale_error': 'Fehler in der robusten Locale-Konfiguration',
        'robust_autologin_error': 'Fehler beim Konfigurieren des robusten Autologin',
        'restarting_sddm_script': 'SDDM wird neu gestartet, um Sprachänderungen anzuwenden...',
        'robust_restart_error': 'Fehler beim robusten Neustart',
        'sddm_config_error': 'Fehler beim Ändern von /etc/sddm.conf',
        'kde_command_error': 'Fehler beim Ausführen von {}: {}',
        'kde_config_error': 'Fehler beim Neuladen der KDE-Konfiguration',
        'app_title': 'Soplos Welcome Live',
        'autostart_create_error': 'Fehler: Die Autostart-Datei konnte nicht erstellt werden',
        'autostart_enable_error': 'Fehler beim Aktivieren des Autostarts: {}',
        'autostart_enabled': 'Autostart aktiviert: {} -> {}',
        'desktop_file_not_found': 'Fehler: .desktop-Datei wurde an keinem bekannten Ort gefunden',
        'basic_desktop_created': 'Basis-Desktop-Datei als Backup erstellt',
        'basic_desktop_error': 'Fehler beim Erstellen der Basis-Desktop-Datei: {}',
        # New messages for desktop_detector.py
        'wayland_session': 'Sitzung erkannt: Wayland',
        'x11_session': 'Sitzung erkannt: X11',
        'unknown_session': 'Sitzungstyp konnte nicht ermittelt werden, X11 wird als Standard verwendet',
        'autologin_check_error': 'Fehler beim Überprüfen des Autologins: {}',
        'autologin_found': 'Autologin gefunden in {file_path} für Benutzer: {user}',
        'autologin_file_error': 'Fehler beim Lesen von {file_path}: {error}',
        'kde_restore_error': 'Fehler beim Wiederherstellen der KDE-Konfiguration: {}',
        'kde_backup_error': 'Fehler beim Sichern der KDE-Konfiguration: {}',
        'backed_up': '{src} -> {dst} gesichert',
        'restored': '{src} -> {dst} wiederhergestellt'
    },
    'progress': {
        'configuring': 'Sprache wird konfiguriert...'
    },
    'commands': {
        'gparted': 'sudo gparted',
        'calamares_sudo': 'sudo',
        'calamares': 'calamares'
    },
    'errors': {
        'slide_load': 'Fehler beim Laden der Folie',
        'language_config': 'Fehler bei der Konfiguration der Sprache'
    },
    'system': {
        'xorg_conf_dir': '/etc/X11/xorg.conf.d',
        'keyboard_conf_file': '/etc/X11/xorg.conf.d/00-keyboard.conf',
        'xorg_keyboard_template': """Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection"""
    },
    'templates': {
        'basic_desktop_file': """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Willkommensbildschirm für die Live-Umgebung von Soplos Linux
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
"""
    },
    'session_manager': {
        'using_temp_dir': 'Verwende temporäres Verzeichnis für Konfiguration: {}',
        'error_creating_config_dir': 'Fehler beim Erstellen des Konfigurationsverzeichnisses: {}',
        'first_run_marked': 'Erster Start markiert - automatischer Neustart wird vermieden',
        'error_first_run_marker': 'Fehler beim Erstellen des Erstes-Mal-Markers: {}',
        'error_configuring_autologin': 'Fehler: Autologin konnte nicht konfiguriert werden',
        'saving_autostart_state': 'Speichere aktivierten Autostart-Status für Wiederherstellung nach Neustart',
        'restart_request_created': 'Neustartanforderungsdatei erfolgreich erstellt',
        'error_creating_restart_file': 'Fehler beim Erstellen der Neustartanforderungsdatei: {}',
        'executing_sddm_restart': 'Führe SDDM-Neustart in {}-Sitzung aus...',
        'critical_sddm_restart_error': 'Kritischer Fehler beim Neustart von SDDM: {}',
        'copying_dir': 'Kopiere Verzeichnis {} nach {}',
        'error_reloading_kde': 'Fehler beim Neuladen der KDE-Konfiguration: {}',
        'error_restoring_theme': 'Fehler beim Wiederherstellen des Themes aus skel: {}',
        'error_configuring_locale': 'Fehler beim Konfigurieren der Systemlocale: {}',
        # New strings added
        'no_restart_request': 'Keine explizite Neustartanforderung, automatischer Neustart wird vermieden',
        'restoring_autostart': 'Autostart nach Neustart wird wiederhergestellt...',
        'error_tmp_state': 'Fehler beim Überprüfen des Status in /tmp: {}',
        'locale_mismatch': 'Aktuelle Locale ({}) stimmt nicht mit gespeicherter ({}) überein',
        'error_verifying_locale': 'Fehler beim Überprüfen der Locale-Anwendung: {}',
        'skel_dir_missing': 'Das Verzeichnis {} existiert nicht',
        'timeout_warning': 'Das Konfigurationsskript hat zu lange gedauert, könnte aber funktioniert haben',
        'error_ensuring_autologin': 'Fehler beim Sicherstellen des Autologins: {}'
    },
    'xdg': {
        'updating_directories': 'XDG-Verzeichnisse für Locale aktualisieren: {}',
        'backup_created': 'Backup von user-dirs.dirs erstellt',
        'file_deleted': 'user-dirs.dirs Datei für Regeneration gelöscht',
        'running_update': 'xdg-user-dirs-update --force wird ausgeführt...',
        'result': 'Ergebnis: {}',
        'errors': 'Fehler: {}',
        'not_created': 'Fehler: user-dirs.dirs wurde nicht erstellt',
        'restored_backup': 'Aus Backup wiederhergestellt',
        'updating_gtk': 'GTK-Konfiguration wird aktualisiert...',
        'updating_references': 'Verzeichnisreferenzen in der Desktop-Umgebung werden aktualisiert...',
        'file_content': 'Inhalt von user-dirs.dirs:\n{}',
        'error_updating': 'Fehler beim Aktualisieren der XDG-Verzeichnisse: {}',
        'renaming_directories': 'Verzeichnisse für Sprache umbenennen: {}',
        'no_mapping': 'Keine Verzeichniszuordnung für Sprache: {}',
        'both_exist': 'Beide Verzeichnisse existieren. Inhalt wird migriert: {} → {}',
        'content_migrated': 'Inhalt migriert und Verzeichnis {} gelöscht',
        'error_consolidating': 'Fehler beim Konsolidieren der Verzeichnisse: {}',
        'renaming': 'Umbenennung: {} → {}',
        'error_renaming': 'Fehler beim Umbenennen von {}: {}',
        'destination_exists': 'Das Zielverzeichnis {} existiert bereits, es bleibt',
        'neither_exists': 'Keines der Verzeichnisse existiert: {} noch {}',
        'general_error': 'Allgemeiner Fehler beim Umbenennen der Verzeichnisse: {}',
        'error_kde_references': 'Fehler beim Aktualisieren der KDE-Referenzen: {}',
        'generating_config': 'XDG-Konfiguration für Locale wird generiert: {}',
        'config_generated': 'XDG-Konfiguration generiert in: {}',
        'error_generating_config': 'Fehler beim Generieren der XDG-Konfiguration: {}'
    }
}
