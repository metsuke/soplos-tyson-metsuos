STRINGS_FR = {
    'welcome': 'Soplos Linux',
    'welcome_desc': 'La distribution Linux faite pour vous !',
    'version': 'Tyron Live 2023.2',
    'buttons': {
        'exit': '_Quitter',
        'website': 'Site Web',
        'forums': 'Forums',
        'wiki': 'Wiki',
        'donate': 'Faire un don',
        'install': 'Installer Soplos _Linux',
        'chroot': 'Récupérer le système avec _CHROOT',
        'open_gparted': 'Ouvrir _GParted',
        'close': '_Fermer',
        'next': '_Suivant',
        'cancel': '_Annuler',
        'mount': '_Monter'
    },
    'dialog': {
        'exit_title': 'Êtes-vous sûr de vouloir quitter ?',
        'exit_desc': 'Le programme de bienvenue se fermera.',
        'error': 'Erreur',
        'select_disk': 'Veuillez sélectionner un disque',
        'select_root': 'Vous devez sélectionner une partition racine (/)',
        'no_partitions': 'Aucune partition trouvée sur ce disque',
        'partition_header': 'Sélectionnez les partitions à monter :',
        'mounting': 'Montage des partitions',
        'invalid_partition': 'Partition non valide',
        'invalid_partition_desc': 'La partition sélectionnée ne contient pas un système Linux valide ou est endommagée.',
        'mount_error': 'Erreur de montage',
        'mount_error_desc': 'Impossible de monter les partitions sélectionnées.'
    },
    'locale': {
        'error_generating': 'Erreur lors de la génération des locales :',
        'error_updating': 'Erreur lors de la définition de la locale par défaut :',
        'error_restart': 'Erreur lors du redémarrage de SDDM',
        'not_found_locale_gen': 'Commande locale-gen introuvable.\nVeuillez installer le paquet locales.',
        'not_found_update_locale': 'update-locale introuvable',
        'restart_session_title': 'Modifications appliquées',
        'restart_session_desc': 'Pour que toutes les modifications prennent pleinement effet, il est recommandé de se déconnecter et de se reconnecter.'
    },
    'chroot': {
        'title': 'Récupération CHROOT',
        'select_disk': 'Sélectionnez le disque système',
        'open_gparted': 'Ouvrir GParted',
        'select_partitions': 'Sélectionner les partitions',
        'mount': 'Monter',
        'cancel': 'Annuler',
        'terminal_title': 'Environnement de récupération CHROOT Soplos Linux',
        'welcome_message': 'Vous êtes entré dans un environnement chroot pour récupérer votre système.',
        'instructions': 'Vous pouvez exécuter des commandes telles que des mises à jour, réinstaller\nle gestionnaire de démarrage ou toute autre réparation.',
        'exit_message': 'Pour quitter l\'environnement chroot, tapez \'exit\' ou appuyez sur Ctrl+D.',
        'mounting_partitions': 'Montage des partitions...',
        'mounting_root': 'Montage de la partition racine',
        'mounting_boot': 'Montage de la partition /boot',
        'mounting_efi': 'Montage de la partition EFI',
        'mounting_virtual': 'Montage des systèmes de fichiers virtuels',
        'exit_chroot': 'Vous avez quitté l\'environnement chroot.',
        'unmounting': 'Démontage',
        'unmount_complete': 'Toutes les partitions ont été démontées correctement.',
        'cleanup_question': 'Voulez-vous supprimer le répertoire de montage {}? [o/N]: ',
        'process_complete': 'Processus de chroot terminé.',
        'chroot_started': 'Chroot démarré avec succès',
        'mounting_content': 'Contenu du point de montage:',
        'using_shell': 'Utilisation du shell:',
        'starting_chroot': 'Démarrage de l\'environnement chroot...',
        'mount_point_label': 'Point de montage',
        'root_partition_label': 'Partition racine',
        'creating_dirs': 'Création de répertoires pour les montages bind',
        'creating_boot_dir': 'Création du répertoire /boot',
        'creating_efi_dir': 'Création du répertoire /boot/efi',
        'bin_content': 'Contenu de /bin',
        'usr_bin_content': 'Contenu de /usr/bin',
        'still_mounted': 'Systèmes de fichiers encore montés',
        'mount_boot_error': 'ERROR: Impossible de monter {} dans {}/boot',
        'mount_efi_error': 'ERROR: Impossible de monter {} dans {}/boot/efi'
    },
    'autostart': 'Afficher au démarrage:',
    'labels': {
        'language': 'Langue :',
        'show_startup': 'Afficher au démarrage :',
        'device': 'Appareil',
        'size': 'Taille',
        'model': 'Modèle',
        'filesystem': 'Système de fichiers',
        'mountpoint': 'Point de montage',
        'select_option': '-- Sélectionner --',
        'unknown': 'Inconnu'
    },
    'live_iso': {
        'title': 'Live ISO',
        'description': 'Cette version Live vous permet d\'essayer Soplos Linux\nsans rien installer sur votre ordinateur.\nLorsque vous êtes prêt, utilisez le bouton orange pour l\'installer.'
    },
    'thanks': 'Merci d\'avoir essayé Soplos Linux!',
    'messages': {
        'selected_disk': 'Disque sélectionné: {}',
        'error_loading_disks': 'Erreur lors du chargement des disques',
        'error_loading_partitions': 'Erreur lors de l\'obtention des partitions',
        'error_mounting': 'Erreur lors du montage des partitions',
        'error_unmounting': 'Erreur lors du démontage du système',
        'mount_point_error': 'ERROR: Impossible de créer le point de montage',
        'mount_root_error': 'ERROR: Impossible de monter',
        'in': 'dans',
        'completed': 'terminé',
        'mount_dev_error': 'ERROR: Impossible de monter /dev dans',
        'mount_proc_error': 'ERROR: Impossible de monter /proc dans',
        'mount_sys_error': 'ERROR: Impossible de monter /sys dans',
        'mount_pts_error': 'ERROR: Impossible de monter /dev/pts dans',
        'resolv_copy_error': 'Impossible de copier resolv.conf',
        'no_shell_error': 'ERROR: Aucun shell valide trouvé dans le système monté',
        'unmount_warning': 'AVERTISSEMENT: Certains points de montage n\'ont pas pu être démontés.',
        'restart_needed': 'Un redémarrage du système peut être nécessaire pour libérer ces ressources.',
        'directory_removed': 'Répertoire supprimé',
        'directory_remove_error': 'Impossible de supprimer',
        'directory_kept': 'Répertoire conservé',
        'mount_point_missing': 'ERROR: Le point de montage n\'existe pas',
        'shell_not_found': 'ERROR: Aucun shell valide trouvé dans le système monté',
        'lsblk_error': 'Erreur lors de l\'exécution de lsblk',
        'gparted_error': 'Erreur lors de l\'exécution de GParted',
        'mount_result': 'Résultat du montage:',
        'konsole_error': 'Erreur lors du démarrage de konsole',
        'xterm_error': 'Erreur lors du démarrage de xterm',
        'first_start_detected': 'Premier démarrage détecté, saut de la vérification de redémarrage',
        'first_start_error': 'Erreur lors du marquage du premier démarrage: {}',
        'restart_detected': 'Redémarrage détecté pour changement de langue, application de la configuration...',
        'keyboard_config_warning': 'Avertissement: Impossible d\'appliquer la configuration clavier/locale',
        'restarting_session': 'Redémarrage de la session...',
        'restarting_sddm': 'Redémarrage de SDDM pour appliquer les changements de langue...',
        'icon_error': 'Erreur lors de la définition de l\'icône: {}',
        'desktop_info': 'Environnement de bureau: {}, Type de session: {}',
        'logo_error': 'Erreur lors du chargement du logo: {}',
        'locale_config_error': 'Erreur lors de la configuration de la locale système',
        'robust_locale_error': 'Erreur dans la configuration robuste de locale',
        'robust_autologin_error': 'Erreur lors de la configuration de l\'autologin robuste',
        'restarting_sddm_script': 'Redémarrage de SDDM pour appliquer les changements de langue...',
        'robust_restart_error': 'Erreur lors du redémarrage robuste',
        'sddm_config_error': 'Erreur lors de la modification de /etc/sddm.conf',
        'kde_command_error': 'Erreur lors de l\'exécution de {}: {}',
        'kde_config_error': 'Erreur lors du rechargement de la configuration KDE',
        'app_title': 'Soplos Welcome Live',
        'autostart_create_error': 'Erreur: Impossible de créer le fichier de démarrage automatique',
        'autostart_enable_error': 'Erreur lors de l\'activation du démarrage automatique: {}',
        'autostart_enabled': 'Démarrage automatique activé: {} -> {}',
        'desktop_file_not_found': 'Erreur: Fichier .desktop introuvable dans les emplacements connus',
        'basic_desktop_created': 'Création d\'un fichier desktop basique en secours',
        'basic_desktop_error': 'Erreur lors de la création du fichier desktop basique: {}',
        # New messages for desktop_detector.py
        'wayland_session': 'Session détectée: Wayland',
        'x11_session': 'Session détectée: X11',
        'unknown_session': 'Impossible de déterminer le type de session, utilisation de X11 par défaut',
        'autologin_check_error': 'Erreur lors de la vérification de l\'autologin: {}',
        'autologin_found': 'Autologin trouvé dans {file_path} pour l\'utilisateur: {user}',
        'autologin_file_error': 'Erreur lors de la lecture de {file_path}: {error}',
        'kde_restore_error': 'Erreur lors de la restauration de la configuration KDE: {}',
        'kde_backup_error': 'Erreur lors de la sauvegarde de la configuration KDE: {}',
        'backed_up': 'Sauvegardé {src} -> {dst}',
        'restored': 'Restauré {src} -> {dst}'
    },
    'progress': {
        'configuring': 'Configuration de la langue...'
    },
    'commands': {
        'gparted': 'sudo gparted',
        'calamares_sudo': 'sudo',
        'calamares': 'calamares'
    },
    'errors': {
        'slide_load': 'Erreur lors du chargement de la diapositive',
        'language_config': 'Erreur lors de la configuration de la langue'
    },
    'system': {
        'xorg_conf_dir': '/etc/X11/xorg.conf.d',
        'keyboard_conf_file': '/etc/X11/xorg.conf.d/00-keyboard.conf',
        'xorg_keyboard_template': """Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection"""
    },
    'templates': {
        'basic_desktop_file': """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Écran de bienvenue pour l'environnement Live de Soplos Linux
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
"""
    },
    'session_manager': {
        'using_temp_dir': 'Utilisation du répertoire temporaire pour la configuration: {}',
        'error_creating_config_dir': 'Erreur lors de la création du répertoire de configuration: {}',
        'first_run_marked': 'Premier démarrage marqué - le redémarrage automatique sera évité',
        'error_first_run_marker': 'Erreur lors de la création du marqueur de premier démarrage: {}',
        'error_configuring_autologin': 'Erreur: Impossible de configurer l\'autologin',
        'saving_autostart_state': 'Sauvegarde de l\'état d\'autostart activé pour restauration après redémarrage',
        'restart_request_created': 'Fichier de demande de redémarrage créé avec succès',
        'error_creating_restart_file': 'Erreur lors de la création du fichier de demande de redémarrage: {}',
        'executing_sddm_restart': 'Exécution du redémarrage de SDDM en session {}...',
        'critical_sddm_restart_error': 'Erreur critique lors du redémarrage de SDDM: {}',
        'copying_dir': 'Copie du répertoire {} vers {}',
        'error_reloading_kde': 'Erreur lors du rechargement de la configuration KDE: {}',
        'error_restoring_theme': 'Erreur lors de la restauration du thème depuis skel: {}',
        'error_configuring_locale': 'Erreur lors de la configuration de la locale du système: {}',
        # New strings added
        'no_restart_request': 'Pas de demande explicite de redémarrage, évitement du redémarrage automatique',
        'restoring_autostart': 'Restauration du démarrage automatique après redémarrage...',
        'error_tmp_state': 'Erreur lors de la vérification de l\'état dans /tmp: {}',
        'locale_mismatch': 'La locale actuelle ({}) ne correspond pas à celle enregistrée ({})',
        'error_verifying_locale': 'Erreur lors de la vérification de l\'application de la locale: {}',
        'skel_dir_missing': 'Le répertoire {} n\'existe pas',
        'timeout_warning': 'Le script de configuration a pris trop de temps, mais il peut avoir fonctionné',
        'error_ensuring_autologin': 'Erreur lors de la configuration de l\'autologin: {}'
    },
    'xdg': {
        'updating_directories': 'Mise à jour des répertoires XDG pour la locale: {}',
        'backup_created': 'Sauvegarde de user-dirs.dirs créée',
        'file_deleted': 'Fichier user-dirs.dirs supprimé pour régénération',
        'running_update': 'Exécution de xdg-user-dirs-update --force...',
        'result': 'Résultat: {}',
        'errors': 'Erreurs: {}',
        'not_created': 'Erreur: user-dirs.dirs n\'a pas été créé',
        'restored_backup': 'Restauré depuis la sauvegarde',
        'updating_gtk': 'Mise à jour de la configuration GTK...',
        'updating_references': 'Mise à jour des références de répertoires dans l\'environnement de bureau...',
        'file_content': 'Contenu de user-dirs.dirs:\n{}',
        'error_updating': 'Erreur lors de la mise à jour des répertoires XDG: {}',
        'renaming_directories': 'Renommage des répertoires pour la langue: {}',
        'no_mapping': 'Aucun mappage de répertoires pour la langue: {}',
        'both_exist': 'Les deux répertoires existent. Migration du contenu: {} → {}',
        'content_migrated': 'Contenu migré et répertoire {} supprimé',
        'error_consolidating': 'Erreur lors de la consolidation des répertoires: {}',
        'renaming': 'Renommage: {} → {}',
        'error_renaming': 'Erreur lors du renommage de {}: {}',
        'destination_exists': 'Le répertoire de destination {} existe déjà, il reste',
        'neither_exists': 'Aucun répertoire n\'existe: {} ni {}',
        'general_error': 'Erreur générale lors du renommage des répertoires: {}',
        'error_kde_references': 'Erreur lors de la mise à jour des références KDE: {}',
        'generating_config': 'Génération de la configuration XDG pour la locale: {}',
        'config_generated': 'Configuration XDG générée dans: {}',
        'error_generating_config': 'Erreur lors de la génération de la configuration XDG: {}'
    }
}
