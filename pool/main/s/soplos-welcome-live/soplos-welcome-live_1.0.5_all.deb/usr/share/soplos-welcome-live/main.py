#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Configure environment variables before importing GTK
import os
import locale
import sys
import shutil
import subprocess
import json
import time

# Configure locale before importing GTK to avoid warnings
try:
    locale_set = False
    # Try to set system locale
    current_locale = os.getenv('LANG', 'en_US.UTF-8')
    try:
        locale.setlocale(locale.LC_ALL, '')
        locale_set = True
    except locale.Error:
        pass
        
    # If it fails, try 'C.UTF-8' first, or 'en_US.UTF-8' as fallback
    if not locale_set:
        try:
            locale.setlocale(locale.LC_ALL, 'C.UTF-8')
        except locale.Error:
            try:
                locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
            except locale.Error:
                # If everything fails, use 'C' locale as last resort
                locale.setlocale(locale.LC_ALL, 'C')
except:
    pass

# Other environment variables needed for GTK
os.environ['NO_AT_BRIDGE'] = '1'
os.environ['GTK_MODULES'] = ''
os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gio
from ui.main_window import MainWindow
from config.strings import STRINGS
from config.paths import ICON_PATH
from utils.desktop_detector import load_language_preference, get_session_type
from utils.session_manager import session_manager  # Ensure correct import
from utils.xdg_helper import xdg_manager  # Add new module

def clean_pycache():
    """Cleans all __pycache__ files from the project"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    for root, dirs, files in os.walk(base_dir):
        if '__pycache__' in dirs:
            shutil.rmtree(os.path.join(root, '__pycache__'))

def get_system_locale():
    """Gets the system locale"""
    # First try to read from locale.conf
    if os.path.exists('/etc/locale.conf'):
        try:
            with open('/etc/locale.conf', 'r') as f:
                for line in f:
                    if line.startswith('LANG='):
                        return line.split('=')[1].strip().strip('"')
        except:
            pass
    
    # If it doesn't exist or fails, use LANG variable or default en_US.UTF-8
    return os.getenv('LANG', 'en_US.UTF-8')

def get_language_code():
    """Gets the system language code and returns a valid one"""
    current_locale = get_system_locale()
    
    # If it's C.UTF-8 or similar, use English by default
    if current_locale.startswith('C.') or current_locale == 'C':
        return 'en'
    
    # Get language code (first two letters)
    lang_code = current_locale.split('_')[0].lower()
    
    # Check if the code exists in STRINGS, if not, use English
    return lang_code if lang_code in STRINGS else 'en'

def check_environment():
    """Checks and configures the necessary environment"""
    # Check user
    if os.getenv('USER') != 'liveuser':
        print("Warning: Not running as liveuser")
    
    # Ensure autologin is configured
    try:
        username = os.environ.get('USER', 'liveuser')
        session_manager.ensure_autologin(username)
    except Exception as e:
        print(f"Error configuring autologin: {e}")
    
    # Detect session type (X11 or Wayland)
    session_type = get_session_type()
    print(f"Detected session type: {session_type}")
    
    # Check if we're starting after a language change
    if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
        try:
            with open('/tmp/soplos_welcome_restart_state.json', 'r') as f:
                restart_state = json.load(f)
            
            # If restarted recently and autostart was enabled
            if restart_state.get('restarted') and restart_state.get('autostart_enabled'):
                print("Detected restart with autostart enabled")
                # Check if autostart file exists and create it if not
                from utils.autostart import AutostartManager
                autostart_manager = AutostartManager()
                if not autostart_manager.is_enabled():
                    print("Restoring autostart configuration")
                    autostart_manager.enable()
        except Exception as e:
            print(f"Error checking restart state: {e}")
    
    # Check critical variables according to session type
    if session_type == 'wayland':
        required_vars = {
            'WAYLAND_DISPLAY': os.getenv('WAYLAND_DISPLAY', 'wayland-0'),
            'XDG_RUNTIME_DIR': f"/run/user/{os.getuid()}",
            'XDG_SESSION_TYPE': 'wayland',
            'LANG': os.getenv('LANG', 'en_US.UTF-8')
        }
    else:  # x11 by default
        required_vars = {
            'DISPLAY': ':0',
            'XAUTHORITY': os.path.expanduser('~/.Xauthority'),
            'XDG_RUNTIME_DIR': f"/run/user/{os.getuid()}",
            'XDG_SESSION_TYPE': 'x11',
            'LANG': os.getenv('LANG', 'en_US.UTF-8')
        }
    
    # Set missing variables
    for var, default in required_vars.items():
        if not os.getenv(var):
            os.environ[var] = default
            print(f"Setting {var}={default}")
    
    # Check if this is the first run to avoid unwanted automatic restarts
    if not os.path.exists('/tmp/soplos_welcome_first_run_complete'):
        print("First run detected, creating marker...")
        with open('/tmp/soplos_welcome_first_run_complete', 'w') as f:
            f.write(str(time.time()))
        # Remove any previous restart state
        if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
            os.unlink('/tmp/soplos_welcome_restart_state.json')

def diagnose_locale():
    """Diagnoses the system locale configuration"""
    print("\n=== Locale Diagnosis ===")
    
    # 1. LANG variable
    print(f"LANG={os.getenv('LANG', 'not defined')}")
    
    # 2. Content of /etc/default/locale
    try:
        with open('/etc/default/locale', 'r') as f:
            print("\n/etc/default/locale:")
            print(f.read().strip())
    except:
        print("\n/etc/default/locale: does not exist or is not accessible")
    
    # 3. Generated locales
    try:
        output = subprocess.check_output(['locale', '-a'], text=True)
        print("\nAvailable locales:")
        print(output.strip())
    except:
        print("\nError getting available locales")
    
    # 4. Current locale state
    try:
        output = subprocess.check_output(['locale'], text=True)
        print("\nCurrent locale state:")
        print(output.strip())
    except:
        print("\nError getting locale state")
    
    print("\n==========================")

def set_app_icon():
    """Sets the application icon silently"""
    try:
        if os.path.exists(ICON_PATH):
            Gtk.Window.set_default_icon_from_file(ICON_PATH)
        else:
            Gtk.Window.set_default_icon_name("system-software-install")
    except:
        Gtk.Window.set_default_icon_name("system-software-install")

class SoplosWelcomeLive(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.soplos.welcomelive",
                        flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window = None

    def do_activate(self):
        clean_pycache()  # Clean on startup
        set_app_icon()   # Set default icon
        if not self.window:
            # Get saved or detected language
            lang_code = load_language_preference()
            if not lang_code or lang_code not in STRINGS:
                lang_code = get_language_code()
            
            self.window = MainWindow(lang_code)
            self.window.set_application(self)
            
            # Set icon using icon theme first
            try:
                icon_theme = Gtk.IconTheme.get_default()
                icon = icon_theme.load_icon("soplos-welcome-live", 128, 0)
                self.window.set_icon(icon)
            except:
                # Fallback to local file
                if os.path.exists(ICON_PATH):
                    self.window.set_icon_from_file(ICON_PATH)

            self.window.connect("destroy", lambda x: self.on_quit())
        self.window.show_all()

    def on_quit(self):
        """Cleans cache and closes the application"""
        clean_pycache()  # Clean on close
        
        # Additional cleanup of temporary files we might have created
        temp_files = [
            '/tmp/autologin.conf',
            '/tmp/sddm_autologin.conf',
            '/tmp/sddm_autologin_append'
        ]
        
        for temp_file in temp_files:
            if os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except:
                    pass
                
        self.quit()

def main():
    # Check and configure environment before starting
    check_environment()
    
    app = SoplosWelcomeLive()
    app.run(sys.argv)

if __name__ == "__main__":
    main()