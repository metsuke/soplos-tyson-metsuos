STRINGS_ES = {
    'welcome': 'Soplos Linux',
    'welcome_desc': '¡La distribución Linux hecha para ti!',
    'version': 'Tyron Live 2023.2',
    'buttons': {
        'exit': '_Salir',
        'website': 'Sitio Web',
        'forums': 'Foros',
        'wiki': 'Wiki',
        'donate': 'Donar',
        'install': 'Instalar Soplos _Linux',
        'chroot': 'Recuperar sistema con _CHROOT',
        'open_gparted': 'Abrir _GParted',
        'close': '_Cerrar',
        'next': '_Siguiente',
        'cancel': '_Cancelar',
        'mount': '_Montar'
    },
    'dialog': {
        'exit_title': '¿Está seguro que desea salir?',
        'exit_desc': 'Se cerrará el programa de bienvenida.',
        'error': 'Error',
        'select_disk': 'Por favor, seleccione un disco',
        'select_root': 'Debe seleccionar una partición raíz (/)',
        'no_partitions': 'No se encontraron particiones en este disco',
        'partition_header': 'Seleccione las particiones a montar:',
        'mounting': 'Montando particiones',
        'invalid_partition': 'Partición no válida',
        'invalid_partition_desc': 'La partición seleccionada no contiene un sistema Linux válido o está dañada.',
        'mount_error': 'Error de montaje',
        'mount_error_desc': 'No se pudieron montar las particiones seleccionadas.'
    },
    'locale': {
        'error_generating': 'Error al generar los locales:',
        'error_updating': 'Error al establecer el locale predeterminado:',
        'error_restart': 'Error al reiniciar SDDM',
        'not_found_locale_gen': 'No se encuentra el comando locale-gen.\nPor favor, instale el paquete locales.',
        'not_found_update_locale': 'No se encuentra update-locale',
        'restart_session_title': 'Cambios aplicados',
        'restart_session_desc': 'Para que todos los cambios tengan efecto completamente, se recomienda cerrar sesión y volver a iniciarla.'
    },
    'chroot': {
        'title': 'Recuperación CHROOT',
        'select_disk': 'Seleccione el disco del sistema',
        'open_gparted': 'Abrir GParted',
        'select_partitions': 'Seleccionar particiones',
        'mount': 'Montar',
        'cancel': 'Cancelar',
        'terminal_title': 'Entorno CHROOT de Recuperación de Soplos Linux',
        'welcome_message': 'Has ingresado en un entorno chroot para recuperar tu sistema.',
        'instructions': 'Puedes ejecutar comandos como actualizaciones, reinstalar\nel gestor de arranque o cualquier otra reparación.',
        'exit_message': 'Para salir del entorno chroot, escribe \'exit\' o presiona Ctrl+D.',
        'mounting_partitions': 'Montando particiones...',
        'mounting_root': 'Montando partición raíz',
        'mounting_boot': 'Montando partición /boot',
        'mounting_efi': 'Montando partición EFI',
        'mounting_virtual': 'Montando sistemas de archivos virtuales',
        'exit_chroot': 'Has salido del entorno chroot.',
        'unmounting': 'Desmontando',
        'unmount_complete': 'Todas las particiones fueron desmontadas correctamente.',
        'cleanup_question': '¿Desea eliminar el directorio de montaje {}? [s/N]: ',
        'process_complete': 'Proceso de chroot finalizado.',
        'chroot_started': 'Chroot iniciado correctamente',
        'mounting_content': 'Contenido del punto de montaje:',
        'using_shell': 'Usando shell:',
        'starting_chroot': 'Iniciando entorno chroot...',
        'mount_point_label': 'Punto de montaje',
        'root_partition_label': 'Partición raíz',
        'creating_dirs': 'Creando directorios para bind mounts',
        'creating_boot_dir': 'Creando directorio /boot',
        'creating_efi_dir': 'Creando directorio /boot/efi',
        'bin_content': 'Contenido de /bin',
        'usr_bin_content': 'Contenido de /usr/bin',
        'still_mounted': 'Sistemas de archivos aún montados',
        'mount_boot_error': 'ERROR: No se pudo montar {} en {}/boot',
        'mount_efi_error': 'ERROR: No se pudo montar {} en {}/boot/efi'
    },
    'autostart': 'Mostrar al inicio:',
    'labels': {
        'language': 'Idioma:',
        'show_startup': 'Mostrar al inicio:',
        'device': 'Dispositivo',
        'size': 'Tamaño',
        'model': 'Modelo',
        'filesystem': 'Sistema de archivos',
        'mountpoint': 'Punto de montaje',
        'select_option': '-- Seleccionar --',
        'unknown': 'Desconocido'
    },
    'live_iso': {
        'title': 'Live ISO',
        'description': 'Esta versión Live te permite probar Soplos Linux\nsin necesidad de instalar nada en tu ordenador.\nCuando estés listo, usa el botón naranja para instalarlo.'
    },
    'thanks': '¡Gracias por probar Soplos Linux!',
    'messages': {
        'selected_disk': 'Disco seleccionado: {}',
        'error_loading_disks': 'Error al cargar discos',
        'error_loading_partitions': 'Error al obtener particiones',
        'error_mounting': 'Error al montar particiones',
        'error_unmounting': 'Error desmontando el sistema',
        'mount_point_error': 'ERROR: No se pudo crear el punto de montaje',
        'mount_root_error': 'ERROR: No se pudo montar',
        'in': 'en',
        'completed': 'completado',
        'mount_dev_error': 'ERROR: No se pudo montar /dev en',
        'mount_proc_error': 'ERROR: No se pudo montar /proc en',
        'mount_sys_error': 'ERROR: No se pudo montar /sys en',
        'mount_pts_error': 'ERROR: No se pudo montar /dev/pts en',
        'resolv_copy_error': 'No se pudo copiar resolv.conf',
        'no_shell_error': 'ERROR: No se encontró un shell válido en el sistema montado',
        'unmount_warning': 'ADVERTENCIA: Algunos puntos de montaje no pudieron ser desmontados.',
        'restart_needed': 'Puede ser necesario reiniciar el sistema para liberar estos recursos.',
        'directory_removed': 'Directorio eliminado',
        'directory_remove_error': 'No se pudo eliminar',
        'directory_kept': 'Directorio conservado',
        'mount_point_missing': 'ERROR: El punto de montaje no existe',
        'shell_not_found': 'ERROR: No se encontró un shell válido en el sistema montado',
        'lsblk_error': 'Error ejecutando lsblk',
        'gparted_error': 'Error ejecutando GParted',
        'mount_result': 'Resultado del montaje:',
        'konsole_error': 'Error al iniciar konsole',
        'xterm_error': 'Error al iniciar xterm',
        'first_start_detected': 'Primer inicio detectado, omitiendo verificación de reinicio',
        'first_start_error': 'Error al marcar primer inicio: {}',
        'restart_detected': 'Detectado reinicio por cambio de idioma, aplicando configuración...',
        'keyboard_config_warning': 'Advertencia: No se pudo aplicar la configuración de teclado/locale',
        'restarting_session': 'Reiniciando sesión...',
        'restarting_sddm': 'Reiniciando SDDM para aplicar cambios de idioma...',
        'icon_error': 'Error al establecer el icono: {}',
        'desktop_info': 'Entorno de escritorio: {}, Tipo de sesión: {}',
        'logo_error': 'Error al cargar el logo: {}',
        'locale_config_error': 'Error configurando locale del sistema',
        'robust_locale_error': 'Error en configuración robusta de locale',
        'robust_autologin_error': 'Error configurando autologin robusto',
        'restarting_sddm_script': 'Reiniciando SDDM para aplicar cambios de idioma...',
        'robust_restart_error': 'Error en reinicio robusto',
        'sddm_config_error': 'Error modificando /etc/sddm.conf',
        'kde_command_error': 'Error ejecutando {}: {}',
        'kde_config_error': 'Error recargando configuración de KDE',
        'app_title': 'Soplos Welcome Live',
        'autostart_create_error': 'Error: No se pudo crear el archivo de autostart',
        'autostart_enable_error': 'Error activando autostart: {}',
        'autostart_enabled': 'Autostart habilitado: {} -> {}',
        'desktop_file_not_found': 'Error: No se encuentra el archivo .desktop en ninguna ubicación conocida',
        'basic_desktop_created': 'Se creó un archivo desktop básico como respaldo',
        'basic_desktop_error': 'Error creando archivo desktop básico: {}',
        # New messages for desktop_detector.py
        'wayland_session': 'Sesión detectada: Wayland',
        'x11_session': 'Sesión detectada: X11',
        'unknown_session': 'No se pudo determinar el tipo de sesión, usando X11 por defecto',
        'autologin_check_error': 'Error verificando autologin: {}',
        'autologin_found': 'Autologin encontrado en {file_path} para usuario: {user}',
        'autologin_file_error': 'Error leyendo {file_path}: {error}',
        'kde_restore_error': 'Error restaurando configuración KDE: {}',
        'kde_backup_error': 'Error respaldando configuración KDE: {}',
        'backed_up': 'Respaldado {src} -> {dst}',
        'restored': 'Restaurado {src} -> {dst}'
    },
    'progress': {
        'configuring': 'Configurando idioma...'
    },
    'commands': {
        'gparted': 'sudo gparted',
        'calamares_sudo': 'sudo',
        'calamares': 'calamares'
    },
    'errors': {
        'slide_load': 'Error al cargar slide',
        'language_config': 'Error configurando idioma'
    },
    'system': {
        'xorg_conf_dir': '/etc/X11/xorg.conf.d',
        'keyboard_conf_file': '/etc/X11/xorg.conf.d/00-keyboard.conf',
        'xorg_keyboard_template': """Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection"""
    },
    'templates': {
        'basic_desktop_file': """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Pantalla de bienvenida para Soplos Linux Live
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
"""
    },
    'session_manager': {
        'using_temp_dir': 'Usando directorio temporal para configuración: {}',
        'error_creating_config_dir': 'Error creando directorio de configuración: {}',
        'first_run_marked': 'Primera ejecución marcada - se evitará el reinicio automático',
        'error_first_run_marker': 'Error al crear marcador de primer inicio: {}',
        'error_configuring_autologin': 'Error: No se pudo configurar autologin',
        'saving_autostart_state': 'Guardando estado de autostart habilitado para restauración después del reinicio',
        'restart_request_created': 'Archivo de solicitud de reinicio creado correctamente',
        'error_creating_restart_file': 'Error creando archivo de solicitud de reinicio: {}',
        'executing_sddm_restart': 'Ejecutando reinicio de SDDM en sesión {}...',
        'critical_sddm_restart_error': 'Error crítico reiniciando SDDM: {}',
        'copying_dir': 'Copiando directorio {} a {}',
        'error_reloading_kde': 'Error al recargar configuración de KDE: {}',
        'error_restoring_theme': 'Error restaurando tema desde skel: {}',
        'error_configuring_locale': 'Error configurando locale del sistema: {}',
        # New strings added
        'no_restart_request': 'No hay solicitud explícita de reinicio, evitando reinicio automático',
        'restoring_autostart': 'Restaurando inicio automático después del reinicio...',
        'error_tmp_state': 'Error comprobando estado en /tmp: {}',
        'locale_mismatch': 'El locale actual ({}) no coincide con el guardado ({})',
        'error_verifying_locale': 'Error verificando aplicación de locale: {}',
        'skel_dir_missing': 'El directorio {} no existe',
        'timeout_warning': 'El script de configuración tardó demasiado, pero es posible que haya funcionado',
        'error_ensuring_autologin': 'Error asegurando autologin: {}'
    },
    'xdg': {
        'updating_directories': 'Actualizando directorios XDG para locale: {}',
        'backup_created': 'Backup de user-dirs.dirs creado',
        'file_deleted': 'Archivo user-dirs.dirs eliminado para regeneración',
        'running_update': 'Ejecutando xdg-user-dirs-update --force...',
        'result': 'Resultado: {}',
        'errors': 'Errores: {}',
        'not_created': 'Error: No se ha creado user-dirs.dirs',
        'restored_backup': 'Restaurado desde backup',
        'updating_gtk': 'Actualizando configuración GTK...',
        'updating_references': 'Actualizando referencias de directorios en el entorno de escritorio...',
        'file_content': 'Contenido de user-dirs.dirs:\n{}',
        'error_updating': 'Error actualizando directorios XDG: {}',
        'renaming_directories': 'Renombrando directorios para el idioma: {}',
        'no_mapping': 'No hay mapeo de directorios para el idioma: {}',
        'both_exist': 'Ambos directorios existen. Migrando contenido: {} → {}',
        'content_migrated': 'Contenido migrado y directorio {} eliminado',
        'error_consolidating': 'Error consolidando directorios: {}',
        'renaming': 'Renombrando: {} → {}',
        'error_renaming': 'Error renombrando {}: {}',
        'destination_exists': 'El directorio destino {} ya existe, se mantiene',
        'neither_exists': 'Ningún directorio existe: {} ni {}',
        'general_error': 'Error general en renombrado de directorios: {}',
        'error_kde_references': 'Error actualizando referencias KDE: {}',
        'generating_config': 'Generando configuración XDG para locale: {}',
        'config_generated': 'Configuración XDG generada en: {}',
        'error_generating_config': 'Error generando configuración XDG: {}'
    }
}
