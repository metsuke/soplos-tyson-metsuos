import gi
import os
import subprocess
import shutil
import sys

# Add the root directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib
from core.chroot_operations import SystemOperations
from config.strings import STRINGS  # Changed import

# Disable accessibility warnings
os.environ['NO_AT_BRIDGE'] = '1'

class ChRootWindow(Gtk.Window):
    def __init__(self):
        # Clean pycache before initializing
        self.clean_pycache()
        
        # Get system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        self.current_lang = current_locale.split('_')[0]
        
        Gtk.Window.__init__(self, title=STRINGS[self.current_lang]['chroot']['title'])
        self.set_default_size(600, 400)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_border_width(10)
        
        self.sys_ops = SystemOperations()
        
        # Main container
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Title label
        title_label = Gtk.Label()
        title_label.set_markup(f"<span size='large' weight='bold'>{STRINGS[self.current_lang]['chroot']['select_disk']}</span>")
        main_box.pack_start(title_label, False, False, 10)
        
        # Disk list
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        main_box.pack_start(scrolled, True, True, 0)
        
        self.disks_store = Gtk.ListStore(str, str, str)  # Device, Size, Model
        self.disks_view = Gtk.TreeView(model=self.disks_store)
        
        # Columns
        columns = [
            (STRINGS[self.current_lang]['labels']['device'], 0),
            (STRINGS[self.current_lang]['labels']['size'], 1),
            (STRINGS[self.current_lang]['labels']['model'], 2)
        ]
        
        for title, col_id in columns:
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(title, renderer, text=col_id)
            self.disks_view.append_column(column)
        
        scrolled.add(self.disks_view)
        
        # GParted Button
        gparted_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['open_gparted'])
        gparted_button.set_use_underline(True)
        gparted_button.connect("clicked", self.on_gparted_clicked)
        main_box.pack_start(gparted_button, False, False, 0)
        
        # Bottom buttons
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.pack_start(button_box, False, False, 0)
        
        close_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['close'])
        close_button.set_use_underline(True)
        close_button.connect("clicked", self.on_close_clicked)
        button_box.pack_start(close_button, True, True, 0)
        
        next_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['next'])
        next_button.set_use_underline(True)
        next_button.connect("clicked", self.on_next_clicked)
        button_box.pack_start(next_button, True, True, 0)
        
        # Load disks
        self.load_disks()
    
    def load_disks(self):
        """Loads the list of disks"""
        try:
            self.disks_store.clear()
            for device, size, model in self.sys_ops.get_disks():
                self.disks_store.append([device, size, model])
        except Exception as e:
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'],
                STRINGS[self.current_lang]['messages']['error_loading_disks']
            )
    
    def on_gparted_clicked(self, button):
        """Executes GParted"""
        try:
            # Run GParted directly with pkexec
            subprocess.Popen(['pkexec', '/usr/sbin/gparted'], 
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
        except Exception as e:
            self.show_error(STRINGS[self.current_lang]['dialog']['error'], str(e))
    
    def on_next_clicked(self, button):
        """Proceeds to the next step"""
        selection = self.disks_view.get_selection()
        model, iter = selection.get_selected()
        
        # Error messages
        if iter is None:
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'],
                STRINGS[self.current_lang]['dialog']['select_disk']
            )
            return
        
        selected_disk = model[iter][0]
        print(STRINGS[self.current_lang]['messages']['selected_disk'].format(selected_disk))
        
        try:
            # Get disk partitions
            partitions = self.sys_ops.get_disk_partitions(selected_disk)
            
            # Show partitions selection dialog
            self.show_partitions_dialog(partitions)
        except Exception as e:
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'],
                STRINGS[self.current_lang]['messages']['error_loading_partitions']
            )
    
    def show_partitions_dialog(self, partitions):
        """Show dialog for partition selection with btrfs support"""
        dialog = Gtk.Dialog(
            title=STRINGS[self.current_lang]['chroot']['select_partitions'],
            parent=self,
            flags=0
        )
        dialog.set_default_size(600, 500)  # Increase size for btrfs
        
        # Configure Alt+key shortcuts for dialog buttons
        for button in dialog.get_action_area().get_children():
            button.set_use_underline(True)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_border_width(10)
        
        if not partitions:
            label = Gtk.Label(label=STRINGS[self.current_lang]['dialog']['no_partitions'])
            box.pack_start(label, False, False, 0)
            box.show_all()
            dialog.run()
            dialog.destroy()
            return
            
        label = Gtk.Label(label=STRINGS[self.current_lang]['dialog']['partition_header'])
        box.pack_start(label, False, False, 0)
        
        # Partition list
        grid = Gtk.Grid()
        grid.set_column_spacing(10)
        grid.set_row_spacing(5)
        
        # Create headers
        headers = [
            STRINGS[self.current_lang]['labels']['mountpoint'],
            STRINGS[self.current_lang]['labels']['device'],
            STRINGS[self.current_lang]['labels']['size'],
            STRINGS[self.current_lang]['labels']['filesystem']
        ]
        for i, header in enumerate(headers):
            label = Gtk.Label(label=header)
            label.set_markup(f"<b>{header}</b>")
            grid.attach(label, i, 0, 1, 1)
        
        # Create partition rows
        mount_points = ['/', '/boot', '/boot/efi', '/home']
        self.partition_combos = {}
        self.btrfs_subvol_combos = {}  # For btrfs subvolumes
        
        current_row = 1
        for mount in mount_points:
            # Mount point label
            mount_label = Gtk.Label(label=mount)
            mount_label.set_halign(Gtk.Align.START)
            grid.attach(mount_label, 0, current_row, 1, 1)
            
            # Combo to select partition
            combo = Gtk.ComboBoxText()
            combo.append_text(STRINGS[self.current_lang]['labels']['select_option'])
            for part in partitions:
                text = f"{part['device']} ({part['size']} - {part['fstype']})"
                combo.append_text(text)
            combo.set_active(0)
            
            # Fix automatic suggestion selection
            for j, part in enumerate(partitions):
                if part.get('suggested_mount') == mount:
                    combo.set_active(j + 1)  # +1 because index 0 is "-- Select --"
                    break
            
            self.partition_combos[mount] = combo
            combo.connect("changed", self.on_partition_combo_changed, mount, partitions, grid)
            grid.attach(combo, 1, current_row, 3, 1)
            
            current_row += 1
        
        box.pack_start(grid, True, True, 0)
        box.show_all()
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.process_selected_partitions()
        
        dialog.destroy()
    
    def on_partition_combo_changed(self, combo, mount_point, partitions, grid):
        """Handle partition selection change, showing btrfs options if necessary"""
        selection = combo.get_active_text()
        
        # Remove previous subvolume combo if exists
        if mount_point in self.btrfs_subvol_combos:
            old_combo = self.btrfs_subvol_combos[mount_point]
            grid.remove(old_combo)
            del self.btrfs_subvol_combos[mount_point]
        
        if selection and selection != STRINGS[self.current_lang]['labels']['select_option']:
            device = selection.split()[0]
            
            # Find corresponding partition
            selected_partition = None
            for part in partitions:
                if part['device'] == device:
                    selected_partition = part
                    break
            
            # If it's btrfs with subvolumes, show subvolume combo
            if selected_partition and selected_partition.get('is_btrfs') and selected_partition.get('btrfs_subvolumes'):
                btrfs_info = selected_partition['btrfs_subvolumes']
                if btrfs_info.get('has_subvolumes'):
                    self.show_btrfs_subvolume_combo(mount_point, btrfs_info, grid, combo)

    def show_btrfs_subvolume_combo(self, mount_point, btrfs_info, grid, partition_combo):
        """Show combo for btrfs subvolume selection"""
        # Find partition combo row
        row = None
        for child in grid.get_children():
            if child == partition_combo:
                row = grid.child_get_property(child, "top-attach")
                break
        
        if row is None:
            return
        
        # Create combo for subvolumes
        subvol_combo = Gtk.ComboBoxText()
        subvol_combo.append_text(STRINGS[self.current_lang]['btrfs']['select_subvolume'])
        
        # Add subvolumes
        for subvol in btrfs_info['subvolumes']:
            is_default = " (default)" if subvol.get('is_default') else ""
            suggested = f" -> {subvol['suggested_mount']}" if subvol.get('suggested_mount') else ""
            text = f"{subvol['path']} (ID: {subvol['id']}){is_default}{suggested}"
            subvol_combo.append_text(text)
        
        # Auto-select if there's a suggestion
        for i, subvol in enumerate(btrfs_info['subvolumes'], 1):
            if subvol.get('suggested_mount') == mount_point or subvol.get('is_default'):
                subvol_combo.set_active(i)
                break
        else:
            subvol_combo.set_active(0)
        
        self.btrfs_subvol_combos[mount_point] = subvol_combo
        
        # Insert new row for subvolume combo
        grid.insert_row(row + 1)
        
        # Label for subvolume
        subvol_label = Gtk.Label()
        subvol_label.set_markup(f"<i>{STRINGS[self.current_lang]['btrfs']['select_subvolume']}:</i>")
        subvol_label.set_halign(Gtk.Align.START)
        grid.attach(subvol_label, 0, row + 1, 1, 1)
        
        grid.attach(subvol_combo, 1, row + 1, 3, 1)
        grid.show_all()

    def process_selected_partitions(self):
        """Processes the selected partitions and executes chroot"""
        try:
            mount_points = {}
            for mount, combo in self.partition_combos.items():
                device = combo.get_active_text()
                if device and device != STRINGS[self.current_lang]['labels']['select_option']:
                    device = device.split()[0]  # Get only the device
                    mount_points[mount] = device

            if '/' not in mount_points:
                self.show_error(
                    STRINGS[self.current_lang]['dialog']['error'],
                    STRINGS[self.current_lang]['dialog']['select_root']
                )
                return

            # Show a progress dialog
            self.show_progress_dialog(mount_points)
            
        except Exception as e:
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'], 
                str(e)
            )
    
    def show_progress_dialog(self, mount_points):
        """Shows a progress dialog while mounting and preparing chroot"""
        dialog = Gtk.Dialog(
            title=STRINGS[self.current_lang]['dialog']['mounting'],
            parent=self,
            flags=0,
            buttons=(
                STRINGS[self.current_lang]['buttons']['close'], Gtk.ResponseType.CLOSE,
            )
        )
        dialog.set_default_size(400, 100)
        dialog.set_modal(True)
        
        # Configure Alt+key shortcuts for dialog button
        for button in dialog.get_action_area().get_children():
            button.set_use_underline(True)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_border_width(10)
        
        label = Gtk.Label(label=STRINGS[self.current_lang]['chroot']['mounting_partitions'])
        box.pack_start(label, False, False, 0)
        
        progress_bar = Gtk.ProgressBar()
        progress_bar.set_fraction(0.0)
        box.pack_start(progress_bar, False, False, 5)
        
        status_label = Gtk.Label(label="")
        box.pack_start(status_label, False, False, 0)
        
        box.show_all()
        
        # Update progress and execute chroot
        def update_progress():
            try:
                # Mount partitions and execute chroot
                status_label.set_text(STRINGS[self.current_lang]['chroot']['mounting_partitions'])
                progress_bar.set_fraction(0.3)
                while Gtk.events_pending():
                    Gtk.main_iteration()
                
                progress_bar.set_fraction(0.5)
                status_label.set_text(STRINGS[self.current_lang]['chroot']['mounting_virtual'])
                while Gtk.events_pending():
                    Gtk.main_iteration()
                
                self.sys_ops.mount_and_chroot(
                    root_part=mount_points['/'],
                    boot_part=mount_points.get('/boot'),
                    efi_part=mount_points.get('/boot/efi')
                )
                
                progress_bar.set_fraction(1.0)
                status_label.set_text(STRINGS[self.current_lang]['chroot'].get('chroot_started', "Chroot started successfully"))
                
                # Automatically close dialog after 2 seconds
                GLib.timeout_add(2000, dialog.response, Gtk.ResponseType.CLOSE)
                
            except Exception as e:
                progress_bar.set_fraction(0.0)
                status_label.set_markup(f"<span color='red'>{STRINGS[self.current_lang]['dialog'].get('mount_error', 'Error')}: {str(e)}</span>")
                # Show specific error dialog
                self.show_mount_error(str(e))
                
            return False
        
        # Start the task after showing the dialog
        GLib.idle_add(update_progress)
        
        # Run the dialog
        dialog.run()
        dialog.destroy()
    
    def on_close_clicked(self, button):
        """Closes the window"""
        self.clean_pycache()  # Clean on close
        self.destroy()
    
    def show_error(self, title, message):
        """Shows an error dialog"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def show_mount_error(self, error_message):
        """Shows a specific error dialog for mounting problems"""
        # Change hardcoded check to a more robust one
        if any(keyword in error_message.lower() for keyword in ['linux válido', 'valid linux', 'linux valido']):
            self.show_error(
                STRINGS[self.current_lang]['dialog']['invalid_partition'],
                STRINGS[self.current_lang]['dialog']['invalid_partition_desc']
            )
        else:
            self.show_error(
                STRINGS[self.current_lang]['dialog']['mount_error'],
                STRINGS[self.current_lang]['dialog']['mount_error_desc']
            )
    
    def clean_pycache(self):
        """Cleans all project __pycache__ files"""
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        for root, dirs, files in os.walk(base_dir):
            if '__pycache__' in dirs:
                shutil.rmtree(os.path.join(root, '__pycache__'))
