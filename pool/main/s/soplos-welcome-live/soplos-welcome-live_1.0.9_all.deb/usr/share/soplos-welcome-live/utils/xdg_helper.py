#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import shutil
from utils.desktop_detector import get_session_type

class XDGDirectoriesManager:
    """Manages XDG directories in a simple way"""
    
    def __init__(self, strings=None):
        self.home_dir = os.path.expanduser('~')
        self.config_dir = os.path.join(self.home_dir, '.config')
        self.user_dirs_path = os.path.join(self.config_dir, 'user-dirs.dirs')
        self.session_type = get_session_type()
        self.strings = strings
    
    def _get_string(self, key_path, *args):
        """Get internationalized string from the strings dictionary"""
        if not self.strings:
            # Fallback to English if no strings provided
            return key_path.split('.')[-1]
        
        keys = key_path.split('.')
        value = self.strings
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return key_path.split('.')[-1]  # Return last key as fallback
        
        if args:
            try:
                return value.format(*args)
            except:
                return value
        return value
    
    def set_strings(self, strings):
        """Set the strings dictionary for internationalization"""
        self.strings = strings
    
    def update_directories(self, locale):
        """Renames XDG directories according to the provided locale in a more robust way"""
        try:
            lang_code = locale.split('_')[0]
            print(self._get_string('xdg.updating_directories', locale))
            
            # 1. Configure and apply environment variables before running xdg-user-dirs-update
            env = os.environ.copy()
            env['LANG'] = locale
            env['LC_ALL'] = locale
            env['LANGUAGE'] = locale.split('_')[0]
            os.environ['LANG'] = locale  # Also set in the current environment
            os.environ['LC_ALL'] = locale
            os.environ['LANGUAGE'] = locale.split('_')[0]
            
            # 2. First, backup current configuration in case of error
            user_dirs_backup = "/tmp/user-dirs.dirs.backup"
            if os.path.exists(self.user_dirs_path):
                shutil.copy2(self.user_dirs_path, user_dirs_backup)
                print(self._get_string('xdg.backup_created'))
            
            # 3. Delete the existing user-dirs.dirs file to force complete regeneration
            if os.path.exists(self.user_dirs_path):
                os.unlink(self.user_dirs_path)
                print(self._get_string('xdg.file_deleted'))
            
            # 4. Explicitly regenerate user-dirs.dirs for the new locale
            print(self._get_string('xdg.running_update'))
            update_result = subprocess.run(['xdg-user-dirs-update', '--force'], 
                                          env=env, capture_output=True, text=True)
            print(self._get_string('xdg.result', update_result.stdout))
            print(self._get_string('xdg.errors', update_result.stderr))
            
            # 5. Check if it was generated correctly
            if not os.path.exists(self.user_dirs_path):
                print(self._get_string('xdg.not_created'))
                # Try to recover from backup
                if os.path.exists(user_dirs_backup):
                    shutil.copy2(user_dirs_backup, self.user_dirs_path)
                    print(self._get_string('xdg.restored_backup'))
            
            # 6. Also update GTK configuration if it exists
            if shutil.which('xdg-user-dirs-gtk-update'):
                print(self._get_string('xdg.updating_gtk'))
                subprocess.run(['xdg-user-dirs-gtk-update', '--force'], 
                              env=env, check=False)
            
            # 7. Physically rename directories if necessary
            # (The existing method is already adequate)
            self._rename_physical_directories(locale)
            
            # 8. Update desktop environment to recognize changes
            print(self._get_string('xdg.updating_references'))
            self._update_kde_directory_references(lang_code)
            
            # 9. Run an additional command to force update in graphical environment
            subprocess.run(['xdg-user-dirs-update', '--force'], check=False)
            
            # Show content of the generated file for diagnosis
            if os.path.exists(self.user_dirs_path):
                with open(self.user_dirs_path, 'r') as f:
                    print(self._get_string('xdg.file_content', f.read()))
            
            return True
        except Exception as e:
            print(self._get_string('xdg.error_updating', e))
            import traceback
            traceback.print_exc()
            return False
    
    def _generate_xdg_config(self, locale):
        """Generates XDG directory configuration according to locale"""
        try:
            lang_code = locale.split('_')[0]
            print(self._get_string('xdg.generating_config', locale))
            
            # Basic template for user-dirs.dirs
            config_content = f"""
# This file is generated by the system
# Edit at your own risk

XDG_DESKTOP_DIR="{self.home_dir}/Desktop"
XDG_DOWNLOAD_DIR="{self.home_dir}/Downloads"
XDG_TEMPLATES_DIR="{self.home_dir}/Templates"
XDG_PUBLICSHARE_DIR="{self.home_dir}/Public"
XDG_DOCUMENTS_DIR="{self.home_dir}/Documents"
XDG_MUSIC_DIR="{self.home_dir}/Music"
XDG_PICTURES_DIR="{self.home_dir}/Pictures"
XDG_VIDEOS_DIR="{self.home_dir}/Videos"
            """.strip()
            
            # Override specific directories for the language
            if lang_code in ['es', 'pt', 'fr', 'de', 'it', 'ru', 'ro']:
                config_content = config_content.replace('Desktop', 'Escritorio')
                config_content = config_content.replace('Downloads', 'Descargas')
                config_content = config_content.replace('Documents', 'Documentos')
                config_content = config_content.replace('Music', 'Música')
                config_content = config_content.replace('Pictures', 'Imágenes')
                config_content = config_content.replace('Videos', 'Vídeos')
                config_content = config_content.replace('Public', 'Público')
                config_content = config_content.replace('Templates', 'Plantillas')
            
            # Write the configuration to the user-dirs.dirs file
            with open(self.user_dirs_path, 'w') as f:
                f.write(config_content)
            
            print(self._get_string('xdg.config_generated', self.user_dirs_path))
            return True
        except Exception as e:
            print(self._get_string('xdg.error_generating_config', e))
            return False
    
    def _rename_physical_directories(self, locale):
        """Physically renames existing directories without duplicating them"""
        try:
            # Extract language code from locale
            lang_code = locale.split('_')[0]
            print(self._get_string('xdg.renaming_directories', lang_code))
            
            # Name mapping for each language
            directory_names = {
                'es': {
                    'Desktop': 'Escritorio',
                    'Downloads': 'Descargas',
                    'Documents': 'Documentos',
                    'Music': 'Música',
                    'Pictures': 'Imágenes',
                    'Videos': 'Vídeos',
                    'Public': 'Público',
                    'Templates': 'Plantillas'
                },
                'en': {
                    'Escritorio': 'Desktop',
                    'Descargas': 'Downloads',
                    'Documentos': 'Documents',
                    'Música': 'Music',
                    'Imágenes': 'Pictures',
                    'Vídeos': 'Videos',
                    'Público': 'Public',
                    'Plantillas': 'Templates'
                },
                'fr': {
                    'Desktop': 'Bureau',
                    'Downloads': 'Téléchargements',
                    'Documents': 'Documents',
                    'Music': 'Musique',
                    'Pictures': 'Images',
                    'Videos': 'Vidéos',
                    'Public': 'Public',
                    'Templates': 'Modèles'
                },
                'de': {
                    'Desktop': 'Schreibtisch',
                    'Downloads': 'Downloads',
                    'Documents': 'Dokumente',
                    'Music': 'Musik',
                    'Pictures': 'Bilder',
                    'Videos': 'Videos',
                    'Public': 'Öffentlich',
                    'Templates': 'Vorlagen'
                },
                'it': {
                    'Desktop': 'Scrivania',
                    'Downloads': 'Scaricati',
                    'Documents': 'Documenti',
                    'Music': 'Musica',
                    'Pictures': 'Immagini',
                    'Videos': 'Video',
                    'Public': 'Pubblici',
                    'Templates': 'Modelli'
                },
                'pt': {
                    'Desktop': 'Área de Trabalho',
                    'Downloads': 'Transferências',
                    'Documents': 'Documentos',
                    'Music': 'Música',
                    'Pictures': 'Imagens',
                    'Videos': 'Vídeos',
                    'Public': 'Público',
                    'Templates': 'Modelos'
                },
                'ru': {
                    'Desktop': 'Рабочий стол',
                    'Downloads': 'Загрузки',
                    'Documents': 'Документы',
                    'Music': 'Музыка',
                    'Pictures': 'Изображения',
                    'Videos': 'Видео',
                    'Public': 'Общедоступные',
                    'Templates': 'Шаблоны'
                },
                'ro': {
                    'Desktop': 'Desktop',
                    'Downloads': 'Descărcări',
                    'Documents': 'Documente',
                    'Music': 'Muzică',
                    'Pictures': 'Poze',
                    'Videos': 'Videoclipuri',
                    'Public': 'Public',
                    'Templates': 'Șabloane'
                }
            }
            
            # If there is no mapping for the language, do nothing
            if lang_code not in directory_names:
                print(self._get_string('xdg.no_mapping', lang_code))
                return
            
            # For each pair of directories (source -> destination)
            for src_name, dst_name in directory_names[lang_code].items():
                src_path = os.path.join(self.home_dir, src_name)
                dst_path = os.path.join(self.home_dir, dst_name)
                
                # CASE 1: Both exist - migrate content and delete the original
                if os.path.exists(src_path) and os.path.exists(dst_path):
                    print(self._get_string('xdg.both_exist', src_path, dst_path))
                    # Migrate all files from src to dst
                    try:
                        for item in os.listdir(src_path):
                            item_src = os.path.join(src_path, item)
                            item_dst = os.path.join(dst_path, item)
                            
                            # If it's a directory, use copytree
                            if os.path.isdir(item_src):
                                if not os.path.exists(item_dst):
                                    shutil.copytree(item_src, item_dst)
                                else:
                                    # If it already exists, merge recursively
                                    for subitem in os.listdir(item_src):
                                        sub_src = os.path.join(item_src, subitem)
                                        sub_dst = os.path.join(item_dst, subitem)
                                        if os.path.isdir(sub_src):
                                            if not os.path.exists(sub_dst):
                                                shutil.copytree(sub_src, sub_dst)
                                        elif not os.path.exists(sub_dst):
                                            shutil.copy2(sub_src, sub_dst)
                            # If it's a file, use copy2 to preserve metadata
                            elif not os.path.exists(item_dst):
                                shutil.copy2(item_src, item_dst)
                        
                        # Delete the source directory after migrating everything
                        shutil.rmtree(src_path)
                        print(self._get_string('xdg.content_migrated', src_path))
                    except Exception as e:
                        print(self._get_string('xdg.error_consolidating', e))
                
                # CASE 2: Only the source exists - rename directly
                elif os.path.exists(src_path) and not os.path.exists(dst_path):
                    print(self._get_string('xdg.renaming', src_path, dst_path))
                    try:
                        # Create the parent directory if necessary
                        parent_dir = os.path.dirname(dst_path)
                        if not os.path.exists(parent_dir):
                            os.makedirs(parent_dir, exist_ok=True)
                        # Rename the directory
                        os.rename(src_path, dst_path)
                    except Exception as e:
                        print(self._get_string('xdg.error_renaming', src_path, e))
                
                # CASE 3: Only the destination exists - do nothing
                elif os.path.exists(dst_path):
                    print(self._get_string('xdg.destination_exists', dst_path))
                
                # CASE 4: Neither exists - do not create directories automatically
                else:
                    print(self._get_string('xdg.neither_exists', src_path, dst_path))

            # Update the desktop environment specifically for the Desktop/Escritorio directory
            self._update_kde_directory_references(lang_code)
            
        except Exception as e:
            print(self._get_string('xdg.general_error', e))
            import traceback
            traceback.print_exc()
    
    def _update_kde_directory_references(self, lang_code):
        """Updates directory references in KDE"""
        try:
            # Update references in Plasma
            subprocess.run([
                'kwriteconfig5', '--file', 'dolphinrc',
                '--group', 'General', '--key', 'HomeUrl',
                f'file://{self.home_dir}'
            ], check=False)
            
            # Update desktop to show icons
            desktop_path = os.path.join(self.home_dir, 'Desktop')
            if lang_code == 'es':
                desktop_path = os.path.join(self.home_dir, 'Escritorio')
            elif lang_code == 'pt':
                desktop_path = os.path.join(self.home_dir, 'Área de Trabalho')
            elif lang_code == 'fr':
                desktop_path = os.path.join(self.home_dir, 'Bureau')
            elif lang_code == 'de':
                desktop_path = os.path.join(self.home_dir, 'Schreibtisch')
            elif lang_code == 'it':
                desktop_path = os.path.join(self.home_dir, 'Scrivania')
            
            # Update plasma configuration for the desktop
            subprocess.run([
                'kwriteconfig5', '--file', 'plasma-org.kde.plasma.desktop-appletsrc',
                '--group', 'Containments', '--group', '1', '--group', 'General',
                '--key', 'url', f'file://{desktop_path}'
            ], check=False)
            
            # Force refresh of the plasma shell
            subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 
                           'org.kde.PlasmaShell.evaluateScript', 
                           'refreshCurrentShell()'], check=False)
        except Exception as e:
            print(self._get_string('xdg.error_kde_references', e))

# Global instance for direct use
xdg_manager = XDGDirectoriesManager()
