import os
import sys

# Add the root directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# This file can be empty, we just need it to exist
