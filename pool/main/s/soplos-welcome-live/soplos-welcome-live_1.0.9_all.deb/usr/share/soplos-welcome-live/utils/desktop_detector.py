#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import json
import time
import shutil
from config.strings import STRINGS

def get_desktop_environment():
    """Detects the current desktop environment"""
    desktop = os.getenv('XDG_CURRENT_DESKTOP', '').lower()
    session = os.getenv('DESKTOP_SESSION', '').lower()
    
    # For this version, we only focus on KDE
    is_kde = 'kde' in desktop or 'plasma' in desktop or 'kde' in session
    
    return 'kde' if is_kde else 'unknown'

def get_session_type():
    """Correctly detects if the session is Wayland or X11"""
    # Get the current system language
    current_locale = os.getenv('LANG', 'en_US.UTF-8')
    current_lang = current_locale.split('_')[0]
    if current_lang not in STRINGS:
        current_lang = 'en'
    
    # Check environment variables to determine the session type
    if os.environ.get('WAYLAND_DISPLAY'):
        print(STRINGS[current_lang]['messages'].get('wayland_session', "Session detected: Wayland"))
        return 'wayland'
    elif os.environ.get('DISPLAY'):
        print(STRINGS[current_lang]['messages'].get('x11_session', "Session detected: X11"))
        return 'x11'
    else:
        print(STRINGS[current_lang]['messages'].get('unknown_session', "Could not determine session type, using X11 by default"))
        return 'x11'
    

def save_language_preference(lang_code):
    """Saves the user's language preference"""
    # Check if we're in a live session
    is_live_session = os.path.exists('/usr/bin/calamares') and os.environ.get('USER') == 'liveuser'
    
    if is_live_session:
        config_dir = '/tmp/soplos-welcome-live'
    else:
        config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
        
    os.makedirs(config_dir, exist_ok=True)
    
    with open(os.path.join(config_dir, 'language'), 'w') as f:
        f.write(lang_code)

def load_language_preference():
    """Loads the user's language preference"""
    # Check if we're in a live session
    is_live_session = os.path.exists('/usr/bin/calamares') and os.environ.get('USER') == 'liveuser'
    
    if is_live_session:
        config_dir = '/tmp/soplos-welcome-live'
    else:
        config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
        
    config_file = os.path.join(config_dir, 'language')
    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            lang_code = f.read().strip()
            # The language code validation will be done in the caller
            return lang_code
    return None

def get_kde_version():
    """
    Gets the KDE/Plasma version if available
    
    Returns:
        str: KDE Plasma version or None if it cannot be determined
    """
    try:
        output = subprocess.check_output(['plasmashell', '--version'], text=True).strip()
        version = output.split(' ')[-1] if ' ' in output else output
        return version
    except Exception:
        return None

def has_autologin_enabled():
    """Verifies if autologin is enabled more precisely"""
    try:
        # Get the current language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        
        # Check SDDM configurations in priority order
        sddm_conf_paths = [
            '/etc/sddm.conf.d/autologin.conf',  # Specific configuration
            '/etc/sddm.conf.d/',                # Configuration directory
            '/etc/sddm.conf',                   # Main configuration
            '/usr/lib/sddm/sddm.conf.d/'        # System configuration
        ]
        
        for conf_path in sddm_conf_paths:
            if os.path.isdir(conf_path):
                # It's a directory, look for .conf files
                try:
                    for filename in os.listdir(conf_path):
                        if filename.endswith('.conf'):
                            full_path = os.path.join(conf_path, filename)
                            autologin_user = _check_autologin_in_file(full_path)
                            if autologin_user:
                                return autologin_user
                except:
                    continue
            elif os.path.isfile(conf_path):
                # It's a file, check directly
                autologin_user = _check_autologin_in_file(conf_path)
                if autologin_user:
                    return autologin_user
        
        return False
    except Exception as e:
        # Get the current language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        print(STRINGS[current_lang]['messages'].get('autologin_check_error', f"Error checking autologin: {e}"))
        return False

def _check_autologin_in_file(file_path):
    """Checks if a specific file contains valid autologin configuration"""
    try:
        # Get the current language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        
        with open(file_path, 'r') as f:
            content = f.read()
            
            if '[Autologin]' in content:
                lines = content.split('\n')
                in_autologin_section = False
                
                for line in lines:
                    line = line.strip()
                    
                    # Detect Autologin section
                    if line == '[Autologin]':
                        in_autologin_section = True
                        continue
                    elif line.startswith('[') and line != '[Autologin]':
                        in_autologin_section = False
                        continue
                    
                    # If we're in the section and find User=
                    if in_autologin_section and line.startswith('User='):
                        if not line.startswith('#'):  # Not commented
                            user = line.split('=')[1].strip()
                            if user:  # There's a user configured
                                print(STRINGS[current_lang]['messages'].get('autologin_found', f"Autologin found in {file_path} for user: {user}").format(file_path=file_path, user=user))
                                return user
        
        return False
    except Exception as e:
        # Get the current language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        print(STRINGS[current_lang]['messages'].get('autologin_file_error', f"Error reading {file_path}: {e}").format(file_path=file_path, error=e))
        return False

def update_kde_locale(locale):
    """Updates the locale configuration in KDE more completely"""
    try:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        
        # Extract the language code (es, en, etc.)
        lang_code = locale.split('_')[0]
        
        # KDE locale configuration using multiple methods
        # 1. plasma-localerc file
        subprocess.run([
            'kwriteconfig5', '--file', 'plasma-localerc',
            '--group', 'Translations',
            '--key', 'LANGUAGE', lang_code
        ], check=False)
        
        # 2. kdeglobals file
        subprocess.run([
            'kwriteconfig5', '--file', 'kdeglobals',
            '--group', 'Locale',
            '--key', 'Language', locale
        ], check=False)
        
        # 3. Specific configuration for regional formats
        subprocess.run([
            'kwriteconfig5', '--file', 'plasma-localerc',
            '--group', 'Formats',
            '--key', 'LANG', locale
        ], check=False)
        
        # 4. Reload configuration in various ways
        commands = [
            ['qdbus', 'org.kde.klauncher', '/KLauncher', 'reparseConfiguration'],
            ['qdbus', 'org.kde.plasma.session', '/MainApplication', 'refreshX11Connection'],
            ['qdbus', 'org.kde.KGlobalSettings', '/KGlobalSettings', 'notifyChange', '0', '0'],
            ['kquitapp5', 'plasmashell', '||', 'true'],
            ['kstart5', 'plasmashell', '||', 'true']
        ]
        
        for cmd in commands:
            try:
                subprocess.run(cmd, check=False, timeout=2)
            except:
                pass
                
    except Exception as e:
        print(STRINGS[current_lang]['messages'].get('kde_config_error', f"Error updating KDE locale: {e}"))

def backup_kde_theme_config():
    """Saves a backup of the KDE theme configuration"""
    try:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        
        home_dir = os.path.expanduser('~')
        config_dir = os.path.join(home_dir, '.config')
        backup_dir = os.path.join(home_dir, '.config', 'soplos-welcome-live', 'theme-backup')
        
        # Create backup directory if it doesn't exist
        os.makedirs(backup_dir, exist_ok=True)
        
        # Files to backup
        theme_files = [
            'kdeglobals',
            'plasma-org.kde.plasma.desktop-appletsrc',
            'plasmarc',
            'kxkbrc'
        ]
        
        # Create backups
        for file in theme_files:
            src_path = os.path.join(config_dir, file)
            dst_path = os.path.join(backup_dir, file)
            if os.path.exists(src_path):
                shutil.copy2(src_path, dst_path)
                print(STRINGS[current_lang]['messages'].get('backed_up', "Backed up {src} -> {dst}").format(src=src_path, dst=dst_path))
        
        return True
    except Exception as e:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        print(STRINGS[current_lang]['messages'].get('kde_backup_error', f"Error backing up KDE configuration: {e}").format(e))
        return False

def restore_kde_theme_config():
    """Restores the KDE theme configuration from backup"""
    try:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        
        home_dir = os.path.expanduser('~')
        config_dir = os.path.join(home_dir, '.config')
        backup_dir = os.path.join(home_dir, '.config', 'soplos-welcome-live', 'theme-backup')
        
        if not os.path.exists(backup_dir):
            print(STRINGS[current_lang]['messages'].get('directory_kept', "Theme backup directory does not exist"))
            return False
        
        # Files to restore
        theme_files = [
            'kdeglobals',
            'plasma-org.kde.plasma.desktop-appletsrc',
            'plasmarc',
            'kxkbrc'
        ]
        
        # Restore from backups
        for file in theme_files:
            src_path = os.path.join(backup_dir, file)
            dst_path = os.path.join(config_dir, file)
            if os.path.exists(src_path):
                shutil.copy2(src_path, dst_path)
                print(STRINGS[current_lang]['messages'].get('restored', "Restored {src} -> {dst}").format(src=src_path, dst=dst_path))
        
        # Reload configuration
        try:
            subprocess.run(['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'], check=False)
            subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript',
                        'refreshCurrentShell()'], check=False)
        except Exception as e:
            print(STRINGS[current_lang]['messages'].get('kde_config_error', f"Error reloading KDE configuration: {e}"))
        
        return True
    except Exception as e:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        print(STRINGS[current_lang]['messages'].get('kde_restore_error', f"Error restoring KDE configuration: {e}").format(e))
        return False

def get_kde_theme_config():
    """Gets the current KDE theme configuration"""
    try:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
            
        theme_config = {}
        home_dir = os.path.expanduser('~')
        config_dir = os.path.join(home_dir, '.config')
        
        # Read color scheme configuration
        try:
            result = subprocess.check_output(
                ['kreadconfig5', '--file', 'kdeglobals', '--group', 'General', '--key', 'ColorScheme'],
                text=True
            ).strip()
            theme_config['ColorScheme'] = result
        except:
            pass
        
        # Read icon theme configuration
        try:
            result = subprocess.check_output(
                ['kreadconfig5', '--file', 'kdeglobals', '--group', 'Icons', '--key', 'Theme'],
                text=True
            ).strip()
            theme_config['IconTheme'] = result
        except:
            pass
        
        # Read plasma theme configuration
        try:
            result = subprocess.check_output(
                ['kreadconfig5', '--file', 'plasmarc', '--group', 'Theme', '--key', 'name'],
                text=True
            ).strip()
            theme_config['PlasmaTheme'] = result
        except:
            pass
        
        # Read cursor theme configuration
        try:
            result = subprocess.check_output(
                ['kreadconfig5', '--file', 'kcminputrc', '--group', 'Mouse', '--key', 'cursorTheme'],
                text=True
            ).strip()
            theme_config['CursorTheme'] = result
        except:
            pass
        
        return theme_config
    except Exception as e:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        print(STRINGS[current_lang]['messages'].get('kde_config_error', f"Error getting theme configuration: {e}"))
        return {}

def apply_kde_theme_config(theme_config):
    """Applies a previously saved theme configuration"""
    try:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        
        if 'ColorScheme' in theme_config:
            subprocess.run([
                'kwriteconfig5', '--file', 'kdeglobals',
                '--group', 'General', '--key', 'ColorScheme', theme_config['ColorScheme']
            ], check=False)
        
        if 'IconTheme' in theme_config:
            subprocess.run([
                'kwriteconfig5', '--file', 'kdeglobals',
                '--group', 'Icons', '--key', 'Theme', theme_config['IconTheme']
            ], check=False)
        
        if 'PlasmaTheme' in theme_config:
            subprocess.run([
                'kwriteconfig5', '--file', 'plasmarc',
                '--group', 'Theme', '--key', 'name', theme_config['PlasmaTheme']
            ], check=False)
        
        if 'CursorTheme' in theme_config:
            subprocess.run([
                'kwriteconfig5', '--file', 'kcminputrc',
                '--group', 'Mouse', '--key', 'cursorTheme', theme_config['CursorTheme']
            ], check=False)
        
        # Reload configurations
        subprocess.run(['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'], check=False)
        subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript', 
                      'refreshCurrentShell()'], check=False)
        subprocess.run(['qdbus', 'org.kde.KGlobalSettings', '/KGlobalSettings', 
                      'notifyChange', '2', '0'], check=False)
        
        return True
    except Exception as e:
        # Get the current system language
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        current_lang = current_locale.split('_')[0]
        if current_lang not in STRINGS:
            current_lang = 'en'
        print(STRINGS[current_lang]['messages'].get('kde_config_error', f"Error applying theme configuration: {e}"))
        return False
