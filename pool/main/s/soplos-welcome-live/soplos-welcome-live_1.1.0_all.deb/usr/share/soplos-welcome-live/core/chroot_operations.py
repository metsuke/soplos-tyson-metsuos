import subprocess
import os
import json
import shutil
import logging
from config.strings import STRINGS

class SystemOperations:
    def __init__(self):
        # Change from /mnt/soplos_rescue to simply /mnt/chroot
        self.mount_point = "/mnt/chroot"
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        # Get system language more robustly
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        # If it's C.UTF-8 or similar, use English by default
        if current_locale.startswith('C.') or current_locale == 'C':
            self.current_lang = 'en'
        else:
            self.current_lang = current_locale.split('_')[0]
            # If language doesn't exist in STRINGS, use English
            if self.current_lang not in STRINGS:
                self.current_lang = 'en'
        
        print(f"DEBUG: SystemOperations - Detected locale: {current_locale}, using language: {self.current_lang}")

    def format_size(self, size):
        """Convert byte sizes to readable format"""
        try:
            size = int(size)
            for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
                if size < 1024.0:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
            return f"{size:.1f} TB"
        except:
            return "Unknown"

    def get_disks(self):
        """Get list of available disks"""
        try:
            cmd = "lsblk -lnp -o NAME,SIZE,MODEL -d -I 8,259"
            output = subprocess.check_output(cmd.split()).decode()
            disks = []
            for line in output.splitlines():
                if line.strip():
                    parts = line.split()
                    device = parts[0]
                    size = parts[1]
                    model = ' '.join(parts[2:]) if len(parts) > 2 else STRINGS[self.current_lang]['labels']['device']
                    disks.append((device, size, model))
            return disks
        except Exception as e:
            self.logger.error(STRINGS[self.current_lang]['messages']['error_loading_disks'])
            return []

    def get_disk_partitions(self, disk_name):
        """Get partitions from a specific disk with complete information including btrfs"""
        try:
            cmd = ['lsblk', '-lnp', '-o', 'NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL,UUID', disk_name]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                raise Exception(f"Error executing lsblk: {result.stderr}")
            
            partitions = []
            used_suggestions = set()
                
            for line in result.stdout.strip().split('\n'):
                parts = line.split()
                # Skip empty lines or main disk
                if not parts or parts[0] == disk_name:
                    continue
                
                device = parts[0]
                size = parts[1]
                fstype = parts[2] if len(parts) > 2 and parts[2] != '' else 'unknown'
                mount = parts[3] if len(parts) > 3 and parts[3] != '' else ''
                label = parts[4] if len(parts) > 4 and parts[4] != '' else ''
                uuid = parts[5] if len(parts) > 5 and parts[5] != '' else ''
                
                # Filter non-mountable partitions
                if self._is_mountable_filesystem(fstype):
                    # Detect btrfs subvolumes
                    btrfs_info = None
                    is_btrfs = False
                    if fstype.lower() == 'btrfs':
                        is_btrfs = True
                        btrfs_info = self._detect_btrfs_subvolumes(device)
                    
                    # Suggest intelligent mount point
                    suggested = self._suggest_mount_point_intelligent(fstype, label, mount, used_suggestions, btrfs_info)
                    if suggested:
                        used_suggestions.add(suggested)
                    
                    partition_data = {
                        'device': device,
                        'size': size,
                        'fstype': fstype,
                        'mountpoint': mount,
                        'label': label,
                        'uuid': uuid,
                        'suggested_mount': suggested,
                        'is_btrfs': is_btrfs
                    }
                    
                    if btrfs_info:
                        partition_data['btrfs_subvolumes'] = btrfs_info
                    
                    partitions.append(partition_data)
            
            return partitions
            
        except Exception as e:
            self.logger.error(STRINGS[self.current_lang]['messages']['error_loading_partitions'])
            raise

    def _detect_btrfs_subvolumes(self, device):
        """Detect btrfs subvolumes on a partition"""
        try:
            temp_mount = f"/tmp/btrfs_temp_{os.getpid()}"
            os.makedirs(temp_mount, exist_ok=True)
            
            try:
                mount_result = subprocess.run(
                    ['sudo', 'mount', '-t', 'btrfs', device, temp_mount],
                    capture_output=True, text=True, timeout=10
                )
                
                if mount_result.returncode != 0:
                    return None
                
                subvol_result = subprocess.run(
                    ['sudo', 'btrfs', 'subvolume', 'list', temp_mount],
                    capture_output=True, text=True, timeout=10
                )
                
                default_result = subprocess.run(
                    ['sudo', 'btrfs', 'subvolume', 'get-default', temp_mount],
                    capture_output=True, text=True, timeout=10
                )
                
                subvolumes = []
                default_subvol_id = None
                
                if default_result.returncode == 0:
                    for line in default_result.stdout.split('\n'):
                        if 'ID' in line:
                            try:
                                default_subvol_id = line.split()[1]
                            except:
                                pass
                
                if subvol_result.returncode == 0:
                    for line in subvol_result.stdout.split('\n'):
                        if line.strip() and 'ID' in line:
                            try:
                                parts = line.split()
                                if len(parts) >= 9:
                                    subvol_id = parts[1]
                                    subvol_path = parts[8]
                                    
                                    suggested_mount = self._suggest_btrfs_mount_point(subvol_path)
                                    
                                    subvolumes.append({
                                        'id': subvol_id,
                                        'path': subvol_path,
                                        'is_default': subvol_id == default_subvol_id,
                                        'suggested_mount': suggested_mount
                                    })
                            except:
                                continue
                
                return {
                    'subvolumes': subvolumes,
                    'default_subvolume_id': default_subvol_id,
                    'has_subvolumes': len(subvolumes) > 0
                }
                
            finally:
                subprocess.run(['sudo', 'umount', temp_mount], 
                             capture_output=True, timeout=5)
                try:
                    os.rmdir(temp_mount)
                except:
                    pass
                    
        except Exception as e:
            self.logger.error(f"Error detecting btrfs subvolumes: {str(e)}")
            return None

    def _suggest_btrfs_mount_point(self, subvol_path):
        """Suggest mount point based on btrfs subvolume name"""
        path_lower = subvol_path.lower()
        
        mount_patterns = {
            '@': '/',
            '@root': '/',
            '@home': '/home',
            '@var': '/var',
            '@tmp': '/tmp',
            '@opt': '/opt',
            '@srv': '/srv',
            '@usr': '/usr',
            '@boot': '/boot',
            'root': '/',
            'home': '/home',
            'var': '/var',
            'tmp': '/tmp'
        }
        
        if subvol_path in mount_patterns:
            return mount_patterns[subvol_path]
        
        for pattern, mount_point in mount_patterns.items():
            if pattern in path_lower:
                return mount_point
                
        return None

    def _suggest_mount_point_intelligent(self, fstype, label, current_mount, used_suggestions, btrfs_info=None):
        """Intelligent mount point suggestions including btrfs"""
        # Ignore current_mount if it contains our mount_point
        if current_mount and self.mount_point in current_mount:
            current_mount = None

        fstype = (fstype or '').lower()
        label = (label or '').lower()

        # EFI filesystems
        if fstype in ['vfat', 'fat32']:
            if 'efi' in label or 'esp' in label or current_mount == '/boot/efi':
                if '/boot/efi' not in used_suggestions:
                    return '/boot/efi'
        
        # Btrfs filesystems with special logic
        elif fstype == 'btrfs':
            if btrfs_info and btrfs_info.get('has_subvolumes'):
                # For btrfs with subvolumes, suggest based on default subvolume
                default_subvol = None
                for subvol in btrfs_info['subvolumes']:
                    if subvol.get('is_default'):
                        default_subvol = subvol
                        break
                
                if default_subvol and default_subvol.get('suggested_mount'):
                    suggested = default_subvol['suggested_mount']
                    if suggested not in used_suggestions:
                        return suggested
                
                # If no clear default subvolume, look for @ or root
                for subvol in btrfs_info['subvolumes']:
                    if subvol['path'] in ['@', 'root'] and '/' not in used_suggestions:
                        return '/'
            
            # Fallback for btrfs without subvolumes
            if '/' not in used_suggestions:
                return '/'
        
        # Linux filesystems
        elif fstype in ['ext2', 'ext3', 'ext4', 'xfs', 'jfs', 'reiserfs', 'f2fs']:
            # Based on labels
            if 'root' in label or 'system' in label:
                if '/' not in used_suggestions:
                    return '/'
            elif 'home' in label:
                if '/home' not in used_suggestions:
                    return '/home'
            elif 'boot' in label and 'efi' not in label:
                if '/boot' not in used_suggestions:
                    return '/boot'
            
            # Based on current mount point
            elif current_mount == '/':
                if '/' not in used_suggestions:
                    return '/'
            elif current_mount == '/home':
                if '/home' not in used_suggestions:
                    return '/home'
            elif current_mount == '/boot':
                if '/boot' not in used_suggestions:
                    return '/boot'
            
            # Priority assignment if no clear labels
            elif '/' not in used_suggestions:
                return '/'
            elif '/boot' not in used_suggestions and fstype in ['ext2', 'ext3', 'ext4']:
                return '/boot'
            elif '/home' not in used_suggestions:
                return '/home'

        return None

    def execute_chroot(self):
        """Executes the chroot"""
        subprocess.run(['chroot', self.mount_point], check=True)

    def execute_gparted(self):
        """Executes GParted using the absolute path"""
        try:
            subprocess.Popen(['pkexec', '/usr/sbin/gparted'])
        except Exception as e:
            self.logger.error(STRINGS[self.current_lang]['messages'].get('gparted_error', f"Error executing GParted: {e}"))

    def _validate_mounted_system(self):
        """Verifies if the mounted system is a valid Linux
        
        Returns:
            bool: True if the system looks like a valid Linux, False otherwise
        """
        # Verify essential directories and files that should exist in a Linux system
        essential_paths = [
            '/bin', '/usr/bin', '/lib', '/usr/lib', 
            '/etc/fstab', '/etc/passwd', '/etc/shadow'
        ]
        
        # At least one shell must exist
        shell_paths = ['/bin/bash', '/bin/sh', '/usr/bin/bash', '/usr/bin/sh']
        
        # Verify essential directories
        essential_found = 0
        for path in essential_paths:
            full_path = os.path.join(self.mount_point, path.lstrip('/'))
            if os.path.exists(full_path):
                essential_found += 1
        
        # Verify if there is at least one shell
        shell_found = False
        for shell in shell_paths:
            full_path = os.path.join(self.mount_point, shell.lstrip('/'))
            if os.path.exists(full_path):
                shell_found = True
                break
        
        # We consider it valid if there are at least 3 essential directories/files and a shell
        return essential_found >= 3 and shell_found

    def unmount_all(self):
        """Unmounts all partitions and virtual filesystems"""
        try:
            # Create a script to safely unmount everything
            unmount_script = f"""#!/bin/bash
# Function to safely unmount a mount point
safe_umount() {{
    local mount_point="$1"
    if mount | grep -q " on $mount_point "; then
        echo "{STRINGS[self.current_lang]['chroot'].get('unmounting', 'Unmounting')} $mount_point..."
        umount -l "$mount_point" || umount -f "$mount_point" || true
    fi
}}

# Unmount virtual filesystems in reverse order
safe_umount {self.mount_point}/dev/pts
safe_umount {self.mount_point}/dev
safe_umount {self.mount_point}/proc
safe_umount {self.mount_point}/sys
safe_umount {self.mount_point}/boot/efi
safe_umount {self.mount_point}/boot
safe_umount {self.mount_point}

echo "{STRINGS[self.current_lang]['chroot'].get('unmount_complete', 'Unmount completed')}"
"""
            # Execute the unmount script
            with open('/tmp/unmount.sh', 'w') as f:
                f.write(unmount_script)
            os.chmod('/tmp/unmount.sh', 0o755)
            
            subprocess.run(['sudo', '/tmp/unmount.sh'], check=False)
            return True
        except Exception as e:
            self.logger.error(STRINGS[self.current_lang]['messages'].get('error_unmounting', f"Error unmounting the system: {e}"))
            return False

    def mount_and_chroot(self, root_part, boot_part=None, efi_part=None, root_subvol=None):
        """Mount partitions and execute chroot with complete btrfs support"""
        try:
            # First unmount any previous mount to avoid conflicts
            self.unmount_all()
            
            # Get translated strings
            strings = STRINGS[self.current_lang]['chroot']
            btrfs_strings = STRINGS[self.current_lang]['btrfs']
            
            # Script to mount everything with btrfs subvolume support
            mount_script = f"""#!/bin/bash
# Create mount point with appropriate permissions
sudo rm -rf {self.mount_point} 2>/dev/null || true
sudo mkdir -p {self.mount_point}
sudo chmod 755 {self.mount_point}

# Verify the mount point exists
if [ ! -d "{self.mount_point}" ]; then
    echo "{STRINGS[self.current_lang]['messages'].get('mount_point_error', 'ERROR: Could not create mount point')} {self.mount_point}"
    exit 1
fi

# Clean any previous mounts
sudo umount -l {self.mount_point}/dev/pts 2>/dev/null || true
sudo umount -l {self.mount_point}/dev 2>/dev/null || true
sudo umount -l {self.mount_point}/proc 2>/dev/null || true
sudo umount -l {self.mount_point}/sys 2>/dev/null || true
sudo umount -l {self.mount_point}/boot/efi 2>/dev/null || true
sudo umount -l {self.mount_point}/boot 2>/dev/null || true
sudo umount -l {self.mount_point} 2>/dev/null || true

echo "{STRINGS[self.current_lang]['chroot'].get('mount_point_label', 'Mount point')}: {self.mount_point}"
echo "{STRINGS[self.current_lang]['chroot'].get('root_partition_label', 'Root partition')}: {root_part}"

# Prepare mount options for btrfs
ROOT_MOUNT_OPTIONS=""
if [ "$ROOT_FSTYPE" = "btrfs" ] && [ -n "{root_subvol or ''}" ]; then
    ROOT_MOUNT_OPTIONS="subvol={root_subvol}"
    echo "Using btrfs subvolume: {root_subvol}"
fi

# Mount root with btrfs subvolume support
if [ -n "$ROOT_MOUNT_OPTIONS" ] && [ "$ROOT_FSTYPE" = "btrfs" ]; then
    echo "{btrfs_strings['mounting_btrfs']} with subvolume"
    sudo mount -t btrfs -o "$ROOT_MOUNT_OPTIONS" "{root_part}" "{self.mount_point}"
else
    sudo mount "{root_part}" "{self.mount_point}"
fi

if [ $? -ne 0 ]; then
    echo "{STRINGS[self.current_lang]['messages'].get('mount_root_error', 'ERROR: Could not mount')} {root_part} {STRINGS[self.current_lang]['messages'].get('in', 'in')} {self.mount_point}"
    exit 1
fi

echo "{strings['mounting_root']} {STRINGS[self.current_lang]['messages'].get('completed', 'completed')}"
"""
            if boot_part:
                mount_script += f"""
# Create /boot directory
echo "{STRINGS[self.current_lang]['chroot'].get('creating_boot_dir', 'Creating /boot directory')}..."
sudo mkdir -p {self.mount_point}/boot

echo "{strings['mounting_boot']} {boot_part}..."
sudo mount {boot_part} {self.mount_point}/boot
if [ $? -ne 0 ]; then
    echo "{STRINGS[self.current_lang]['chroot'].get('mount_boot_error', 'ERROR: Could not mount {0} on {1}/boot').format(boot_part, self.mount_point)}"
    exit 1
fi
"""
            if efi_part:
                mount_script += f"""
# Create /boot/efi directory
echo "{STRINGS[self.current_lang]['chroot'].get('creating_efi_dir', 'Creating /boot/efi directory')}..."
sudo mkdir -p {self.mount_point}/boot/efi

echo "{strings['mounting_efi']} {efi_part}..."
sudo mount {efi_part} {self.mount_point}/boot/efi
if [ $? -ne 0 ]; then
    echo "{STRINGS[self.current_lang]['chroot'].get('mount_efi_error', 'ERROR: Could not mount {0} on {1}/boot/efi').format(efi_part, self.mount_point)}"
    exit 1
fi
"""
            
            mount_script += f"""
# Create directories for bind mounts
echo "{STRINGS[self.current_lang]['chroot'].get('creating_dirs', 'Creating directories for bind mounts')}..."
sudo mkdir -p {self.mount_point}/dev
sudo mkdir -p {self.mount_point}/proc
sudo mkdir -p {self.mount_point}/sys
sudo mkdir -p {self.mount_point}/dev/pts

# {strings['mounting_virtual']}
echo "{strings['mounting_virtual']}..."
sudo mount --bind /dev {self.mount_point}/dev
if [ $? -ne 0 ]; then
    echo "{STRINGS[self.current_lang]['messages'].get('mount_dev_error', 'ERROR: Could not mount /dev on')} {self.mount_point}/dev"
    exit 1
fi

sudo mount --bind /proc {self.mount_point}/proc
if [ $? -ne 0 ]; then
    echo "{STRINGS[self.current_lang]['messages'].get('mount_proc_error', 'ERROR: Could not mount /proc on')} {self.mount_point}/proc"
    exit 1
fi

sudo mount --bind /sys {self.mount_point}/sys
if [ $? -ne 0 ]; then
    echo "{STRINGS[self.current_lang]['messages'].get('mount_sys_error', 'ERROR: Could not mount /sys on')} {self.mount_point}/sys"
    exit 1
fi

sudo mount --bind /dev/pts {self.mount_point}/dev/pts
if [ $? -ne 0 ]; then
    echo "{STRINGS[self.current_lang]['messages'].get('mount_pts_error', 'ERROR: Could not mount /dev/pts on')} {self.mount_point}/dev/pts"
    exit 1
fi

# Copy resolv.conf for DNS resolution
sudo mkdir -p {self.mount_point}/etc
sudo cp /etc/resolv.conf {self.mount_point}/etc/resolv.conf 2>/dev/null || echo "{STRINGS[self.current_lang]['messages'].get('resolv_copy_error', 'Could not copy resolv.conf')}"

# Verify if it is a valid Linux system
if [ ! -e "{self.mount_point}/bin/bash" ] && [ ! -e "{self.mount_point}/usr/bin/bash" ]; then
    echo "{STRINGS[self.current_lang]['messages'].get('no_shell_error', 'ERROR: No valid shell found in the mounted system')}"
    if [ -d "{self.mount_point}/bin" ]; then
        echo "{STRINGS[self.current_lang]['chroot'].get('bin_content', 'Content of /bin')}:"
        ls -la {self.mount_point}/bin/
    fi
    if [ -d "{self.mount_point}/usr/bin" ]; then
        echo "{STRINGS[self.current_lang]['chroot'].get('usr_bin_content', 'Content of /usr/bin')}:"
        ls -la {self.mount_point}/usr/bin/ | grep -E "bash|sh"
    fi
    exit 1
fi

# List contents to verify
echo "{strings['mounting_content']}"
ls -la {self.mount_point}
"""
            
            # Execute mount script
            with open('/tmp/mount.sh', 'w') as f:
                f.write(mount_script)
            os.chmod('/tmp/mount.sh', 0o755)
            mount_result = subprocess.run(['bash', '/tmp/mount.sh'], capture_output=True, text=True)
            
            if mount_result.returncode != 0:
                raise Exception(f"Error mounting partitions: {mount_result.stderr or mount_result.stdout}")
            
            # Verify if it's a valid Linux system before continuing
            is_valid_system = self._validate_mounted_system()
            if not is_valid_system:
                self.unmount_all()
                raise Exception(STRINGS[self.current_lang]['dialog'].get('invalid_partition_desc', "The selected partition does not contain a valid Linux system or is damaged"))
            
            # Script for chroot with shell detection and translated texts
            chroot_script = f"""#!/bin/bash
# Configure cleanup function on exit
cleanup() {{
    echo ""
    echo "===================================================="
    echo "{strings['exit_chroot']}"
    echo "{strings['unmounting']}"
    echo "===================================================="
    
    # Unmount everything on exit
    sudo umount -l {self.mount_point}/dev/pts 2>/dev/null || true
    sudo umount -l {self.mount_point}/dev 2>/dev/null || true
    sudo umount -l {self.mount_point}/proc 2>/dev/null || true
    sudo umount -l {self.mount_point}/sys 2>/dev/null || true

    if [ -d "{self.mount_point}/boot/efi" ] && mountpoint -q {self.mount_point}/boot/efi 2>/dev/null; then
        sudo umount {self.mount_point}/boot/efi 2>/dev/null || sudo umount -l {self.mount_point}/boot/efi 2>/dev/null || true
    fi

    if [ -d "{self.mount_point}/boot" ] && mountpoint -q {self.mount_point}/boot 2>/dev/null; then
        sudo umount {self.mount_point}/boot 2>/dev/null || sudo umount -l {self.mount_point}/boot 2>/dev/null || true
    fi

    sudo umount {self.mount_point} 2>/dev/null || sudo umount -l {self.mount_point} 2>/dev/null || true

    # Check if all filesystems were unmounted
    if mount | grep -q "{self.mount_point}"; then
        echo "{STRINGS[self.current_lang]['messages'].get('unmount_warning', 'WARNING: Some mount points could not be unmounted.')}"
        echo "{STRINGS[self.current_lang]['chroot'].get('still_mounted', 'Filesystems still mounted')}:"
        mount | grep "{self.mount_point}"
        echo "{STRINGS[self.current_lang]['messages'].get('restart_needed', 'You may need to restart the system to free these resources.')}"
    else
        echo "{strings['unmount_complete']}"
    fi

    # Ask if the mount directory should be removed
    read -p "{strings['cleanup_question']}" response
    case "$response" in
        [SsYy]* ) 
            sudo rm -rf {self.mount_point} && echo "{STRINGS[self.current_lang]['messages'].get('directory_removed', 'Directory removed')} {self.mount_point}." || echo "{STRINGS[self.current_lang]['messages'].get('directory_remove_error', 'Could not remove')} {self.mount_point}"
            ;;
        * ) 
            echo "{STRINGS[self.current_lang]['messages'].get('directory_kept', 'Directory kept')} {self.mount_point}."
            ;;
    esac

    echo "{strings['process_complete']}"
    exit 0
}}

# Configure signal traps
trap cleanup EXIT INT TERM

# Verify the mount point exists
if [ ! -d "{self.mount_point}" ]; then
    echo "{STRINGS[self.current_lang]['messages'].get('mount_point_missing', 'ERROR: The mount point does not exist')} {self.mount_point}"
    exit 1
fi

# List contents to verify
echo "{strings['mounting_content']}"
ls -la {self.mount_point}

# Detect the available shell
if [ -e "{self.mount_point}/bin/bash" ]; then
    SHELL_PATH="/bin/bash"
elif [ -e "{self.mount_point}/usr/bin/bash" ]; then
    SHELL_PATH="/usr/bin/bash"
elif [ -e "{self.mount_point}/bin/sh" ]; then
    SHELL_PATH="/bin/sh"
elif [ -e "{self.mount_point}/usr/bin/sh" ]; then
    SHELL_PATH="/usr/bin/sh"
else
    echo "{STRINGS[self.current_lang]['messages'].get('shell_not_found', 'ERROR: No valid shell found in the mounted system')}"
    exit 1
fi

echo "{strings['using_shell']} $SHELL_PATH"
echo "{strings['starting_chroot']}"

# Configure terminal for better appearance in chroot
export TERM=xterm-256color
export PS1="\\[\\e[1;31m\\](chroot) \\[\\e[1;34m\\]\\w \\[\\e[0m\\]\\$ "

echo "===================================================="
echo "  {strings['terminal_title'].upper()}"
echo "===================================================="
echo "{strings['welcome_message']}"
echo "{strings['instructions']}"
echo ""
echo "{strings['exit_message']}"
echo "===================================================="

# Enter chroot with the detected shell
exec sudo chroot {self.mount_point} $SHELL_PATH
"""
            
            with open('/tmp/chroot.sh', 'w') as f:
                f.write(chroot_script)
            os.chmod('/tmp/chroot.sh', 0o755)
            
            # Use konsole without --noclose to allow automatic closing
            terminal_cmd = ['konsole', '--hide-menubar', '--hide-tabbar', 
                           '--title', strings['terminal_title'], 
                           '-e', 'bash', '/tmp/chroot.sh']
            
            # Execute chroot in konsole
            try:
                subprocess.Popen(terminal_cmd, start_new_session=True)
            except Exception as e:
                self.logger.error(STRINGS[self.current_lang]['messages'].get('konsole_error', f"Error starting konsole: {e}"))
                # If it fails, try with the only fallback which is xterm
                try:
                    subprocess.Popen(['xterm', '-title', strings['terminal_title'], 
                                    '-e', 'bash', '/tmp/chroot.sh'])
                except Exception as e:
                    self.logger.error(STRINGS[self.current_lang]['messages'].get('xterm_error', f"Error starting xterm: {e}"))
                    # Last resort: generic terminal
                    subprocess.Popen(['x-terminal-emulator', '-e', 'bash', '/tmp/chroot.sh'])
        
        except Exception as e:
            # Ensure cleanup if something goes wrong
            self.unmount_all()
            raise e
