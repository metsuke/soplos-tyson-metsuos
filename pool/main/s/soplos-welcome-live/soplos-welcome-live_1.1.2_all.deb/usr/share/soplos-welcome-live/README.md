# Soplos Welcome Live

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.1.2-green.svg)]()

Welcome screen for Soplos Linux Live Environment that helps users navigate the system and perform installation.

## 📝 Description

A welcome application for Soplos Linux Live Environment that helps users navigate the live system and install Soplos Linux, offering multiple configuration and customization tools.

## ✨ Features

- Software Center integration
- Driver management
- System customization tools
- Recommended software installation
- Multi-language support (8 languages)
- Hardware detection and configuration
- Locale and keyboard layout configuration
- CHROOT recovery tools
- GParted integration for disk management
- Autostart control for welcome screen
- NumLock activation toggle

## 📸 Screenshots

### Live Welcome Screen
![Welcome Screen](https://raw.githubusercontent.com/SoplosLinux/tyson/main/media/soplos-welcome-live/screenshots/screenshot1.png)

### Installation Options
![Installation Options](https://raw.githubusercontent.com/SoplosLinux/tyson/main/media/soplos-welcome-live/screenshots/screenshot2.png)

### Hardware Detection
![Hardware Detection](https://raw.githubusercontent.com/SoplosLinux/tyson/main/media/soplos-welcome-live/screenshots/screenshot3.png)

## 🔧 Installation

```bash
sudo apt install soplos-welcome-live
```

## 🌐 Supported Languages

- Spanish
- English
- French
- Portuguese
- German
- Italian
- Russian
- Romanian

## 📄 License

This project is licensed under [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License version 3 or later).

This license guarantees the following freedoms:
- The freedom to use the program for any purpose
- The freedom to study how the program works and modify it
- The freedom to distribute copies of the program
- The freedom to improve the program and publish those improvements

Any derivative work must be distributed under the same license (GPL-3.0+).

For more details, see the LICENSE file or visit [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Developers

Developed by Sergi Perich

## 🔗 Links

- [Website](https://soploslinux.com)
- [GitHub Repository](https://github.com/SoplosLinux)
- [Report Issues](https://github.com/SoplosLinux/tyson/issues)
- [Contact](mailto:info@soploslinux.com)

## 📦 Versions

### v1.1.2 (07/27/2025)
- Advanced detection and selection of partitions and btrfs subvolumes in the chroot environment.
- Full support for mounting /home as a partition or btrfs subvolume.
- Improved robustness of the recovery flow and compatibility with multiple terminals.
- Author changed to Sergi Perich.

### v1.1.1 (07/18/2025)
- Minor maintenance update and translations.
- Minor improvements in language detection and startup robustness.

### v1.1.0 (07/16/2025)
- Metainfo finalized to AppStream/DEP-11 standard.
- Program icons added in 48x48, 64x64, and 128x128.

### v1.0.9 (07/14/2025)
- Finalized metainfo corrections for proper appearance in software centers (AppStream/Discover).

### v1.0.8 (07/13/2025)
- Fixed metainfo file for proper visualization in Discover/AppStream.

### v1.0.7 (07/10/2025)
- Full support for btrfs subvolumes in CHROOT recovery.
- Complete removal of NumLockX.
- Correction and review of all dictionary text strings.

### v1.0.6 (06/24/2025)
- Now visible in Discover (AppStream integration).

### v1.0.5 (06/20/2025)
- Complete program internationalization.
- Label refinement to English for better consistency.
- Minor bug fixes.
- General stability improvements.
- User interface optimizations.
- Performance improvements.

### v1.0.3 (01/27/2024)
- Initial release version.
