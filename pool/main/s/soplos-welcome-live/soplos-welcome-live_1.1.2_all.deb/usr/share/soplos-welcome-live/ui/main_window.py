import gi
import os
import subprocess
import sys
import shutil
import json
import time

# Add the root directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf, Gdk, GLib
from ui.welcome_tab import WelcomeTab
from config.paths import LOGO_PATH, ICON_PATH
from config.strings import STRINGS
from utils.autostart import AutostartManager
from ui.chroot_window import ChRootWindow
from utils.desktop_detector import (
    get_desktop_environment, 
    get_session_type,
    has_autologin_enabled,
    update_kde_locale
)
from utils.session_manager import session_manager  # Import the new session_manager
from utils.xdg_helper import xdg_manager  # Add import

# Dictionary of languages and their configurations
LANGUAGES = {
    'Español': {'locale': 'es_ES.UTF-8', 'layout': 'es'},
    'English': {'locale': 'en_US.UTF-8', 'layout': 'us'},
    'Português': {'locale': 'pt_PT.UTF-8', 'layout': 'pt'},
    'Français': {'locale': 'fr_FR.UTF-8', 'layout': 'fr'},
    'Deutsch': {'locale': 'de_DE.UTF-8', 'layout': 'de'},
    'Italiano': {'locale': 'it_IT.UTF-8', 'layout': 'it'},
    'Română': {'locale': 'ro_RO.UTF-8', 'layout': 'ro'},
    'Русский': {'locale': 'ru_RU.UTF-8', 'layout': 'ru'}
}

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, lang_code=None):
        super().__init__()
        # Detectar idioma del sistema si no se pasa lang_code
        if lang_code and lang_code in STRINGS:
            self.current_lang = lang_code
        else:
            current_locale = os.getenv('LANG', 'en_US.UTF-8')
            if current_locale.startswith('C.') or current_locale == 'C':
                self.current_lang = 'en'
            else:
                lang_code = current_locale.split('_')[0]
                self.current_lang = lang_code if lang_code in STRINGS else 'en'
        
        # Set WM_CLASS to match the .desktop file
        # These technical identifiers should remain consistent but could be added to config
        self.set_wmclass("com.soplos.welcomelive", "com.soplos.welcomelive")
        
        # Explicitly set the window icon
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.welcomelive", 128, 0)
                self.set_icon(icon)
            except:
                # Fallback to absolute path if loading by name fails
                if os.path.exists(ICON_PATH):
                    self.set_icon_from_file(ICON_PATH)
        except Exception as e:
            print(STRINGS[self.current_lang]['messages'].get('icon_error', f"Error loading icon: {e}"))
        
        app = Gtk.Application.get_default()
        Gtk.ApplicationWindow.__init__(self, application=app)
        self.set_title(STRINGS[self.current_lang]['messages'].get('app_title', "Soplos Welcome Live"))
        
        # Detect desktop environment and session type
        self.desktop_env = get_desktop_environment()
        self.session_type = get_session_type()
        print(STRINGS[self.current_lang]['messages'].get('desktop_info', f"Desktop environment: {self.desktop_env}, Session type: {self.session_type}").format(self.desktop_env, self.session_type))
        
        # Check if we're starting after a language change
        self._check_restart_state()
        
        # REMOVE DUPLICATE LANGUAGE DETECTION THAT WAS HERE
        
        # Look for language name in LANGUAGES
        current_language_name = None
        for name, config in LANGUAGES.items():
            if config['locale'].startswith(f"{self.current_lang}_"):
                current_language_name = name
                break
        
        if not current_language_name:
            # If no name was found, use the first one that matches the code
            for name, config in LANGUAGES.items():
                if config['locale'].startswith(self.current_lang):
                    current_language_name = name
                    break
        
        self.set_title(STRINGS[self.current_lang]['welcome'])
        self.set_wmclass('soplos-welcome-live', 'soplos-welcome-live')
        
        self.set_border_width(10)
        
        self.set_default_size(800, 450)  # Increased height from 400 to 550
        self.set_position(Gtk.WindowPosition.CENTER)
        
        # Main horizontal container
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Horizontal sub-container for logo and content
        content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.pack_start(content_box, True, True, 0)

        # Left panel for logo (now goes in content_box)
        left_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        left_panel.set_size_request(200, -1)
        content_box.pack_start(left_panel, False, False, 5)

        try:
            header_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                filename=LOGO_PATH,
                width=150,
                height=150,
                preserve_aspect_ratio=True
            )
            logo_image = Gtk.Image.new_from_pixbuf(header_pixbuf)
            left_panel.pack_start(logo_image, False, False, 10)
        except Exception as e:
            print(STRINGS[self.current_lang]['messages'].get('logo_error', f"Error loading logo: {e}"))
        
        welcome_label = Gtk.Label()
        welcome_label.set_markup(
            f"<span size='large' weight='bold'>{STRINGS[self.current_lang]['welcome']}</span>\n" +
            f"<span size='small'>{STRINGS[self.current_lang]['thanks']}</span>"
        )
        welcome_label.set_justify(Gtk.Justification.CENTER)
        welcome_label.set_line_wrap(True)
        left_panel.pack_start(welcome_label, False, False, 5)
        
        # Add flexible space that will push the language selector downwards
        left_panel.pack_start(Gtk.Box(), True, True, 0)
        
        # Language selector and autostart in the left panel
        controls_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        left_panel.pack_end(controls_box, False, False, 0)

        # Autostart switch (removed numlockx switch)
        autostart_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        autostart_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['show_startup'])
        autostart_box.pack_start(autostart_label, False, False, 0)
        
        self.autostart_switch = Gtk.Switch()
        self.autostart_manager = AutostartManager()
        self.autostart_switch.set_active(self.autostart_manager.is_enabled())
        self.autostart_switch.connect("notify::active", self.on_autostart_toggled)
        autostart_box.pack_end(self.autostart_switch, False, False, 0)
        
        controls_box.pack_start(autostart_box, False, False, 5)
        
        # Language selector in the left panel, will now align with the exit button
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        lang_box.set_margin_bottom(5)  # Bottom margin to align with exit button
        controls_box.pack_start(lang_box, False, False, 0)  # Use pack_end instead of pack_start
        
        lang_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['language'])
        lang_box.pack_start(lang_label, False, False, 0)
        
        self.lang_combo = Gtk.ComboBoxText()
        # Add languages and save the current language index
        current_index = 0
        for i, (lang, config) in enumerate(LANGUAGES.items()):
            self.lang_combo.append_text(lang)
            if current_language_name and lang == current_language_name:
                current_index = i
        
        # Select the current language by index
        self.lang_combo.set_active(current_index)
        self.lang_combo.connect("changed", self.on_language_changed)
        lang_box.pack_start(self.lang_combo, True, True, 5)
        
        # Right panel (now goes in content_box)
        right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        content_box.pack_start(right_panel, True, True, 0)
        
        welcome_tab = WelcomeTab(self)
        right_panel.pack_start(welcome_tab, True, True, 0)
        
        # Bottom panel with buttons
        button_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        right_panel.pack_end(button_panel, False, False, 5)

        # Buttons (maintain existing order)
        exit_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['exit'])
        exit_button.set_use_underline(True)
        exit_button.connect("clicked", self.on_exit_clicked)
        button_panel.pack_end(exit_button, False, False, 0)

        chroot_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['chroot'])
        chroot_button.set_use_underline(True)
        chroot_button.connect("clicked", self.on_chroot_clicked)
        button_panel.pack_end(chroot_button, False, False, 5)

        install_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['install'])
        install_button.set_use_underline(True)
        install_button.connect("clicked", self.on_install_clicked)
        install_button.get_style_context().add_class("install-button")
        button_panel.pack_end(install_button, False, False, 5)

        # Progress bar at the end of main_box
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(False)  # Initially without text
        self.progress_bar.set_visible(False)
        main_box.pack_end(self.progress_bar, False, True, 0)

        # CSS for the install button - These colors should be in a separate config file
        css_provider = Gtk.CssProvider()
        css = b"""
            .install-button {
                background: #e95420;
                color: white;
                padding: 5px 10px;
                font-weight: bold;
            }
            .install-button:hover {
                background: #e9662b;
            }
        """
        css_provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def _check_restart_state(self):
        """Checks if we're starting after a language change"""
        # Check if it's the first app start and avoid unnecessary actions
        first_run_file = os.path.join(session_manager.config_dir, 'first_run_completed')
        is_first_run = not os.path.exists(first_run_file)
        
        if is_first_run:
            print(STRINGS[self.current_lang]['messages'].get('first_start_detected', "First start detected, skipping restart verification"))
            try:
                # Mark first start as completed
                with open(first_run_file, 'w') as f:
                    f.write(str(time.time()))
                return
            except Exception as e:
                print(STRINGS[self.current_lang]['messages'].get('first_start_error', f"Error marking first start: {e}"))
        
        # Verify normal restart only if it's not first start
        if session_manager.was_restarted():
            print(STRINGS[self.current_lang]['messages'].get('restart_detected', "Restart detected due to language change, applying configuration..."))
            
            # Check if locale was applied correctly
            session_manager.verify_locale_applied()
            
            # Restore only keyboard and locale configuration, keep theme intact
            success = session_manager.restore_theme_from_skel()
            if not success:
                print(STRINGS[self.current_lang]['messages'].get('keyboard_config_warning', "Warning: Could not apply keyboard/locale configuration"))
                
            # Delete state file
            session_manager.clear_restart_state()

    def on_language_changed(self, combo):
        lang_name = combo.get_active_text()
        lang_config = LANGUAGES[lang_name]
        
        # Get language code and complete locale
        lang_code = lang_config['locale'].split('_')[0]
        locale = lang_config['locale']
        layout = lang_config['layout']
        
        # Show progress bar with text
        self.progress_bar.set_visible(True)
        self.progress_bar.set_show_text(True)
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text(STRINGS[self.current_lang]['progress']['configuring'])
        
        try:
            # Update progress bar while tasks are performed
            self.progress_bar.set_fraction(0.2)
            while Gtk.events_pending():
                Gtk.main_iteration()
        
            # Change current language for this session immediately
            os.environ['LANG'] = locale
            os.environ['LC_ALL'] = locale
            
            # 1. Configure system-level locale and keyboard
            success = session_manager.configure_system_locale(locale, layout)
            if not success:
                raise Exception(STRINGS[self.current_lang]['messages'].get('locale_config_error', "Error configuring system locale"))
                
            self.progress_bar.set_fraction(0.6)
            while Gtk.events_pending():
                Gtk.main_iteration()
                
            # 2. Migrate XDG directories according to new locale using xdg_manager
            xdg_manager.update_directories(locale)
            
            self.progress_bar.set_fraction(0.8)
            while Gtk.events_pending():
                Gtk.main_iteration()
                
            # 3. Ensure autologin is configured before restart
            username = os.environ.get('USER', 'liveuser')
            session_manager.ensure_autologin(username)
            
            # 4. Prepare to restart session
            self.progress_bar.set_text(STRINGS[self.current_lang]['messages'].get('restarting_session', "Restarting session..."))
            self.progress_bar.set_fraction(1.0)
            while Gtk.events_pending():
                Gtk.main_iteration()
                
            # 5. Restart SDDM after a short pause
            GLib.timeout_add(1500, self._restart_session)
            
        except Exception as e:
            self.progress_bar.set_visible(False)
            self.show_error_dialog(f"{STRINGS[self.current_lang]['locale']['error_generating']}\n{str(e)}")

    def reload_app_for_language(self, lang_code):
        """Reloads the app with the new language without restarting SDDM"""
        self.progress_bar.set_visible(False)
        
        # Inform user that changes were applied
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=STRINGS[lang_code]['locale']['restart_session_title']
        )
        dialog.format_secondary_text(STRINGS[lang_code]['locale']['restart_session_desc'])
        dialog.run()
        dialog.destroy()
        
        # Restart the application
        python = sys.executable
        os.execl(python, python, *sys.argv)
        
        return False  # So the timer doesn't execute it again

    def _configure_system_locale_robust(self, locale, layout):
        """Robust locale configuration for live ISO"""
        try:
            # 1. Generate locale if it doesn't exist
            subprocess.run(['sudo', 'locale-gen', locale], check=True)
            
            # 2. Write to /etc/locale.conf with robust method
            # Configuration templates should be in separate template files
            # or at least defined as constants at the beginning of the file
            locale_content = f"""LANG={locale}
LC_ALL={locale}
LANGUAGE={locale.split('_')[0]}
"""
            with open('/tmp/locale.conf', 'w') as f:
                f.write(locale_content)
            subprocess.run(['sudo', 'mv', '/tmp/locale.conf', '/etc/locale.conf'], check=True)
            
            # 3. Configure keyboard for current session
            subprocess.run(['setxkbmap', layout], check=True)
            
            # 4. Configure permanent keyboard
            keyboard_conf = f"""Section "InputClass"
    Identifier "system-keyboard"
    MatchIsKeyboard "on"
    Option "XkbLayout" "{layout}"
EndSection
"""
            subprocess.run(['sudo', 'mkdir', '-p', '/etc/X11/xorg.conf.d'], check=True)
            with open('/tmp/00-keyboard.conf', 'w') as f:
                f.write(keyboard_conf)
            subprocess.run(['sudo', 'mv', '/tmp/00-keyboard.conf', '/etc/X11/xorg.conf.d/00-keyboard.conf'], check=True)
            
            # 5. Save locale information for later verification
            locale_info = {
                'locale': locale,
                'layout': layout,
                'timestamp': time.time()
            }
            locale_info_file = os.path.join(session_manager.config_dir, 'locale_info.json')
            with open(locale_info_file, 'w') as f:
                json.dump(locale_info, f)
            
            return True
        except Exception as e:
            print(STRINGS[self.current_lang]['messages'].get('robust_locale_error', f"Error in robust locale configuration: {e}"))
            return False
    
    def _ensure_autologin_robust(self, username):
        """Robust autologin configuration for live ISO"""
        try:
            # This template should be in a template file or defined as a constant
            autologin_content = f"""[Autologin]
User={username}
Session=plasma
Relogin=true

[General]
HaltCommand=/usr/bin/systemctl poweroff
RebootCommand=/usr/bin/systemctl reboot
"""
            
            # 2. Ensure SDDM configuration directory
            subprocess.run(['sudo', 'mkdir', '-p', '/etc/sddm.conf.d'], check=True)
            
            # 3. Write autologin configuration
            with open('/tmp/autologin.conf', 'w') as f:
                f.write(autologin_content)
            subprocess.run(['sudo', 'mv', '/tmp/autologin.conf', '/etc/sddm.conf.d/autologin.conf'], check=True)
            subprocess.run(['sudo', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=True)
            
            # 4. Also configure the main SDDM file if it exists
            if os.path.exists('/etc/sddm.conf'):
                # Read current configuration
                try:
                    with open('/etc/sddm.conf', 'r') as f:
                        sddm_content = f.read()
                    
                    # If it doesn't have an Autologin section, add it
                    if '[Autologin]' not in sddm_content:
                        sddm_content += f"\n\n{autologin_content}"
                    else:
                        # Replace existing section
                        lines = sddm_content.split('\n')
                        new_lines = []
                        in_autologin = False
                        
                        for line in lines:
                            if line.strip() == '[Autologin]':
                                in_autologin = True
                                new_lines.append(line)
                                new_lines.append(f'User={username}')
                                new_lines.append(f'Session=plasma')
                                new_lines.append(f'Relogin=true')
                            elif line.startswith('[') and line != '[Autologin]':
                                in_autologin = False
                                new_lines.append(line)
                            elif not in_autologin:
                                new_lines.append(line)
                        
                        sddm_content = '\n'.join(new_lines)
                    
                    with open('/tmp/sddm.conf', 'w') as f:
                        f.write(sddm_content)
                    subprocess.run(['sudo', 'mv', '/tmp/sddm.conf', '/etc/sddm.conf'], check=True)
                except Exception as e:
                    print(STRINGS[self.current_lang]['messages'].get('sddm_config_error', f"Error modifying /etc/sddm.conf: {e}"))
            
            return True
        except Exception as e:
            print(STRINGS[self.current_lang]['messages'].get('robust_autologin_error', f"Error configuring robust autologin: {e}"))
            return False

    def _restart_session_robust(self):
        """Robust restart of the session"""
        try:
            # Create restart script that persists
            restart_script = f"""#!/bin/bash
echo "{STRINGS[self.current_lang]['messages'].get('restarting_sddm_script', 'Restarting SDDM to apply language changes...')}"
systemctl restart sddm
"""
            with open('/tmp/restart_sddm.sh', 'w') as f:
                f.write(restart_script)
            os.chmod('/tmp/restart_sddm.sh', 0o755)
            
            # Execute restart with sudo
            subprocess.run(['sudo', '/tmp/restart_sddm.sh'], check=True)
            return False
        except Exception as e:
            print(STRINGS[self.current_lang]['messages'].get('robust_restart_error', f"Error in robust restart: {e}"))
            return False

    def _migrate_xdg_dirs_safely(self, locale):
        """Delegate XDG directory migration to specialized module"""
        from utils.xdg_helper import xdg_manager
        return xdg_manager.update_directories(locale)
    
    def _restart_session(self):
        """Automatically restart session with forced autologin"""
        print(STRINGS[self.current_lang]['messages'].get('restarting_sddm', "Restarting SDDM to apply language changes..."))
        session_manager.restart_sddm()
        return False  # so GLib.timeout_add doesn't call it again

    def _restore_kde_desktop_config(self):
        """Reload KDE desktop configuration completely"""
        try:
            # Reload KDE configuration more completely
            commands = [
                ['qdbus', 'org.kde.keyboard', '/Layouts', 'reset'],
                ['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'],
                ['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript', 'refreshCurrentShell()'],
                ['qdbus', 'org.kde.KGlobalSettings', '/KGlobalSettings', 'notifyChange', '0', '0']
            ]
            
            for cmd in commands:
                try:
                    subprocess.run(cmd, check=False)
                except Exception as e:
                    print(STRINGS[self.current_lang]['messages'].get('kde_command_error', f"Error executing {cmd}: {e}"))
        except Exception as e:
            print(STRINGS[self.current_lang]['messages'].get('kde_config_error', f"Error reloading KDE configuration: {e}"))
    
    def _hide_progress_bar(self):
        """Hide the progress bar"""
        self.progress_bar.set_visible(False)
        return False  # so GLib.timeout_add doesn't call it again
    
    def show_error_dialog(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def on_exit_clicked(self, widget):
        """Handler for exit button"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=STRINGS[self.current_lang]['dialog']['exit_title']
        )
        dialog.format_secondary_text(STRINGS[self.current_lang]['dialog']['exit_desc'])
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            app = self.get_application()
            if app:
                app.quit()
    
    def on_window_destroy(self, window):
        """Handler for destroy signal"""
        app = self.get_application()
        if app:
            app.quit()

    def on_chroot_clicked(self, button):
        """Opens the CHROOT window"""
        # Environment variables - These are technical and can remain hardcoded
        os.environ['NO_AT_BRIDGE'] = '1'
        os.environ['GTK_MODULES'] = ''
        os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''
        os.environ['XDG_RUNTIME_DIR'] = f"/run/user/{os.getuid()}"
        os.environ['DISPLAY'] = ':0'
        
        from ui.chroot_window import ChRootWindow
        chroot_window = ChRootWindow()
        chroot_window.show_all()

    def on_gparted_clicked(self, button):
        """Executes GParted"""
        os.system(STRINGS[self.current_lang]['commands'].get('gparted', 'sudo gparted'))  # Use os.system directly

    def on_install_clicked(self, button):
        """Executes the Calamares installer"""
        subprocess.Popen([STRINGS[self.current_lang]['commands'].get('calamares_sudo', 'sudo'), STRINGS[self.current_lang]['commands'].get('calamares', 'calamares')])
        # Destroy the window after 1 second
        GLib.timeout_add(1000, lambda: self.destroy())

    def on_autostart_toggled(self, switch, gparam):
        """Handles the change in the autostart switch"""
        if switch.get_active():
            self.autostart_manager.enable()
        else:
            self.autostart_manager.disable()