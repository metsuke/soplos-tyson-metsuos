from setuptools import setup, find_packages

setup(
    name="soplos-welcome-live",
    version="1.1.2",  # Update version
    packages=find_packages(),
    install_requires=[
        'PyGObject>=3.40.0',
    ],
    data_files=[
        ('share/icons/hicolor/128x128/apps', ['assets/icons/soplos-welcome-live.png'])
    ],
    entry_points={
        'console_scripts': [
            'soplos-welcome-live=main:main',
        ],
    },
    author="Sergi Perich",
    author_email="info@soploslinux.com",
    url="https://soploslinux.com",
    description="Advanced welcome screen for Soplos Linux Live Environment with btrfs support",
    license="GPL-3.0",
)
