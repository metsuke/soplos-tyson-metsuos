# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [1.1.2] - 2025-07-27

### ✨ Added - Advanced partition detection and support
- Advanced detection and selection of partitions and btrfs subvolumes in the chroot environment.
- Full support for mounting /home as a partition or btrfs subvolume.
- Improved robustness of the recovery flow and compatibility with multiple terminals.
- Author changed to Sergi Perich.

## [1.1.1] - 2025-07-18

### 🛠️ Fixed - Maintenance and robustness
- Minor maintenance update and translations.
- Minor improvements in language detection and startup robustness.

## [1.1.0] - 2025-07-16

### ✨ Added - AppStream/DEP-11 standard and icons
- Metainfo finalized to AppStream/DEP-11 standard.
- Program icons added in 48x48, 64x64, and 128x128.

## [1.0.9] - 2025-07-14

### 🛠️ Fixed - Metainfo and software center visibility
- Finalized metainfo corrections for proper appearance in software centers (AppStream/Discover).

## [1.0.8] - 2025-07-13

### 🛠️ Fixed - Metainfo
- Fixed metainfo file for proper visualization in Discover/AppStream.

## [1.0.7] - 2025-07-10

### 🌍 Added - Recovery and support
- Full support for btrfs subvolumes in CHROOT recovery.

### 🗑️ Removed
- Complete removal of NumLockX.

### 🐛 Fixed - Strings and texts
- Correction and review of all dictionary text strings.

## [1.0.6] - 2025-06-24

### 🌍 Added - AppStream integration
- Now visible in Discover (AppStream integration).

## [1.0.5] - 2025-06-20

### 🌍 Added - Internationalization
- Complete program internationalization.
- Label refinement to English for better consistency.

### 🐛 Fixed - Stability
- Minor bug fixes.
- General stability improvements.

### 🔧 Improved - Interface and performance
- User interface optimizations.
- Performance improvements.

## [1.0.4] - 2025-06-15

### 🐛 Fixed - Interface and stability
- Minor interface fixes.
- Stability improvements.

## [1.0.3] - 2024-01-27

### 🎉 Initial Release
- Initial version.
- Software Center integration.
- Driver management.
- System customization tools.
- Recommended software installation.
- Multi-language support (8 languages).
- Hardware detection and configuration.
- Locale and keyboard layout configuration.
- CHROOT recovery tools.
- GParted integration for disk management.
- Autostart control for the welcome screen.
- NumLock activation toggle.

---

## Types of Changes

- **Added** for new features
- **Changed** for changes in existing functionality
- **Deprecated** for soon-to-be removed features
- **Removed** for now removed features
- **Fixed** for any bug fixes
- **Security** for vulnerabilities

## Contributing

To report bugs or request features:
- **Issues**: https://github.com/SoplosLinux/tyson/issues
- **Email**: info@soploslinux.com

## Support

- **Documentation**: https://soploslinux.com/foros/
- **Community**: https://soploslinux.com/foros/
- **Support**: info@soploslinux.com
