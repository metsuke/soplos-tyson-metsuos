"""
Main configuration package for Soplos Welcome Live.

This module initializes the configuration by setting up paths and importing
key configuration variables from submodules, making them available
to the rest of the application.
"""
import os
import sys

# Add the root directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Configuration package

# Import the necessary paths
from .paths import (
    LOGO_PATH,
    ICON_PATH,
    SLIDE_PATH,
    BASE_DIR,
    ASSETS_DIR,
    SLIDES_DIR,
    ICONS_DIR
)

# Import from the strings module (which is in strings/__init__.py)
from .strings import STRINGS

# Ensure that the assets directories exist
os.makedirs(ICONS_DIR, exist_ok=True)
os.makedirs(SLIDES_DIR, exist_ok=True)

__all__ = ['STRINGS', 'LOGO_PATH', 'ICON_PATH', 'SLIDE_PATH', 'BASE_DIR', 'ASSETS_DIR', 'ICONS_DIR', 'SLIDES_DIR']