"""
Internationalized text strings module for Soplos Welcome Live
Supports 8 languages: Spanish, English, Portuguese, French, German, Italian, Romanian and Russian
"""

# Import all translations
from .es import STRINGS_ES
from .en import STRINGS_EN
from .pt import STRINGS_PT
from .fr import STRINGS_FR
from .de import STRINGS_DE
from .it import STRINGS_IT
from .ro import STRINGS_RO
from .ru import STRINGS_RU

# Combine all translations into the main dictionary
STRINGS = {
    'es': STRINGS_ES,
    'en': STRINGS_EN,
    'pt': STRINGS_PT,
    'fr': STRINGS_FR,
    'de': STRINGS_DE,
    'it': STRINGS_IT,
    'ro': STRINGS_RO,
    'ru': STRINGS_RU
}

# List of available languages
AVAILABLE_LANGUAGES = list(STRINGS.keys())

# Mapping of language codes to native names
LANGUAGE_NAMES = {
    'es': 'Español',
    'en': 'English',
    'pt': 'Português',
    'fr': 'Français',
    'de': 'Deutsch',
    'it': 'Italiano',
    'ro': 'Română',
    'ru': 'Русский'
}

# Add btrfs support to all language strings
for lang_code in STRINGS:
    if 'btrfs' not in STRINGS[lang_code]:
        if lang_code == 'es':
            STRINGS[lang_code]['btrfs'] = {
                'detected': 'Sistema de archivos Btrfs detectado',
                'subvolumes_found': 'Subvolúmenes encontrados',
                'select_subvolume': 'Seleccionar subvolumen',
                'no_subvolumes': 'No se encontraron subvolúmenes en esta partición',
                'default_subvolume': 'Subvolumen por defecto',
                'mount_subvolume': 'Montar subvolumen',
                'subvolume_id': 'ID del subvolumen',
                'subvolume_path': 'Ruta del subvolumen',
                'detecting_subvolumes': 'Detectando subvolúmenes btrfs...',
                'mounting_btrfs': 'Montando sistema de archivos btrfs',
                'invalid_btrfs': 'Partición btrfs no válida o corrupta'
            }
        elif lang_code == 'en':
            STRINGS[lang_code]['btrfs'] = {
                'detected': 'Btrfs filesystem detected',
                'subvolumes_found': 'Subvolumes found',
                'select_subvolume': 'Select subvolume',
                'no_subvolumes': 'No subvolumes found on this partition',
                'default_subvolume': 'Default subvolume',
                'mount_subvolume': 'Mount subvolume',
                'subvolume_id': 'Subvolume ID',
                'subvolume_path': 'Subvolume path',
                'detecting_subvolumes': 'Detecting btrfs subvolumes...',
                'mounting_btrfs': 'Mounting btrfs filesystem',
                'invalid_btrfs': 'Invalid or corrupted btrfs partition'
            }
        # Add similar blocks for pt, fr, de, it, ro, ru following the same pattern
        elif lang_code == 'pt':
            STRINGS[lang_code]['btrfs'] = {
                'detected': 'Sistema de arquivos Btrfs detectado',
                'subvolumes_found': 'Subvolumes encontrados',
                'select_subvolume': 'Selecionar subvolume',
                'no_subvolumes': 'Nenhum subvolume encontrado nesta partição',
                'default_subvolume': 'Subvolume padrão',
                'mount_subvolume': 'Montar subvolume',
                'subvolume_id': 'ID do subvolume',
                'subvolume_path': 'Caminho do subvolume',
                'detecting_subvolumes': 'Detectando subvolumes btrfs...',
                'mounting_btrfs': 'Montando sistema de arquivos btrfs',
                'invalid_btrfs': 'Partição btrfs inválida ou corrompida'
            }
        elif lang_code == 'fr':
            STRINGS[lang_code]['btrfs'] = {
                'detected': 'Système de fichiers Btrfs détecté',
                'subvolumes_found': 'Sous-volumes trouvés',
                'select_subvolume': 'Sélectionner le sous-volume',
                'no_subvolumes': 'Aucun sous-volume trouvé sur cette partition',
                'default_subvolume': 'Sous-volume par défaut',
                'mount_subvolume': 'Monter le sous-volume',
                'subvolume_id': 'ID du sous-volume',
                'subvolume_path': 'Chemin du sous-volume',
                'detecting_subvolumes': 'Détection des sous-volumes btrfs...',
                'mounting_btrfs': 'Montage du système de fichiers btrfs',
                'invalid_btrfs': 'Partition btrfs invalide ou corrompue'
            }
        elif lang_code == 'de':
            STRINGS[lang_code]['btrfs'] = {
                'detected': 'Btrfs-Dateisystem erkannt',
                'subvolumes_found': 'Untervolumes gefunden',
                'select_subvolume': 'Untervolume auswählen',
                'no_subvolumes': 'Keine Untervolumes auf dieser Partition gefunden',
                'default_subvolume': 'Standard-Untervolume',
                'mount_subvolume': 'Untervolume einhängen',
                'subvolume_id': 'Untervolume-ID',
                'subvolume_path': 'Untervolume-Pfad',
                'detecting_subvolumes': 'Erkenne btrfs-Untervolumes...',
                'mounting_btrfs': 'Btrfs-Dateisystem wird eingehängt',
                'invalid_btrfs': 'Ungültige oder beschädigte btrfs-Partition'
            }
        elif lang_code == 'it':
            STRINGS[lang_code]['btrfs'] = {
                'detected': 'Filesystem Btrfs rilevato',
                'subvolumes_found': 'Sottovolumi trovati',
                'select_subvolume': 'Seleziona sottovolume',
                'no_subvolumes': 'Nessun sottovolume trovato su questa partizione',
                'default_subvolume': 'Sottovolume predefinito',
                'mount_subvolume': 'Monta sottovolume',
                'subvolume_id': 'ID del sottovolume',
                'subvolume_path': 'Percorso del sottovolume',
                'detecting_subvolumes': 'Rilevamento dei sottovolumi btrfs...',
                'mounting_btrfs': 'Montaggio del filesystem btrfs',
                'invalid_btrfs': 'Partizione btrfs non valida o corrotta'
            }
        elif lang_code == 'ro':
            STRINGS[lang_code]['btrfs'] = {
                'detected': 'Sistem de fișiere Btrfs detectat',
                'subvolumes_found': 'Subvolume găsite',
                'select_subvolume': 'Selectați subvolumul',
                'no_subvolumes': 'Nu s-au găsit subvolume pe această partiție',
                'default_subvolume': 'Subvolum implicit',
                'mount_subvolume': 'Montați subvolumul',
                'subvolume_id': 'ID-ul subvolumului',
                'subvolume_path': 'Calea subvolumului',
                'detecting_subvolumes': 'Detectarea subvolumele btrfs...',
                'mounting_btrfs': 'Montarea sistemului de fișiere btrfs',
                'invalid_btrfs': 'Partiție btrfs nevalidă sau coruptă'
            }
        elif lang_code == 'ru':
            STRINGS[lang_code]['btrfs'] = {
                'detected': 'Обнаружена файловая система Btrfs',
                'subvolumes_found': 'Найдены подтома',
                'select_subvolume': 'Выбрать подтом',
                'no_subvolumes': 'На этом разделе не найдено подтомов',
                'default_subvolume': 'Подтом по умолчанию',
                'mount_subvolume': 'Подмонтировать подтом',
                'subvolume_id': 'ID подтома',
                'subvolume_path': 'Путь к подтому',
                'detecting_subvolumes': 'Обнаружение подтомов btrfs...',
                'mounting_btrfs': 'Подключение файловой системы btrfs',
                'invalid_btrfs': 'Недопустимый или поврежденный раздел btrfs'
            }

# Remove 'numlockx' from all language labels
for lang_code in STRINGS:
    if 'labels' in STRINGS[lang_code] and 'numlockx' in STRINGS[lang_code]['labels']:
        del STRINGS[lang_code]['labels']['numlockx']
