#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import time
import subprocess
import shutil
from utils.desktop_detector import get_session_type
from utils.autostart import AutostartManager  # Import AutostartManager
from config.strings import STRINGS  # Import string dictionary

class SessionManager:
    """Session manager to handle aspects related to the user session"""
    
    def __init__(self, lang='es'):
        # Set default language
        self.lang = lang
        self.strings = STRINGS[self.lang]
        
        # Constant variables
        self.DEFAULT_USERNAME = 'liveuser'
        self.DEFAULT_SESSION = 'plasma.desktop'
        self.VERSION = '2023.2'
        self.CALAMARES_PATH = '/usr/bin/calamares'
        
        # Add verification for ISO Live
        self.is_live_session = os.path.exists(self.CALAMARES_PATH) and os.environ.get('USER') == self.DEFAULT_USERNAME
        if self.is_live_session:
            # In live session, use /tmp to avoid writing to home
            self.config_dir = '/tmp/soplos-welcome-live'
            os.makedirs(self.config_dir, exist_ok=True)
            print(self.strings['session_manager']['using_temp_dir'].format(self.config_dir))
        else:
            self.config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
            # Ensure directory exists before any operation
            try:
                os.makedirs(self.config_dir, exist_ok=True)
            except Exception as e:
                print(self.strings['session_manager']['error_creating_config_dir'].format(e))
                # Try with alternative location in /tmp if it fails
                self.config_dir = '/tmp/soplos-welcome-live'
                os.makedirs(self.config_dir, exist_ok=True)
        
        self.restart_state_file = os.path.join(self.config_dir, 'restart_state.json')
        self.session_type = get_session_type()
        self.autostart_manager = AutostartManager()
        
        # Create first run marker to prevent automatic restart
        self.first_run_marker = os.path.join(self.config_dir, 'first_run_completed')
        if not os.path.exists(self.first_run_marker):
            try:
                with open(self.first_run_marker, 'w') as f:
                    f.write(str(time.time()))
                print(self.strings['session_manager']['first_run_marked'])
            except Exception as e:
                print(self.strings['session_manager']['error_first_run_marker'].format(e))
        
    def set_language(self, lang):
        """Change the session manager language"""
        if lang in STRINGS:
            self.lang = lang
            self.strings = STRINGS[self.lang]
            
    def mark_for_restart(self):
        """Marks the session for restart with timestamp and autostart state"""
        restart_state = {
            'restarted': True,
            'time': time.time(),
            'need_locale_check': True,
            'autostart_enabled': self.autostart_manager.is_enabled(),  # Save autostart state
            'version': self.VERSION  # Add version to avoid false positives
        }
        
        with open(self.restart_state_file, 'w') as f:
            json.dump(restart_state, f)
        
        # Also create a file in /tmp directory to persist after restart
        try:
            with open('/tmp/soplos_welcome_restart_state.json', 'w') as f:
                json.dump(restart_state, f)
        except Exception as e:
            print(self.strings['messages']['error_saving_state_tmp'].format(e))
    
    def was_restarted(self):
        """Checks if the session was recently restarted"""
        # Check if it's the first run
        if not os.path.exists('/tmp/soplos_restart_requested'):
            print(self.strings['session_manager'].get('no_restart_request', "No explicit restart request, avoiding automatic restart"))
            return False
        
        # Remove restart request marker to avoid loops
        try:
            os.unlink('/tmp/soplos_restart_requested')
        except:
            pass
        
        # Check restart state only if explicitly requested
        # First check the standard file
        if os.path.exists(self.restart_state_file):
            try:
                with open(self.restart_state_file, 'r') as f:
                    restart_state = json.load(f)
                
                # If less than 60 seconds have passed since the restart
                # And the version matches (to avoid false positives)
                if (restart_state.get('restarted') and 
                    time.time() - restart_state.get('time', 0) < 60 and
                    restart_state.get('version') == '2023.2'):
                    return True
            except:
                pass
                
        # Check the file in /tmp as a backup
        try:
            if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
                with open('/tmp/soplos_welcome_restart_state.json', 'r') as f:
                    restart_state = json.load(f)
                
                # If less than 120 seconds have passed since the restart (more time for /tmp)
                # And the version matches (to avoid false positives)
                if (restart_state.get('restarted') and 
                    time.time() - restart_state.get('time', 0) < 120 and
                    restart_state.get('version') == '2023.2'):
                    
                    # Restore autostart state if it was enabled
                    if restart_state.get('autostart_enabled', False):
                        print(self.strings['session_manager'].get('restoring_autostart', "Restoring autostart after restart..."))
                        self.autostart_manager.enable()
                    
                    return True
        except Exception as e:
            print(self.strings['session_manager'].get('error_tmp_state', "Error checking state in /tmp: {0}").format(e))
        
        return False
    
    def clear_restart_state(self):
        """Clears the restart state"""
        if os.path.exists(self.restart_state_file):
            os.remove(self.restart_state_file)
        
        # Also clear the file in /tmp
        if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
            try:
                os.remove('/tmp/soplos_welcome_restart_state.json')
            except:
                pass
    
    def verify_locale_applied(self):
        """Verifies that locale changes were applied correctly"""
        try:
            locale_info_file = os.path.join(self.config_dir, 'locale_info.json')
            if os.path.exists(locale_info_file):
                with open(locale_info_file, 'r') as f:
                    locale_info = json.load(f)
                
                # Check if the current locale matches the saved one
                current_locale = os.getenv('LANG', '')
                if locale_info.get('locale', '') != current_locale:
                    print(self.strings['session_manager'].get('locale_mismatch', "Current locale ({0}) does not match saved ({1})").format(current_locale, locale_info.get('locale')))
                    # Force reload of the locale
                    os.environ['LANG'] = locale_info.get('locale', '')
                    os.environ['LC_ALL'] = locale_info.get('locale', '')
                    
                    # Try to set manually if in liveuser
                    if os.getenv('USER') == 'liveuser':
                        try:
                            subprocess.run([
                                'kwriteconfig5', '--file', 'plasma-localerc',
                                '--group', 'Translations',
                                '--key', 'LANGUAGE', locale_info.get('locale', '').split('.')[0]
                            ], check=False)
                        except:
                            pass
        except Exception as e:
            print(self.strings['session_manager'].get('error_verifying_locale', "Error verifying locale application: {0}").format(e))
    
    def restore_theme_from_skel(self):
        """Restore theme configuration from /etc/skel"""
        try:
            # Restore configuration files from /etc/skel
            skel_config_files = [
                'kdeglobals',
                'plasma-org.kde.plasma.desktop-appletsrc',
                'plasmarc',
                'kxkbrc',  # For keyboard configuration
                'baloofilerc',  # For search configuration
                'Trolltech.conf',  # For Qt theme
                'gtk-3.0/settings.ini',  # GTK3 configuration
                'gtk-4.0/settings.ini'   # GTK4 configuration
            ]
            
            home_dir = os.path.expanduser('~')
            user_config_dir = os.path.join(home_dir, '.config')
            skel_config_dir = '/etc/skel/.config'
            
            # Check if the skel configuration directory exists
            if not os.path.exists(skel_config_dir):
                print(self.strings['session_manager'].get('skel_dir_missing', "The directory {0} does not exist").format(skel_config_dir))
                return False
            
            # Create backup directory before modifying anything
            backup_dir = os.path.join(user_config_dir, 'soplos-welcome-live', 'theme-backup-old')
            os.makedirs(backup_dir, exist_ok=True)
            timestamp = time.strftime('%Y%m%d-%H%M%S')
            backup_target = os.path.join(backup_dir, f'backup-{timestamp}')
            os.makedirs(backup_target, exist_ok=True)
            
            for config_file in skel_config_files:
                # Check if it's an individual file or a directory
                skel_path = os.path.join(skel_config_dir, config_file)
                user_path = os.path.join(user_config_dir, config_file)
                
                # If it's a directory (like gtk-3.0), make sure it exists
                if '/' in config_file:
                    dir_name = os.path.dirname(user_path)
                    os.makedirs(dir_name, exist_ok=True)
                
                # Backup current configuration if it exists
                if os.path.exists(user_path):
                    if os.path.isdir(user_path):
                        # It's a directory, backup the content
                        backup_dir_path = os.path.join(backup_target, config_file)
                        os.makedirs(os.path.dirname(backup_dir_path), exist_ok=True)
                        shutil.copytree(user_path, backup_dir_path, dirs_exist_ok=True)
                    else:
                        # It's a file, simple backup
                        backup_file_path = os.path.join(backup_target, config_file)
                        os.makedirs(os.path.dirname(backup_file_path), exist_ok=True)
                        shutil.copy2(user_path, backup_file_path)
                
                # Copy from skel if the file/directory exists
                if os.path.exists(skel_path):
                    # Create parent directory if necessary
                    parent_dir = os.path.dirname(user_path)
                    if parent_dir and not os.path.exists(parent_dir):
                        os.makedirs(parent_dir, exist_ok=True)
                    
                    # Copy the file or directory
                    if os.path.isdir(skel_path):
                        # It's a directory, copy recursively
                        shutil.copytree(skel_path, user_path, dirs_exist_ok=True)
                        print(self.strings['session_manager']['copying_dir'].format(skel_path, user_path))
                    else:
                        # It's a simple file
                        shutil.copy2(skel_path, user_path)
                        print(self.strings['session_manager']['copying_dir'].format(skel_path, user_path))
            
            # Force KDE configuration reload
            try:
                subprocess.run(['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'], check=False)
                subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript', 
                            'refreshCurrentShell()'], check=False)
                
                # Reload specific theme configurations
                subprocess.run(['kwriteconfig5', '--file', 'kcminputrc', '--group', 'Mouse', 
                              '--key', 'cursorTheme', '--reload'], check=False)
                subprocess.run(['qdbus', 'org.kde.KGlobalSettings', '/KGlobalSettings', 
                              'notifyChange', '2', '0'], check=False)
            except Exception as e:
                print(self.strings['session_manager']['error_reloading_kde'].format(e))
            
            return True
        except Exception as e:
            print(self.strings['session_manager']['error_restoring_theme'].format(e))
            return False
    
    def configure_system_locale(self, locale, layout):
        """Configure system-level locale and keyboard"""
        try:
            # 1. Configure locale in system files
            system_locale_script = f"""#!/bin/bash
# Configure system-level locale - set in multiple locations for maximum compatibility

# 1. Update /etc/locale.conf
cat > /etc/locale.conf << EOF
LANG={locale}
LC_ADDRESS={locale}
LC_IDENTIFICATION={locale}
LC_MEASUREMENT={locale}
LC_MONETARY={locale}
LC_NAME={locale}
LC_NUMERIC={locale}
LC_PAPER={locale}
LC_TELEPHONE={locale}
LC_TIME={locale}
EOF

# 2. Also update /etc/default/locale
cat > /etc/default/locale << EOF
LANG={locale}
LC_ALL={locale}
EOF

# 3. Set variables in /etc/environment
if grep -q "LANG=" /etc/environment; then
    sed -i "s/LANG=.*/LANG={locale}/" /etc/environment
else
    echo "LANG={locale}" >> /etc/environment
fi

if grep -q "LC_ALL=" /etc/environment; then
    sed -i "s/LC_ALL=.*/LC_ALL={locale}/" /etc/environment
else
    echo "LC_ALL={locale}" >> /etc/environment
fi

# 4. Ensure locale is generated
if grep -q "^#{locale} UTF-8" /etc/locale.gen; then
    # Uncomment the locale
    sed -i "s/^#{locale} UTF-8/{locale} UTF-8/" /etc/locale.gen
    # Generate the specific locale
    locale-gen {locale}
elif ! grep -q "^{locale} UTF-8" /etc/locale.gen; then
    # If it doesn't exist, add it and generate
    echo "{locale} UTF-8 UTF-8" >> /etc/locale.gen
    locale-gen {locale}
fi

# 5. Use localectl to configure system
localectl set-locale LANG={locale} LC_ALL={locale}

# 6. Configure keyboard for Wayland
mkdir -p /etc/xdg
cat > /etc/xdg/keyboard << EOF
XKBLAYOUT={layout}
EOF

# 7. Configure keyboard at system level
localectl set-keymap {layout} 2>/dev/null || true
localectl set-x11-keymap {layout} 2>/dev/null || true

# 8. Configuration for Linux console
echo "KEYMAP={layout}" > /etc/vconsole.conf

# 9. Specific configuration for SDDM (KDE)
if [ -d "/etc/sddm.conf.d" ]; then
    echo "[X11]" > /etc/sddm.conf.d/keyboard.conf
    echo "ServerArguments=-layout {layout}" >> /etc/sddm.conf.d/keyboard.conf
    
    echo "[General]" > /etc/sddm.conf.d/locale.conf
    echo "Language={locale}" >> /etc/sddm.conf.d/locale.conf
fi

# 10. Create file to verify configuration after restart
echo "LOCALE_CONFIGURED={locale}" > /tmp/locale_configured
echo "LAYOUT_CONFIGURED={layout}" >> /tmp/locale_configured
"""
            script_path = '/tmp/configure_system_locale.sh'
            with open(script_path, 'w') as f:
                f.write(system_locale_script)
            os.chmod(script_path, 0o755)
            
            # Execute with sudo and add timeout to avoid hangs
            try:
                subprocess.run(['sudo', '/bin/bash', script_path], check=True, timeout=60)
            except subprocess.TimeoutExpired:
                print(self.strings['session_manager'].get('timeout_warning', "The configuration script took too long, but it may have worked"))
        
            # 2. Configure current environment variables
            os.environ['LANG'] = locale
            os.environ['LC_ALL'] = locale
            
            # 3. Update KDE configuration for current user
            subprocess.run([
                'kwriteconfig5', '--file', 'plasma-localerc',
                '--group', 'Translations',
                '--key', 'LANGUAGE', locale.split('.')[0]
            ], check=False)
            
            # 4. Configure keyboard layout
            # Configuration for Wayland and X11
            subprocess.run([
                'kwriteconfig5', '--file', 'kxkbrc',
                '--group', 'Layout',
                '--key', 'LayoutList', layout
            ], check=True)
            
            subprocess.run([
                'kwriteconfig5', '--file', 'kxkbrc',
                '--group', 'Layout',
                '--key', 'Use', 'true'
            ], check=True)
            
            # Reload using qdbus if possible
            subprocess.run([
                'qdbus', 'org.kde.keyboard', '/Layouts', 'reset'
            ], check=False)
                
            # Save locale information to verify after restart
            with open(os.path.join(self.config_dir, 'locale_info.json'), 'w') as f:
                json.dump({'locale': locale, 'layout': layout, 'time': time.time()}, f)

            return True
        except Exception as e:
            print(self.strings['session_manager']['error_configuring_locale'].format(e))
            return False
    
    def restart_sddm(self):
        """Restart SDDM safely and directly ensuring autologin"""
        try:
            # 1. Ensure autologin is configured for this user
            username = os.environ.get('USER', self.DEFAULT_USERNAME)
            if not self.ensure_autologin(username):
                print(self.strings['session_manager']['error_configuring_autologin'])
            
            # 2. Save the current autostart state
            autostart_enabled = self.autostart_manager.is_enabled()
            
            # 3. Create a script that restores autostart after restart
            if autostart_enabled:
                print(self.strings['session_manager']['saving_autostart_state'])
            
            # 4. Mark for restart
            self.mark_for_restart()
            
            # 5. Create file to allow automatic restart
            try:
                with open('/tmp/soplos_restart_requested', 'w') as f:
                    f.write(str(time.time()))
                print(self.strings['session_manager']['restart_request_created'])
            except Exception as e:
                print(self.strings['session_manager']['error_creating_restart_file'].format(e))
            
            # 6. Preserve current session type (wayland or x11)
            session_type = get_session_type()
            
            # 7. Restart SDDM
            print(self.strings['session_manager']['executing_sddm_restart'].format(session_type))
            subprocess.run(['sudo', 'systemctl', 'restart', 'sddm'], check=True)
            return True
        except Exception as e:
            print(self.strings['session_manager']['critical_sddm_restart_error'].format(e))
            return False

    def ensure_autologin(self, username=None):
        """Ensure autologin is configured persistently"""
        if username is None:
            username = self.DEFAULT_USERNAME
            
        try:
            # Create sddm.conf.d directory if it doesn't exist
            try:
                subprocess.run(['sudo', 'mkdir', '-p', '/etc/sddm.conf.d'], check=True)
            except:
                subprocess.run(['pkexec', 'mkdir', '-p', '/etc/sddm.conf.d'], check=True)
            
            # Configuration file content
            autologin_content = f"""[Autologin]
User={username}
Session={self.DEFAULT_SESSION}
Relogin=true
"""
            # Use echo directly to create the file 
            with open('/tmp/autologin.conf', 'w') as f:
                f.write(autologin_content)
            
            # Move the file to its location
            try:
                subprocess.run(['sudo', 'mv', '/tmp/autologin.conf', '/etc/sddm.conf.d/autologin.conf'], check=True)
                subprocess.run(['sudo', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=True)
            except:
                try:
                    subprocess.run(['pkexec', 'mv', '/tmp/autologin.conf', '/etc/sddm.conf.d/autologin.conf'], check=True)
                    subprocess.run(['pkexec', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=True)
                except:
                    # Last resort: use echo with sudo directly
                    subprocess.run(['sudo', 'bash', '-c', f'echo "{autologin_content}" > /etc/sddm.conf.d/autologin.conf'], check=False)
                    subprocess.run(['sudo', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=False)
            
            # Configure sddm.conf if it exists
            if os.path.exists('/etc/sddm.conf'):
                with open('/tmp/sddm_autologin.conf', 'w') as f:
                    f.write(autologin_content)
                
                try:
                    # If sddm.conf already has Autologin section, replace it
                    if subprocess.run(['grep', '-q', '\\[Autologin\\]', '/etc/sddm.conf'], check=False).returncode == 0:
                        subprocess.run(['sudo', 'sed', '-i', 
                                      f'/\\[Autologin\\]/,/\\[/{{s/User=.*/User={username}/;s/Session=.*/Session=plasma.desktop/;s/Relogin=.*/Relogin=true/}}', 
                                      '/etc/sddm.conf'], check=False)
                    else:
                        # Add section at the end of the file
                        with open('/tmp/sddm_autologin_append', 'w') as f:
                            f.write(f"\n{autologin_content}")
                        subprocess.run(['sudo', 'bash', '-c', 'cat /tmp/sddm_autologin_append >> /etc/sddm.conf'], check=False)
                        os.unlink('/tmp/sddm_autologin_append')
                except:
                    pass
            
            # Enable linger for the user
            try:
                subprocess.run(['sudo', 'loginctl', 'enable-linger', username], check=False)
            except:
                subprocess.run(['pkexec', 'loginctl', 'enable-linger', username], check=False)
            
            return True
        except Exception as e:
            print(self.strings['session_manager'].get('error_ensuring_autologin', "Error ensuring autologin: {0}").format(e))
            return False

# Global instance
session_manager = SessionManager()
