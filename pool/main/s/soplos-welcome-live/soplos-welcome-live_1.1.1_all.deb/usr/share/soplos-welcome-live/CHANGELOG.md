# Changelog

Todos los cambios notables de este proyecto se documentarán en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto se adhiere a [Semantic Versioning](https://semver.org/lang/es/).

## [1.1.1] - 2025-07-18

### 🛠️ Corregido - Mantenimiento y robustez
- Actualización menor de mantenimiento y traducciones.
- Mejoras menores en la detección de idioma y robustez de arranque.

## [1.1.0] - 2025-07-16

### ✨ Añadido - Estándar AppStream/DEP-11 e iconos
- Metainfo finalizado al estándar AppStream/DEP-11.
- Agregados los iconos del programa en 48x48, 64x64 y 128x128.

## [1.0.9] - 2025-07-14

### 🛠️ Corregido - Metainfo y visibilidad en centros de software
- Agregadas y finalizadas las correcciones del metainfo para aparecer correctamente en centros de software (AppStream/Discover).

## [1.0.8] - 2025-07-13

### 🛠️ Corregido - Metainfo
- Corregido el archivo metainfo para su correcta visualización en Discover/AppStream.

## [1.0.7] - 2025-07-10

### 🌍 Añadido - Recuperación y soporte
- Soporte completo para subvolúmenes btrfs en la recuperación CHROOT.

### 🗑️ Eliminado
- Eliminación completa de NumLockX.

### 🐛 Corregido - Cadenas y textos
- Corrección y revisión de todas las cadenas de texto de los diccionarios.

## [1.0.6] - 2025-06-24

### 🌍 Añadido - Integración AppStream
- Ahora visible en Discover (integración AppStream).

## [1.0.5] - 2025-06-20

### 🌍 Añadido - Internacionalización
- Internacionalización completa del programa.
- Refinamiento de etiquetas a inglés para mayor consistencia.

### 🐛 Corregido - Estabilidad
- Corrección de errores menores.
- Mejoras generales de estabilidad.

### 🔧 Mejorado - Interfaz y rendimiento
- Optimización de la interfaz de usuario.
- Mejoras de rendimiento.

## [1.0.4] - 2025-06-15

### 🐛 Corregido - Interfaz y estabilidad
- Correcciones menores de interfaz.
- Mejoras de estabilidad.

## [1.0.3] - 2024-01-27

### 🎉 Lanzamiento Inicial
- Versión inicial.
- Integración con el Centro de Software.
- Gestión de drivers.
- Herramientas de personalización del sistema.
- Instalación de software recomendado.
- Soporte multilenguaje (8 idiomas).
- Detección y configuración de hardware.
- Configuración de locale y teclado.
- Herramientas de recuperación CHROOT.
- Integración de GParted para gestión de discos.
- Control de autoinicio de la pantalla de bienvenida.
- Alternancia de activación de NumLock.

---

## Tipos de Cambios

- **Añadido** para nuevas características
- **Cambiado** para cambios en funcionalidad existente
- **Obsoleto** para características que serán eliminadas
- **Eliminado** para características eliminadas
- **Corregido** para corrección de errores
- **Seguridad** para vulnerabilidades

## Contribuir

Para reportar errores o solicitar características:
- **Issues**: https://github.com/SoplosLinux/tyson/issues
- **Email**: info@soploslinux.com

## Soporte

- **Documentación**: https://soploslinux.com/docs/soplos-welcome-live
- **Comunidad**: https://soploslinux.com/community
- **Support**: support@soploslinux.com
