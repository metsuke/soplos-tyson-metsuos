import os

# Get the base directory
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Define resource paths
ASSETS_DIR = os.path.join(BASE_DIR, 'assets')
ICONS_DIR = os.path.join(ASSETS_DIR, 'icons')
SLIDES_DIR = os.path.join(ASSETS_DIR, 'slides')

# Specific paths
LOGO_PATH = os.path.join(ICONS_DIR, 'soplos-logo.png')
ICON_PATH = os.path.join(ICONS_DIR, 'com.soplos.welcomelive.png')
SLIDE_PATH = os.path.join(SLIDES_DIR, 'slide.png')

# .desktop file paths
DESKTOP_FILE_NAME = 'com.soplos.welcomelive.desktop'
DESKTOP_PATHS = [
    f'/usr/share/applications/{DESKTOP_FILE_NAME}',
    os.path.join(ASSETS_DIR, DESKTOP_FILE_NAME)
]

# Tyson-specific URLs
WEBSITE_URL = "https://soploslinux.com/tyson"
FORUM_URL = "https://soploslinux.com/foros/viewforum.php?f=77"
WIKI_URL = "https://sourceforge.net/p/soplos-linux-tyson/wiki/Home/"
DONATE_URL = "https://paypal.me/isubdes"

# Global configuration
DEFAULT_LANGUAGE = 'en'

# Ensure all exported paths are available
__all__ = [
    'BASE_DIR', 'ASSETS_DIR', 'ICONS_DIR', 'SLIDES_DIR',
    'LOGO_PATH', 'ICON_PATH', 'SLIDE_PATH',
    'WEBSITE_URL', 'FORUM_URL', 'WIKI_URL', 'DONATE_URL',
    'DESKTOP_FILE_NAME', 'DESKTOP_PATHS', 'DEFAULT_LANGUAGE'
]