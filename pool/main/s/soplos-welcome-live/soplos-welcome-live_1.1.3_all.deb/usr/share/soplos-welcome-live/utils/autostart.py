import os
import shutil
from config.strings import STRINGS
from config.paths import DEFAULT_LANGUAGE

# Desktop file paths - NO NumLock related paths
DESKTOP_PATHS = [
    '/usr/share/applications/com.soplos.welcomelive.desktop',
    '/usr/local/bin/soplos-welcome-live-tyson/assets/com.soplos.welcomelive.desktop'
]

class AutostartManager:
    def __init__(self, current_lang=DEFAULT_LANGUAGE):
        self.current_lang = current_lang
        self.autostart_dir = os.path.expanduser('~/.config/autostart')
        self.desktop_source_paths = DESKTOP_PATHS
        self.desktop_target = os.path.join(self.autostart_dir, 'com.soplos.welcomelive.desktop')

    def is_enabled(self):
        """Checks if welcome-live is in autostart"""
        return os.path.exists(self.desktop_target)

    def toggle(self):
        """Enables/disables autostart"""
        if self.is_enabled():
            # Disable
            if os.path.exists(self.desktop_target):
                os.remove(self.desktop_target)
        else:
            # Enable
            self._copy_desktop_file()

    def enable(self):
        """Safely enables autostart"""
        try:
            if not self.is_enabled():
                self._copy_desktop_file()
                # Verify it was created correctly
                if not os.path.exists(self.desktop_target):
                    print(STRINGS[self.current_lang]['messages'].get('autostart_create_error', 
                                                                  "Error: Could not create autostart file"))
                    return False
                return True
            return True  # Was already enabled
        except Exception as e:
            print(STRINGS[self.current_lang]['messages'].get('autostart_enable_error', 
                                                         "Error enabling autostart: {}").format(e))
            return False

    def disable(self):
        """Disables autostart"""
        if os.path.exists(self.desktop_target):
            os.remove(self.desktop_target)
    
    def _copy_desktop_file(self):
        """Searches and copies the desktop file to the autostart folder"""
        os.makedirs(self.autostart_dir, exist_ok=True)
        
        # Try with each possible location of the desktop file
        for source_path in self.desktop_source_paths:
            if os.path.exists(source_path):
                shutil.copy2(source_path, self.desktop_target)
                print(STRINGS[self.current_lang]['messages'].get('autostart_enabled', 
                                                              "Autostart enabled: {} -> {}").format(source_path, self.desktop_target))
                return True
        
        # If we get here, the file wasn't found
        print(STRINGS[self.current_lang]['messages'].get('desktop_file_not_found', 
                                                      "Error: .desktop file not found in any known location"))
        
        # Try to create a basic one as a last resort
        self._create_basic_desktop_file()
        return False
        
    def _create_basic_desktop_file(self):
        """Creates a basic desktop file as a last resort"""
        try:
            with open(self.desktop_target, 'w') as f:
                desktop_content = STRINGS[self.current_lang]['templates'].get('basic_desktop_file', """[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Welcome screen for Soplos Linux Live Environment
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
""")
                f.write(desktop_content)
            print(STRINGS[self.current_lang]['messages'].get('basic_desktop_created', 
                                                     "Created basic desktop file as backup"))
        except Exception as e:
            print(STRINGS[self.current_lang]['messages'].get('basic_desktop_error', 
                                                     "Error creating basic desktop file: {}").format(e))