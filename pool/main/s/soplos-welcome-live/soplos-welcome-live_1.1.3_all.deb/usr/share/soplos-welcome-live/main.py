#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Configure environment variables before importing GTK
import os
import sys

# Prevent creation of .pyc files from startup
sys.dont_write_bytecode = True

# Define base_dir as global variable at startup
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

os.environ['NO_AT_BRIDGE'] = '1'
os.environ['GTK_MODULES'] = ''

import gi
import shutil
import subprocess
import atexit

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gio
from ui.main_window import MainWindow
from config.strings import STRINGS
from config.paths import ICON_PATH

def clean_pycache():
    """Clean all __pycache__, .pyc and .pyo files from project"""
    # Use global BASE_DIR variable
    base_dir = BASE_DIR
    
    # List of patterns to clean
    patterns_to_clean = [
        '**/__pycache__',
        '**/*.pyc',
        '**/*.pyo',
        '**/*.pyd'
    ]
    
    import glob
    
    for pattern in patterns_to_clean:
        full_pattern = os.path.join(base_dir, pattern)
        
        # Find files/folders matching the pattern
        try:
            matches = glob.glob(full_pattern, recursive=True)
            
            for match in matches:
                try:
                    if os.path.isdir(match):
                        shutil.rmtree(match, ignore_errors=True)
                    elif os.path.isfile(match):
                        os.remove(match)
                except (OSError, PermissionError):
                    pass
        except Exception:
            continue

def aggressive_cleanup():
    """Aggressive cleanup that runs continuously"""
    try:
        # Use global BASE_DIR instead of __file__
        base_dir = BASE_DIR
        
        # Find and remove any __pycache__ that appears
        for root, dirs, files in os.walk(base_dir):
            try:
                for dir_name in dirs[:]:
                    if dir_name == '__pycache__':
                        pycache_path = os.path.join(root, dir_name)
                        try:
                            shutil.rmtree(pycache_path, ignore_errors=True)
                            dirs.remove(dir_name)
                        except:
                            pass
                
                # Remove individual .pyc files
                for file_name in files:
                    if file_name.endswith(('.pyc', '.pyo', '.pyd')):
                        file_path = os.path.join(root, file_name)
                        try:
                            os.remove(file_path)
                        except:
                            pass
            except Exception:
                continue
    except Exception:
        pass

def get_system_locale():
    """Get system locale"""
    # First try to read from locale.conf
    if os.path.exists('/etc/locale.conf'):
        try:
            with open('/etc/locale.conf', 'r') as f:
                for line in f:
                    if line.startswith('LANG='):
                        return line.split('=')[1].strip().strip('"')
        except:
            pass
    
    # If it doesn't exist or fails, use LANG variable or default to en_US.UTF-8
    return os.getenv('LANG', 'en_US.UTF-8')

def get_language_code():
    """Get system language code and return a valid one"""
    current_locale = get_system_locale()
    
    # If it's C.UTF-8 or similar, use English by default
    if current_locale.startswith('C.') or current_locale == 'C':
        return 'en'
    
    # Get language code (first two letters)
    lang_code = current_locale.split('_')[0]
    
    # Check if code exists in STRINGS, if not, use English
    return lang_code if lang_code in STRINGS else 'en'

def check_environment():
    """Check and configure necessary environment"""
    # Check user - allow any user for Plasma 6
    username = os.getenv('USER', 'user')
    print(f"Running as user: {username}")
    
    # Check critical variables
    required_vars = {
        'DISPLAY': ':0',
        'XDG_RUNTIME_DIR': f"/run/user/{os.getuid()}",
        'XDG_SESSION_TYPE': 'x11',
        'LANG': os.getenv('LANG', 'en_US.UTF-8')
    }
    
    for var, default in required_vars.items():
        if not os.getenv(var):
            os.environ[var] = default

def set_app_icon():
    """Set application icon silently"""
    try:
        if os.path.exists(ICON_PATH):
            Gtk.Window.set_default_icon_from_file(ICON_PATH)
        else:
            Gtk.Window.set_default_icon_name("system-software-install")
    except:
        Gtk.Window.set_default_icon_name("system-software-install")

class SoplosWelcomeLive(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.soplos.welcomelive",
                        flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window = None
        self.cleanup_timeout_id = None

    def do_activate(self):
        # Check environment first
        check_environment()
        
        # Clean after all modules are loaded
        aggressive_cleanup()
        set_app_icon()
        
        if not self.window:
            # Detect system language before creating the main window
            lang_code = get_language_code()
            self.window = MainWindow(lang_code=lang_code)
            self.window.set_application(self)
            
            # Set icon
            try:
                icon_theme = Gtk.IconTheme.get_default()
                icon = icon_theme.load_icon("soplos-welcome-live", 128, 0)
                self.window.set_icon(icon)
            except:
                if os.path.exists(ICON_PATH):
                    self.window.set_icon_from_file(ICON_PATH)

            self.window.connect("destroy", lambda x: self.on_quit())
        self.window.show_all()
        
        # Schedule periodic cleanup
        self.cleanup_timeout_id = GLib.timeout_add_seconds(2, self.periodic_cleanup)

    def periodic_cleanup(self):
        """Periodic cleanup every 2 seconds"""
        try:
            aggressive_cleanup()
            return True  # Continue running
        except Exception:
            return False  # Stop if there's an error

    def on_quit(self):
        """Clean cache and close application"""
        try:
            # Cancel timeout if it exists
            if self.cleanup_timeout_id:
                GLib.source_remove(self.cleanup_timeout_id)
                self.cleanup_timeout_id = None
            
            aggressive_cleanup()  # Final cleanup
        except Exception:
            pass
        finally:
            self.quit()

def main():
    try:
        atexit.register(aggressive_cleanup)
        
        app = SoplosWelcomeLive()
        exit_code = app.run(sys.argv)
        
        try:
            aggressive_cleanup()
        except Exception:
            pass
        
        return exit_code
    except Exception as e:
        print(f"Error in main: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())