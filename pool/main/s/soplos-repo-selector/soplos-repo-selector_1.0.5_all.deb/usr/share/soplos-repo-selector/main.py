#!/usr/bin/env python3
"""
Punto de entrada principal para Soplos Repository Selector

Este script inicializa la aplicación, configura el entorno y lanza la interfaz gráfica.
"""

import os
import sys
import signal
import atexit
import locale
from pathlib import Path

# Añadir el directorio de la aplicación al path de Python
APP_DIR = Path(__file__).parent.absolute()
sys.path.insert(0, str(APP_DIR))

# Configurar variables de entorno antes de importar GTK
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ.setdefault('GDK_BACKEND', 'x11')

# Configurar locale
try:
    locale.setlocale(locale.LC_ALL, '')
except locale.Error:
    # Fallback a C si hay problemas con el locale
    locale.setlocale(locale.LC_ALL, 'C')

def cleanup_cache_files():
    """Limpia archivos de caché al salir"""
    try:
        import shutil
        cache_dirs = []
        
        # Buscar directorios __pycache__
        for root, dirs, files in os.walk(APP_DIR):
            if '__pycache__' in dirs:
                cache_dirs.append(os.path.join(root, '__pycache__'))
        
        # Eliminar directorios encontrados
        for cache_dir in cache_dirs:
            try:
                if os.path.exists(cache_dir):
                    shutil.rmtree(cache_dir)
                    print(f"Limpiado: {cache_dir}")
            except Exception as e:
                print(f"No se pudo limpiar {cache_dir}: {e}")
                
    except Exception as e:
        print(f"Error durante la limpieza: {e}")

def signal_handler(sig, frame):
    """Maneja señales del sistema para cierre limpio"""
    from src.i18n.strings import get_string
    print(f"\n{get_string('signal_received', 'Señal recibida')}: {sig}")
    cleanup_cache_files()
    sys.exit(0)

def main():
    """Función principal de la aplicación"""
    try:
        # Registrar manejadores de señales
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # Registrar limpieza al salir
        atexit.register(cleanup_cache_files)
        
        # Importar y ejecutar la aplicación
        from src.gui.app import create_application
        from src.utils.error_handler import log_info
        from src.i18n.strings import get_string
        
        log_info("Iniciando Soplos Repository Selector v1.0.2")
        
        # Crear y ejecutar la aplicación
        app = create_application()
        return app.run(sys.argv)
        
    except KeyboardInterrupt:
        from src.i18n.strings import get_string
        print(f"\n{get_string('application_interrupted', 'Aplicación interrumpida por el usuario')}")
        return 130
        
    except Exception as e:
        from src.utils.error_handler import log_error
        from src.i18n.strings import get_string
        
        error_msg = get_string('critical_error', 'Error crítico')
        log_error(f"{error_msg}: {e}", e)
        print(f"{error_msg}: {e}", file=sys.stderr)
        return 1
        
    finally:
        cleanup_cache_files()

if __name__ == '__main__':
    sys.exit(main())
