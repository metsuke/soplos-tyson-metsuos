#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Punto de entrada principal para Soplos Repo Selector
"""

import os
import sys
import warnings
import configparser
import locale
import signal
import shutil
from pathlib import Path

# Deshabilitar bus de accesibilidad
os.environ['NO_AT_BRIDGE'] = '1'
os.environ['AT_SPI_BUS'] = '0'

# Suprimir advertencias de accesibilidad
warnings.filterwarnings('ignore', '.*Couldn\'t connect to accessibility bus.*', Warning)
warnings.filterwarnings('ignore', '.*Failed to connect to socket.*', Warning)

# Añadir el directorio raíz al PYTHONPATH
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)

def detect_kde_theme():
    """Detecta el tema actual de KDE y devuelve el nombre de tema GTK equivalente"""
    # Ruta del archivo de configuración de KDE
    kde_config = Path(os.path.expanduser("~/.config/kdeglobals"))
    
    if not kde_config.exists():
        return None
    
    # Intentar leer la configuración de tema GTK desde KDE
    config = configparser.ConfigParser()
    try:
        config.read(kde_config)
        
        # Buscar configuración específica de tema GTK en KDE
        if 'General' in config:
            gtk_theme = config['General'].get('GtkTheme', '')
            if gtk_theme:
                return gtk_theme
        
        # Si no hay tema GTK específico, no forzar ninguno
        # Dejar que el sistema use su configuración predeterminada
        return None

    except Exception as e:
        return None

def handle_signal(signum, frame):
    """Maneja señales del sistema para cierre limpio"""
    print(f"\nSinal recibida: {signum}, cerrando aplicación...")
    sys.exit(0)

def clean_all_pycache(base_dir):
    """Elimina todos los directorios __pycache__ y archivos .pyc"""
    for root, dirs, files in os.walk(base_dir, topdown=False):
        for file in files:
            if file.endswith('.pyc') or file.endswith('.pyo'):
                try:
                    file_path = os.path.join(root, file)
                    if os.access(file_path, os.W_OK):
                        os.remove(file_path)
                except Exception:
                    pass
        
        # Eliminar directorios __pycache__
        for dir_name in dirs:
            if dir_name == '__pycache__':
                try:
                    dir_path = os.path.join(root, dir_name)
                    if os.access(dir_path, os.W_OK):
                        shutil.rmtree(dir_path)
                except Exception:
                    pass

def setup_environment():
    """Configura el entorno de ejecución"""
    try:
        # Configurar locale
        locale.setlocale(locale.LC_ALL, '')
    except locale.Error:
        # Si falla, usar locale por defecto
        pass
    
    # Configurar codificación UTF-8
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8')

def set_app_icon():
    """Establece el icono de la aplicación silenciosamente"""
    try:
        icon_path = os.path.join(BASE_DIR, "assets/icons/com.soplos.reposelector.png")
        if os.path.exists(icon_path):
            import gi
            gi.require_version('Gtk', '3.0')
            from gi.repository import Gtk
            Gtk.Window.set_default_icon_from_file(icon_path)
        else:
            import gi
            gi.require_version('Gtk', '3.0')
            from gi.repository import Gtk
            Gtk.Window.set_default_icon_name("software-properties")
    except:
        pass

# Configurar idioma del sistema ANTES de importar GTK
def configure_language():
    """Detecta y configura el idioma del sistema automáticamente"""
    from src.i18n.strings import detect_system_language
    
    # Detectar idioma del sistema
    detected_lang = detect_system_language()
    
    # Debug: mostrar información de detección
    print(f"Debug - LANG env var: {os.environ.get('LANG', 'Not set')}")
    print(f"Debug - LC_ALL env var: {os.environ.get('LC_ALL', 'Not set')}")
    print(f"Debug - Locale detected: {locale.getdefaultlocale()}")
    print(f"Debug - Language detected: {detected_lang}")
    
    # IMPORTANTE: Establecer una variable global para usar en toda la aplicación
    os.environ['SOPLOS_REPO_SELECTOR_LANG'] = detected_lang
    
    return detected_lang

# Configurar el idioma ANTES de cualquier importación
SYSTEM_LANG = configure_language()
print(f"Sistema configurado para idioma: {SYSTEM_LANG}")

# Detectar y configurar entorno Wayland/KDE antes de importar GTK
def configure_environment_theme():
    """Detecta y configura el entorno para asegurar coherencia de tema en Wayland/X11"""
    
    # Detectar si estamos en Wayland
    wayland_session = os.environ.get('XDG_SESSION_TYPE') == 'wayland'
    kde_desktop = os.environ.get('XDG_CURRENT_DESKTOP', '').lower().find('kde') >= 0
    
    if wayland_session and kde_desktop:
        # Estamos en KDE Plasma con Wayland
        # Intentar detectar el tema activo de KDE
        theme_name = detect_kde_theme()
        if theme_name:
            # Solo aplicar si se detectó un tema específico
            os.environ['GTK_THEME'] = theme_name
            print(f"Wayland + KDE detectado: Aplicando tema GTK '{theme_name}'")
        else:
            # No forzar ningún tema, usar configuración del sistema
            print("Wayland + KDE detectado: Usando tema GTK del sistema")
        
        # Usar portal XDG para mejorar integración con Wayland
        os.environ['GTK_USE_PORTAL'] = '1'

# Configurar el entorno antes de importar GTK
configure_environment_theme()

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf, Gdk, Gio, GLib
from src.gui.app import create_application

def clean_pycache():
    """Limpia los directorios __pycache__ silenciosamente"""
    base_dirs = [
        BASE_DIR,  # Directorio actual del proyecto
        "/usr/local/bin/soplos-repo-selector",
        "/usr/local/bin/soplos-repo-selector-tyson",
        "/usr/local/bin/soplos-welcome",
        "/usr/local/bin/soplos-welcome-tyson",
        "/usr/local/bin/soplos-theme-manager",
        "/usr/local/bin/soplos-docklike",
        "/usr/local/bin/soplos-grub-editor",
        "/usr/local/bin/soplos-plymouth-manager"
    ]

    for base_dir in base_dirs:
        if os.path.exists(base_dir):
            for root, dirs, files in os.walk(base_dir):
                if '__pycache__' in dirs:
                    import shutil
                    try:
                        shutil.rmtree(os.path.join(root, '__pycache__'))
                    except:
                        pass

def main():
    """Función principal de la aplicación"""
    try:
        # Configurar entorno
        setup_environment()
        
        # Configurar manejo de señales
        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)
        
        # Limpiar archivos de caché antiguos al inicio
        clean_all_pycache(BASE_DIR)
        
        # Verificar dependencias antes de continuar
        from src.utils.dependency_checker import DependencyChecker
        checker = DependencyChecker()
        if not checker.check_all_dependencies():
            print("Error: Faltan dependencias críticas. Abortando...")
            return 1
        
        # Configurar icono
        set_app_icon()
        
        # Configurar internacionalización usando el idioma detectado
        locale_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'locale')
        if os.path.exists(locale_dir):
            import gettext
            gettext.bindtextdomain('soplos-repo-selector', locale_dir)
            gettext.textdomain('soplos-repo-selector')
        
        # Crear y ejecutar la aplicación
        app = create_application()
        return app.run(sys.argv)
        
    except KeyboardInterrupt:
        print("\nAplicación interrumpida por el usuario")
        return 0
    except Exception as e:
        print(f"Error crítico: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
