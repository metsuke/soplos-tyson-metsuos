"""
Constantes globales para Soplos Repo Selector
"""

# Identificación de la aplicación
APP_ID = "com.soplos.reposelector"
APP_NAME = "Soplos Repo Selector"
APP_VERSION = "1.0.2"

# Rutas de sistema
KEYRINGS_DIR = '/usr/share/keyrings'
ETC_KEYRINGS_DIR = '/etc/apt/keyrings'
SOURCES_DIR = '/etc/apt/sources.list.d'
MAIN_SOURCES = '/etc/apt/sources.list'

# Ajustes de UI
DEFAULT_WINDOW_WIDTH = 800
DEFAULT_WINDOW_HEIGHT = 600
DEFAULT_MARGIN = 10
SPACING_NORMAL = 6
SPACING_LARGE = 10

# Repositorios predefinidos (constante que faltaba)
PREDEFINED_REPOS = {
    'google-chrome': {
        'name': 'Google Chrome',
        'uri': 'http://dl.google.com/linux/chrome/deb/',
        'distribution': 'stable',
        'components': 'main',
        'gpg_key': 'https://dl.google.com/linux/linux_signing_key.pub'
    },
    'vscode': {
        'name': 'Visual Studio Code',
        'uri': 'https://packages.microsoft.com/repos/code',
        'distribution': 'stable',
        'components': 'main',
        'gpg_key': 'https://packages.microsoft.com/keys/microsoft.asc'
    },
    'docker': {
        'name': 'Docker CE',
        'uri': 'https://download.docker.com/linux/debian',
        'distribution': '$(lsb_release -cs)',
        'components': 'stable',
        'gpg_key': 'https://download.docker.com/linux/debian/gpg'
    },
    'obs-studio': {
        'name': 'OBS Studio',
        'uri': 'http://ppa.launchpad.net/obsproject/obs-studio/ubuntu',
        'distribution': 'focal',
        'components': 'main',
        'gpg_key': 'https://keyserver.ubuntu.com/pks/lookup?op=get&search=0xBC7345F522079769F5BBE987EFC71127F425E228'
    }
}
