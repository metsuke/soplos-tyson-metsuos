# Soplos Repository Selector

[![Version](https://img.shields.io/badge/version-1.0.2-blue.svg)](https://github.com/SoplosLinux/tyron)
[![License](https://img.shields.io/badge/license-GPL--3.0-green.svg)](LICENSE)
[![Languages](https://img.shields.io/badge/languages-8-brightgreen.svg)](#idiomas-soportados)

Un gestor de repositorios gráfico para sistemas basados en Debian con soporte completo multiidioma y funciones avanzadas para encontrar los servidores más rápidos.

## 🌟 Características Principales

- **Interfaz Multiidioma**: Soporte completo para 8 idiomas (Español, Inglés, Francés, Portugués, Alemán, Italiano, Ruso, Rumano)
- **Búsqueda de Repositorios Rápidos**: Encuentra automáticamente los servidores más veloces según tu ubicación
- **Gestión de Claves GPG**: Importa, descarga y administra claves GPG de forma sencilla
- **Plantillas de Distribución**: Configuraciones predefinidas para Debian Stable, Testing/Trixie, Sid/Unstable y Soplos Linux Tyron
- **Interfaz Intuitiva**: Diseño limpio con atajos de teclado y navegación por pestañas
- **Detección Automática**: Reconoce automáticamente el idioma del sistema

## 🚀 Instalación

### Desde el repositorio oficial de Soplos Linux:
```bash
sudo apt update
sudo apt install soplos-repo-selector
```

### Instalación manual:
```bash
git clone https://github.com/SoplosLinux/tyron.git
cd tyron/soplos-repo-selector
sudo python3 setup.py install
```

## 📋 Requisitos del Sistema

- **Sistema Operativo**: Debian, Ubuntu, Soplos Linux o derivados
- **Python**: 3.7 o superior
- **Dependencias**:
  - python3-gi (>= 3.20)
  - python3-requests
  - gir1.2-gtk-3.0
  - apt, gnupg, curl

## 🌍 Idiomas Soportados

| Idioma | Código | Completitud |
|--------|--------|-------------|
| Español | es | 100% |
| English | en | 100% |
| Français | fr | 100% |
| Português | pt | 100% |
| Deutsch | de | 100% |
| Italiano | it | 100% |
| Русский | ru | 100% |
| Română | ro | 100% |

## 🎯 Uso

### Lanzar la aplicación:
```bash
soplos-repo-selector
```

### Funciones principales:

1. **Gestión de Repositorios**:
   - Añadir, editar y eliminar repositorios APT
   - Activar/desactivar repositorios existentes
   - Soporte para formatos legacy y DEB822

2. **Búsqueda de Repositorios Rápidos**:
   - Test de velocidad en tiempo real
   - Filtrado por país
   - Selección automática de los más rápidos

3. **Plantillas de Distribución**:
   - **Debian Stable**: stable, stable-updates, stable-security, stable-backports
   - **Debian Testing/Trixie**: testing y trixie con todas sus variantes
   - **Debian Sid/Unstable**: unstable, sid, experimental
   - **Soplos Linux Tyron**: Configuración híbrida optimizada

4. **Gestión de Claves GPG**:
   - Importar claves desde archivos
   - Descargar claves desde URLs
   - Visualizar detalles de claves instaladas

## ⚡ Atajos de Teclado

| Acción | Atajo |
|--------|-------|
| Aplicar cambios | Ctrl+S |
| Actualizar repositorios | Ctrl+U |
| Buscar repositorios rápidos | Ctrl+F |
| Añadir repositorio | Ctrl+N |
| Editar repositorio | Ctrl+E |
| Eliminar repositorio | Delete |
| Cerrar aplicación | Ctrl+Q |

## 🔧 Desarrollo

### Estructura del proyecto:
```
soplos-repo-selector/
├── src/
│   ├── gui/           # Interfaz gráfica
│   ├── repo/          # Gestión de repositorios
│   ├── i18n/          # Sistema de internacionalización
│   ├── utils/         # Utilidades
│   └── config/        # Configuración
├── assets/            # Recursos (iconos, .desktop)
├── debian/           # Metadatos para empaquetado
└── main.py           # Punto de entrada
```

### Contribuir:
1. Fork el repositorio
2. Crea una rama para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -am 'Añadir nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Abre un Pull Request

## 📝 Changelog

### v1.0.2 (2025-06-17)
- Corregido el manejo del diálogo de confirmación de cierre
- Mejorado el soporte de atajos de teclado y mnemónicos
- Eliminados botones de repositorios predefinidos obsoletos
- Sistema mejorado de manejo de errores y registro
- Optimización de código y mejoras de rendimiento

### v1.0.1 (2025-01-15)
- Sistema completo de internacionalización con 8 idiomas
- Plantillas de distribución predefinidas
- Detección automática del idioma del sistema
- Interfaz de usuario mejorada

### v1.0.0 (2025-05-08)
- Versión inicial

## 📄 Licencia

Este proyecto está licenciado bajo la Licencia GPL v3.0 - ver el archivo [LICENSE](LICENSE) para más detalles.

## 🤝 Soporte

- **Página web**: [soploslinux.com](https://soploslinux.com)
- **Reportar bugs**: [GitHub Issues](https://github.com/SoplosLinux/tyron/issues)
- **Email**: soporte@soplos.org

## 👥 Créditos

Desarrollado por el **Equipo de Soplos Linux** para la comunidad de software libre.

---

*Parte del ecosistema [Soplos Linux](https://soploslinux.com)*
