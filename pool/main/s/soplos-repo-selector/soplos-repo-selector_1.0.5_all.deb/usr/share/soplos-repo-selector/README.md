# Soplos Repo Selector

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.5-green.svg)]()

Soplos Repo Selector es un gestor gráfico de repositorios APT diseñado específicamente para sistemas basados en Debian. Permite gestionar, optimizar y configurar repositorios de software de manera sencilla e intuitiva.

## Características principales

- **Gestión completa de repositorios**: Añadir, editar, eliminar y activar/desactivar repositorios APT
- **Soporte multiidioma**: Interfaz disponible en 8 idiomas (ES, EN, FR, PT, DE, IT, RU, RO)
- **Detección automática de tema**: Soporte para temas claros y oscuros
- **Búsqueda de repositorios rápidos**: Encuentra automáticamente los mirrors más rápidos
- **Gestión de claves GPG**: Importar, descargar y gestionar claves de verificación
- **Repositorios predefinidos**: Acceso rápido a repositorios populares (Chrome, VSCode, Docker, OBS)
- **Compatibilidad Wayland/X11**: Funciona perfectamente en ambos entornos
- **Plantillas de distribución**: Configuraciones preestablecidas para Debian Stable, Testing, Sid y Soplos

## Instalación

### Desde paquete DEB (recomendado)
```bash
sudo dpkg -i soplos-repo-selector_1.0.5_all.deb
sudo apt-get install -f  # Resolver dependencias si es necesario
```

### Desde código fuente
```bash
git clone https://github.com/SoplosLinux/soplos-repo-selector
cd soplos-repo-selector
sudo python3 setup.py install
```

## Dependencias

- **Python 3.8+**
- **GTK 3.0+**
- **GObject Introspection**
- **Python packages**: `python3-gi`, `python3-apt`, `python3-psutil`
- **Sistema**: `curl`, `wget`, `gnupg`, `pkexec`

## Uso básico

### Lanzar la aplicación
```bash
soplos-repo-selector
```

### Gestión de repositorios
1. **Añadir repositorio**: Botón "Añadir" o Ctrl+N
2. **Editar repositorio**: Seleccionar y "Editar" o Ctrl+E
3. **Eliminar repositorio**: Seleccionar y "Eliminar" o Delete
4. **Aplicar cambios**: Botón "Aplicar" o Ctrl+S

### Búsqueda de repositorios rápidos
1. Clic en "Buscar Repositorios Más Rápidos"
2. Seleccionar país/región (opcional)
3. Iniciar test de velocidad
4. Seleccionar repositorios deseados
5. Aplicar configuración

### Gestión de claves GPG
1. Ir a la pestaña "Claves GPG"
2. Importar desde archivo o descargar desde URL
3. Ver detalles y gestionar claves existentes

## Configuración avanzada

### Archivos de configuración
- **Configuración de usuario**: `~/.config/soplos-repo-selector/settings.json`
- **Repositorios del sistema**: `/etc/apt/sources.list.d/`
- **Claves GPG**: `/usr/share/keyrings/` y `/etc/apt/keyrings/`

### Variables de entorno
- `SOPLOS_REPO_SELECTOR_LANG`: Forzar idioma específico
- `GDK_BACKEND`: Backend gráfico (wayland, x11)
- `GTK_THEME`: Tema GTK específico

## Desarrollo

### Estructura del proyecto
```
