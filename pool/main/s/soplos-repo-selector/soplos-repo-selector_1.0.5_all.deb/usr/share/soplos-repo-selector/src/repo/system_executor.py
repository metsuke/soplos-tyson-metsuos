"""
Ejecutor de comandos del sistema para operaciones APT y gestión de repositorios
"""

import os
import subprocess
import tempfile
import shutil
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path

from src.utils.error_handler import log_info, log_error, log_warning, ErrorHandler

class SystemCommandExecutor:
    """Gestor para ejecutar comandos del sistema de forma segura"""
    
    def __init__(self):
        self.use_pkexec = self._check_pkexec_available()
        self.use_sudo = self._check_sudo_available()
        
    def _check_pkexec_available(self) -> bool:
        """Verifica si pkexec está disponible"""
        try:
            result = subprocess.run(['which', 'pkexec'], 
                                  capture_output=True, text=True)
            return result.returncode == 0
        except:
            return False
    
    def _check_sudo_available(self) -> bool:
        """Verifica si sudo está disponible"""
        try:
            result = subprocess.run(['which', 'sudo'], 
                                  capture_output=True, text=True)
            return result.returncode == 0
        except:
            return False
    
    def run_apt_update(self) -> bool:
        """
        Ejecuta apt update para actualizar los índices de paquetes
        
        Returns:
            True si se ejecutó correctamente
        """
        try:
            log_info("Ejecutando apt update...")
            
            if self.use_pkexec:
                cmd = ['pkexec', 'apt', 'update']
            elif self.use_sudo:
                cmd = ['sudo', 'apt', 'update']
            else:
                cmd = ['apt', 'update']
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300  # 5 minutos de timeout
            )
            
            if result.returncode == 0:
                log_info("apt update ejecutado correctamente")
                return True
            else:
                log_error(f"Error en apt update: {result.stderr}")
                ErrorHandler.show_error_dialog(
                    "Error de actualización",
                    f"No se pudieron actualizar los índices de paquetes.\n\n{result.stderr}"
                )
                return False
                
        except subprocess.TimeoutExpired:
            log_error("Timeout ejecutando apt update")
            ErrorHandler.show_error_dialog(
                "Timeout",
                "La actualización de índices tardó demasiado tiempo."
            )
            return False
        except Exception as e:
            log_error("Error ejecutando apt update", e)
            ErrorHandler.show_error_dialog(
                "Error",
                f"Error ejecutando apt update: {str(e)}"
            )
            return False
    
    def install_package(self, package_name: str) -> bool:
        """
        Instala un paquete usando apt
        
        Args:
            package_name: Nombre del paquete a instalar
            
        Returns:
            True si se instaló correctamente
        """
        try:
            log_info(f"Instalando paquete: {package_name}")
            
            if self.use_pkexec:
                cmd = ['pkexec', 'apt', 'install', '-y', package_name]
            elif self.use_sudo:
                cmd = ['sudo', 'apt', 'install', '-y', package_name]
            else:
                cmd = ['apt', 'install', '-y', package_name]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600  # 10 minutos de timeout
            )
            
            if result.returncode == 0:
                log_info(f"Paquete {package_name} instalado correctamente")
                return True
            else:
                log_error(f"Error instalando {package_name}: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            log_error(f"Timeout instalando {package_name}")
            return False
        except Exception as e:
            log_error(f"Error instalando {package_name}", e)
            return False
    
    def copy_file_with_privileges(self, src: str, dst: str) -> bool:
        """
        Copia un archivo usando privilegios elevados
        
        Args:
            src: Archivo origen
            dst: Archivo destino
            
        Returns:
            True si se copió correctamente
        """
        try:
            # Verificar que el archivo origen existe
            if not os.path.exists(src):
                log_error(f"Archivo origen no existe: {src}")
                return False
            
            # Crear directorio destino si no existe
            dst_dir = os.path.dirname(dst)
            if not os.path.exists(dst_dir):
                self.create_directory_with_privileges(dst_dir)
            
            if self.use_pkexec:
                cmd = ['pkexec', 'cp', src, dst]
            elif self.use_sudo:
                cmd = ['sudo', 'cp', src, dst]
            else:
                cmd = ['cp', src, dst]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                log_info(f"Archivo copiado: {src} -> {dst}")
                return True
            else:
                log_error(f"Error copiando archivo: {result.stderr}")
                return False
                
        except Exception as e:
            log_error(f"Error copiando {src} a {dst}", e)
            return False
    
    def create_directory_with_privileges(self, directory: str) -> bool:
        """
        Crea un directorio usando privilegios elevados
        
        Args:
            directory: Directorio a crear
            
        Returns:
            True si se creó correctamente
        """
        try:
            if os.path.exists(directory):
                return True
            
            if self.use_pkexec:
                cmd = ['pkexec', 'mkdir', '-p', directory]
            elif self.use_sudo:
                cmd = ['sudo', 'mkdir', '-p', directory]
            else:
                cmd = ['mkdir', '-p', directory]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                log_info(f"Directorio creado: {directory}")
                return True
            else:
                log_error(f"Error creando directorio: {result.stderr}")
                return False
                
        except Exception as e:
            log_error(f"Error creando directorio {directory}", e)
            return False
    
    def set_file_permissions(self, file_path: str, permissions: str = "644") -> bool:
        """
        Establece permisos de archivo usando privilegios elevados
        
        Args:
            file_path: Ruta del archivo
            permissions: Permisos en formato octal (ej: "644")
            
        Returns:
            True si se establecieron correctamente
        """
        try:
            if not os.path.exists(file_path):
                log_error(f"Archivo no existe: {file_path}")
                return False
            
            if self.use_pkexec:
                cmd = ['pkexec', 'chmod', permissions, file_path]
            elif self.use_sudo:
                cmd = ['sudo', 'chmod', permissions, file_path]
            else:
                cmd = ['chmod', permissions, file_path]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                log_info(f"Permisos establecidos: {file_path} -> {permissions}")
                return True
            else:
                log_error(f"Error estableciendo permisos: {result.stderr}")
                return False
                
        except Exception as e:
            log_error(f"Error estableciendo permisos para {file_path}", e)
            return False
    
    def execute_command_with_privileges(self, command: List[str]) -> Tuple[bool, str, str]:
        """
        Ejecuta un comando con privilegios elevados
        
        Args:
            command: Lista con el comando y argumentos
            
        Returns:
            Tupla (éxito, stdout, stderr)
        """
        try:
            if self.use_pkexec:
                full_cmd = ['pkexec'] + command
            elif self.use_sudo:
                full_cmd = ['sudo'] + command
            else:
                full_cmd = command
            
            result = subprocess.run(
                full_cmd,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            success = result.returncode == 0
            if success:
                log_info(f"Comando ejecutado: {' '.join(command)}")
            else:
                log_error(f"Error ejecutando comando: {result.stderr}")
            
            return success, result.stdout, result.stderr
            
        except subprocess.TimeoutExpired:
            error_msg = f"Timeout ejecutando comando: {' '.join(command)}"
            log_error(error_msg)
            return False, "", error_msg
        except Exception as e:
            error_msg = f"Error ejecutando comando: {str(e)}"
            log_error(error_msg, e)
            return False, "", error_msg
    
    def write_file_with_privileges(self, file_path: str, content: str) -> bool:
        """
        Escribe contenido a un archivo usando privilegios elevados
        
        Args:
            file_path: Ruta del archivo
            content: Contenido a escribir
            
        Returns:
            True si se escribió correctamente
        """
        try:
            # Crear archivo temporal
            with tempfile.NamedTemporaryFile(mode='w', delete=False, encoding='utf-8') as tmp_file:
                tmp_file.write(content)
                tmp_path = tmp_file.name
            
            try:
                # Copiar archivo temporal al destino final con privilegios
                success = self.copy_file_with_privileges(tmp_path, file_path)
                
                if success:
                    # Establecer permisos apropiados
                    self.set_file_permissions(file_path, "644")
                
                return success
            finally:
                # Limpiar archivo temporal
                try:
                    os.unlink(tmp_path)
                except:
                    pass
                    
        except Exception as e:
            log_error(f"Error escribiendo archivo {file_path}", e)
            return False
    
    def remove_file_with_privileges(self, file_path: str) -> bool:
        """
        Elimina un archivo usando privilegios elevados
        
        Args:
            file_path: Ruta del archivo a eliminar
            
        Returns:
            True si se eliminó correctamente
        """
        try:
            if not os.path.exists(file_path):
                return True  # Ya no existe
            
            if self.use_pkexec:
                cmd = ['pkexec', 'rm', '-f', file_path]
            elif self.use_sudo:
                cmd = ['sudo', 'rm', '-f', file_path]
            else:
                cmd = ['rm', '-f', file_path]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                log_info(f"Archivo eliminado: {file_path}")
                return True
            else:
                log_error(f"Error eliminando archivo: {result.stderr}")
                return False
                
        except Exception as e:
            log_error(f"Error eliminando archivo {file_path}", e)
            return False
    
    def get_system_info(self) -> Dict[str, str]:
        """
        Obtiene información del sistema
        
        Returns:
            Diccionario con información del sistema
        """
        info = {}
        
        try:
            # Distribución
            result = subprocess.run(['lsb_release', '-cs'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                info['codename'] = result.stdout.strip()
            
            result = subprocess.run(['lsb_release', '-ds'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                info['description'] = result.stdout.strip()
            
            # Arquitectura
            result = subprocess.run(['dpkg', '--print-architecture'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                info['architecture'] = result.stdout.strip()
            
            # Versión de APT
            result = subprocess.run(['apt', '--version'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                info['apt_version'] = result.stdout.split('\n')[0]
                
        except Exception as e:
            log_warning(f"Error obteniendo información del sistema: {e}")
        
        return info
    
    def check_internet_connectivity(self) -> bool:
        """
        Verifica la conectividad a internet
        
        Returns:
            True si hay conectividad
        """
        try:
            # Intentar ping a varios servidores DNS públicos
            dns_servers = ['8.8.8.8', '1.1.1.1', '9.9.9.9']
            
            for dns in dns_servers:
                result = subprocess.run(
                    ['ping', '-c', '1', '-W', '3', dns],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                if result.returncode == 0:
                    return True
            
            return False
            
        except Exception as e:
            log_warning(f"Error verificando conectividad: {e}")
            return False
