"""
Módulo de widgets reutilizables para la interfaz gráfica
"""
