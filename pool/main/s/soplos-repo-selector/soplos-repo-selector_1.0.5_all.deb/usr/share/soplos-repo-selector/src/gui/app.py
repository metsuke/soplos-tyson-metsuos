import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib

import os
import sys
import time
import atexit
import locale

from src.config.constants import APP_ID, APP_NAME, APP_VERSION
from src.gui.window import MainWindow
from src.i18n.strings import set_language, get_current_language, detect_system_language
from src.utils.error_handler import log_info, log_warning, log_error

class SoplosRepoSelector(Gtk.Application):
    """
    Clase principal de la aplicación Soplos Repo Selector.
    Coordina la ventana principal y gestiona la aplicación Gtk.
    """
    def __init__(self):
        super().__init__(application_id=APP_ID,
                        flags=Gio.ApplicationFlags.FLAGS_NONE)
        
        # Inicializar variables de la aplicación
        self.window = None
        
        # Configurar la aplicación
        self.setup_application()
        
        # Configurar atajos de teclado globales
        self.setup_global_accelerators()
    
    def setup_application(self):
        """Configura los parámetros globales de la aplicación"""
        # Establecer identificadores de aplicación globales
        GLib.set_prgname(APP_ID)
        GLib.set_application_name(APP_NAME)
        
        # Deshabilitar warnings de accesibilidad
        os.environ['NO_AT_BRIDGE'] = '1'
        
        # Configurar idioma basado en locale del sistema
        self.setup_language()
    
    def setup_language(self):
        """Configura el idioma basado en la configuración del sistema"""
        # Usar la función mejorada del módulo i18n para detectar el idioma del sistema
        system_lang = detect_system_language()
        
        # Establecer el idioma en el módulo de internacionalización
        set_language(system_lang)
        
        # Registrar para depuración
        log_info(f"Idioma configurado: {get_current_language()}")
    
    def setup_global_accelerators(self):
        """Configura atajos de teclado globales de la aplicación"""
        # Acción global para salir
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", self._on_quit_activate)
        self.add_action(quit_action)
        
        # Acción para mostrar ayuda
        help_action = Gio.SimpleAction.new("help", None)
        help_action.connect("activate", self._on_help_activate)
        self.add_action(help_action)
        
        # Acción para mostrar acerca de
        about_action = Gio.SimpleAction.new("about", None)
        about_action.connect("activate", self._on_about_activate)
        self.add_action(about_action)
        
        # Configurar atajos globales
        self.set_accels_for_action("app.quit", ["<Control>q", "<Alt>F4"])
        self.set_accels_for_action("app.help", ["F1"])
        self.set_accels_for_action("app.about", ["<Control><Shift>a"])
    
    def _on_quit_activate(self, action, param):
        """Maneja la acción de salir"""
        if self.window:
            self.window.on_close_clicked(None)
    
    def _on_help_activate(self, action, param):
        """Muestra la ayuda"""
        # Implementar ventana de ayuda o abrir documentación
        pass
    
    def _on_about_activate(self, action, param):
        """Muestra el diálogo Acerca de"""
        if self.window:
            about_dialog = Gtk.AboutDialog()
            about_dialog.set_transient_for(self.window)
            about_dialog.set_modal(True)
            about_dialog.set_program_name(APP_NAME)
            about_dialog.set_version(APP_VERSION)
            about_dialog.set_comments("Gestor de repositorios para sistemas Debian")
            about_dialog.set_website("https://soploslinux.com")
            about_dialog.set_license_type(Gtk.License.GPL_3_0)
            about_dialog.run()
            about_dialog.destroy()
    
    def do_startup(self):
        """Invocado durante el inicio de la aplicación, antes de abrir la primera ventana"""
        Gtk.Application.do_startup(self)
    
    def do_activate(self):
        """Gestiona la activación de la aplicación"""
        # Si ya hay una ventana, mostrarla
        if self.window:
            self.window.present()
            return
            
        # Crear la ventana principal
        self.window = MainWindow(application=self)
        
        # Conectar la señal de cierre - CORREGIDO
        self.window.connect('delete-event', self._on_window_close_request)
        
        # Mostrar la ventana
        self.window.show_all()
    
    def _on_window_close_request(self, window, event):
        """Maneja la petición de cierre de ventana"""
        # Dejar que la ventana maneje su propio diálogo de confirmación
        # Si devuelve False, significa que se debe cerrar
        should_close = not window.on_delete_event(window, event)
        
        if should_close:
            # Cerrar la aplicación
            self.quit()
            return False
        else:
            # Cancelar el cierre
            return True
    
    def clean_stale_cache_files(self, verbose=False):
        """
        Elimina todos los directorios __pycache__ y archivos .pyc/.pyo en todo el árbol del proyecto.
        """
        try:
            import shutil
            import os
            
            # Buscar directorios __pycache__ en el directorio de la aplicación
            app_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            
            if verbose:
                log_info(f"Limpiando archivos de caché en: {app_dir}")
            
            # Eliminar los intentos de cambiar permisos que causaban errores
            
            for root, dirs, files in os.walk(app_dir):
                if '__pycache__' in dirs:
                    pycache_dir = os.path.join(root, '__pycache__')
                    try:
                        # Solo intentar eliminar si tenemos permisos
                        if os.access(pycache_dir, os.W_OK):
                            shutil.rmtree(pycache_dir)
                            if verbose:
                                log_info(f"Limpiado directorio de caché: {pycache_dir}")
                        else:
                            if verbose:
                                log_warning(f"Sin permisos para limpiar: {pycache_dir}")
                    except Exception as e:
                        if verbose:
                            log_warning(f"No se pudo limpiar {pycache_dir}: {e}")
                    
                    # Asegúrese de que no intente procesar el directorio eliminado
                    dirs.remove('__pycache__')
                
                # También limpiar archivos .pyc/.pyo sueltos
                for file in files:
                    if file.endswith(('.pyc', '.pyo')):
                        try:
                            file_path = os.path.join(root, file)
                            # Solo intentar eliminar si tenemos permisos
                            if os.access(file_path, os.W_OK):
                                os.remove(file_path)
                                if verbose:
                                    log_info(f"Eliminado archivo: {file_path}")
                            else:
                                if verbose:
                                    log_warning(f"Sin permisos para eliminar: {file_path}")
                        except Exception as e:
                            if verbose:
                                log_warning(f"No se pudo eliminar {file}: {e}")
        
        except Exception as e:
            log_warning(f"Error limpiando archivos de caché: {e}")


def create_application():
    """Crea y devuelve la instancia de la aplicación"""
    app = SoplosRepoSelector()
    
    # Limpiar archivos antiguos al inicio (ahora con modo verbose para depuración)
    app.clean_stale_cache_files(verbose=True)
    
    # Asegurarse de que Python no cree archivos .pyc nuevos
    import sys
    sys.dont_write_bytecode = True
    
    return app

def main():
    """Punto de entrada para la aplicación"""
    app = create_application()
    return app.run(None)

if __name__ == '__main__':
    main()
