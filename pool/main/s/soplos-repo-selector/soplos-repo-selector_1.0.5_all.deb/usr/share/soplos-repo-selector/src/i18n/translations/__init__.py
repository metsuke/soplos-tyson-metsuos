"""
Traducciones para Soplos Repo Selector
"""
