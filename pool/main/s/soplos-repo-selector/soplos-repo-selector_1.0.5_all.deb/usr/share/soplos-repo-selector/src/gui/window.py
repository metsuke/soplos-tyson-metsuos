import os
import sys
import subprocess
import locale as stdlib_locale
from pathlib import Path

# Añadir el directorio raíz al PYTHONPATH
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, root_dir)

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib, GdkPixbuf, Gdk
from src.repo.manager import RepoManager
from src.i18n.strings import get_string, set_language, get_available_languages, get_current_language
# Añadir esta importación para acceder a las cadenas actuales
from src.i18n import strings as i18n_strings
from src.gui.dialogs.speed_dialog import RepoSpeedDialog
from src.gui.dialogs.repo_dialog import RepoDialog
from src.gui.widgets.repo_list import RepoListWidget
from src.gui.widgets.gpg_list import GPGKeyListWidget
# Importar correctamente las constantes de la aplicación desde constants.py en lugar de main
from src.config.constants import APP_ID, APP_NAME, APP_VERSION, DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT, PREDEFINED_REPOS
from src.utils.error_handler import ErrorHandler, log_info, log_error, log_warning

def escape_markup(text):
    """Escapa caracteres especiales para markup GTK"""
    return text.replace('&', '&amp;')\
               .replace('<', '&lt;')\
               .replace('>', '&gt;')\
               .replace('"', '&quot;')\
               .replace("'", '&#39;')

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Usar las constantes definidas en src.config.constants
        self.app_id = APP_ID
        # WMCLASS debería ser igual a APP_ID
        self.wmclass = APP_ID
        
        # Establecer el WM_CLASS primero
        self.set_wmclass(self.wmclass, self.wmclass)
        
        # Establecer el icono desde el sistema primero
        self.set_icon_name(self.app_id)
        
        # Si no encuentra el icono del sistema, usar el local
        if not self.get_icon():
            try:
                window_icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                       'assets/icons/com.soplos.reposelector.png')
                window_icon = GdkPixbuf.Pixbuf.new_from_file(window_icon_path)
                self.set_icon(window_icon)
                Gtk.Window.set_default_icon(window_icon)
            except Exception as e:
                print(f"Error al cargar el icono: {e}")

        # Establecer el título de la ventana usando el nombre de la aplicación
        self.set_title(get_string('window_title', APP_NAME))
        
        # Conectar señal delete-event antes de todo
        self.connect('delete-event', self.on_delete_event)
        
        # Obtener dimensiones de la pantalla
        display = Gdk.Display.get_default()
        monitor = display.get_primary_monitor()
        geometry = monitor.get_geometry()
        screen_height = geometry.height
        
        # Ajustar tamaño de ventana usando las constantes definidas
        self.set_default_size(DEFAULT_WINDOW_WIDTH, min(DEFAULT_WINDOW_HEIGHT, screen_height - 100))

        # Inicializar el gestor de repositorios
        self.repo_manager = RepoManager()
        
        # Inicializar el sistema de manejo de errores con esta ventana como padre
        ErrorHandler.initialize(parent_window=self)
        
        # Crear la interfaz
        self._create_ui()
        
        # NUEVO: Configurar atajos de teclado
        self._setup_keyboard_accelerators()
        
        # Cargar los repositorios existentes
        self._load_repos()
        
        # Inicializar el caché de widgets para optimizar búsquedas
        self._widget_cache = {}
        
    def _setup_keyboard_accelerators(self):
        """Configura los atajos de teclado de la aplicación"""
        # Obtener el grupo de acciones de la aplicación
        action_group = Gio.SimpleActionGroup()
        self.insert_action_group("win", action_group)
        
        # Acción para aplicar cambios (Ctrl+S)
        apply_action = Gio.SimpleAction.new("apply", None)
        apply_action.connect("activate", lambda action, param: self.on_apply_changes_clicked(self.apply_button))
        action_group.add_action(apply_action)
        
        # Acción para actualizar repositorios (Ctrl+U)
        update_action = Gio.SimpleAction.new("update", None)
        update_action.connect("activate", lambda action, param: self.on_update_repos_clicked(self.update_button))
        action_group.add_action(update_action)
        
        # Acción para buscar repositorios rápidos (Ctrl+F)
        find_action = Gio.SimpleAction.new("find-fast", None)
        find_action.connect("activate", lambda action, param: self.on_find_fastest_repos_clicked(self.fast_repos_button))
        action_group.add_action(find_action)
        
        # Acción para añadir repositorio (Ctrl+N)
        add_repo_action = Gio.SimpleAction.new("add-repo", None)
        add_repo_action.connect("activate", lambda action, param: self.repo_list.on_add_repo_clicked(self.repo_list.add_button))
        action_group.add_action(add_repo_action)
        
        # Acción para editar repositorio (Ctrl+E)
        edit_repo_action = Gio.SimpleAction.new("edit-repo", None)
        edit_repo_action.connect("activate", lambda action, param: self.repo_list.on_edit_repo_clicked(self.repo_list.edit_button))
        action_group.add_action(edit_repo_action)
        
        # Acción para eliminar repositorio (Delete)
        remove_repo_action = Gio.SimpleAction.new("remove-repo", None)
        remove_repo_action.connect("activate", lambda action, param: self.repo_list.on_remove_repo_clicked(self.repo_list.remove_button))
        action_group.add_action(remove_repo_action)
        
        # Acción para cerrar (Ctrl+Q)
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", lambda action, param: self.on_close_clicked(self.close_button))
        action_group.add_action(quit_action)
        
        # Configurar atajos de teclado para la aplicación
        app = self.get_application()
        if app:
            app.set_accels_for_action("win.apply", ["<Control>s"])
            app.set_accels_for_action("win.update", ["<Control>u"])
            app.set_accels_for_action("win.find-fast", ["<Control>f"])
            app.set_accels_for_action("win.add-repo", ["<Control>n"])
            app.set_accels_for_action("win.edit-repo", ["<Control>e"])
            app.set_accels_for_action("win.remove-repo", ["Delete"])
            app.set_accels_for_action("win.quit", ["<Control>q"])
    
    def _create_ui(self):
        """Crea la interfaz de usuario principal"""
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        self.add(main_box)
        
        # Panel superior con idioma
        top_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        top_panel.set_halign(Gtk.Align.END)
        main_box.pack_start(top_panel, False, False, 0)
        
        # Selector de idioma
        language_label = Gtk.Label()
        language_label.set_markup_with_mnemonic(get_string("language", "_Idioma") + ":")
        language_label.set_name("language_label")
        top_panel.pack_start(language_label, False, False, 0)
        
        self.language_combo = Gtk.ComboBoxText()
        language_label.set_mnemonic_widget(self.language_combo)  # IMPORTANTE: Asociar mnemonic
        languages = get_available_languages()
        current_lang = get_current_language()
        
        # Ordenar idiomas de manera personalizada
        # Definir un orden específico para los idiomas prioritarios
        priority_langs = ['en', 'es', 'de', 'fr', 'it', 'pt', 'ro', 'ru']
        
        # Primero añadir los idiomas prioritarios en el orden especificado
        for lang_code in priority_langs:
            if lang_code in languages:
                self.language_combo.append(lang_code, languages[lang_code])
                if lang_code == current_lang:
                    self.language_combo.set_active_id(lang_code)
        
        # Luego añadir el resto de idiomas en orden alfabético por nombre
        remaining_langs = [(code, name) for code, name in languages.items() if code not in priority_langs]
        for code, name in sorted(remaining_langs, key=lambda x: x[1]):
            self.language_combo.append(code, name)
            if code == current_lang and self.language_combo.get_active() == -1:
                self.language_combo.set_active_id(code)
        
        self.language_combo.connect('changed', self.on_language_changed)
        top_panel.pack_start(self.language_combo, False, False, 0)
        
        # Crear notebook con mnemonics en las pestañas
        self.notebook = Gtk.Notebook()
        main_box.pack_start(self.notebook, True, True, 0)
        
        # Página 1: Repositorios CON mnemonic
        repo_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        repo_tab_label = Gtk.Label()
        repo_tab_label.set_markup_with_mnemonic(get_string("repositories", "_Repositorios"))
        self.notebook.append_page(repo_page, repo_tab_label)
        
        # Título de la sección de repositorios
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        repo_page.pack_start(title_box, False, False, 0)
        
        # Título y descripción
        title_icon = Gtk.Image.new_from_icon_name("software-properties", Gtk.IconSize.DIALOG)
        title_box.pack_start(title_icon, False, False, 0)
        
        title_text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_box.pack_start(title_text_box, True, True, 0)
        
        self.title_label = Gtk.Label()
        self.title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('repo_manager', 'Gestor de Repositorios Debian')}</span>")
        self.title_label.set_halign(Gtk.Align.START)
        self.title_label.set_name("title_label")
        title_text_box.pack_start(self.title_label, False, False, 0)
        
        self.desc_label = Gtk.Label(label=get_string('repo_description', 'Administra los repositorios APT de tu sistema'))
        self.desc_label.set_halign(Gtk.Align.START)
        self.desc_label.set_name("description_label")
        title_text_box.pack_start(self.desc_label, False, False, 0)
        
        # Separador
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        repo_page.pack_start(separator, False, False, 0)
        
        # Widget de lista de repositorios
        self.repo_list = RepoListWidget()
        self.repo_list.connect('repo-changed', self.on_repo_changed)
        repo_page.pack_start(self.repo_list, True, True, 0)
        
        # Botón para buscar repositorios más rápidos
        fast_repos_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        repo_page.pack_start(fast_repos_box, False, False, 0)
        
        # CORREGIR: Usar Button.new_with_mnemonic para mnemonics
        self.fast_repos_button = Gtk.Button.new_with_mnemonic(get_string("find_fastest_repos", "Buscar Repositorios Más _Rápidos"))
        self.fast_repos_button.connect("clicked", self.on_find_fastest_repos_clicked)
        fast_repos_box.pack_start(self.fast_repos_button, False, False, 0)
        
        # Espaciador
        fast_repos_box.pack_start(Gtk.Box(), True, True, 0)
        
        # Botón de actualización
        self.update_button = Gtk.Button.new_with_mnemonic(get_string("update_repos", "_Actualizar Repositorios"))
        self.update_button.connect("clicked", self.on_update_repos_clicked)
        fast_repos_box.pack_start(self.update_button, False, False, 0)
        
        # COMPLETAMENTE ELIMINADO: Frame para repositorios predefinidos populares
        # (Todo el código relacionado con botones predefinidos ha sido eliminado)
        
        # Página 2: Claves GPG CON mnemonic
        gpg_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        gpg_tab_label = Gtk.Label()
        gpg_tab_label.set_markup_with_mnemonic(get_string("gpg_keys", "Claves _GPG"))
        self.notebook.append_page(gpg_page, gpg_tab_label)
        
        # Título de la sección de claves GPG
        gpg_title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        gpg_page.pack_start(gpg_title_box, False, False, 0)
        
        # Título y descripción
        gpg_title_icon = Gtk.Image.new_from_icon_name("dialog-password", Gtk.IconSize.DIALOG)
        gpg_title_box.pack_start(gpg_title_icon, False, False, 0)
        
        gpg_title_text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        gpg_title_box.pack_start(gpg_title_text_box, True, True, 0)
        
        self.gpg_title_label = Gtk.Label()
        self.gpg_title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('gpg_key_manager', 'Gestor de Claves GPG')}</span>")
        self.gpg_title_label.set_halign(Gtk.Align.START)
        self.gpg_title_label.set_name("gpg_title_label")
        gpg_title_text_box.pack_start(self.gpg_title_label, False, False, 0)
        
        self.gpg_desc_label = Gtk.Label(label=get_string('gpg_key_description', 'Administra las claves GPG para tus repositorios'))
        self.gpg_desc_label.set_halign(Gtk.Align.START)
        self.gpg_desc_label.set_name("gpg_description_label")
        gpg_title_text_box.pack_start(self.gpg_desc_label, False, False, 0)
        
        # Separador
        gpg_separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        gpg_page.pack_start(gpg_separator, False, False, 0)
        
        # Widget de lista de claves GPG
        self.gpg_key_list = GPGKeyListWidget()
        self.gpg_key_list.connect('key-imported', self.on_key_imported)
        gpg_page.pack_start(self.gpg_key_list, True, True, 0)
        
        # Barra de progreso
        self.progress_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.progress_box.set_no_show_all(True)  # Inicialmente oculto
        main_box.pack_start(self.progress_box, False, False, 0)
        
        progress_label_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.progress_box.pack_start(progress_label_box, False, False, 0)
        
        self.progress_spinner = Gtk.Spinner()
        progress_label_box.pack_start(self.progress_spinner, False, False, 0)
        
        self.progress_label = Gtk.Label(label=get_string("processing", "Procesando..."))
        self.progress_label.set_halign(Gtk.Align.START)
        progress_label_box.pack_start(self.progress_label, True, True, 0)
        
        # Barra de progreso
        self.progressbar = Gtk.ProgressBar()
        self.progressbar.set_show_text(True)
        self.progress_box.pack_start(self.progressbar, False, False, 0)
        
        # Botones principales CON mnemonics correctos
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        button_box.set_halign(Gtk.Align.END)
        button_box.set_margin_top(10)
        main_box.pack_end(button_box, False, False, 0)
        
        # CORREGIR: Usar Button.new_with_mnemonic para mnemonics
        self.close_button = Gtk.Button.new_with_mnemonic(get_string("close", "_Cerrar"))
        self.close_button.connect("clicked", self.on_close_clicked)
        button_box.pack_start(self.close_button, False, False, 0)
        
        self.apply_button = Gtk.Button.new_with_mnemonic(get_string("apply", "_Aplicar Cambios"))
        self.apply_button.connect("clicked", self.on_apply_changes_clicked)
        self.apply_button.get_style_context().add_class("suggested-action")
        button_box.pack_start(self.apply_button, False, False, 0)
        
        # Spinner para operaciones
        self.spinner = Gtk.Spinner()
        button_box.pack_start(self.spinner, False, False, 0)

    def on_delete_event(self, window, event):
        """Maneja el evento de cierre de la ventana"""
        # Mostrar diálogo de confirmación
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=get_string("close_confirm", "¿Está seguro de que desea cerrar la aplicación?")
        )
        dialog.format_secondary_text(
            get_string("unsaved_changes_warning", "Se perderán los cambios no guardados.")
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            # Permitir el cierre
            return False
        else:
            # Cancelar el cierre
            return True

    def on_close_clicked(self, button):
        """Maneja el clic en el botón cerrar"""
        # Usar el mismo método que on_delete_event pero adaptado para botón
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=get_string("close_confirm", "¿Está seguro de que desea cerrar la aplicación?")
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            # Cerrar la aplicación
            app = self.get_application()
            if app:
                app.quit()
            else:
                Gtk.main_quit()

    def on_apply_changes_clicked(self, button):
        """Aplica los cambios realizados en los repositorios"""
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("applying_changes", "Aplicando cambios a los repositorios..."), 0.0)
        
        # Deshabilitar botón mientras se procesan cambios
        button.set_sensitive(False)
        self.spinner.start()
        
        # Usar GLib.idle_add para procesar en segundo plano
        GLib.idle_add(self._do_apply_changes, button)

    def _do_apply_changes(self, button):
        """Procesa la aplicación de cambios en segundo plano"""
        try:
            # Aquí iría la lógica para aplicar cambios
            # Por ahora, solo simular el proceso
            import time
            time.sleep(2)  # Simular procesamiento
            
            GLib.idle_add(self._show_info_dialog, get_string("changes_applied", "Cambios aplicados correctamente"))
            
        except Exception as e:
            log_error("Error al aplicar cambios", e)
            GLib.idle_add(self._show_error_dialog, get_string("apply_error", "Error al aplicar cambios: {0}").format(str(e)))
        
        finally:
            # Restaurar botón y ocultar progreso
            GLib.idle_add(button.set_sensitive, True)
            GLib.idle_add(self.spinner.stop)
            GLib.idle_add(self._hide_progress_bar)
        
        return False

    def _show_info_dialog(self, message):
        """Muestra un diálogo de información"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def _show_error_dialog(self, message):
        """Muestra un diálogo de error"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=get_string("error", "Error")
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def _load_repos(self):
        """Carga los repositorios del sistema"""
        self.repo_list.clear()
        
        # Mostrar spinner mientras carga
        self.spinner.start()
        self.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("loading_repos", "Cargando repositorios..."), 0.0)
        
        # Usar GLib.idle_add para no bloquear la UI
        GLib.idle_add(self._do_load_repos)
    
    def _do_load_repos(self):
        """Realiza la carga de repositorios en segundo plano"""
        try:
            repos = self.repo_manager.get_all_repos()
            
            total = len(repos)
            for i, repo in enumerate(repos):
                # Actualizar barra de progreso
                fraction = float(i) / max(total, 1)
                GLib.idle_add(self.progressbar.set_fraction, fraction)
                GLib.idle_add(self.progressbar.set_text, 
                             get_string("loading_repo_progress", "Cargando repositorio {0} de {1}").format(i+1, total))
                
                self.repo_list.add_repo(
                    not repo['disabled'],  # Activo
                    repo['type'],          # Tipo
                    repo['uri'],           # URI
                    repo['distribution'],  # Distribución
                    repo['components'],    # Componentes
                    repo['comment']        # Comentario
                )
            
            # Actualizar barra de progreso a completado
            GLib.idle_add(self.progressbar.set_fraction, 1.0)
            GLib.idle_add(self.progressbar.set_text, 
                         get_string("loaded_repos", "Cargados {0} repositorios").format(total))
            
        except Exception as e:
            log_error("Error al cargar repositorios", e)
            GLib.idle_add(self._hide_progress_bar)
            
            # Corregir la forma de manejar la excepción en el GLib.idle_add
            error_msg = str(e)  # Guardar el mensaje de error antes de pasar al lambda
            GLib.idle_add(lambda: ErrorHandler.show_error_dialog(
                get_string("error", "Error"), 
                get_string("error_loading_repos", "Error al cargar repositorios: {0}").format(error_msg),
                self
            ))
        
        # Detener spinner y restaurar sensibilidad
        GLib.idle_add(self.spinner.stop)
        GLib.idle_add(self.set_sensitive, True)
        
        # Ocultar barra de progreso después de un retraso
        GLib.timeout_add(1500, self._hide_progress_bar)
        
        return False  # Importante para GLib.idle_add
    
    def _show_progress_bar(self, message, fraction=0.0):
        """Muestra la barra de progreso con un mensaje"""
        self.progress_label.set_text(message)
        self.progressbar.set_fraction(fraction)
        self.progressbar.set_text(f"{int(fraction * 100)}%")
        self.progress_spinner.start()
        
        # Cambiar a set_visible(True) en lugar de usar show_all()
        self.progress_box.set_no_show_all(False)
        self.progress_box.set_visible(True)
        self.progress_box.show_all()

    def _update_progress_bar(self, fraction, text=None):
        """Actualiza el progreso de la barra"""
        self.progressbar.set_fraction(fraction)
        if text:
            self.progressbar.set_text(text)
        else:
            self.progressbar.set_text(f"{int(fraction * 100)}%")
    
    def _hide_progress_bar(self):
        """Oculta la barra de progreso"""
        self.progress_spinner.stop()
        self.progress_box.set_visible(False)
        self.progress_box.set_no_show_all(True)
        return False  # Importante para usar con GLib.timeout_add
    
    def on_repo_changed(self, widget):
        """Maneja los cambios en los repositorios"""
        # Este método se llama cuando hay cambios en la lista de repositorios
        # Se puede usar para habilitar/deshabilitar botones, actualizar contadores, etc.
        pass
    
    def on_key_imported(self, widget, success, path_or_error):
        """Maneja el evento de importación de clave GPG"""
        if success:
            self._show_info_dialog(get_string('key_imported', 'Clave importada:') + f" {os.path.basename(path_or_error)}")
        else:
            self._show_error_dialog(get_string('key_import_error', 'Error al importar clave:') + f" {path_or_error}")
    
    def on_find_fastest_repos_clicked(self, button):
        """Abre el diálogo para buscar los repositorios más rápidos y añade los seleccionados"""
        try:
            # Recopilar URLs de repositorios actuales para evitar duplicados
            current_repos = []
            def collect_repos(model, path, iter, data):
                uri = model[iter][2]
                if uri not in data:
                    data.append(uri)
            self.repo_list.repos_store.foreach(collect_repos, current_repos)

            # Mostrar diálogo de velocidad
            from src.gui.dialogs.speed_dialog import RepoSpeedDialog
            dialog = RepoSpeedDialog(self, current_repos)
            response = dialog.run()
            if response == Gtk.ResponseType.OK:
                selected_repos = dialog.get_selected_repos()
                if selected_repos:
                    for repo in selected_repos:
                        self.repo_list.add_repo(
                            True,
                            repo.get('type', 'deb'),
                            repo['uri'],
                            repo['distribution'],
                            repo['components'],
                            get_string('added_via_speed_test', 'Añadido mediante test de velocidad')
                        )
                    self._show_info_dialog(get_string("repos_added", "Repositorios añadidos correctamente"))
                else:
                    self._show_info_dialog(get_string("no_repos_selected", "No se seleccionaron repositorios"))
            dialog.destroy()
        except Exception as e:
            log_error("Error al buscar repositorios rápidos", e)
            self._show_error_dialog(get_string("error_finding_repos", "Error al buscar repositorios rápidos: {0}").format(str(e)))
    
    def on_update_repos_clicked(self, button):
        """Actualiza la lista de paquetes (apt update)"""
        # Guardar los repositorios actuales antes de actualizar
        self.save_current_repos_state()
        
        self.spinner.start()
        button.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("updating_repos", "Actualizando repositorios..."), 0.0)
        
        # Usar GLib.idle_add para ejecutar apt update en segundo plano
        GLib.idle_add(self._do_update_repos, button)
        
    def save_current_repos_state(self):
        """Guarda el estado actual de los repositorios para restaurarlos después de actualizar"""
        self.saved_repos = []
        self.repo_list.repos_store.foreach(self._collect_repos, self.saved_repos)
    
    def _collect_repos(self, model, path, iter, repos_list):
        """Recopila información de repositorios desde el modelo de datos"""
        # Extraer datos de la fila
        active = model[iter][0]
        repo_type = model[iter][1]
        uri = model[iter][2]
        distribution = model[iter][3]
        components = model[iter][4]
        comment = model[iter][5]
        
        # Buscar si este repositorio ya existe en el sistema
        # para mantener su archivo de origen y formato
        existing_repos = self.repo_manager.get_all_repos(use_cache=False)
        found_repo = None
        
        for existing in existing_repos:
            if (existing['uri'] == uri and 
                existing['distribution'] == distribution and 
                existing['type'] == repo_type):
                found_repo = existing
                break
        
        # Si encontramos un repo existente, usar su información
        if found_repo:
            repo = {
                'disabled': not active,  # Importante: respetar el estado de activación actual
                'type': repo_type,
                'uri': uri,
                'distribution': distribution,
                'components': components,
                'comment': comment,
                'file': found_repo['file'],
                'format': found_repo.get('format', 'legacy')
            }
        else:
            # Para repositorios nuevos, usar archivo apropiado y formato DEB822 si es posible
            format_type = 'deb822' if self.repo_manager.use_modern_format else 'legacy'
            file_extension = '.sources' if self.repo_manager.use_modern_format else '.list'
            
            # Determinar archivo adecuado basado en URI y distribución
            if "security.debian.org" in uri:
                # Repositorios de seguridad siempre van en un archivo separado
                file_path = f'/etc/apt/sources.list.d/debian-security{file_extension}'
            elif "debian.org" in uri:
                # Para otros repos oficiales Debian usar formato moderno
                if distribution.endswith('-backports'):
                    file_path = f'/etc/apt/sources.list.d/debian-backports{file_extension}'
                else:
                    file_path = f'/etc/apt/sources.list.d/debian{file_extension}'
            else:
                # Para otros repos, crear un archivo basado en el hostname
                hostname = uri.split('//')[-1].split('/')[0].replace(".", "-")
                file_path = f'/etc/apt/sources.list.d/{hostname}{file_extension}'
            
            repo = {
                'disabled': not active,  # Importante: respetar el estado de activación actual
                'type': repo_type,
                'uri': uri,
                'distribution': distribution,
                'components': components,
                'comment': comment,
                'file': file_path,
                'format': format_type
            }
        
        # Añadir el repositorio (nuevo o existente) a la lista guardada
        repos_list.append(repo)
    
    def _do_update_repos(self, button):
        """Ejecuta el comando apt update y maneja la salida"""
        try:
            # Mostrar información de progreso
            self._update_progress_bar(0.1, get_string("updating_repos", "Actualizando repositorios..."))
            
            # Usar pkexec para obtener privilegios elevados
            process = subprocess.Popen(
                ['pkexec', 'apt', 'update'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Leer la salida línea por línea
            for stdout_line in iter(process.stdout.readline, ''):
                if not stdout_line:
                    break
                    
                # Filtrar líneas de progreso de apt
                if stdout_line.startswith(("Get:", "Hit:", "Ign:")):
                    continue
                
                # Mostrar cada línea en la barra de progreso
                GLib.idle_add(self._update_progress_bar, 0.5, stdout_line.strip())
            
            # Esperar a que el proceso termine
            process.stdout.close()
            return_code = process.wait()
            
            # Leer cualquier error
            stderr_output = process.stderr.read()
            
            # Comprobar si hubo errores
            if return_code != 0:
                if "permission denied" in stderr_output.lower() or "permiso denegado" in stderr_output.lower():
                    GLib.idle_add(self._show_error_dialog, 
                                get_string("permission_error", "Error de permisos: No tiene privilegios para actualizar repositorios"))
                else:
                    GLib.idle_add(self._show_error_dialog, 
                                get_string("error_updating_repos", "Error al actualizar repositorios: {0}").format(stderr_output.strip()))
            else:
                GLib.idle_add(self._show_info_dialog, get_string("repos_updated", "Repositorios actualizados correctamente"))
    
        except subprocess.SubprocessError as e:
            log_error("Error al ejecutar apt update", e)
            # Verificar si es un error relacionado con pkexec cancelado por el usuario
            if isinstance(e, subprocess.CalledProcessError) and e.returncode == 126:
                GLib.idle_add(self._show_info_dialog, get_string("update_cancelled", "Actualización cancelada por el usuario"))
            else:
                GLib.idle_add(self._show_error_dialog, get_string("error_updating_repos", "Error al actualizar repositorios: {0}").format(str(e)))
    
        except Exception as e:
            log_error("Error al ejecutar apt update", e)
            GLib.idle_add(self._show_error_dialog, get_string("error_updating_repos", "Error al actualizar repositorios: {0}").format(str(e)))
    
        finally:
            # Detener spinner y restaurar botón
            GLib.idle_add(self.spinner.stop)
            GLib.idle_add(button.set_sensitive, True)
            GLib.idle_add(self._hide_progress_bar)
    
    def _populate_repos(self):
        """Llena la lista de repositorios desde el gestor de repositorios"""
        self.repo_list.clear()
        try:
            repos = self.repo_manager.get_all_repos()
            for repo in repos:
                self.repo_list.add_repo(
                    not repo.get('disabled', False),
                    repo.get('type', 'deb'),
                    repo.get('uri', ''),
                    repo.get('distribution', ''),
                    repo.get('components', ''),
                    repo.get('comment', '')
                )
        except Exception as e:
            log_error("Error al poblar la lista de repositorios", e)
            self._show_error_dialog(get_string("error_loading_repos", "Error al cargar repositorios: {0}").format(str(e)))

    def on_language_changed(self, combo):
        """Cambia el idioma de la interfaz"""
        lang_code = combo.get_active_id()
        if lang_code:
            set_language(lang_code)
            self._update_ui_strings()
    
    def _update_ui_strings(self):
        """Actualiza las cadenas de la interfaz según el idioma actual"""
        # Actualizar título de la ventana
        self.set_title(get_string('window_title', APP_NAME))
        
        # Actualizar títulos y descripciones principales SIN mnemonics
        self.title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('repo_manager', 'Gestor de Repositorios Debian')}</span>")
        self.desc_label.set_text(get_string('repo_description', 'Administra los repositorios APT de tu sistema'))
        self.gpg_title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('gpg_key_manager', 'Gestor de Claves GPG')}</span>")
        self.gpg_desc_label.set_text(get_string('gpg_key_description', 'Administra las claves GPG para tus repositorios'))
        
        # Actualizar pestañas del notebook CON mnemonics
        repo_tab_label = self.notebook.get_tab_label(self.notebook.get_nth_page(0))
        if repo_tab_label:
            repo_tab_label.set_markup_with_mnemonic(get_string("repositories", "_Repositorios"))
        
        gpg_tab_label = self.notebook.get_tab_label(self.notebook.get_nth_page(1))
        if gpg_tab_label:
            gpg_tab_label.set_markup_with_mnemonic(get_string("gpg_keys", "Claves _GPG"))
        
        # Actualizar botones principales CON mnemonics
        self.close_button.set_label(get_string("close", "_Cerrar"))
        self.close_button.set_use_underline(True)
        
        self.apply_button.set_label(get_string("apply", "_Aplicar Cambios"))
        self.apply_button.set_use_underline(True)
        
        self.fast_repos_button.set_label(get_string("find_fastest_repos", "Buscar Repositorios Más _Rápidos"))
        self.fast_repos_button.set_use_underline(True)
        
        self.update_button.set_label(get_string("update_repos", "_Actualizar Repositorios"))
        self.update_button.set_use_underline(True)
        
        # Actualizar etiqueta de idioma CON mnemonic
        language_label = None
        for child in self.get_children():
            if hasattr(child, 'get_children'):
                for subchild in child.get_children():
                    if hasattr(subchild, 'get_name') and subchild.get_name() == "language_label":
                        language_label = subchild
                        break
        if language_label:
            language_label.set_markup_with_mnemonic(get_string("language", "_Idioma") + ":")
        
        # Actualizar widgets hijos
        if hasattr(self, "repo_list"):
            self.repo_list.update_ui_strings(i18n_strings._current_strings)
        if hasattr(self, "gpg_key_list"):
            self.gpg_key_list.update_ui_strings(i18n_strings._current_strings)
        
    def _update_predefined_repo_buttons(self):
        """MÉTODO ELIMINADO - Ya no necesario"""
        pass
    
    # COMPLETAMENTE ELIMINADOS TODOS ESTOS MÉTODOS:
    # def on_chrome_repo_clicked(self, button):
    # def on_vscode_repo_clicked(self, button):  
    # def on_docker_repo_clicked(self, button):
    # def on_obs_repo_clicked(self, button):
