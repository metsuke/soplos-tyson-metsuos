import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, GObject

from src.gui.dialogs.repo_dialog import RepoDialog
from src.i18n.strings import get_string

class RepoListWidget(Gtk.Box):
    """Widget para mostrar y gestionar la lista de repositorios"""
    
    __gsignals__ = {
        'repo-changed': (GObject.SignalFlags.RUN_FIRST, None, ()),
        'selection-changed': (GObject.SignalFlags.RUN_FIRST, None, (bool,)),
    }
    
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        
        # Crear el modelo para la lista de repositorios
        # Columnas: Activo, Tipo, URI, Distribución, Componentes, Comentario
        self.repos_store = Gtk.ListStore(bool, str, str, str, str, str)
        
        # Lista de repositorios
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled_window.set_shadow_type(Gtk.ShadowType.ETCHED_IN)
        self.pack_start(scrolled_window, True, True, 0)
        
        # Vista de árbol para repositorios
        self.repos_view = Gtk.TreeView(model=self.repos_store)
        
        # Columna de activación (checkbox)
        renderer_toggle = Gtk.CellRendererToggle()
        renderer_toggle.connect("toggled", self.on_repo_toggled)
        column_toggle = Gtk.TreeViewColumn(get_string("active", "Activo"), renderer_toggle, active=0)
        self.repos_view.append_column(column_toggle)
        
        # Columnas de texto
        self._add_text_column(get_string("type", "Tipo"), 1)
        self._add_text_column(get_string("uri", "URI"), 2)
        self._add_text_column(get_string("distribution", "Distribución"), 3)
        self._add_text_column(get_string("components", "Componentes"), 4)
        self._add_text_column(get_string("comment", "Comentario"), 5)
        
        # Permitir selección
        self.selection = self.repos_view.get_selection()
        self.selection.set_mode(Gtk.SelectionMode.SINGLE)
        self.selection.connect("changed", self.on_repo_selection_changed)
        
        scrolled_window.add(self.repos_view)
        
        # Panel de botones para repositorios
        repo_buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.pack_start(repo_buttons, False, False, 0)
        
        # CORREGIDO: Volver a botones simples con iconos como estaba originalmente
        self.add_button = Gtk.Button.new_from_icon_name("list-add", Gtk.IconSize.BUTTON)
        self.add_button.set_tooltip_text(get_string("add_repo_tooltip", "Añadir repositorio") + " (Ctrl+N)")
        self.add_button.connect("clicked", self.on_add_repo_clicked)
        repo_buttons.pack_start(self.add_button, False, False, 0)
        
        self.edit_button = Gtk.Button.new_from_icon_name("document-edit", Gtk.IconSize.BUTTON)
        self.edit_button.set_tooltip_text(get_string("edit_repo_tooltip", "Editar repositorio") + " (Ctrl+E)")
        self.edit_button.connect("clicked", self.on_edit_repo_clicked)
        self.edit_button.set_sensitive(False)
        repo_buttons.pack_start(self.edit_button, False, False, 0)
        
        self.remove_button = Gtk.Button.new_from_icon_name("list-remove", Gtk.IconSize.BUTTON)
        self.remove_button.set_tooltip_text(get_string("remove_repo_tooltip", "Eliminar repositorio") + " (Delete)")
        self.remove_button.connect("clicked", self.on_remove_repo_clicked)
        self.remove_button.set_sensitive(False)
        repo_buttons.pack_start(self.remove_button, False, False, 0)
        
        # Espaciador
        repo_buttons.pack_start(Gtk.Box(), True, True, 0)
    
    def _add_text_column(self, title, index):
        """Añade una columna de texto a la vista de árbol"""
        renderer = Gtk.CellRendererText()
        renderer.set_property("ellipsize", True)  # Permite elipsis en texto largo
        renderer.set_property("xpad", 10)  # Añadir padding horizontal
        column = Gtk.TreeViewColumn(title, renderer, text=index)
        column.set_resizable(True)  # Asegurar que las columnas sean redimensionables
        column.set_expand(True)  # Permitir que la columna se expanda
        column.set_sort_column_id(index)
        
        # Establecer un ancho mínimo para la columna, pero no máximo
        if index == 1:  # Tipo
            column.set_min_width(80)
        elif index == 2:  # URI
            column.set_min_width(200)
        elif index == 3:  # Distribución
            column.set_min_width(120)
        elif index == 4:  # Componentes
            column.set_min_width(150)
        elif index == 5:  # Comentario
            column.set_min_width(150)
        
        self.repos_view.append_column(column)
        return column
    
    def add_repo(self, active, repo_type, uri, distribution, components, comment):
        """Añade un repositorio a la lista"""
        self.repos_store.append([active, repo_type, uri, distribution, components, comment])
        self.emit('repo-changed')
    
    def clear(self):
        """Limpia la lista de repositorios"""
        self.repos_store.clear()

    def get_repos(self):
        """Obtiene la lista de repositorios en el modelo"""
        repos = []
        
        def collect_repo(model, path, iter, data):
            data.append({
                'active': model[iter][0],
                'type': model[iter][1],
                'uri': model[iter][2],
                'distribution': model[iter][3],
                'components': model[iter][4],
                'comment': model[iter][5]
            })
            return False
        
        self.repos_store.foreach(collect_repo, repos)
        return repos
    
    def get_selection(self):
        """Obtiene el repositorio seleccionado actualmente"""
        model, iter = self.selection.get_selected()
        if iter:
            return {
                'active': model[iter][0],
                'type': model[iter][1],
                'uri': model[iter][2],
                'distribution': model[iter][3],
                'components': model[iter][4],
                'comment': model[iter][5]
            }
        return None
    
    def on_repo_toggled(self, renderer, path):
        """Maneja el cambio en el estado de activación de un repositorio"""
        iter = self.repos_store.get_iter(path)
        active = not self.repos_store[iter][0]
        self.repos_store[iter][0] = active
        self.emit('repo-changed')
    
    def on_repo_selection_changed(self, selection):
        """Actualiza la sensibilidad de los botones según la selección"""
        model, iter = selection.get_selected()
        has_selection = iter is not None
        
        self.edit_button.set_sensitive(has_selection)
        self.remove_button.set_sensitive(has_selection)
        
        # Notificar al contenedor que cambió la selección
        self.emit('selection-changed', has_selection)
    
    def on_add_repo_clicked(self, button):
        """Abre el diálogo para añadir un repositorio"""
        parent = self.get_toplevel()
        dialog = RepoDialog(parent)
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            repo = dialog.get_repo()
            if repo:
                self.add_repo(
                    repo['active'],
                    repo['type'],
                    repo['uri'],
                    repo['distribution'],
                    repo['components'],
                    repo['comment']
                )
        
        dialog.destroy()
    
    def on_edit_repo_clicked(self, button):
        """Abre el diálogo para editar un repositorio"""
        model, iter = self.selection.get_selected()
        if iter:
            # Obtener datos del repositorio seleccionado
            repo = {
                'active': model[iter][0],
                'type': model[iter][1],
                'uri': model[iter][2],
                'distribution': model[iter][3],
                'components': model[iter][4],
                'comment': model[iter][5]
            }
            
            parent = self.get_toplevel()
            dialog = RepoDialog(parent, repo)
            response = dialog.run()
            
            if response == Gtk.ResponseType.OK:
                new_repo = dialog.get_repo()
                if new_repo:
                    # Actualizar el repositorio en la lista
                    model[iter][0] = new_repo['active']
                    model[iter][1] = new_repo['type']
                    model[iter][2] = new_repo['uri']
                    model[iter][3] = new_repo['distribution']
                    model[iter][4] = new_repo['components']
                    model[iter][5] = new_repo['comment']
                    
                    self.emit('repo-changed')
            
            dialog.destroy()
    
    def on_remove_repo_clicked(self, button):
        """Elimina el repositorio seleccionado"""
        model, iter = self.selection.get_selected()
        if iter:
            parent = self.get_toplevel()
            from src.utils.error_handler import ErrorHandler
            title = get_string("delete_confirm", "¿Estás seguro de eliminar este repositorio?")
            ErrorHandler.show_warning_dialog(title, "", parent=parent)
            # Confirmación manual, si quieres mantener el diálogo personalizado:
            confirm_dialog = Gtk.MessageDialog(
                transient_for=parent,
                flags=0,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.NONE,
                text=title
            )
            confirm_dialog.add_button(get_string("no", "No"), Gtk.ResponseType.NO)
            confirm_dialog.add_button(get_string("yes", "Sí"), Gtk.ResponseType.YES)
            confirm_dialog.set_default_response(Gtk.ResponseType.YES)
            response = confirm_dialog.run()
            confirm_dialog.destroy()
            if response == Gtk.ResponseType.YES:
                model.remove(iter)
                self.emit('repo-changed')

    def update_ui_strings(self, strings):
        """Actualiza los textos de la interfaz con las traducciones"""
        self.add_button.set_tooltip_text(strings.get('add_repo_tooltip', "Añadir repositorio") + " (Ctrl+N)")
        self.edit_button.set_tooltip_text(strings.get('edit_repo_tooltip', "Editar repositorio") + " (Ctrl+E)")
        self.remove_button.set_tooltip_text(strings.get('remove_repo_tooltip', "Eliminar repositorio") + " (Delete)")
        
        # Actualizar columnas de TreeView
        column_titles = ['active', 'type', 'uri', 'distribution', 'components', 'comment']
        for i, title in enumerate(column_titles):
            column = self.repos_view.get_column(i)
            if column:
                column.set_title(strings.get(title, title.capitalize()))
