"""
Gestión de configuración del sistema y utilidades
"""
import os
import json
import subprocess
from typing import Dict, Any, Optional
from pathlib import Path
from src.utils.error_handler import log_info, log_error, log_warning
from src.i18n.strings import get_string

class SystemConfig:
    """Gestiona la configuración del sistema y verificaciones"""
    
    @classmethod
    def get_debian_version(cls) -> str:
        """Obtiene la versión de Debian del sistema"""
        try:
            result = subprocess.run(['lsb_release', '-cs'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        
        # Fallback: leer /etc/debian_version
        try:
            with open('/etc/debian_version', 'r') as f:
                version = f.read().strip()
                # Mapear números a nombres de código
                version_map = {
                    '12': 'bookworm',
                    '11': 'bullseye', 
                    '10': 'buster'
                }
                return version_map.get(version.split('.')[0], 'stable')
        except Exception:
            pass
            
        return 'stable'
    
    @classmethod
    def is_debian_based(cls) -> bool:
        """Verifica si el sistema está basado en Debian"""
        debian_files = [
            '/etc/debian_version',
            '/etc/apt/sources.list',
            '/usr/bin/dpkg'
        ]
        return any(os.path.exists(f) for f in debian_files)
    
    @classmethod
    def has_apt_support(cls) -> bool:
        """Verifica si el sistema tiene soporte APT"""
        return os.path.exists('/usr/bin/apt-get')
    
    @classmethod
    def get_system_architecture(cls) -> str:
        """Obtiene la arquitectura del sistema"""
        try:
            result = subprocess.run(['dpkg', '--print-architecture'],
                                  capture_output=True, text=True)
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return 'amd64'

class ConfigurationManager:
    """Gestiona archivos de configuración de la aplicación"""
    
    def __init__(self):
        self.config_dir = Path.home() / '.config' / 'soplos-repo-selector'
        self.config_file = self.config_dir / 'config.json'
        self.backup_dir = self.config_dir / 'backups'
        
        # Crear directorios si no existen
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        self._config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Carga la configuración desde el archivo"""
        default_config = {
            'version': '1.0.0',
            'language': '',
            'window': {
                'width': 800,
                'height': 600,
                'maximized': False
            },
            'repositories': {
                'check_fastest_on_startup': False,
                'auto_update_cache': True,
                'preferred_mirrors': []
            },
            'gpg': {
                'auto_download_keys': True,
                'verify_signatures': True
            },
            'advanced': {
                'debug_mode': False,
                'use_modern_format': True,
                'clean_cache_on_exit': True
            }
        }
        
        try:
            if self.config_file.exists():
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    # Fusionar con configuración por defecto
                    self._deep_update(default_config, loaded_config)
                    log_info(get_string("configuration_loaded", "Configuración cargada"))
                    return default_config
            else:
                log_info(get_string("configuration_loaded", "Configuración por defecto cargada"))
                return default_config
                
        except Exception as e:
            log_error(get_string("invalid_configuration", "Error al cargar configuración"), e)
            return default_config
    
    def _deep_update(self, target: Dict, source: Dict) -> None:
        """Actualiza un diccionario anidado con otro"""
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._deep_update(target[key], value)
            else:
                target[key] = value
    
    def save_config(self) -> bool:
        """Guarda la configuración actual al archivo"""
        try:
            # Crear backup antes de guardar
            self._create_backup()
            
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self._config, f, indent=2, ensure_ascii=False)
            
            log_info(get_string("configuration_saved", "Configuración guardada"))
            return True
            
        except Exception as e:
            log_error("Error al guardar configuración", e)
            return False
    
    def _create_backup(self) -> None:
        """Crea una copia de seguridad de la configuración actual"""
        if self.config_file.exists():
            try:
                import shutil
                import time
                
                timestamp = int(time.time())
                backup_file = self.backup_dir / f'config.{timestamp}.json'
                shutil.copy2(self.config_file, backup_file)
                
                # Mantener solo los últimos 5 backups
                backups = sorted(self.backup_dir.glob('config.*.json'))
                if len(backups) > 5:
                    for old_backup in backups[:-5]:
                        old_backup.unlink()
                
                log_info(get_string("backup_created", f"Copia de seguridad creada: {backup_file}"))
                
            except Exception as e:
                log_warning(f"No se pudo crear backup: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Obtiene un valor de configuración usando notación de punto"""
        keys = key.split('.')
        value = self._config
        
        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key: str, value: Any) -> None:
        """Establece un valor de configuración usando notación de punto"""
        keys = key.split('.')
        config = self._config
        
        # Navegar hasta el último nivel
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        # Establecer el valor
        config[keys[-1]] = value
    
    def reset_to_defaults(self) -> None:
        """Restablece la configuración a valores por defecto"""
        try:
            self._create_backup()
            self._config = self._load_config()
            log_info(get_string("reset_configuration", "Configuración restablecida a valores por defecto"))
        except Exception as e:
            log_error("Error al restablecer configuración", e)

# Instancia global para acceso fácil
config_manager = ConfigurationManager()
