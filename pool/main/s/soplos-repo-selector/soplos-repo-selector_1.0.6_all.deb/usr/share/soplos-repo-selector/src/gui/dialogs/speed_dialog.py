import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, GObject
import threading
import time
import requests
from urllib.parse import urlparse
import subprocess
import platform
import os
from src.i18n.strings import get_string

class RepoSpeedTester(GObject.GObject):
    """Clase para probar la velocidad de repositorios mediante descarga real"""
    
    __gsignals__ = {
        'test-completed': (GObject.SignalFlags.RUN_FIRST, None, (str, float, str, str)),
        'all-tests-completed': (GObject.SignalFlags.RUN_FIRST, None, (object,)),
        'progress-update': (GObject.SignalFlags.RUN_FIRST, None, (float, str))
    }
    
    def __init__(self):
        GObject.GObject.__init__(self)
        self.mirrors = self.get_all_mirrors()
        self.stop_requested = False
        self.results = []
    
    def get_all_mirrors(self):
        """Obtiene una lista completa de mirrors de Debian"""
        mirrors = [
            # Principales CDNs globales
            {'url': 'http://deb.debian.org/debian', 'country': get_string('country_global', get_string('global_cdn', 'CDN Global'))},
            {'url': 'http://cdn-aws.deb.debian.org/debian', 'country': get_string('country_global', get_string('global_aws', 'AWS Global'))},
            {'url': 'http://cloudfront.debian.net/debian', 'country': get_string('country_global', get_string('cloudfront', 'CloudFront'))},
            
            # Servidores oficiales por país
            {'url': 'http://ftp.us.debian.org/debian', 'country': get_string('country_usa', 'Estados Unidos')},
            {'url': 'http://ftp.uk.debian.org/debian', 'country': get_string('country_uk', 'Reino Unido')},
            {'url': 'http://ftp.de.debian.org/debian', 'country': get_string('country_germany', 'Alemania')},
            {'url': 'http://ftp.fr.debian.org/debian', 'country': get_string('country_france', 'Francia')},
            {'url': 'http://ftp.es.debian.org/debian', 'country': get_string('country_spain', 'España')},
            {'url': 'http://ftp.it.debian.org/debian', 'country': get_string('country_italy', 'Italia')},
            
            # Otros mirrors populares
            {'url': 'http://mirrors.kernel.org/debian', 'country': get_string('country_usa', 'Estados Unidos')},
            {'url': 'http://debian.mirrors.ovh.net/debian', 'country': get_string('country_france', 'Francia')},
            {'url': 'http://mirror.bytemark.co.uk/debian', 'country': get_string('country_uk', 'Reino Unido')}
        ]
        
        # Filtrar por continente si es posible detectar ubicación del usuario
        try:
            # Aquí se podría implementar detección de región automática
            pass
        except:
            pass
            
        return mirrors
    
    def test_mirror_speed(self, mirror_url):
        """
        Prueba de velocidad mediante descarga real de un archivo pequeño
        
        Este método descarga un archivo más grande (InRelease) para probar
        la velocidad real de descarga, no solo el ping.
        """
        try:
            # URL de un archivo más grande para medir mejor la velocidad
            # InRelease es mayor que Release.gpg y existe en todos los repos
            test_url = f"{mirror_url}/dists/stable/InRelease"
            
            # Configurar timeout y headers
            headers = {'User-Agent': 'Soplos-Repo-Selector/1.0'}
            
            start_time = time.time()
            
            # Realizar la descarga
            response = requests.get(test_url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                # Calcular tiempo que tomó la descarga
                download_time = time.time() - start_time
                content_size = len(response.content)
                
                # Para archivos pequeños, ajustar la calificación basada en tiempo de respuesta
                # en lugar de solo velocidad en MB/s
                if content_size < 102400:  # Menos de 100KB
                    if download_time <= 0.5:
                        speed_category = get_string('fast', 'fast')
                        # Estimación de velocidad simulada para clasificación consistente
                        speed_mbps = 1.0
                    elif download_time <= 1.0:
                        speed_category = get_string('medium', 'medium')
                        speed_mbps = 0.5
                    else:
                        speed_category = get_string('slow', 'slow')
                        speed_mbps = 0.1
                    
                    return speed_mbps, "success", speed_category
                else:
                    # Para archivos grandes, calcular velocidad real en MB/s
                    speed_mbps = (content_size / 1024 / 1024) / download_time if download_time > 0 else 0
                    
                    # Determinar categoría
                    if speed_mbps > 0.5:
                        speed_category = get_string('fast', 'fast')
                    elif speed_mbps > 0.1:
                        speed_category = get_string('medium', 'medium')
                    else:
                        speed_category = get_string('slow', 'slow')
                    
                    return speed_mbps, "success", speed_category
            else:
                return 0.0, "error", "error"
                
        except requests.exceptions.Timeout:
            return 0.0, "timeout", "timeout"
        except requests.exceptions.ConnectionError:
            return 0.0, "connection_error", "error"
        except Exception as e:
            print(f"Error probando {mirror_url}: {e}")
            return 0.0, "error", "error"
    
    def start_test(self, filter_country=None):
        """
        Iniciar pruebas en hilo separado
        
        Args:
            filter_country: Opcional. Si se especifica, solo prueba mirrors de ese país
        """
        self.stop_requested = False
        self.results = []
        
        # Filtrar por país si es necesario
        mirrors_to_test = self.mirrors
        if filter_country and filter_country != get_string('all_countries', 'Todos los países'):
            mirrors_to_test = [m for m in self.mirrors if m['country'] == filter_country]
            
        threading.Thread(target=self._run_tests, args=(mirrors_to_test,), daemon=True).start()
    
    def stop_test(self):
        """Detener pruebas"""
        self.stop_requested = True
    
    def _run_tests(self, mirrors_to_test):
        """Ejecutar todas las pruebas"""
        total_mirrors = len(mirrors_to_test)
        tested = 0
        
        for mirror in mirrors_to_test:
            if self.stop_requested:
                break
            
            url = mirror['url']
            country = mirror['country']
            
            # Informar progreso
            tested += 1
            progress = tested / total_mirrors
            GLib.idle_add(self.emit, 'progress-update', progress, 
                         get_string("testing_mirror", "Probando espejo {0}/{1}").format(tested, total_mirrors))
            
            # Realizar prueba con la nueva firma que devuelve también la categoría
            speed_mbps, status, category = self.test_mirror_speed(url)
            
            result = {
                'url': url,
                'country': country,
                'speed_mbps': speed_mbps,
                'status': status,
                'category': category
            }
            
            self.results.append(result)
            
            # Emitir señal de progreso con la categoría de velocidad
            GLib.idle_add(self.emit, 'test-completed', url, speed_mbps, status, category)
        
        # Ordenar por velocidad (mayor primero)
        self.results.sort(key=lambda x: x['speed_mbps'], reverse=True)
        
        # Emitir señal de finalización
        GLib.idle_add(self.emit, 'all-tests-completed', self.results)


class RepoSpeedDialog(Gtk.Dialog):
    """Diálogo simplificado para encontrar los repositorios más rápidos"""
    
    def __init__(self, parent, current_repos=None):
        super().__init__(
            title=get_string("find_fastest_repos", "Buscar Repositorios Más Rápidos"),
            transient_for=parent,
            flags=Gtk.DialogFlags.MODAL
        )
        
        self.set_default_size(750, 500)
        
        # Botones principales SIN mnemonics visibles por defecto
        self.add_button(get_string("cancel", "Cancelar"), Gtk.ResponseType.CANCEL)
        self.add_button(get_string("select", "Seleccionar"), Gtk.ResponseType.OK)
        self.set_default_response(Gtk.ResponseType.OK)
        
        # Almacenar repositorios actuales y crear tester
        self.current_repos = current_repos or []
        self.speed_tester = RepoSpeedTester()
        
        # Conectar señales
        self.speed_tester.connect('test-completed', self.on_test_completed)
        self.speed_tester.connect('all-tests-completed', self.on_all_tests_completed)
        self.speed_tester.connect('progress-update', self.on_progress_update)
        
        # Crear interfaz
        self._create_ui()
        
        # Mostrar todos los widgets
        self.show_all()
    
    def _create_ui(self):
        """Crea la interfaz simplificada del diálogo"""
        content = self.get_content_area()
        content.set_spacing(10)
        content.set_margin_top(15)
        content.set_margin_bottom(15)
        content.set_margin_start(15)
        content.set_margin_end(15)
        
        # Encabezado
        header_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        content.pack_start(header_box, False, False, 0)
        
        title_label = Gtk.Label()
        title_label.set_markup(f"<span size='large' weight='bold'>{get_string('speed_test_title', 'Test de Velocidad de Repositorios')}</span>")
        title_label.set_halign(Gtk.Align.START)
        header_box.pack_start(title_label, False, False, 0)
        
        desc_label = Gtk.Label()
        desc_label.set_markup(get_string('speed_test_desc', 'Esta herramienta encuentra los repositorios más rápidos según su ubicación.'))
        desc_label.set_halign(Gtk.Align.START)
        desc_label.set_line_wrap(True)
        header_box.pack_start(desc_label, False, False, 0)
        
        # Panel de control superior
        control_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        content.pack_start(control_box, False, False, 0)
        
        # Filtro de país
        country_label = Gtk.Label(label=get_string("country_filter", "Filtrar por país:"))
        control_box.pack_start(country_label, False, False, 0)
        
        self.country_combo = Gtk.ComboBoxText()
        self.country_combo.append_text(get_string("all_countries", "Todos los países"))
        
        # Obtener países únicos
        countries = sorted(set(mirror['country'] for mirror in self.speed_tester.mirrors))
        for country in countries:
            self.country_combo.append_text(country)
        
        self.country_combo.set_active(0)  # "Todos los países" por defecto
        control_box.pack_start(self.country_combo, False, True, 0)
        
        # Espaciador
        control_box.pack_start(Gtk.Box(), True, True, 0)
        
        # Botón de test CON mnemonic
        self.test_button = Gtk.Button.new_with_mnemonic(get_string("start_test", "▶ _Iniciar Test"))
        self.test_button.connect("clicked", self.on_test_clicked)
        control_box.pack_start(self.test_button, False, False, 0)
        
        # Barra de progreso
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_text(get_string("click_to_start", "Haga clic en 'Iniciar Test' para comenzar"))
        self.progress_bar.set_show_text(True)
        content.pack_start(self.progress_bar, False, False, 0)
        
        # Spinner
        self.spinner = Gtk.Spinner()
        control_box.pack_start(self.spinner, False, False, 0)
        
        # Lista de resultados
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        content.pack_start(scrolled, True, True, 0)
        
        # Modelo: Seleccionado, URL, País, Velocidad, Estado, Velocidad raw (para ordenar)
        self.store = Gtk.ListStore(bool, str, str, str, str, float)
        self.tree_view = Gtk.TreeView(model=self.store)
        
        # Columna de selección
        toggle_renderer = Gtk.CellRendererToggle()
        toggle_renderer.connect("toggled", self.on_repo_toggled)
        toggle_column = Gtk.TreeViewColumn(get_string("use", "Usar"), toggle_renderer, active=0)
        toggle_column.set_min_width(50)
        self.tree_view.append_column(toggle_column)
        
        # Columna de repositorio
        repo_renderer = Gtk.CellRendererText()
        repo_column = Gtk.TreeViewColumn(get_string("repository", "Repositorio"), repo_renderer, text=1)
        repo_column.set_min_width(300)
        repo_column.set_expand(True)
        repo_column.set_resizable(True)
        self.tree_view.append_column(repo_column)
        
        # Columna de país
        country_renderer = Gtk.CellRendererText()
        country_column = Gtk.TreeViewColumn(get_string("country", "País"), country_renderer, text=2)
        country_column.set_min_width(120)
        self.tree_view.append_column(country_column)
        
        # Columna de velocidad
        speed_renderer = Gtk.CellRendererText()
        speed_column = Gtk.TreeViewColumn(get_string("speed", "Velocidad"), speed_renderer, text=3)
        speed_column.set_min_width(100)
        self.tree_view.append_column(speed_column)
        
        # Columna de estado
        status_renderer = Gtk.CellRendererText()
        status_column = Gtk.TreeViewColumn(get_string("status", "Estado"), status_renderer, text=4)
        status_column.set_min_width(100)
        self.tree_view.append_column(status_column)
        
        scrolled.add(self.tree_view)
        
        # Etiqueta de información/estado
        self.info_label = Gtk.Label()
        self.info_label.set_markup(get_string('speed_test_help', '<i>Los repositorios se ordenarán por velocidad cuando complete el test</i>'))
        self.info_label.set_halign(Gtk.Align.START)
        content.pack_start(self.info_label, False, False, 0)
        
        # Panel de distribuciones
        self._create_distribution_panel(content)
        
        # Llenar la lista con los repositorios iniciales
        self._populate_initial_mirrors()
    
    def _create_distribution_panel(self, content):
        """Crea el panel de selección de distribuciones"""
        # Marco con etiqueta para las distribuciones
        dist_frame = Gtk.Frame(label=get_string("distributions", "Distribuciones a configurar"))
        content.pack_start(dist_frame, False, False, 5)
        
        dist_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        dist_box.set_margin_top(10)
        dist_box.set_margin_bottom(10)
        dist_box.set_margin_start(10)
        dist_box.set_margin_end(10)
        dist_frame.add(dist_box)
        
        # Descripción
        dist_desc = Gtk.Label()
        dist_desc.set_markup(get_string("dist_desc", "<i>Seleccione las distribuciones que desea configurar con los repositorios seleccionados:</i>"))
        dist_desc.set_halign(Gtk.Align.START)
        dist_box.pack_start(dist_desc, False, False, 0)
        
        # NUEVO: Panel de plantillas de distribución
        templates_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        dist_box.pack_start(templates_box, False, False, 5)
        
        template_label = Gtk.Label(label=get_string("dist_template", "Plantilla:"))
        templates_box.pack_start(template_label, False, False, 0)
        
        self.template_combo = Gtk.ComboBoxText()
        self.template_combo.append_text(get_string("custom_selection", "Selección personalizada"))
        self.template_combo.append_text(get_string("debian_stable_full", "Debian Stable (completo)"))
        self.template_combo.append_text(get_string("debian_testing_full", "Debian Testing/Trixie (completo)"))
        self.template_combo.append_text(get_string("debian_sid_full", "Debian Sid/Unstable (completo)"))
        self.template_combo.append_text(get_string("soplos_tyron", "Soplos Linux Tyron"))
        self.template_combo.set_active(0)
        self.template_combo.connect("changed", self.on_template_selected)
        templates_box.pack_start(self.template_combo, True, True, 0)
        
        apply_template_button = Gtk.Button.new_with_mnemonic(get_string("apply_template", "_Aplicar plantilla"))
        apply_template_button.connect("clicked", self.on_apply_template_clicked)
        templates_box.pack_start(apply_template_button, False, False, 0)
        
        # Separador
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        dist_box.pack_start(separator, False, False, 5)
        
        # Flow box para las distribuciones
        self.dist_flow = Gtk.FlowBox()
        self.dist_flow.set_selection_mode(Gtk.SelectionMode.NONE)
        self.dist_flow.set_max_children_per_line(4)
        self.dist_flow.set_column_spacing(10)
        self.dist_flow.set_row_spacing(10)
        self.dist_flow.set_homogeneous(False)
        dist_box.pack_start(self.dist_flow, False, False, 5)
        
        # Añadir más distribuciones comunes relevantes para Debian Testing/Trixie
        distributions = [
            ("stable", False),
            ("stable-updates", False),
            ("stable-security", False),
            ("stable-backports", False),
            ("testing", False),
            ("testing-updates", False),
            ("testing-security", False),
            ("testing-backports", False),
            ("testing-proposed-updates", False),
            ("unstable", False), 
            ("sid", False),
            ("experimental", False),
            ("trixie", False),
            ("trixie-updates", False),
            ("trixie-security", False),
            ("trixie-backports", False),
            ("bookworm", False),
            ("bookworm-updates", False),
            ("bookworm-security", False),
            ("bookworm-backports", False)
        ]
        
        # Intentar detectar versión actual
        try:
            current_version = subprocess.check_output(["lsb_release", "-cs"], universal_newlines=True).strip()
            # Validar si es una versión conocida
            known_versions = ["bookworm", "trixie", "sid", "testing"]
            if current_version in known_versions:
                distributions.insert(0, (current_version, True))
        except:
            pass
        
        # Crear checkboxes
        self.dist_checks = {}
        for dist, active in distributions:
            check = Gtk.CheckButton(label=dist)
            check.set_active(active)
            self.dist_flow.add(check)
            self.dist_checks[dist] = check

    def on_template_selected(self, combo):
        """Cuando se selecciona una plantilla, muestra información pero no la aplica aún"""
        template = combo.get_active_text()
        
        if template == get_string("debian_stable_full", "Debian Stable (completo)"):
            self.info_label.set_markup(get_string("template_info_stable", 
                "<i>Esta plantilla configurará: stable, stable-updates, stable-security y stable-backports</i>"))
        
        elif template == get_string("debian_testing_full", "Debian Testing/Trixie (completo)"):
            self.info_label.set_markup(get_string("template_info_testing", 
                "<i>Esta plantilla configurará las distribuciones testing (testing, testing-updates, etc.) y trixie (trixie, trixie-updates, etc.)</i>"))
        
        elif template == get_string("debian_sid_full", "Debian Sid/Unstable (completo)"):
            self.info_label.set_markup(get_string("template_info_sid", 
                "<i>Esta plantilla configurará: unstable (sid) y experimental</i>"))
        
        elif template == get_string("soplos_tyron", "Soplos Linux Tyron"):
            self.info_label.set_markup(get_string("template_info_soplos", 
                "<i>Esta plantilla configurará la distribución completa Soplos Linux Tyron (combinación híbrida de Testing y Trixie)</i>"))

    def on_apply_template_clicked(self, button):
        """Aplica la plantilla seleccionada"""
        template = self.template_combo.get_active_text()
        
        # Desactivar todas las distribuciones primero
        for check in self.dist_checks.values():
            check.set_active(False)
        
        # Aplicar la plantilla seleccionada
        if template == get_string("debian_stable_full", "Debian Stable (completo)"):
            for dist in ["stable", "stable-updates", "stable-security", "stable-backports"]:
                if dist in self.dist_checks:
                    self.dist_checks[dist].set_active(True)
        
        elif template == get_string("debian_testing_full", "Debian Testing/Trixie (completo)"):
            # CORREGIDO: Ahora incluye tanto las distribuciones testing como trixie
            for dist in [
                "testing", "testing-updates", "testing-security", 
                "testing-backports", "testing-proposed-updates",
                "trixie", "trixie-updates", "trixie-security", "trixie-backports"
            ]:
                if dist in self.dist_checks:
                    self.dist_checks[dist].set_active(True)
    
        elif template == get_string("debian_sid_full", "Debian Sid/Unstable (completo)"):
            for dist in ["unstable", "sid", "experimental"]:
                if dist in self.dist_checks:
                    self.dist_checks[dist].set_active(True)
        
        elif template == get_string("soplos_tyron", "Soplos Linux Tyron"):
            for dist in ["testing", "testing-updates", "testing-security", 
                        "testing-backports", "testing-proposed-updates", 
                        "trixie", "trixie-updates", "trixie-security"]:
                if dist in self.dist_checks:
                    self.dist_checks[dist].set_active(True)
        
        # Mostrar un mensaje más claro sobre lo que se ha seleccionado
        selected_count = sum(1 for check in self.dist_checks.values() if check.get_active())
        self.info_label.set_markup(get_string("template_applied", 
            f"<b>Plantilla aplicada</b>: Se han seleccionado {selected_count} distribuciones. " +
            "Ahora seleccione los repositorios y pulse 'Usar Seleccionados'"))

    def _populate_initial_mirrors(self):
        """Llena la lista con mirrors sin probar"""
        self.store.clear()
        
        # Filtrar por país si es necesario
        selected_country = self.country_combo.get_active_text()
        mirrors = self.speed_tester.mirrors
        
        if selected_country != get_string("all_countries", "Todos los países"):
            mirrors = [m for m in mirrors if m['country'] == selected_country]
        
        for mirror in mirrors:
            self.store.append([
                False,  # No seleccionado inicialmente
                mirror['url'],
                mirror['country'],
                get_string("not_tested", "No probado"),
                get_string("waiting_emoji", "⏳ Esperando"),
                0.0  # Velocidad raw (para ordenar)
            ])
    
    def on_test_clicked(self, button):
        """Controla el inicio/parada del test de velocidad"""
        if button.get_label() == get_string("start_test", "▶ Iniciar Test"):
            # Iniciar test
            selected_country = self.country_combo.get_active_text()
            
            button.set_label(get_string("stop_test", "⏹ Detener Test"))
            self.spinner.start()
            
            # Iniciar tests
            self._populate_initial_mirrors()  # Reiniciar la lista
            self.speed_tester.start_test(filter_country=selected_country)
            
        else:
            # Detener test
            button.set_label(get_string("start_test", "▶ Iniciar Test"))
            self.spinner.stop()
            self.speed_tester.stop_test()
            self.info_label.set_markup(get_string("test_stopped", "<i>Test detenido por el usuario</i>"))

    def on_progress_update(self, tester, fraction, message):
        """Actualiza la barra de progreso"""
        self.progress_bar.set_fraction(fraction)
        self.progress_bar.set_text(message)
    
    def on_test_completed(self, tester, url, speed, status, category=None):
        """Actualiza los resultados en la UI cuando se completa un test"""
        for row in self.store:
            if row[1] == url:
                # Formatear velocidad según el resultado
                if status == "success":
                    # Formatear velocidad mejor (usar KB/s si es muy lento)
                    if speed < 0.01:  # Menos de 0.01 MB/s (10 KB/s)
                        speed_text = f"{speed * 1024:.0f} {get_string('kb_per_second', 'KB/s')}"
                    else:
                        speed_text = f"{speed:.2f} {get_string('mb_per_second', 'MB/s')}"
                    
                    # Usar la categoría si está disponible, de lo contrario usar la lógica anterior
                    if category == get_string('fast', 'fast'):
                        status_text = get_string('excellent', '✅ Excelente')
                    elif category == get_string('medium', 'medium'):
                        status_text = get_string('good', '✓ Bueno')
                    else:
                        # Emojis visuales según velocidad (lógica anterior como fallback)
                        if speed > 0.5:  # Más de 0.5 MB/s
                            status_text = get_string('excellent', '✅ Excelente')
                        elif speed > 0.1:  # Más de 0.1 MB/s
                            status_text = get_string('good', '✓ Bueno')
                        elif speed > 0.05:  # Más de 50 KB/s
                            status_text = get_string('acceptable', '⚠️ Aceptable')
                        else:
                            status_text = get_string('very_slow', '🐢 Lento')
                elif status == "timeout":
                    speed_text = get_string("timeout", "Tiempo agotado")
                    status_text = get_string('timeout_emoji', '⏱️ Timeout')
                else:
                    speed_text = get_string("error", "Error")
                    status_text = get_string('error_emoji', '❌ Error')
                
                # Actualizar la fila
                row[3] = speed_text
                row[4] = status_text
                row[5] = speed
                break

    def on_all_tests_completed(self, tester, results):
        """Procesa la finalización de todos los tests"""
        self.test_button.set_label(get_string("start_test", "▶ Iniciar Test"))
        self.spinner.stop()
        
        # Ordenar resultados por velocidad
        self.store.clear()
        
        # Añadir resultados a la lista ordenados por velocidad
        for result in results:
            url = result['url']
            country = result['country']
            speed = result['speed_mbps']
            status = result['status']
            category = result.get('category', None)
            
            # Formatear velocidad y estado
            if status == "success":
                if speed < 0.01:
                    speed_text = f"{speed * 1024:.0f} {get_string('kb_per_second', 'KB/s')}"
                else:
                    speed_text = f"{speed:.2f} {get_string('mb_per_second', 'MB/s')}"
                if category == get_string('fast', 'fast'):
                    status_text = get_string('excellent', '✅ Excelente')
                elif category == get_string('medium', 'medium'):
                    status_text = get_string('good', '✓ Bueno')
                elif category == get_string('slow', 'slow'):
                    status_text = get_string('acceptable', '⚠️ Aceptable')
                else:
                    if speed > 0.5:
                        status_text = get_string('excellent', '✅ Excelente')
                    elif speed > 0.1:
                        status_text = get_string('good', '✓ Bueno')
                    elif speed > 0.05:
                        status_text = get_string('acceptable', '⚠️ Aceptable')
                    else:
                        status_text = get_string('very_slow', '🐢 Lento')
            elif status == "timeout":
                speed_text = get_string("timeout", "Tiempo agotado")
                status_text = get_string('timeout_emoji', '⏱️ Timeout')
                speed = 0
            else:
                speed_text = get_string("error", "Error")
                status_text = get_string('error_emoji', '❌ Error')
                speed = 0
            
            exists = any(url in repo for repo in self.current_repos)
            
            self.store.append([False, url, country, speed_text, status_text, speed])
        
        # Formatear mensaje final con estadísticas
        success_count = sum(1 for r in results if r['status'] == "success" and r['speed_mbps'] > 0)
        if success_count > 0:
            fastest = next((r for r in results if r['status'] == "success" and r['speed_mbps'] > 0), None)
            if fastest:
                self.progress_bar.set_fraction(1.0)
                self.progress_bar.set_text(
                    get_string("test_complete", "Test completo: {0}/{1} repositorios funcionando").format(
                        success_count, len(results)
                    )
                )
                self.info_label.set_markup(
                    f"{get_string('best_repository', '<b>Mejor repositorio:</b>')} {fastest['country']} ({fastest['speed_mbps']:.2f} {get_string('mb_per_second', 'MB/s')}) - {get_string('select_manually', '<i>Seleccione manualmente los repositorios que desee usar</i>')}"
                )
        else:
            self.info_label.set_markup(get_string("no_working_repos", "<span color='red'>No se encontró ningún repositorio funcional</span>"))

    def on_repo_toggled(self, cell, path):
        """Maneja la selección manual de repositorios"""
        row = self.store[path]
        row[0] = not row[0]
        
        # Actualizar el contador de seleccionados
        selected_count = sum(1 for row in self.store if row[0])
        if selected_count > 0:
            self.info_label.set_markup(get_string("selected_repos", "<b>Seleccionados {0} repositorios</b>").format(selected_count))
        else:
            self.info_label.set_markup(get_string("no_repos_selected", "<i>No hay repositorios seleccionados</i>"))

    def get_selected_repos(self):
        """Devuelve los repositorios seleccionados con sus distribuciones"""
        result = []
        
        # Obtener los repositorios seleccionados
        selected_repos = []
        for row in self.store:
            if row[0]:  # Si está seleccionado
                selected_repos.append(row[1])  # URL
        
        # Si no hay repositorios seleccionados, retornar lista vacía
        if not selected_repos:
            return []
        
        # Obtener distribuciones seleccionadas
        selected_dists = []
        for dist, check in self.dist_checks.items():
            if check.get_active():
                selected_dists.append(dist)
        
        # Si no hay distribuciones seleccionadas, usar stable por defecto
        if not selected_dists:
            selected_dists = [get_string('stable_default', 'stable')]
        
        # Crear una entrada para cada combinación de repo + distribución
        for url in selected_repos:
            for dist in selected_dists:
                # Configurar componentes según la distribución
                if dist == "experimental":
                    components = get_string('main_component', 'main')
                elif any(name in dist for name in ["bookworm", "trixie"]):
                    components = get_string('main_contrib_nonfree_firmware', 'main contrib non-free non-free-firmware')
                else:
                    components = get_string('main_contrib_nonfree', 'main contrib non-free')
                
                # Repositorios de seguridad tienen una URL especial
                actual_url = url
                if "security" in dist:
                    actual_url = get_string('security_url', 'https://security.debian.org/debian-security')
                
                # NUEVO: Detectar tipos de repositorios especiales para configuración avanzada
                repo_type = get_string('deb_type', 'deb')
                
                # Para Soplos Linux Tyron, usar configuración de tipos más avanzada
                if self.template_combo.get_active_text() == get_string("soplos_tyron", "Soplos Linux Tyron"):
                    # Agregar src para algunos repositorios
                    if any(name in dist for name in ["trixie", "sid", "unstable"]):
                        result.append({
                            'uri': actual_url,
                            'distribution': dist,
                            'components': components,
                            'type': get_string('deb_src_type', 'deb deb-src'),  # Tipo combinado para configuraciones híbridas
                            'signed_by': get_string('keyring_path', '/usr/share/keyrings/debian-archive-keyring.gpg')
                        })
                        continue  # Saltar a la siguiente iteración

                # Añadir el repositorio estándar
                result.append({
                    'uri': actual_url,
                    'distribution': dist,
                    'components': components,
                    'type': repo_type,
                    'signed_by': get_string('keyring_path', '/usr/share/keyrings/debian-archive-keyring.gpg')
                })
        
        return result