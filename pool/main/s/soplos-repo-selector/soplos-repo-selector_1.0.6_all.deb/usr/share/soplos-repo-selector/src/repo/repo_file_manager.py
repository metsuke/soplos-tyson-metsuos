"""
Gestor de archivos de repositorios APT (sources.list y formato DEB822)
"""

import os
import re
import tempfile
import shutil
import subprocess
from typing import List, Dict, Any, Optional
from pathlib import Path

from src.utils.error_handler import log_info, log_error, log_warning

class RepoFileManager:
    """Gestor para lectura y escritura de archivos de fuentes APT"""
    
    def __init__(self):
        self.comment_pattern = re.compile(r'^\s*#')
        self.deb_line_pattern = re.compile(
            r'^\s*(deb|deb-src)\s+(\[.*?\]\s+)?(\S+)\s+(\S+)\s*(.*?)\s*$'
        )
    
    def read_sources_file(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Lee un archivo de fuentes y devuelve lista de repositorios
        
        Args:
            file_path: Ruta del archivo a leer
            
        Returns:
            Lista de diccionarios con datos de repositorios
        """
        repos = []
        file_path_obj = Path(file_path)
        
        try:
            if not file_path_obj.exists():
                return repos
            
            content = file_path_obj.read_text(encoding='utf-8')
            
            # Determinar formato del archivo
            if file_path_obj.suffix == '.sources' or self._is_deb822_format(content):
                repos = self._parse_deb822_format(content, str(file_path_obj))
            else:
                repos = self._parse_legacy_format(content, str(file_path_obj))
            
            log_info(f"Leídos {len(repos)} repositorios de {file_path}")
            return repos
            
        except Exception as e:
            log_error(f"Error leyendo archivo {file_path}", e)
            return []
    
    def write_sources_file(self, file_path: str, repos: List[Dict[str, Any]]) -> bool:
        """
        Escribe repositorios a un archivo de fuentes
        
        Args:
            file_path: Ruta del archivo a escribir
            repos: Lista de repositorios a escribir
            
        Returns:
            True si se escribió correctamente
        """
        try:
            file_path_obj = Path(file_path)
            
            # Determinar formato basado en la extensión y configuración
            use_deb822 = (file_path_obj.suffix == '.sources' or 
                         any(r.get('format') == 'deb822' for r in repos))
            
            # Filtrar repositorios para este archivo
            file_repos = [r for r in repos if r.get('file') == file_path]
            
            if use_deb822:
                content = self._generate_deb822_content(file_repos)
            else:
                content = self._generate_legacy_content(file_repos)
            
            # Escribir de forma segura usando archivo temporal
            return self._write_file_safely(file_path, content)
            
        except Exception as e:
            log_error(f"Error escribiendo archivo {file_path}", e)
            return False
    
    def _is_deb822_format(self, content: str) -> bool:
        """Detecta si el contenido está en formato DEB822"""
        # Buscar patrones típicos de DEB822
        deb822_patterns = [
            re.compile(r'^\s*Types:\s*', re.MULTILINE),
            re.compile(r'^\s*URIs:\s*', re.MULTILINE),
            re.compile(r'^\s*Suites:\s*', re.MULTILINE),
            re.compile(r'^\s*Components:\s*', re.MULTILINE)
        ]
        
        return any(pattern.search(content) for pattern in deb822_patterns)
    
    def _parse_legacy_format(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """Parsea archivo en formato legacy (sources.list)"""
        repos = []
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Saltar líneas vacías y comentarios
            if not line or self.comment_pattern.match(line):
                continue
            
            # Verificar si la línea está deshabilitada
            disabled = False
            if line.startswith('# '):
                # Verificar si es una línea comentada que era un repo
                uncommented = line[2:].strip()
                if self.deb_line_pattern.match(uncommented):
                    line = uncommented
                    disabled = True
                else:
                    continue
            
            # Parsear línea de repositorio
            match = self.deb_line_pattern.match(line)
            if match:
                repo_type = match.group(1)
                options = match.group(2) or ''
                uri = match.group(3)
                distribution = match.group(4)
                components = match.group(5) or ''
                
                # Extraer opciones (ej: [arch=amd64])
                signed_by = ''
                if options:
                    signed_by_match = re.search(r'signed-by=([^\]]+)', options)
                    if signed_by_match:
                        signed_by = signed_by_match.group(1)
                
                repos.append({
                    'disabled': disabled,
                    'type': repo_type,
                    'uri': uri,
                    'distribution': distribution,
                    'components': components.strip(),
                    'comment': '',
                    'signed_by': signed_by,
                    'file': file_path,
                    'format': 'legacy',
                    'line': line_num
                })
        
        return repos
    
    def _parse_deb822_format(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """Parsea archivo en formato DEB822 (.sources)"""
        repos = []
        
        # Dividir en bloques (separados por líneas vacías)
        blocks = re.split(r'\n\s*\n', content.strip())
        
        for block_num, block in enumerate(blocks, 1):
            if not block.strip():
                continue
            
            # Verificar si el bloque está deshabilitado
            disabled = False
            if block.strip().startswith('#'):
                # Intentar descomentarlo para parsearlo
                lines = block.split('\n')
                uncommented_lines = []
                for line in lines:
                    if line.strip().startswith('#'):
                        uncommented_lines.append(line[1:])
                    else:
                        uncommented_lines.append(line)
                block = '\n'.join(uncommented_lines)
                disabled = True
            
            # Parsear campos del bloque
            fields = {}
            for line in block.split('\n'):
                line = line.strip()
                if ':' in line:
                    key, value = line.split(':', 1)
                    fields[key.strip().lower()] = value.strip()
            
            # Convertir a formato interno
            if 'types' in fields and 'uris' in fields and 'suites' in fields:
                repo_types = fields['types'].split()
                uris = fields['uris'].split()
                suites = fields['suites'].split()
                components = fields.get('components', '').strip()
                signed_by = fields.get('signed-by', '')
                
                # Crear entrada para cada combinación
                for repo_type in repo_types:
                    for uri in uris:
                        for suite in suites:
                            repos.append({
                                'disabled': disabled,
                                'type': repo_type,
                                'uri': uri,
                                'distribution': suite,
                                'components': components,
                                'comment': '',
                                'signed_by': signed_by,
                                'file': file_path,
                                'format': 'deb822',
                                'block': block_num
                            })
        
        return repos
    
    def _generate_legacy_content(self, repos: List[Dict[str, Any]]) -> str:
        """Genera contenido en formato legacy"""
        lines = []
        
        # Añadir encabezado
        lines.append("# Archivo generado por Soplos Repo Selector")
        lines.append("# No editar manualmente")
        lines.append("")
        
        for repo in repos:
            # Construir línea
            prefix = "# " if repo.get('disabled', False) else ""
            
            options = ""
            if repo.get('signed_by'):
                options = f"[signed-by={repo['signed_by']}] "
            
            line = f"{prefix}{repo['type']} {options}{repo['uri']} {repo['distribution']}"
            if repo.get('components'):
                line += f" {repo['components']}"
            
            # Añadir comentario si existe
            if repo.get('comment'):
                lines.append(repo['comment'])
            
            lines.append(line)
            lines.append("")  # Línea vacía
        
        return '\n'.join(lines)
    
    def _generate_deb822_content(self, repos: List[Dict[str, Any]]) -> str:
        """Genera contenido en formato DEB822"""
        lines = []
        
        # Añadir encabezado
        lines.append("# Archivo generado por Soplos Repo Selector")
        lines.append("# Formato DEB822")
        lines.append("")
        
        # Agrupar repositorios similares
        grouped_repos = self._group_similar_repos(repos)
        
        for group in grouped_repos:
            # Determinar si está deshabilitado
            disabled = any(r.get('disabled', False) for r in group)
            prefix = "# " if disabled else ""
            
            # Extraer campos comunes
            uris = list(set(r['uri'] for r in group))
            types = list(set(r['type'] for r in group))
            suites = list(set(r['distribution'] for r in group))
            components = list(set(r['components'] for r in group if r['components']))
            signed_by = next((r['signed_by'] for r in group if r.get('signed_by')), '')
            
            # Generar bloque DEB822
            if group[0].get('comment'):
                lines.append(group[0]['comment'])
            
            lines.append(f"{prefix}Types: {' '.join(types)}")
            lines.append(f"{prefix}URIs: {' '.join(uris)}")
            lines.append(f"{prefix}Suites: {' '.join(suites)}")
            
            if components:
                lines.append(f"{prefix}Components: {' '.join(components)}")
            
            if signed_by:
                lines.append(f"{prefix}Signed-By: {signed_by}")
            
            lines.append("")  # Separador entre bloques
        
        return '\n'.join(lines)
    
    def _group_similar_repos(self, repos: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
        """Agrupa repositorios similares para formato DEB822"""
        groups = []
        
        for repo in repos:
            # Buscar grupo compatible
            compatible_group = None
            for group in groups:
                if self._repos_compatible_for_grouping(repo, group[0]):
                    compatible_group = group
                    break
            
            if compatible_group:
                compatible_group.append(repo)
            else:
                groups.append([repo])
        
        return groups
    
    def _repos_compatible_for_grouping(self, repo1: Dict[str, Any], repo2: Dict[str, Any]) -> bool:
        """Verifica si dos repositorios pueden agruparse en DEB822"""
        # Mismo signed-by y mismo estado de habilitación
        return (repo1.get('signed_by') == repo2.get('signed_by') and
                repo1.get('disabled', False) == repo2.get('disabled', False))
    
    def _write_file_safely(self, file_path: str, content: str) -> bool:
        """Escribe archivo de forma segura usando archivo temporal"""
        try:
            file_path_obj = Path(file_path)
            
            # Crear directorio si no existe
            file_path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            # Escribir a archivo temporal primero
            temp_fd, temp_path = tempfile.mkstemp(
                suffix='.tmp',
                dir=str(file_path_obj.parent),
                text=True
            )
            
            try:
                with open(temp_fd, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                temp_path_obj = Path(temp_path)
                
                # Verificar que necesitamos privilegios
                if file_path_obj.exists():
                    # Preservar permisos del archivo original
                    stat_info = file_path_obj.stat()
                    temp_path_obj.chmod(stat_info.st_mode)
                else:
                    # Nuevos archivos: permisos estándar
                    temp_path_obj.chmod(0o644)
                
                # Mover archivo temporal al destino (operación atómica)
                if Path(file_path_obj.parent).is_dir() and os.access(str(file_path_obj.parent), os.W_OK):
                    # Tenemos permisos de escritura
                    shutil.move(temp_path, file_path)
                else:
                    # Necesitamos privilegios elevados
                    result = subprocess.run(
                        ['pkexec', 'mv', temp_path, file_path],
                        capture_output=True,
                        text=True
                    )
                    if result.returncode != 0:
                        error_msg = result.stderr.strip() if result.stderr else "Error desconocido"
                        raise PermissionError(f"No se pudieron obtener privilegios de administrador: {error_msg}")
                
                log_info(f"Archivo escrito correctamente: {file_path}")
                return True
                
            except Exception as e:
                # Limpiar archivo temporal si algo falla
                try:
                    Path(temp_path).unlink()
                except:
                    pass
                raise
                
        except Exception as e:
            log_error(f"Error escribiendo archivo {file_path}", e)
            return False

# Nota: Este módulo ahora es el único responsable de la lectura y escritura de archivos de repositorios.
# Todas las operaciones de parsing y escritura deben hacerse aquí, y ser usadas por RepoManager.
