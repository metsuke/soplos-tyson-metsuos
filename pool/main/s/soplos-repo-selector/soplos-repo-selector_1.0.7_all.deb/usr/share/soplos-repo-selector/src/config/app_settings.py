"""
Gestión de configuraciones y preferencias de usuario para la aplicación
"""
import os
import json
from typing import Any, Dict, Optional
import gi
from gi.repository import GLib

from src.utils.error_handler import ErrorHandler, log_error, log_warning
from src.utils.event_bus import EventBus, EVENT_SETTINGS_CHANGED

class AppSettings:
    """
    Gestiona las configuraciones de usuario de la aplicación.
    Implementa un patrón singleton para acceso global.
    """
    
    _instance = None
    
    # Valores predeterminados
    DEFAULT_SETTINGS = {
        # UI
        'window_width': 800,
        'window_height': 600,
        'window_maximized': False,
        'dark_theme': False,
        'show_tooltips': True,
        
        # Idiomas
        'language': '',  # Vacío significa usar el del sistema
        
        # Repositorios
        'check_fastest_mirrors': True,
        'show_backports': True,
        'predefined_repo_buttons': ['chrome', 'vscode', 'docker', 'obs'],
        
        # Aplicación
        'check_updates_on_startup': True,
        'auto_update_cache': False,
        'advanced_mode': False,
        'clean_pycache_on_exit': True,  # Nueva opción para limpiar __pycache__ al salir
        'avoid_bytecode': True          # Evitar creación de archivos .pyc
    }
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(AppSettings, cls).__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        """Inicializa las configuraciones"""
        # Determinar la ruta del archivo de configuración
        self.config_dir = os.path.join(
            GLib.get_user_config_dir(),
            'soplos-repo-selector'
        )
        
        self.config_file = os.path.join(self.config_dir, 'settings.json')
        
        # Crear directorio si no existe
        os.makedirs(self.config_dir, exist_ok=True)
        
        # Cargar configuraciones existentes o usar predeterminadas
        self.settings = self.DEFAULT_SETTINGS.copy()
        self._load_settings()
    
    def _load_settings(self):
        """Carga las configuraciones desde el archivo"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    saved_settings = json.load(f)
                    
                    # Actualizar sólo las claves existentes
                    for key, value in saved_settings.items():
                        if key in self.settings:
                            self.settings[key] = value
        except Exception as e:
            log_error(f"Error al cargar configuraciones: {e}", e)
    
    def save_settings(self):
        """Guarda las configuraciones actuales en el archivo"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=2)
        except Exception as e:
            log_error(f"Error al guardar configuraciones: {e}", e)
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Obtiene el valor de una configuración
        
        Args:
            key: Clave de la configuración
            default: Valor por defecto si no existe
            
        Returns:
            El valor de la configuración o el valor por defecto
        """
        return self.settings.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """
        Establece el valor de una configuración
        
        Args:
            key: Clave de la configuración
            value: Valor a establecer
        """
        if key in self.settings and self.settings[key] != value:
            old_value = self.settings[key]
            self.settings[key] = value
            
            # Guardar configuración
            self.save_settings()
            
            # Notificar cambio
            EventBus.publish(EVENT_SETTINGS_CHANGED, key, value, old_value)
    
    def reset(self, key: str = None) -> None:
        """
        Restablece una configuración a su valor predeterminado
        
        Args:
            key: Clave a restablecer o None para restablecer todas
        """
        if key is None:
            # Restablecer todas las configuraciones
            for k, v in self.DEFAULT_SETTINGS.items():
                if self.settings.get(k) != v:
                    self.set(k, v)
        elif key in self.DEFAULT_SETTINGS:
            # Restablecer sólo una configuración
            self.set(key, self.DEFAULT_SETTINGS[key])
    
    def get_window_size(self) -> tuple:
        """Obtiene el tamaño de ventana guardado"""
        return (self.get('window_width'), self.get('window_height'))
    
    def set_window_size(self, width: int, height: int) -> None:
        """Guarda el tamaño de la ventana"""
        self.set('window_width', width)
        self.set('window_height', height)
    
    def get_language(self) -> Optional[str]:
        """
        Obtiene el idioma configurado
        
        Returns:
            Código de idioma o None para usar el del sistema
        """
        lang = self.get('language')
        if not lang:
            return None
        return lang

# Instancia global para acceso fácil
settings = AppSettings()
