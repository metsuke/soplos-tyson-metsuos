# Soplos Repo Selector

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.7-green.svg)]()

Soplos Repo Selector es un gestor gráfico de repositorios APT diseñado específicamente para sistemas basados en Debian. Permite gestionar, optimizar y configurar repositorios de software de manera sencilla e intuitiva.


## 🆕 Historial de versiones

### 🆕 Novedades en la versión 1.0.7 (27 de julio de 2025)
- Cambio de icono del programa

### 🆕 Novedades en la versión 1.0.6 (16 de julio de 2025)
- Cumplimiento total del estándar AppStream/DEP11 en el metainfo
- Iconos añadidos en 48x48, 64x64 y 128x128 para integración con centros de software

### 🆕 Novedades en la versión 1.0.5 (14 de julio de 2025)
- Correcciones finales de metainfo para garantizar la aparición correcta en centros de software como Discover, GNOME Software y otros compatibles con AppStream.

### 🆕 Novedades en la versión 1.0.4 (13 de julio de 2025)
- Actualización de metainfo para mejor visibilidad y compatibilidad en Discover y AppStream.
- Corrección de referencias de screenshots: nombres de capturas consistentes y reales.

### 🆕 Novedades en la versión 1.0.3 (17 de junio de 2025)
- Detección mejorada de tema GTK específico leyendo configuración de KDE.
- Mejor integración con portal XDG y compatibilidad con Wayland.
- Compatibilidad con temas personalizados y respeto por la configuración del sistema.
- Reducción de tiempo de carga y uso de memoria.
- Corrección de problemas de colores y acentos naranjas.

### 🆕 Novedades en la versión 1.0.2 (15 de enero de 2025)
- Detección automática de tema del sistema (KDE y GNOME).
- Soporte mejorado para Wayland.
- Variables de entorno para temas configuradas automáticamente.
- Mejoras en la interfaz y rendimiento de inicio.
- Mejor gestión de errores y detección de idioma.

### 🆕 Novedades en la versión 1.0.1 (10 de enero de 2025)
- Soporte multiidioma completo (8 idiomas).
- Gestión de claves GPG y test de velocidad de repositorios.
- Repositorios predefinidos y mejor manejo de errores.

### 🆕 Novedades en la versión 1.0.0 (5 de enero de 2025)
- Lanzamiento inicial de Soplos Repo Selector.
- Gestión básica de repositorios APT y soporte para formato DEB822.
- Interfaz GTK 3 y compatibilidad Debian.

## Características principales

- **Gestión completa de repositorios**: Añadir, editar, eliminar y activar/desactivar repositorios APT
- **Soporte multiidioma**: Interfaz disponible en 8 idiomas (ES, EN, FR, PT, DE, IT, RU, RO)
- **Detección automática de tema**: Soporte para temas claros y oscuros
- **Búsqueda de repositorios rápidos**: Encuentra automáticamente los mirrors más rápidos
- **Gestión de claves GPG**: Importar, descargar y gestionar claves de verificación
- **Repositorios predefinidos**: Acceso rápido a repositorios populares (Chrome, VSCode, Docker, OBS)
- **Compatibilidad Wayland/X11**: Funciona perfectamente en ambos entornos
- **Plantillas de distribución**: Configuraciones preestablecidas para Debian Stable, Testing, Sid y Soplos

## Instalación

### Desde paquete DEB (recomendado)
```bash
sudo dpkg -i soplos-repo-selector_1.0.6_all.deb
sudo apt-get install -f  # Resolver dependencias si es necesario
```

### Desde código fuente
```bash
git clone https://github.com/SoplosLinux/soplos-repo-selector
cd soplos-repo-selector
sudo python3 setup.py install
```

## Dependencias

- **Python 3.8+**
- **GTK 3.0+**
- **GObject Introspection**
- **Python packages**: `python3-gi`, `python3-apt`, `python3-psutil`
- **Sistema**: `curl`, `wget`, `gnupg`, `pkexec`

## Uso básico

### Lanzar la aplicación
```bash
soplos-repo-selector
```

### Gestión de repositorios
1. **Añadir repositorio**: Botón "Añadir" o Ctrl+N
2. **Editar repositorio**: Seleccionar y "Editar" o Ctrl+E
3. **Eliminar repositorio**: Seleccionar y "Eliminar" o Delete
4. **Aplicar cambios**: Botón "Aplicar" o Ctrl+S

### Búsqueda de repositorios rápidos
1. Clic en "Buscar Repositorios Más Rápidos"
2. Seleccionar país/región (opcional)
3. Iniciar test de velocidad
4. Seleccionar repositorios deseados
5. Aplicar configuración

### Gestión de claves GPG
1. Ir a la pestaña "Claves GPG"
2. Importar desde archivo o descargar desde URL
3. Ver detalles y gestionar claves existentes

## Configuración avanzada

### Archivos de configuración
- **Configuración de usuario**: `~/.config/soplos-repo-selector/settings.json`
- **Repositorios del sistema**: `/etc/apt/sources.list.d/`
- **Claves GPG**: `/usr/share/keyrings/` y `/etc/apt/keyrings/`

### Variables de entorno
- `SOPLOS_REPO_SELECTOR_LANG`: Forzar idioma específico
- `GDK_BACKEND`: Backend gráfico (wayland, x11)
- `GTK_THEME`: Tema GTK específico

## Desarrollo

### Estructura del proyecto
```
