# Changelog

Todos los cambios notables de este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto adhiere a [Versionado Semántico](https://semver.org/lang/es/).

## [1.0.3] - 2025-06-17

### Añadido
- **Detección mejorada de tema GTK específico**: Lee directamente la configuración GTK de KDE
- **Respeto por configuración del sistema**: No fuerza temas específicos si no es necesario
- **Mejor integración con portal XDG**: Mejorada la compatibilidad con Wayland

### Mejorado
- **Compatibilidad con temas personalizados**: Ahora respeta colores y acentos personalizados
- **Detección de tema KDE**: Busca el tema GTK configurado en KDE en lugar de forzar Adwaita
- **Rendimiento de inicio**: Reducido tiempo de carga y uso de memoria
- **Integración con sistema**: Mejor respeto por la configuración de tema del usuario

### Corregido
- **Problema de colores azules**: Resuelto el forzado de tema Adwaita que causaba colores incorrectos
- **Compatibilidad con temas naranjas**: Ahora respeta correctamente los acentos naranjas de Soplos
- **Detección de tema en KDE**: Mejorada la lectura de `~/.config/kdeglobals`
- **Configuración GTK**: Evita sobrescribir configuraciones de tema del usuario

### Técnico
- **Refactorización de `detect_kde_theme()`**: Ahora busca configuración GTK específica en KDE
- **Lógica de aplicación de tema**: Solo aplica tema si se detecta uno específico
- **Mejor manejo de errores**: Gestión mejorada de archivos de configuración faltantes
- **Documentación**: Actualizada documentación sobre compatibilidad de temas

## [1.0.2] - 2025-01-15

### Añadido
- **Detección automática de tema del sistema**: Soporte para temas claros y oscuros en KDE y GNOME
- **Función `detect_kde_theme()`**: Detección específica de temas KDE leyendo `~/.config/kdeglobals`
- **Configuración automática de `GTK_THEME`**: Se aplica automáticamente según el tema detectado
- **Soporte mejorado para Wayland**: Mejor integración con compositores Wayland
- **Variables de entorno para temas**: `GDK_BACKEND`, `GTK_USE_PORTAL` configuradas automáticamente
- **Configuración previa del entorno**: Detección de tema antes de cargar GTK

### Mejorado
- **Interfaz de usuario**: Mejor adaptación a temas oscuros con colores naranjas de Soplos
- **Compatibilidad con KDE Plasma**: Detección precisa de esquemas de color Breeze/Breeze-Dark
- **Rendimiento de inicio**: Optimización en la carga inicial de la aplicación
- **Detección de idioma**: Mejorada la detección automática del idioma del sistema
- **Gestión de errores**: Mejor manejo de errores en la detección de temas

### Corregido
- **Tema azul no deseado**: Resuelto problema de tonos azules en tema oscuro
- **Inconsistencias de tema**: Ahora respeta correctamente el tema del sistema
- **Problemas de Wayland**: Mejor soporte y estabilidad en entornos Wayland
- **Configuración de iconos**: Mejorada la carga de iconos en diferentes temas

### Técnico
- **Refactorización de `main.py`**: Reorganización del código de inicialización
- **Nuevas funciones de detección**: `detect_kde_theme()` y `configure_environment_theme()`
- **Limpieza de código**: Eliminación de código redundante de detección de tema
- **Documentación**: Actualizada documentación técnica sobre detección de temas

## [1.0.1] - 2025-01-10

### Añadido
- **Soporte multiidioma completo**: 8 idiomas soportados (ES, EN, FR, PT, DE, IT, RU, RO)
- **Detección automática de idioma**: Basada en configuración del sistema
- **Gestión de claves GPG**: Importar, descargar y gestionar claves de verificación
- **Búsqueda de repositorios rápidos**: Test de velocidad para encontrar mirrors óptimos
- **Repositorios predefinidos**: Acceso rápido a Chrome, VSCode, Docker, OBS Studio

### Mejorado
- **Interfaz de usuario**: Diseño más intuitivo y responsive
- **Compatibilidad**: Mejor soporte para Wayland y X11
- **Rendimiento**: Optimización en la carga de repositorios
- **Gestión de errores**: Sistema mejorado de manejo de errores

### Corregido
- **Problemas de permisos**: Mejor manejo de sudo/pkexec
- **Validación de repositorios**: Verificación mejorada de sintaxis
- **Estabilidad**: Corrección de crashes ocasionales

## [1.0.0] - 2025-01-05

### Añadido
- **Lanzamiento inicial** de Soplos Repo Selector
- **Gestión básica de repositorios**: Añadir, editar, eliminar repositorios APT
- **Soporte para formato DEB822**: Compatibilidad con formato moderno de repositorios
- **Interfaz GTK 3**: Interfaz gráfica nativa y responsive
- **Aplicación de cambios**: Sistema seguro para aplicar configuraciones
- **Compatibilidad Debian**: Soporte completo para sistemas basados en Debian

### Características principales
- Gestión completa de `/etc/apt/sources.list.d/`
- Interfaz intuitiva para usuarios novatos y avanzados
- Validación automática de sintaxis de repositorios
- Sistema de backup automático de configuraciones
- Integración con pkexec para operaciones administrativas

---

## Tipos de cambios
- **Añadido** para nuevas características
- **Mejorado** para cambios en características existentes
- **Obsoleto** para características que se eliminarán pronto
- **Eliminado** para características eliminadas
- **Corregido** para corrección de errores
- **Seguridad** para vulnerabilidades

## Enlaces
- [1.0.3]: https://github.com/SoplosLinux/soplos-repo-selector/compare/v1.0.2...v1.0.3
- [1.0.2]: https://github.com/SoplosLinux/soplos-repo-selector/compare/v1.0.1...v1.0.2
- [1.0.1]: https://github.com/SoplosLinux/soplos-repo-selector/compare/v1.0.0...v1.0.1
- [1.0.0]: https://github.com/SoplosLinux/soplos-repo-selector/releases/tag/v1.0.0
