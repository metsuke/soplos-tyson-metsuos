"""
Sistema de eventos para comunicación entre componentes
"""
from typing import Dict, List, Callable

# Constantes de eventos
EVENT_SETTINGS_CHANGED = "settings_changed"

class EventBus:
    """Bus de eventos simple para comunicación entre componentes"""
    
    _subscribers: Dict[str, List[Callable]] = {}
    
    @classmethod
    def subscribe(cls, event_type: str, callback: Callable):
        """Suscribirse a un tipo de evento"""
        if event_type not in cls._subscribers:
            cls._subscribers[event_type] = []
        cls._subscribers[event_type].append(callback)
    
    @classmethod
    def publish(cls, event_type: str, *args, **kwargs):
        """Publicar un evento"""
        if event_type in cls._subscribers:
            for callback in cls._subscribers[event_type]:
                try:
                    callback(*args, **kwargs)
                except Exception as e:
                    print(f"Error in event callback: {e}")
