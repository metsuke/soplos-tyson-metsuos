#!/usr/bin/env python3
"""
Setup script para Soplos Repo Selector
"""

from setuptools import setup, find_packages
import os

# Leer el README
def read_readme():
    with open("README.md", "r", encoding="utf-8") as f:
        return f.read()

# Leer los requirements
def read_requirements():
    with open("requirements.txt", "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip() and not line.startswith("#")]

setup(
    name="soplos-repo-selector",
    version="1.0.0",
    author="Soplos Linux Team",
    author_email="soporte@soploslinux.com",
    description="Gestor gráfico de repositorios APT para sistemas basados en Debian",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://soploslinux.com",
    project_urls={
        "Bug Reports": "https://github.com/SoplosLinux/tyron/issues",
        "Source": "https://github.com/SoplosLinux/tyron",
        "Documentation": "https://soploslinux.com"
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: System Administrators",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: System :: Software Distribution",
        "Topic :: System :: Systems Administration",
        "Topic :: Utilities",
        "Environment :: X11 Applications :: GTK",
    ],
    python_requires=">=3.9",
    install_requires=read_requirements(),
    entry_points={
        "console_scripts": [
            "soplos-repo-selector=main:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.py", "*.json", "*.md", "*.txt"],
        "assets": ["*"],
        "debian": ["*"],
        "src": ["**/*.py"],
    },
    data_files=[
        ("share/applications", ["assets/com.soplos.reposelector.desktop"]),
        ("share/metainfo", ["debian/com.soplos.reposelector.metainfo.xml"]),
        ("share/icons/hicolor/scalable/apps", ["assets/icons/com.soplos.reposelector.svg"]),
        ("share/icons/hicolor/256x256/apps", ["assets/icons/com.soplos.reposelector.png"]),
    ],
    zip_safe=False,
)
