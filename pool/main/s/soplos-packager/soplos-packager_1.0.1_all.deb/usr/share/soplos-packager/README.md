# Soplos Packager

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

[![Version](https://img.shields.io/badge/version-1.0.1-green.svg)]()

Empaquetador de aplicaciones Python para sistemas basados en Debian.

*Python application packager for Debian-based systems*

## 📝 Descripción

Una herramienta gráfica para crear paquetes Debian desde aplicaciones Python con detección automática de dependencias e integración con el escritorio.

## ✨ Características

- 📦 Creación visual de paquetes .deb
- 🔍 Detección automática de dependencias
- 🖼️ Integración de iconos y .desktop
- 👁️ Vista previa del paquete
- 🌍 Soporte multiidioma
- ✅ Validación en tiempo real

## 📸 Capturas de pantalla

### Ventana principal de Soplos Packager
![Main window of Soplos Packager](https://raw.githubusercontent.com/SoplosLinux/tyron/refs/heads/main/media/soplos-packager/screenshots/screenshot1.png)

### Vista previa y dependencias
![Package preview and dependencies](https://raw.githubusercontent.com/SoplosLinux/tyron/refs/heads/main/media/soplos-packager/screenshots/screenshot2.png)

## 🛠️ Requisitos
- Python 3.8+
- GTK 3.0
- dpkg-dev
- policykit-1

## 📥 Instalación
```bash
# Dependencias
sudo apt install python3-gi python3-xlib gir1.2-gtk-3.0 dpkg-dev policykit-1 python3-dev libgtk-3-0

# Instalación
sudo pip3 install .
```

## 🌐 Idiomas soportados

- Español
- Inglés
- Francés
- Portugués
- Alemán
- Italiano
- Ruso
- Rumano

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos Linux](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)

## 📦 Versiones

### v1.0.1 (15/07/2025)
- Lectura automática de versión y descripción desde metainfo.xml.
- Soporte para iconos multi-resolución (48x48, 64x64, 128x128) en el empaquetado.
- Memoria de la última carpeta de proyecto y de salida usadas.
- Advertencia y confirmación antes de sobrescribir un .deb existente.
- Mejoras de usabilidad en los diálogos de selección de carpetas.

### v1.0.0 (08/05/2025)
- Versión inicial de lanzamiento
- GUI para crear paquetes Debian
- Detección automática de dependencias 
- Integración de archivos desktop e iconos
- Soporte multilenguaje