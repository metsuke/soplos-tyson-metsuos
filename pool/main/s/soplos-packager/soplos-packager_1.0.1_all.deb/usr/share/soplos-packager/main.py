import gi
import os
import shutil
import sys
import atexit
from pathlib import Path

# Definir las constantes de identificación de manera consistente
APP_ID = "com.soplos.packager"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

# Importaciones de biblioteca
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

def setup_application():
    """Configura los parámetros de la aplicación"""
    # Establecer identificadores de aplicación globales
    GLib.set_prgname(APP_ID)
    GLib.set_application_name("Soplos Packager")  # Nombre legible para humanos

    # Establecer icono predeterminado para todas las ventanas
    try:
        Gtk.Window.set_default_icon_name(APP_ID)
    except:
        pass

    # Configuración para asegurar que GDK use el WMCLASS correcto
    try:
        if hasattr(Gdk, 'set_program_class'):
            Gdk.set_program_class(WMCLASS)
    except:
        pass

    # Deshabilitar warnings de accesibilidad
    os.environ['NO_AT_BRIDGE'] = '1'

from gi.repository import Gio, GdkPixbuf
from src.gui.window import MainWindow

def clean_pycache_files(verbose=False):
    """Limpia los archivos __pycache__ de manera más exhaustiva y silenciosa"""
    try:
        # Usar una ruta absoluta fija en lugar de depender de __file__
        base_dir = "/usr/local/bin/soplos-packager"
        if not os.path.exists(base_dir):
            # Intentar obtener la ruta del script actual si no se encuentra la ruta fija
            try:
                base_dir = os.path.dirname(os.path.abspath(__file__))
            except NameError:
                # Si __file__ no está disponible (como en atexit), usar el directorio de trabajo actual
                base_dir = os.getcwd()
    
        # Primera pasada: intentar eliminar directorios completos de manera silenciosa
        for root, dirs, _ in os.walk(base_dir):
            for d in dirs:
                if d == "__pycache__":
                    path = os.path.join(root, d)
                    try:
                        shutil.rmtree(path, ignore_errors=True)
                        if verbose:
                            print(f"Eliminado directorio: {path}")
                    except Exception:
                        pass  # Ignorar errores silenciosamente
    
        # Segunda pasada: eliminar archivos .pyc individualmente por si quedan algunos
        for root, _, files in os.walk(base_dir):
            for file in files:
                if file.endswith('.pyc') or file.endswith('.pyo'):
                    try:
                        path = os.path.join(root, file)
                        os.remove(path)
                        if verbose:
                            print(f"Eliminado archivo: {path}")
                    except Exception:
                        pass  # Ignorar errores silenciosamente
    except Exception:
        pass  # Capturar cualquier error en la función completa para asegurar ejecución silenciosa

# Registrar limpieza al salir - con verbose=False para no mostrar mensajes
atexit.register(lambda: clean_pycache_files(verbose=False))

# Limpiar al inicio también - con verbose=False para no mostrar mensajes
clean_pycache_files(verbose=False)

class SoplosPackager(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                        flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        window = MainWindow(application=self)
        
        # Establecer el WM_CLASS explícitamente
        window.set_wmclass(WMCLASS, WMCLASS)
        
        # Establecer el icono de la aplicación
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                # Intentar cargar el icono por nombre - debe coincidir con .desktop
                icon = icon_theme.load_icon(APP_ID, 128, 0)
                window.set_icon(icon)
            except:
                # Fallar a la ruta del archivo - ASEGURARSE de usar com.soplos.packager.png
                icon_path = os.path.join(os.path.dirname(__file__), 'assets/icons/com.soplos.packager.png')
                if os.path.exists(icon_path):
                    icon = GdkPixbuf.Pixbuf.new_from_file(icon_path)
                    window.set_icon(icon)
                    Gtk.Window.set_default_icon(icon)
        except Exception as e:
            print(f"Error al cargar el icono: {e}")
            
        # Forzar actualización de propiedades de ventana antes de mostrar
        window.realize()

        # Conectar la señal delete-event
        window.connect('delete-event', self.on_window_delete)
        window.show_all()

    def on_window_delete(self, widget, event):
        dialog = Gtk.MessageDialog(
            transient_for=widget,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text="¿Estás seguro de que quieres cerrar la aplicación?"
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            return False  # Proceder con el cierre
        return True  # Cancelar el cierre

def main():
    """Entry point for the application"""
    import locale
    
    # Configurar la aplicación una sola vez
    setup_application()
    
    try:
        # Usar setlocale() en lugar de getdefaultlocale()
        locale.setlocale(locale.LC_ALL, '')
        current_lang = locale.getlocale()[0]
        if current_lang:
            lang = current_lang.split('_')[0]
        else:
            lang = 'en'
    except locale.Error:
        lang = 'en'
    
    os.environ['LANGUAGE'] = lang
    os.environ['LANG'] = f"{lang}.UTF-8"
    
    # Limpiar __pycache__ al inicio
    clean_pycache_files()
    
    app = SoplosPackager()
    return app.run(None)

if __name__ == '__main__':
    main()