import pkg_resources
import subprocess
import sys
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

class DependencyChecker:
    REQUIRED_PACKAGES = {
        'python': {
            'PyGObject': '3.0.0',
            'python-gi': '3.0',
            'python-xlib': '0.20',
            'setuptools': '40.0',
            'wheel': '0.30',
        },
        'system': {
            'python3-gi': None,
            'python3-xlib': None,
            'gir1.2-gtk-3.0': None,
            'python3-setuptools': None,
            'python3-wheel': None,
            'dpkg-dev': None,
            'policykit-1': None,
            'make': None,
            'gcc': None,
            'python3-dev': None,
            'libgtk-3-0': None,
        }
    }

    def __init__(self):
        self.missing_deps = []
        self.missing_system_deps = []

    def check_python_packages(self):
        """Verifica las dependencias de Python"""
        for package, version in self.REQUIRED_PACKAGES['python'].items():
            try:
                pkg_resources.require(f"{package}>={version}")
            except (pkg_resources.DistributionNotFound, pkg_resources.VersionConflict):
                self.missing_deps.append(f"{package}>={version}")

    def check_system_packages(self):
        """Verifica las dependencias del sistema"""
        for package in self.REQUIRED_PACKAGES['system'].values():
            try:
                result = subprocess.run(['dpkg', '-s', package], 
                                     stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE)
                if result.returncode != 0:
                    self.missing_system_deps.append(package)
            except Exception:
                self.missing_system_deps.append(package)

    def install_missing_dependencies(self, parent_window=None):
        """Instala las dependencias faltantes"""
        if not self.missing_deps and not self.missing_system_deps:
            return True

        message = "Se encontraron dependencias faltantes:\n\n"
        if self.missing_deps:
            message += "Python packages:\n"
            message += "\n".join(f"• {dep}" for dep in self.missing_deps)
            message += "\n\n"
            
        if self.missing_system_deps:
            message += "System packages:\n"
            message += "\n".join(f"• {dep}" for dep in self.missing_system_deps)
            
        message += "\n\n¿Desea instalar las dependencias faltantes?"

        dialog = Gtk.MessageDialog(
            transient_for=parent_window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=message
        )
        
        response = dialog.run()
        dialog.destroy()

        if response == Gtk.ResponseType.YES:
            if self.missing_deps:
                try:
                    subprocess.check_call([sys.executable, '-m', 'pip', 'install'] + self.missing_deps)
                except subprocess.CalledProcessError:
                    return False

            if self.missing_system_deps:
                try:
                    subprocess.check_call(['pkexec', 'apt-get', 'install', '-y'] + self.missing_system_deps)
                except subprocess.CalledProcessError:
                    return False
                    
            return True
            
        return False

def check_dependencies(parent_window=None):
    """Función de utilidad para verificar e instalar dependencias"""
    checker = DependencyChecker()
    checker.check_python_packages()
    checker.check_system_packages()
    
    if checker.missing_deps or checker.missing_system_deps:
        return checker.install_missing_dependencies(parent_window)
    return True
