import os
import re

class DependencyAnalyzer:
    def __init__(self, project_path):
        self.project_path = project_path
        
    def analyze(self):
        """Analiza el proyecto y retorna una lista de dependencias"""
        dependencies = set()
        
        # 1. Primero buscar en debian/control
        control_path = os.path.join(self.project_path, 'debian/control')
        if os.path.exists(control_path):
            dependencies.update(self._analyze_debian_control(control_path))
            # Si encontramos debian/control, usamos esas dependencias y paramos
            return sorted(list(dependencies))
            
        # 2. Buscar en requirements.txt
        req_path = os.path.join(self.project_path, 'requirements.txt')
        if os.path.exists(req_path):
            dependencies.update(self._analyze_requirements_txt(req_path))
            
        # 3. Si es proyecto Python, buscar en setup.py
        setup_path = os.path.join(self.project_path, 'setup.py')
        if os.path.exists(setup_path):
            dependencies.update(self._analyze_setup_py(setup_path))
            
        return sorted(list(dependencies))

    def _analyze_debian_control(self, control_path):
        """Analiza el archivo debian/control"""
        dependencies = set()
        try:
            with open(control_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Buscar todas las secciones Depends
            depends_matches = re.finditer(r'Depends:\s*(.*?)(?:\n\n|\n[^\s]|\Z)', content, re.DOTALL)
            for match in depends_matches:
                deps_section = match.group(1)
                # Unir líneas que estén indentadas (continuación)
                deps_section = re.sub(r'\n\s+', ' ', deps_section)
                
                # Procesar cada dependencia
                for dep in deps_section.split(','):
                    dep = dep.strip()
                    if dep and not dep.startswith('${'):
                        # Si hay alternativas (|), tomar todo el grupo
                        if '|' in dep:
                            dependencies.add(dep)
                        else:
                            # Limpiar versiones pero mantener el nombre del paquete
                            dep_name = dep.split('(')[0].strip()
                            dependencies.add(dep_name)
                            
        except Exception as e:
            print(f"Error analizando debian/control: {e}")
        return dependencies

    def _analyze_requirements_txt(self, req_path):
        """Analiza requirements.txt"""
        dependencies = set()
        try:
            with open(req_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        dependencies.add(line)
        except Exception as e:
            print(f"Error analizando requirements.txt: {e}")
        return dependencies

    def _analyze_setup_py(self, setup_path):
        """Analiza setup.py"""
        dependencies = set()
        try:
            with open(setup_path, 'r', encoding='utf-8') as f:
                content = f.read()
                # Buscar install_requires
                match = re.search(r'install_requires\s*=\s*\[(.*?)\]', content, re.DOTALL)
                if match:
                    deps = match.group(1)
                    # Procesar cada línea
                    for line in deps.split('\n'):
                        line = line.strip().strip(',').strip('"\'')
                        if line and not line.startswith('#'):
                            dependencies.add(line)
        except Exception as e:
            print(f"Error analizando setup.py: {e}")
        return dependencies