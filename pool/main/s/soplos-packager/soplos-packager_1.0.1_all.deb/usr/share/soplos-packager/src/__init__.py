"""Módulo principal"""

# Este archivo puede estar vacío, solo necesita existir
