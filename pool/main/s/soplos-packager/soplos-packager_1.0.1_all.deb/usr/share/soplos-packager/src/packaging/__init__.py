"""Módulo de empaquetado"""

# Este archivo puede estar vacío, solo necesita existir
