import os
import re
import xml.etree.ElementTree as ET

class IdValidator:
    """Clase para validar IDs en archivos de aplicación"""
    
    def __init__(self, app_name, app_id=None):
        """
        Inicializa el validador de IDs
        
        Args:
            app_name (str): Nombre base de la aplicación (ej: 'soplos-docklike')
            app_id (str): ID completo de la aplicación (ej: 'com.soplos.docklike')
        """
        self.app_name = app_name
        self.app_id = app_id
        
    def verify_desktop_file(self, desktop_path):
        """Valida un archivo .desktop"""
        if not os.path.exists(desktop_path):
            return {'valid': False, 'error': f"No existe el archivo: {desktop_path}"}
            
        # Leer el archivo
        with open(desktop_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        issues = []
        
        # Si se especificó un app_id, verificar que el archivo lo use
        if self.app_id:
            if f'X-GNOME-Application-ID={self.app_id}' not in content:
                issues.append(f"X-GNOME-Application-ID no coincide con {self.app_id}")
                
            if f'StartupWMClass={self.app_id}' not in content:
                issues.append(f"StartupWMClass no coincide con {self.app_id}")
                
            if f'Icon={self.app_id}' not in content:
                issues.append(f"Icon no coincide con {self.app_id}")
                
        # Verificar campos necesarios generales
        if 'StartupNotify=' not in content:
            issues.append("Falta StartupNotify=true")
            
        # Verificar que Exec incluye %U para mejor compatibilidad con lanzadores
        if re.search(r'Exec=.*[^%]$', content):
            issues.append("Exec no incluye parámetros de archivo (%U)")
            
        return {
            'valid': len(issues) == 0,
            'issues': issues
        }
    
    def verify_metainfo_file(self, metainfo_path):
        """Valida un archivo metainfo.xml"""
        if not os.path.exists(metainfo_path):
            return {'valid': False, 'error': f"No existe el archivo: {metainfo_path}"}
            
        try:
            tree = ET.parse(metainfo_path)
            root = tree.getroot()
            
            issues = []
            
            # Verificar que component type sea desktop-application
            if root.get('type') != 'desktop-application':
                issues.append("El tipo de componente no es desktop-application")
            
            # Verificar el ID del componente si se especificó uno
            id_elem = root.find('id')
            if id_elem is not None and self.app_id:
                if id_elem.text != self.app_id:
                    issues.append(f"El ID '{id_elem.text}' no coincide con '{self.app_id}'")
            
            # Verificar launchable desktop-id
            launchable_found = False
            for launchable in root.findall('./launchable[@type="desktop-id"]'):
                launchable_found = True
                if self.app_id and launchable.text != f"{self.app_id}.desktop":
                    issues.append(f"El launchable '{launchable.text}' no coincide con '{self.app_id}.desktop'")
                    
            if not launchable_found:
                issues.append("Falta el elemento launchable type='desktop-id'")
                
            # Verificar que existe un campo provides/binary
            binary_found = False
            provides = root.find('provides')
            if provides is not None:
                for binary in provides.findall('binary'):
                    binary_found = True
                    break
                    
            if not binary_found:
                issues.append("Falta el elemento binary dentro de provides")
                
            # Verificar que hay un campo content_rating
            content_rating = root.find('content_rating')
            if content_rating is None:
                issues.append("Falta el elemento content_rating")
                
            return {
                'valid': len(issues) == 0,
                'issues': issues
            }
                
        except Exception as e:
            return {'valid': False, 'error': str(e)}
    
    def verify_icon_files(self, icon_dirs):
        """
        Verifica que los iconos existen con el nombre correcto
        
        Args:
            icon_dirs (list): Lista de rutas a directorios de iconos
        """
        if not self.app_id:
            return {'valid': True, 'message': "No se especificó app_id para verificación"}
            
        issues = []
        found_icons = []
            
        for icon_dir in icon_dirs:
            if not os.path.isdir(icon_dir):
                continue
                
            for file in os.listdir(icon_dir):
                # Verificar si existe un icono con el nombre del app_id
                if file.startswith(f"{self.app_id}."):
                    found_icons.append(os.path.join(icon_dir, file))
                        
        if not found_icons:
            issues.append(f"No se encontraron iconos con el nombre {self.app_id}.*")
            
        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'found_icons': found_icons
        }
    
    def verify_all(self, install_dir):
        """
        Verifica la consistencia de todos los IDs en el directorio de instalación
        
        Args:
            install_dir (str): Directorio donde están instalados los archivos
        """
        results = {
            'valid': True,
            'desktop_file': None,
            'metainfo_file': None,
            'icons': None,
            'issues': []
        }
        
        # Buscar y verificar archivos .desktop
        desktop_files = []
        desktop_dir = os.path.join(install_dir, "usr/share/applications")
        if os.path.isdir(desktop_dir):
            for file in os.listdir(desktop_dir):
                if file.endswith(".desktop"):
                    desktop_files.append(os.path.join(desktop_dir, file))
                    
            if desktop_files:
                # Verificar el primer .desktop encontrado
                results['desktop_file'] = self.verify_desktop_file(desktop_files[0])
                if not results['desktop_file']['valid']:
                    results['valid'] = False
                    if 'issues' in results['desktop_file']:
                        results['issues'].extend([f"Desktop: {i}" for i in results['desktop_file']['issues']])
                    elif 'error' in results['desktop_file']:
                        results['issues'].append(f"Desktop Error: {results['desktop_file']['error']}")
            else:
                results['valid'] = False
                results['issues'].append("No se encontró ningún archivo .desktop")
        
        # Buscar y verificar archivos metainfo
        metainfo_files = []
        metainfo_dir = os.path.join(install_dir, "usr/share/metainfo")
        if os.path.isdir(metainfo_dir):
            for file in os.listdir(metainfo_dir):
                if file.endswith(".metainfo.xml") or file.endswith(".appdata.xml"):
                    metainfo_files.append(os.path.join(metainfo_dir, file))
                    
            if metainfo_files:
                # Verificar el primer metainfo encontrado
                results['metainfo_file'] = self.verify_metainfo_file(metainfo_files[0])
                if not results['metainfo_file']['valid']:
                    results['valid'] = False
                    if 'issues' in results['metainfo_file']:
                        results['issues'].extend([f"Metainfo: {i}" for i in results['metainfo_file']['issues']])
                    elif 'error' in results['metainfo_file']:
                        results['issues'].append(f"Metainfo Error: {results['metainfo_file']['error']}")
            else:
                results['valid'] = False
                results['issues'].append("No se encontró ningún archivo metainfo.xml")
        
        # Buscar y verificar iconos
        icon_dirs = []
        hicolor_dir = os.path.join(install_dir, "usr/share/icons/hicolor")
        if os.path.isdir(hicolor_dir):
            for size_dir in os.listdir(hicolor_dir):
                apps_dir = os.path.join(hicolor_dir, size_dir, "apps")
                if os.path.isdir(apps_dir):
                    icon_dirs.append(apps_dir)
        
        pixmaps_dir = os.path.join(install_dir, "usr/share/pixmaps")
        if os.path.isdir(pixmaps_dir):
            icon_dirs.append(pixmaps_dir)
            
        if icon_dirs:
            results['icons'] = self.verify_icon_files(icon_dirs)
            if not results['icons']['valid']:
                results['valid'] = False
                if 'issues' in results['icons']:
                    results['issues'].extend([f"Iconos: {i}" for i in results['icons']['issues']])
                    
        return results

# Para mantener compatibilidad con código existente, mantenemos el nombre original
IdUnifier = IdValidator
