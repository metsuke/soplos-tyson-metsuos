# Changelog

## [1.0.1] - 2025-07-15
### Añadado
- Lectura automática de versión y descripción desde metainfo.xml.
- Soporte para iconos multi-resolución (48x48, 64x64, 128x128) en el empaquetado.
- Memoria de la última carpeta de proyecto y de salida usadas.
- Advertencia y confirmación antes de sobrescribir un .deb existente.
- Mejoras de usabilidad en los diálogos de selección de carpetas.

## [1.0.0] - 2025-05-08
### Añadado
- Versión inicial de lanzamiento
- GUI para crear paquetes Debian
- Detección automática de dependencias
- Integración de archivos desktop e iconos
- Soporte multilenguaje
