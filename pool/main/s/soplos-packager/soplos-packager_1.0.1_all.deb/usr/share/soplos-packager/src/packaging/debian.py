import os
import re
import shutil
import subprocess
import stat
from pathlib import Path
from datetime import datetime
from src.utils.id_unifier import IdUnifier  # Importar IdUnifier

class DebPackager:
    def __init__(self, program_path, package_name, version, description, maintainer, 
                 output_dir=None, dependencies=None, icon_path=None, requires_root=False):  
        self.program_path = Path(program_path)
        self.package_name = package_name
        self.version = version
        self.description = description
        self.maintainer = maintainer
        self.build_dir = Path(f"/tmp/{package_name}")
        self.output_dir = Path(output_dir) if output_dir else Path.cwd()
        self.dependencies = dependencies or []
        self.icon_path = Path(icon_path) if icon_path else None
        self.requires_root = requires_root
        
        # Usar el nombre del paquete directamente, sin manipularlo
        self.app_id = self.package_name

    def _create_directory_structure(self):
        """Crea la estructura de directorios necesaria"""
        # Limpiar directorio si existe
        if self.build_dir.exists():
            shutil.rmtree(self.build_dir)
        
        # Crear directorios
        (self.build_dir / "DEBIAN").mkdir(parents=True)
        (self.build_dir / "usr/bin").mkdir(parents=True)
        (self.build_dir / "usr/share" / self.package_name).mkdir(parents=True)
        (self.build_dir / "usr/share/applications").mkdir(parents=True)
        (self.build_dir / "usr/share/metainfo").mkdir(parents=True)

    def _copy_program(self):
        """Copia el programa o directorio a la ubicación correcta"""
        source_path = Path(self.program_path)
        # Cambiado para usar /usr/share/[package_name] en lugar de /usr/local/bin
        dest_path = self.build_dir / "usr/share" / self.package_name
        
        try:
            if source_path.is_dir():
                # Buscar archivo metainfo.xml - USAR NOMBRES ORIGINALES
                metainfo_paths = [
                    source_path / "debian" / f"{source_path.name}.metainfo.xml",
                    source_path / "debian" / f"com.{source_path.name}.metainfo.xml",
                    source_path / "debian" / f"com.soplos.{source_path.name}.metainfo.xml",
                    source_path / "debian" / f"{source_path.name}.appdata.xml",
                    source_path / "data" / f"{source_path.name}.metainfo.xml",
                    source_path / "data" / f"com.{source_path.name}.metainfo.xml",
                    source_path / "data" / f"com.soplos.{source_path.name}.metainfo.xml",
                    source_path / "data" / f"{source_path.name}.appdata.xml",
                ]
                
                # Buscar también archivos como "com.soplos.packager.metainfo.xml"
                for metainfo_dir in [source_path / "debian", source_path / "data", source_path]:
                    if metainfo_dir.exists():
                        for file in metainfo_dir.glob("*.metainfo.xml"):
                            if file not in metainfo_paths:
                                metainfo_paths.append(file)
                        for file in metainfo_dir.glob("*.appdata.xml"):
                            if file not in metainfo_paths:
                                metainfo_paths.append(file)
                
                metainfo_found = False
                for meta_path in metainfo_paths:
                    if meta_path.exists():
                        # Crear directorio de metainfo si no existe
                        metainfo_dir = self.build_dir / "usr/share/metainfo"
                        metainfo_dir.mkdir(parents=True, exist_ok=True)
                        
                        # IMPORTANTE: Mantener el nombre original del archivo
                        dest_name = meta_path.name
                        shutil.copy2(meta_path, metainfo_dir / dest_name)
                        metainfo_found = True
                        print(f"Copiado metainfo desde {meta_path} a {metainfo_dir / dest_name}")
                        break
                
                # Solo crear uno nuevo si no se encuentra ninguno existente y está habilitado
                if not metainfo_found:
                    self._create_metainfo_file()

                # Continuar con la copia normal del programa
                if dest_path.exists():
                    shutil.rmtree(dest_path)
                shutil.copytree(source_path, dest_path)

            else:
                dest_file = dest_path / source_path.name
                shutil.copy2(source_path, dest_file)

            # Copiar iconos multi-resolución si existen en assets/icons
            icon_base_dir = source_path / "assets" / "icons"
            for size in ["48x48", "64x64", "128x128"]:
                size_dir = icon_base_dir / size
                if size_dir.exists() and size_dir.is_dir():
                    dest_dir = self.build_dir / f"usr/share/icons/hicolor/{size}/apps"
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    for icon_file in size_dir.iterdir():
                        if icon_file.is_file() and icon_file.suffix in [".png", ".svg", ".ico"]:
                            try:
                                shutil.copy2(icon_file, dest_dir / icon_file.name)
                                print(f"Copiado icono {icon_file.name} a {dest_dir}")
                            except Exception as e:
                                print(f"Advertencia: No se pudo copiar el icono {icon_file} a {dest_dir}: {e}")

            # Copiar icono principal como antes
            # Copiar icono si existe - MANTENER NOMBRES ORIGINALES
            if self.icon_path and self.icon_path.exists():
                # Evitar usar soplos-logo.png si es posible
                if os.path.basename(self.icon_path) == "soplos-logo.png":
                    # Buscar un icono alternativo si es poslos-logo.png
                    icon_dir = os.path.dirname(self.icon_path)
                    alternative_icon = None
                    app_prefix = f"com.{self.package_name.replace('-', '')}"
                    for file in os.listdir(icon_dir):
                        if file.startswith(app_prefix) and file.endswith((".png", ".svg", ".ico")):
                            alternative_icon = os.path.join(icon_dir, file)
                            break
                    if alternative_icon:
                        print(f"Usando {os.path.basename(alternative_icon)} en lugar de soplos-logo.png")
                        self.icon_path = alternative_icon
                for size in ["16x16", "22x22", "24x24", "32x32", "48x48", "64x64", "128x128", "256x256"]:
                    icon_dir = self.build_dir / f"usr/share/icons/hicolor/{size}/apps"
                    icon_dir.mkdir(parents=True, exist_ok=True)
                    original_icon_name = self.icon_path.name
                    icon_dest = icon_dir / original_icon_name
                    try:
                        shutil.copy2(self.icon_path, icon_dest)
                    except Exception as e:
                        print(f"Advertencia: No se pudo copiar el icono a {size}: {e}")
                pixmaps_dir = self.build_dir / "usr/share/pixmaps"
                pixmaps_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(self.icon_path, pixmaps_dir / self.icon_path.name)

            # Buscar y usar script wrapper personalizado si existe, o crearlo si no
            if not self._copy_custom_wrapper():
                self._create_wrapper_script()
            
        except Exception as e:
            raise Exception(f"Error al copiar archivos: {str(e)}")

    def _copy_custom_wrapper(self):
        """Busca y copia un script wrapper personalizado si existe"""
        source_path = self.program_path
        wrapper_sources = [
            source_path / "debian" / self.package_name,
            source_path / "bin" / self.package_name,
            source_path / "scripts" / self.package_name
        ]
        
        for wrapper_source in wrapper_sources:
            if wrapper_source.exists():
                # Copiar el script wrapper existente
                wrapper_dest = self.build_dir / "usr/bin" / self.package_name
                shutil.copy2(wrapper_source, wrapper_dest)
                # Hacer el script ejecutable
                wrapper_dest.chmod(wrapper_dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
                print(f"Copiado script wrapper desde {wrapper_source} a {wrapper_dest}")
                return True
                
        return False

    def _create_wrapper_script(self):
        """Crea un script wrapper en /usr/bin que ejecuta el programa desde /usr/share"""
        source_path = Path(self.program_path)
        wrapper_path = self.build_dir / "usr/bin" / self.package_name
        
        # Agregar debug para verificar el valor de requires_root
        print(f"DEBUG - Creando wrapper para {self.package_name}. Requiere root: {self.requires_root}")
        
        if source_path.is_dir():
            main_script = "main.py"
            # Buscar el script principal
            if not (source_path / main_script).exists():
                main_script = f"{source_path.name}.py"
                if not (source_path / main_script).exists():
                    # Buscar cualquier archivo .py que podría ser el principal
                    for file in source_path.glob("*.py"):
                        if file.name != "__init__.py":
                            main_script = file.name
                            break
            
            # Elegir el método de ejecución basado en si requiere privilegios de root
            if self.requires_root:
                # Script para aplicaciones con privilegios de root
                wrapper_content = f"""#!/bin/bash
# Script generado automáticamente por Soplos Packager
# Para aplicaciones que requieren privilegios de root

if [ $(id -u) -ne 0 ]; then
    # No somos root, relanzar con pkexec
    display=$DISPLAY
    xauthority=$XAUTHORITY
    xdg_runtime_dir=$XDG_RUNTIME_DIR
    
    pkexec --disable-internal-agent env \\
        DISPLAY=$display \\
        XAUTHORITY=$xauthority \\
        XDG_RUNTIME_DIR=$xdg_runtime_dir \\
        WMCLASS="{self.app_id}" \\
        GDK_STARTUP_NOTIFICATION_ID="${{STARTUP_ID:-0}}" \\
        HOME=/root \\
        python3 -c "
import sys
import os
sys.path.insert(0, '/usr/share/{self.package_name}')
os.environ['GDK_STARTUP_ID'] = '${{GDK_STARTUP_NOTIFICATION_ID}}'
os.environ['WMCLASS'] = '{self.app_id}'

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

# Establecer el nombre de la aplicación antes de importar módulos
GLib.set_prgname('{self.app_id}')
GLib.set_application_name('{self.package_name}')
Gtk.Window.set_default_icon_name('{self.app_id}')
if hasattr(Gdk, 'set_program_class'):
    Gdk.set_program_class('{self.app_id}')

# Importar y ejecutar el programa principal
import {main_script.replace('.py', '')}
try:
    if hasattr({main_script.replace('.py', '')}, 'main'):
        sys.exit({main_script.replace('.py', '')}.main())
    else:
        # Buscar una función que pueda ser el punto de entrada
        for attr_name in dir({main_script.replace('.py', '')}):
            if attr_name.lower() in ['main', 'run', 'start']:
                attr = getattr({main_script.replace('.py', '')}, attr_name)
                if callable(attr):
                    sys.exit(attr())
                    break
        else:
            # Si no hay función main, simplemente importar es suficiente
            pass
except Exception as e:
    print(f'Error al ejecutar {main_script}: {{e}}')
    sys.exit(1)
"
    exit $?
else
    # Ya somos root, ejecutar directamente con los IDs correctos
    export WMCLASS="{self.app_id}"
    export GDK_STARTUP_NOTIFICATION_ID="${{STARTUP_ID:-0}}"
    cd /usr/share/{self.package_name}
    
    python3 -c "
import sys
import os
sys.path.insert(0, '/usr/share/{self.package_name}')
os.environ['GDK_STARTUP_ID'] = '${{GDK_STARTUP_NOTIFICATION_ID}}'
os.environ['WMCLASS'] = '{self.app_id}'

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

# Establecer el nombre de la aplicación antes de importar módulos
GLib.set_prgname('{self.app_id}')
GLib.set_application_name('{self.package_name}')
Gtk.Window.set_default_icon_name('{self.app_id}')
if hasattr(Gdk, 'set_program_class'):
    Gdk.set_program_class('{self.app_id}')

# Importar y ejecutar el programa principal
import {main_script.replace('.py', '')}
try:
    if hasattr({main_script.replace('.py', '')}, 'main'):
        sys.exit({main_script.replace('.py', '')}.main())
    else:
        # Buscar una función que pueda ser el punto de entrada
        for attr_name in dir({main_script.replace('.py', '')}):
            if attr_name.lower() in ['main', 'run', 'start']:
                attr = getattr({main_script.replace('.py', '')}, attr_name)
                if callable(attr):
                    sys.exit(attr())
                    break
        else:
            # Si no hay función main, simplemente importar es suficiente
            pass
except Exception as e:
    print(f'Error al ejecutar {main_script}: {{e}}')
    sys.exit(1)
"
fi
"""
            else:
                # Script para aplicaciones normales (sin privilegios de root)
                wrapper_content = f"""#!/bin/bash
# Script generado automáticamente por Soplos Packager
# Establecer explícitamente el WM_CLASS para Docklike y otros docks
export WMCLASS="{self.app_id}"

# Si estamos en GTK, podríamos usar GDK_STARTUP_NOTIFICATION_ID
export GDK_STARTUP_NOTIFICATION_ID="${{STARTUP_ID:-0}}"

# Lanzar el programa con el ID de aplicación correcto
cd /usr/share/{self.package_name}

exec python3 -c "
import sys
import os
sys.path.insert(0, '/usr/share/{self.package_name}')
os.environ['GDK_STARTUP_ID'] = '${{GDK_STARTUP_NOTIFICATION_ID}}'
os.environ['WMCLASS'] = '{self.app_id}'

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

# Establecer el nombre de la aplicación antes de importar módulos
GLib.set_prgname('{self.app_id}')
GLib.set_application_name('{self.package_name}')
Gtk.Window.set_default_icon_name('{self.app_id}')
if hasattr(Gdk, 'set_program_class'):
    Gdk.set_program_class('{self.app_id}')

# Importar y ejecutar el programa principal
import {main_script.replace('.py', '')}
try:
    if hasattr({main_script.replace('.py', '')}, 'main'):
        sys.exit({main_script.replace('.py', '')}.main())
    else:
        # Buscar una función que pueda ser el punto de entrada
        for attr_name in dir({main_script.replace('.py', '')}):
            if attr_name.lower() in ['main', 'run', 'start']:
                attr = getattr({main_script.replace('.py', '')}, attr_name)
                if callable(attr):
                    sys.exit(attr())
                    break
        else:
            # Si no hay función main, simplemente importar es suficiente
            pass
except Exception as e:
    print(f'Error al ejecutar {main_script}: {{e}}')
    sys.exit(1)
"
"""
        else:
            # Código similar para archivos individuales
            if self.requires_root:
                # Wrapper con privilegios para archivo individual
                wrapper_content = f"""#!/bin/bash
# Script generado automáticamente por Soplos Packager
# Para aplicaciones que requieren privilegios de root

if [ $(id -u) -ne 0 ]; then
    # No somos root, relanzar con pkexec
    display=$DISPLAY
    xauthority=$XAUTHORITY
    xdg_runtime_dir=$XDG_RUNTIME_DIR
    
    pkexec --disable-internal-agent env \\
        DISPLAY=$display \\
        XAUTHORITY=$xauthority \\
        XDG_RUNTIME_DIR=$xdg_runtime_dir \\
        WMCLASS="{self.app_id}" \\
        GDK_STARTUP_NOTIFICATION_ID="${{STARTUP_ID:-0}}" \\
        HOME=/root \\
        python3 -c "
import sys
import os
os.environ['GDK_STARTUP_ID'] = '${{GDK_STARTUP_NOTIFICATION_ID}}'
os.environ['WMCLASS'] = '{self.app_id}'

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

# Establecer el nombre de la aplicación antes de importar módulos
GLib.set_prgname('{self.app_id}')
GLib.set_application_name('{self.package_name}')
Gtk.Window.set_default_icon_name('{self.app_id}')
if hasattr(Gdk, 'set_program_class'):
    Gdk.set_program_class('{self.app_id}')

# Ejecutar el programa principal
sys.path.insert(0, '/usr/share/{self.package_name}')
exec(open('/usr/share/{self.package_name}/{source_path.name}').read())
"
    exit $?
else
    # Ya somos root, ejecutar directamente
    export WMCLASS="{self.app_id}"
    export GDK_STARTUP_NOTIFICATION_ID="${{STARTUP_ID:-0}}"
    cd /usr/share/{self.package_name}
    
    python3 -c "
import sys
import os
os.environ['GDK_STARTUP_ID'] = '${{GDK_STARTUP_NOTIFICATION_ID}}'
os.environ['WMCLASS'] = '{self.app_id}'

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

# Establecer el nombre de la aplicación antes de importar módulos
GLib.set_prgname('{self.app_id}')
GLib.set_application_name('{self.package_name}')
Gtk.Window.set_default_icon_name('{self.app_id}')
if hasattr(Gdk, 'set_program_class'):
    Gdk.set_program_class('{self.app_id}')

# Ejecutar el programa principal
sys.path.insert(0, '/usr/share/{self.package_name}')
exec(open('/usr/share/{self.package_name}/{source_path.name}').read())
"
fi
"""
            else:
                # Wrapper normal para archivo individual
                wrapper_content = f"""#!/bin/bash
# Script generado automáticamente por Soplos Packager
# Establecer explícitamente el WM_CLASS para Docklike y otros docks
export WMCLASS="{self.app_id}"

# Si estamos en GTK, podríamos usar GDK_STARTUP_NOTIFICATION_ID
export GDK_STARTUP_NOTIFICATION_ID="${{STARTUP_ID:-0}}"

# Lanzar el programa con el ID de aplicación correcto
cd /usr/share/{self.package_name}

exec python3 -c "
import sys
import os
os.environ['GDK_STARTUP_ID'] = '${{GDK_STARTUP_NOTIFICATION_ID}}'
os.environ['WMCLASS'] = '{self.app_id}'

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

# Establecer el nombre de la aplicación antes de importar módulos
GLib.set_prgname('{self.app_id}')
GLib.set_application_name('{self.package_name}')
Gtk.Window.set_default_icon_name('{self.app_id}')
if hasattr(Gdk, 'set_program_class'):
    Gdk.set_program_class('{self.app_id}')

# Ejecutar el programa principal
sys.path.insert(0, '/usr/share/{self.package_name}')
exec(open('/usr/share/{self.package_name}/{source_path.name}').read())
"
"""
        
        # Verificar la generación correcta del wrapper
        print(f"DEBUG - Wrapper generado con {'privilegios de root' if self.requires_root else 'privilegios normales'}")
        
        wrapper_path.write_text(wrapper_content)
        # Hacer el script ejecutable
        wrapper_path.chmod(wrapper_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        
        # También modificar los archivos Python principales para establecer los IDs
        self._update_python_files()

    def _update_python_files(self):
        """Modifica los archivos Python principales para establecer los IDs correctamente"""
        dest_path = self.build_dir / "usr/share" / self.package_name
        
        # Buscar archivos Python principales
        main_files = []
        
        # Buscar archivos candidatos: main.py, [package_name].py, app.py, application.py
        candidates = [
            dest_path / "main.py",
            dest_path / f"{self.package_name}.py",
            dest_path / "app.py",
            dest_path / "application.py"
        ]
        
        for file_path in candidates:
            if file_path.exists():
                main_files.append(file_path)
        
        # Si no se encuentran por nombre específico, buscar archivos que contengan ciertas palabras clave
        if not main_files:
            for py_file in dest_path.glob("**/*.py"):
                with open(py_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    # Buscar patrones comunes que indican un archivo principal
                    if ('application_id' in content or 
                        'Gtk.Application(' in content or
                        'class MainWindow' in content or
                        'GLib.set_prgname' in content or
                        'set_wmclass' in content or
                        'if __name__ == "__main__"' in content):
                        main_files.append(py_file)
        
        print(f"DEBUG - Encontrados {len(main_files)} archivos Python para modificar: {main_files}")
        
        # Modificar cada archivo principal encontrado
        for file_path in main_files:
            try:
                self._update_python_file(file_path)
            except Exception as e:
                print(f"ERROR - No se pudo actualizar {file_path}: {e}")
    
    def _update_python_file(self, file_path):
        """Actualiza un archivo Python individual para usar los ID correctos"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Buscar patrones comunes para reemplazar
            patterns = [
                # application_id en Gtk.Application
                (r'application_id=[\'"]([^\'"]*)[\'"](,|\))', f'application_id=\'{self.app_id}\'\\g<2>'),
                
                # GLib.set_prgname
                (r'GLib\.set_prgname\([\'"]([^\'"]*)[\'"]\)', f'GLib.set_prgname(\'{self.app_id}\')'),
                
                # set_wmclass
                (r'set_wmclass\([\'"]([^\'"]*)[\'"]\s*,\s*[\'"]([^\'"]*)[\'"]', f'set_wmclass(\'{self.app_id}\', \'{self.package_name}\''),
                
                # Gdk.set_program_class
                (r'Gdk\.set_program_class\([\'"]([^\'"]*)[\'"]\)', f'Gdk.set_program_class(\'{self.app_id}\')'),
                
                # set_default_icon_name
                (r'Gtk\.Window\.set_default_icon_name\([\'"]([^\'"]*)[\'"]\)', f'Gtk.Window.set_default_icon_name(\'{self.app_id}\')'),
                
                # Inicialización de clase de aplicación (con flag re.DOTALL)
                (r'(class\s+\w+Application\(Gtk\.Application\):.*?\s+def\s+__init__\s*\(.+?\):.*?)(super\(\)\.__|self\.__|Gtk\.Application\.__init__\s*\()',
                 lambda m: f"{m.group(1)}self.__app_id = '{self.app_id}'\n        {m.group(2)}", 
                 re.DOTALL)
            ]
            
            # Aplicar cada patrón de búsqueda y reemplazo
            modified = False
            for pattern_data in patterns:
                # Manejar tanto patrones con 2 elementos (patrón, reemplazo)
                # como patrones con 3 elementos (patrón, reemplazo, flags)
                if len(pattern_data) == 3:
                    pattern, replacement, flags = pattern_data
                    new_content, num_subs = re.subn(pattern, replacement, content, flags=flags)
                else:
                    pattern, replacement = pattern_data
                    new_content, num_subs = re.subn(pattern, replacement, content)
                    
                if num_subs > 0:
                    content = new_content
                    modified = True
                    print(f"DEBUG - Patrón encontrado y reemplazado en {file_path}")
            
            # Identificar el caso especial cuando necesitamos agregar una sección de ID
            # Buscar "if __name__ == '__main__':" sin GLib.set_prgname antes
            if 'if __name__ == "__main__"' in content or "if __name__ == '__main__':" in content:
                if 'GLib.set_prgname' not in content and 'set_wmclass' not in content:
                    # Insertar código para establecer el ID de la aplicación
                    id_setup_code = f"""
# Added by Soplos Packager - Setup Application ID
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

GLib.set_prgname('{self.app_id}')
GLib.set_application_name('{self.package_name}')
try:
    Gtk.Window.set_default_icon_name('{self.app_id}')
except:
    pass
try:
    if hasattr(Gdk, 'set_program_class'):
        Gdk.set_program_class('{self.app_id}')
except:
    pass
# End of Soplos Packager addition
"""
                    # Encontrar la sección de importaciones para agregar nuestro código después
                    import_match = re.search(r'((?:from\s+[\w.]+\s+import\s+.*?\n|import\s+.*?\n)+)', content)
                    if import_match:
                        content = content[:import_match.end()] + id_setup_code + content[import_match.end():]
                        modified = True
                        print(f"DEBUG - Agregado código de ID de aplicación en {file_path}")
            
            # Guardar el archivo modificado si hubo cambios
            if modified:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"INFO - Archivo {file_path} modificado con éxito para usar ID: {self.app_id}")
            else:
                print(f"INFO - No se requieren cambios en {file_path}")
                
        except Exception as e:
            print(f"ERROR - Error al actualizar el archivo {file_path}: {e}")

    def _create_metainfo_file(self):
        """Crea el archivo AppStream metadata"""
        # Asegurar que el XML tenga la declaración XML correcta con encoding UTF-8
        metainfo_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<component type="desktop-application">
  <id>{self.app_id}</id>
  <metadata_license>CC0-1.0</metadata_license>
  <project_license>GPL-3.0+</project_license>
  <name>{self.package_name}</name>
  <name xml:lang="es">{self.package_name}</name>
  <name xml:lang="fr">{self.package_name}</name>
  <name xml:lang="pt">{self.package_name}</name>
  <name xml:lang="de">{self.package_name}</name>
  <name xml:lang="it">{self.package_name}</name>
  <name xml:lang="ru">{self.package_name}</name>
  <name xml:lang="ro">{self.package_name}</name>
  
  <summary>{self.description.split('.')[0]}</summary>
  <summary xml:lang="es">{self.description.split('.')[0]}</summary>
  <summary xml:lang="fr">{self.description.split('.')[0]}</summary>
  <summary xml:lang="pt">{self.description.split('.')[0]}</summary>
  <summary xml:lang="de">{self.description.split('.')[0]}</summary>
  <summary xml:lang="it">{self.description.split('.')[0]}</summary>
  <summary xml:lang="ru">{self.description.split('.')[0]}</summary>
  <summary xml:lang="ro">{self.description.split('.')[0]}</summary>

  <description>
    <p>{self.description}</p>
    <p xml:lang="es">{self.description}</p>
    <p xml:lang="fr">{self.description}</p>
    <p xml:lang="pt">{self.description}</p>
    <p xml:lang="de">{self.description}</p>
    <p xml:lang="it">{self.description}</p>
    <p xml:lang="ru">{self.description}</p>
    <p xml:lang="ro">{self.description}</p>
  </description>

  <launchable type="desktop-id">{self.app_id}.desktop</launchable>

  <url type="homepage">https://github.com/soplos/{self.package_name}</url>
  <developer_name>{self.maintainer.split('<')[0].strip()}</developer_name>

  <provides>
    <binary>{self.package_name}</binary>
  </provides>

  <releases>
    <release version="{self.version}" date="{datetime.now().strftime('%Y-%m-%d')}">
      <description>
        <p>Initial release</p>
      </description>
    </release>
  </releases>

  <content_rating type="oars-1.1"/>
</component>"""

        # Guardar siempre con el nombre de app_id (NO con package_name)
        metainfo_path = self.build_dir / f"usr/share/metainfo/{self.app_id}.metainfo.xml"
        metainfo_path.write_text(metainfo_content)
        print(f"Metainfo creado: {metainfo_path} con ID={self.app_id}")

    def create_package(self):
        """Crea el paquete .deb con la estructura necesaria"""
        try:
            # Limpiar directorio temporal si existe
            if self.build_dir.exists():
                try:
                    shutil.rmtree(self.build_dir)
                except PermissionError:
                    subprocess.run(['sudo', 'rm', '-rf', str(self.build_dir)], check=True)
            
            # Crear estructura de directorios
            self._create_directory_structure()
            self._copy_program()  # Ahora _copy_program respeta nombres originales
            self._create_control_file()
            self._create_desktop_file()  # Modificado para respetar nombres originales
            
            # Solo verificar consistencia y reportar problemas, no modificar
            try:
                print(f"Verificando consistencia de IDs")
                self._verify_id_consistency()
                print("Verificación completada (solo reporte)")
            except Exception as e:
                print(f"Error en verificación de consistencia: {e}")
            
            # Asegurar que el directorio de salida existe
            self.output_dir.mkdir(parents=True, exist_ok=True)
            
            # Construir el paquete
            self._build_package()
            
            # Devolver la ruta con "_all" incluido en el nombre del archivo
            return True, str(self.output_dir / f"{self.package_name}_{self.version}_all.deb")
        except Exception as e:
            return False, str(e)
        finally:
            # Limpiar directorio temporal
            if self.build_dir.exists():
                try:
                    shutil.rmtree(self.build_dir)
                except PermissionError:
                    subprocess.run(['sudo', 'rm', '-rf', str(self.build_dir)], check=True)

    def _verify_id_consistency(self):
        """Verifica la consistencia de los IDs en todos los archivos (solo reportar, no modificar)"""
        try:
            # Buscar todos los archivos .desktop
            desktop_files = []
            desktop_dir = self.build_dir / "usr/share/applications"
            if (desktop_dir.exists()):
                for file in desktop_dir.glob("*.desktop"):
                    desktop_files.append(str(file))
                    
            # Buscar todos los archivos metainfo.xml y appdata.xml
            metainfo_files = []
            metainfo_dir = self.build_dir / "usr/share/metainfo"
            if (metainfo_dir.exists()):
                for file in metainfo_dir.glob("*.metainfo.xml"):
                    metainfo_files.append(str(file))
                for file in metainfo_dir.glob("*.appdata.xml"):
                    metainfo_files.append(str(file))
                    
            # Reportar archivos encontrados
            print(f"Archivos .desktop encontrados: {', '.join(desktop_files)}")
            print(f"Archivos metainfo encontrados: {', '.join(metainfo_files)}")
                
        except Exception as e:
            print(f"Error en verificación de consistencia: {e}")

    def _create_control_file(self):
        """Crea el archivo DEBIAN/control"""
        # Crear lista de dependencias
        base_deps = ["python3 (>= 3.8)", "python3-gi"]
        
        # Si requiere permisos de root, añadir dependencia de policykit o sudo
        if self.requires_root:
            base_deps.append("policykit-1 | sudo")
        
        all_deps = base_deps + self.dependencies
        deps_str = ", ".join(all_deps)

        control_content = f"""Package: {self.package_name}
Version: {self.version}
Section: utils
Priority: optional
Architecture: all
Depends: {deps_str}
Maintainer: {self.maintainer}
Description: {self.description}
"""
        control_path = self.build_dir / "DEBIAN/control"
        control_path.write_text(control_content)

    def _create_desktop_file(self):
        """Copia o crea el archivo .desktop"""
        source_path = Path(self.program_path)
        
        # Lista de posibles ubicaciones del archivo .desktop
        desktop_paths = [
            source_path / "debian" / f"{source_path.name}.desktop",
            source_path / "debian" / f"com.{source_path.name}.desktop",
            source_path / "debian" / f"com.soplos.{source_path.name}.desktop",
            source_path / "assets" / f"{source_path.name}.desktop",
            source_path / "assets" / f"com.{source_path.name}.desktop",
            source_path / "assets" / f"com.soplos.{source_path.name}.desktop",
            source_path / "data" / f"{source_path.name}.desktop",
            source_path / "data" / f"com.{source_path.name}.desktop",
            source_path / "data" / f"com.soplos.{source_path.name}.desktop",
            source_path / f"{source_path.name}.desktop",
            source_path / f"com.{source_path.name}.desktop",
            source_path / f"com.soplos.{source_path.name}.desktop"
        ]

        # Buscar también archivos .desktop custom en los directorios
        for desktop_dir in [source_path / "debian", source_path / "assets", source_path / "data", source_path]:
            if desktop_dir.exists():
                for file in desktop_dir.glob("*.desktop"):
                    if file not in desktop_paths:
                        desktop_paths.append(file)

        # Buscar y copiar el archivo .desktop existente (MANTENER NOMBRE ORIGINAL)
        for desktop_path in desktop_paths:
            if (desktop_path.exists()):
                # Crear directorio applications si no existe
                desktop_dest_dir = self.build_dir / "usr/share/applications"
                desktop_dest_dir.mkdir(parents=True, exist_ok=True)
                
                # IMPORTANTE: Mantener el nombre original del archivo
                desktop_dest = desktop_dest_dir / desktop_path.name
                
                # Copiar el archivo .desktop sin modificarlo
                shutil.copy2(desktop_path, desktop_dest)
                print(f"Copiado .desktop desde {desktop_path} a {desktop_dest}")
                return True

        # Solo crear uno nuevo si no se encuentra ninguno existente
        self._generate_default_desktop_file()
        return False
    
    def _generate_default_desktop_file(self):
        """Genera un archivo .desktop predeterminado solo si no se encuentra uno existente"""
        # Crear el nombre preferido para el archivo .desktop
        desktop_name = f"{self.package_name}.desktop"
        desktop_content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name={self.package_name}
Comment={self.description}
Exec={self.package_name} %U
Icon={self.package_name}
Terminal=false
Categories=Utility;Development;
StartupNotify=true
"""

        # Guardar con el nombre predeterminado
        desktop_dir = self.build_dir / "usr/share/applications"
        desktop_dir.mkdir(parents=True, exist_ok=True)
        desktop_path = desktop_dir / desktop_name
        
        desktop_path.write_text(desktop_content)
        print(f"Creado .desktop predeterminado en {desktop_path}")

    def _build_package(self):
        """Construye el paquete .deb"""
        # Añadir "_all" al nombre del archivo para arquitectura "all"
        output_path = self.output_dir / f"{self.package_name}_{self.version}_all.deb"
        try:
            subprocess.run([
                "pkexec",  # o gksudo si prefieres
                "dpkg-deb",
                "--root-owner-group",
                "--build",
                str(self.build_dir),
                str(output_path)
            ], check=True)
        except subprocess.CalledProcessError as e:
            raise Exception(f"Error al construir el paquete: {str(e)}")

def crear_paquete(nombre, version, descripcion, mantenedor):
    """
    Crea un paquete .deb con la información proporcionada.
    
    :param nombre: Nombre del paquete.
    :param version: Versión del paquete.
    :param descripcion: Descripción del paquete.
    :param mantenedor: Nombre y correo electrónico del mantenedor.
    """
    # Lógica para crear el paquete .deb
    pass

def configurar_paquete(ruta_paquete):
    """
    Configura el paquete .deb en la ruta especificada.
    
    :param ruta_paquete: Ruta donde se encuentra el paquete .deb.
    """
    # Lógica para configurar el paquete .deb
    pass