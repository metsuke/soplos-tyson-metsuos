"""Módulo GUI para Soplos Packager"""
# Este archivo puede estar vacío, solo necesita existir
