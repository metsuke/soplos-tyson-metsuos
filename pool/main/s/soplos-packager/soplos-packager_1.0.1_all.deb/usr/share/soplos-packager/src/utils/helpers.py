# src/utils/helpers.py

import os
import xml.etree.ElementTree as ET

def validate_input(data):
    """Validar la entrada de datos."""
    # Implementar la lógica de validación aquí
    pass

def format_data(data):
    """Formatear los datos para su uso en la aplicación."""
    # Implementar la lógica de formateo aquí
    pass

def log_message(message):
    """Registrar un mensaje en el sistema de logs."""
    # Implementar la lógica de registro aquí
    pass

def get_metainfo_data(metainfo_path):
    """
    Extrae la versión y la descripción en inglés del metainfo.xml.
    Si no encuentra en inglés, toma el primer valor disponible.
    Devuelve un diccionario: {'version': str, 'description': str}
    """
    result = {'version': '', 'description': ''}
    if not os.path.exists(metainfo_path):
        return result
    try:
        tree = ET.parse(metainfo_path)
        root = tree.getroot()

        # Buscar versión en el primer <release version="...">
        version = ''
        releases = root.find('releases')
        if releases is not None:
            release = releases.find('release')
            if release is not None and 'version' in release.attrib:
                version = release.attrib['version']
        result['version'] = version

        # Buscar <summary xml:lang="en"> o el primero disponible
        summary = ''
        for elem in root.findall('summary'):
            if elem.attrib.get('{http://www.w3.org/XML/1998/namespace}lang') == 'en':
                summary = elem.text.strip() if elem.text else ''
                break
        if not summary:
            # Si no hay en inglés, tomar el primero
            elem = root.find('summary')
            if elem is not None and elem.text:
                summary = elem.text.strip()
        result['description'] = summary

        # Si quieres una descripción más larga, puedes buscar <description><p>...</p></description>
        # pero para la mayoría de los casos el summary es suficiente y más universal

    except Exception as e:
        print(f"Error leyendo metainfo.xml: {e}")
    return result