from .es import SPANISH
from .en import ENGLISH
from .fr import FRENCH
from .pt import PORTUGUESE
from .de import GERMAN
from .it import ITALIAN
from .ro import ROMANIAN
from .ru import RUSSIAN

__all__ = ['SPANISH', 'ENGLISH', 'FRENCH', 'PORTUGUESE', 'GERMAN', 'ITALIAN', 'ROMANIAN', 'RUSSIAN']
