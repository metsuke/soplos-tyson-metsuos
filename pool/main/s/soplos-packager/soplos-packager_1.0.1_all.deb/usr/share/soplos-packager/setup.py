from setuptools import setup, find_packages

setup(
    name="soplos-packager",
    version="1.0.1",
    packages=find_packages(),
    install_requires=[
        "PyGObject>=3.0.0",
        "python-gi>=3.0",
        "python-xlib>=0.20",
        "setuptools>=40.0",
    ],
    data_files=[
        ('share/applications', ['assets/soplos-packager.desktop']),
        ('share/icons/hicolor/128x128/apps', [
            'assets/icons/soplos-packager.png',  # Icono principal de la aplicación
            'assets/icons/soplos-logo.png'       # Logo para la ventana
        ]),
        ('share/metainfo', ['debian/soplos-packager.metainfo.xml']),
    ],
    package_data={
        '': [
            'assets/icons/*.png',
            'assets/*.desktop',
            'locale/translations/*.py',
        ],
    },
    entry_points={
        'console_scripts': [
            'soplos-packager=src.gui.window:main',
        ],
    },
    author="Soplos Team",
    author_email="info@soploslinux.com",
    description="Empaquetador gráfico de aplicaciones Python para Debian",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://github.com/soplos/soplos-packager",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: POSIX :: Linux",
        "Environment :: X11 Applications :: GTK",
    ],
    python_requires='>=3.8',
)