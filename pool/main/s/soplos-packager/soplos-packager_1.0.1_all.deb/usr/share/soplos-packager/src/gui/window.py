import os
import sys
import locale

# Añadir el directorio raíz al PYTHONPATH
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, root_dir)

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib, GdkPixbuf, Gdk
from src.packaging.debian import DebPackager
from src.utils.dependency_analyzer import DependencyAnalyzer
from src.utils.config import load_config, update_config, get_config_value  # Importar funciones de configuración
from src.locale.strings import (
    get_string, set_language, get_available_languages, 
    get_current_language, locale_manager, WIDGET_IDS as IDS
)
from src.utils.helpers import get_metainfo_data

def escape_markup(text):
    """Escapa caracteres especiales para markup GTK"""
    return text.replace('&', '&amp;')\
               .replace('<', '&lt;')\
               .replace('>', '&gt;')\
               .replace('"', '&quot;')\
               .replace("'", '&#39;')

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Obtener el APP_ID del módulo principal
        try:
            from main import APP_ID, WMCLASS
            self.app_id = APP_ID
            self.wmclass = WMCLASS
        except ImportError:
            self.app_id = "com.soplos.packager"
            self.wmclass = "com.soplos.packager"
        
        # Establecer el WM_CLASS primero
        self.set_wmclass(self.wmclass, self.wmclass)
        
        # Establecer el icono desde el sistema primero
        self.set_icon_name(self.app_id)

        # Cargar configuración guardada ANTES de usarla
        self.config = load_config()
        
        # Si no encuentra el icono del sistema, usar el local
        if not self.get_icon():
            try:
                window_icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                       'assets/icons/com.soplos.packager.png')  # Corregido el nombre del archivo
                window_icon = GdkPixbuf.Pixbuf.new_from_file(window_icon_path)
                self.set_icon(window_icon)
                Gtk.Window.set_default_icon(window_icon)
            except Exception as e:
                print(f"Error al cargar el icono: {e}")

        # Asegurarnos de que los IDs coincidan con WIDGET_IDS
        self.set_name(IDS['main_window'])
        
        # Actualizar mapeo de widgets a sus claves de traducción
        self.widget_translations = {
            'title': 'window_title',
            'file_entry': 'select_program',
            'icon_entry': 'select_icon',
            'package_name_entry': 'package_name',
            'version_entry': 'version',
            'description_entry': 'description',
            'maintainer_label': 'maintainer',
            'maintainer_name': 'name',
            'maintainer_email': 'email',
            'language_label': 'language',
            'output_entry': 'output_path',
            'file_button': 'browse',
            'icon_button': 'browse_alt',
            'output_button': 'select',
            'add_dep_button': 'add_btn',      # Cambiado de 'add' a 'add_btn'
            'remove_dep_button': 'remove_btn', # Cambiado de 'remove' a 'remove_btn'
            'deps_frame': 'dependencies',
            'preview_frame': 'preview',
            'preview_label': 'preview_empty',
            'close_button': 'close',
            'generate_button': 'generate',
            'dep_entry': 'new_dependency',
        }

        # Asignar ID a la ventana principal
        self.set_name(IDS['main_window'])

        # Añadir el selector de idioma
        language_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        language_box.set_halign(Gtk.Align.END)
        language_box.set_margin_end(10)
        language_box.set_name(IDS['language_box'])
        
        self.language_combo = Gtk.ComboBoxText()
        self.language_combo.set_name(IDS['language_combo'])
        languages = get_available_languages()
        current_lang = get_current_language()
        
        for code, name in languages.items():
            self.language_combo.append(code, name)
            if code == current_lang:
                self.language_combo.set_active_id(code)
        
        self.language_combo.connect('changed', self.on_language_changed)
        language_box.pack_start(self.language_combo, False, False, 0)
        
        # Conectar señal de cambio de idioma
        self.locale_handler_id = locale_manager.connect('language-changed', 
                                                      self._on_language_changed)
        
        # Establecer el título de la ventana
        self.set_title("Soplos Packager")
        
        # Conectar señal delete-event antes de todo
        self.connect('delete-event', self.on_delete_event)
        
        # Obtener dimensiones de la pantalla
        display = Gdk.Display.get_default()
        monitor = display.get_primary_monitor()
        geometry = monitor.get_geometry()
        screen_height = geometry.height
        
        # Ajustar tamaño de ventana - reducido de 700 a 600
        self.set_default_size(800, min(450, screen_height - 100))

        # Contenedor principal con menos espaciado
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)  # reducido de 6 a 4
        main_box.set_margin_top(4)     # reducido de 6 a 4
        main_box.set_margin_bottom(4)  # reducido de 6 a 4
        main_box.set_margin_start(6)   # mantenido para lectura
        main_box.set_margin_end(6)     # mantenido para lectura
        self.add(main_box)

        # Añadir selector de idioma en la parte superior
        language_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        language_box.set_halign(Gtk.Align.END)
        main_box.pack_start(language_box, False, False, 0)
        
        # Crear el label de idioma como un widget que vamos a actualizar
        self.language_label = Gtk.Label(label=get_string("language_label") + ":")
        language_box.pack_start(self.language_label, False, False, 0)
        
        # ComboBox para idiomas
        self.language_combo = Gtk.ComboBoxText()
        languages = get_available_languages()
        current_lang = get_current_language()  # Usar get_current_language() en lugar de CURRENT_LANG
        active_index = 0
        
        for i, (code, name) in enumerate(languages.items()):
            self.language_combo.append(code, name)
            if code == current_lang:
                active_index = i
        
        self.language_combo.set_active(active_index)
        self.language_combo.connect('changed', self.on_language_changed)
        language_box.pack_start(self.language_combo, False, False, 0)

        # Panel superior con logo pequeño y campos principales
        top_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        main_box.pack_start(top_panel, False, True, 0)

        # Logo pequeño (izquierda)
        logo_frame = Gtk.Frame()
        logo_frame.set_size_request(100, 100)  # Logo más pequeño
        top_panel.pack_start(logo_frame, False, True, 0)

        try:
            # Usar com.soplos.packager.png para el icono de la ventana
            window_icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                   'assets/icons/com.soplos.packager.png')  # Corregido el nombre del archivo
            window_icon = GdkPixbuf.Pixbuf.new_from_file(window_icon_path)
            self.set_icon(window_icon)
            
            # Usar soplos-logo.png solo para el logo dentro de la ventana
            logo_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                   'assets/icons/soplos-logo.png')
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                logo_path, 
                90, 90,
                True
            )
            logo_image = Gtk.Image.new_from_pixbuf(pixbuf)
            logo_frame.add(logo_image)
        except Exception as e:
            print(f"Error al cargar el logo: {e}")

        # Campos principales (derecha)
        fields_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        top_panel.pack_start(fields_box, True, True, 0)

        # Campo para seleccionar programa
        file_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        fields_box.pack_start(file_box, False, True, 0)
        
        self.file_entry = Gtk.Entry()
        self.file_entry.set_name(IDS['file_entry'])
        self.file_entry.set_placeholder_text(get_string("select_program"))
        file_box.pack_start(self.file_entry, True, True, 0)
        
        # Guardar referencia al botón de búsqueda de programa
        self.file_button = Gtk.Button()
        self.file_button.set_label(get_string("search_program"))  # Usar search_program
        self.file_button.set_use_underline(True)
        self.file_button.connect("clicked", self.on_file_clicked)
        self.file_button.set_name(IDS['file_button'])
        file_box.pack_start(self.file_button, False, True, 0)

        # Campo para seleccionar icono
        icon_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        fields_box.pack_start(icon_box, False, True, 0)
        
        self.icon_entry = Gtk.Entry()
        self.icon_entry.set_placeholder_text(get_string("select_icon"))
        self.icon_entry.set_name(IDS['icon_entry'])
        icon_box.pack_start(self.icon_entry, True, True, 0)
        
        # Guardar referencia al botón de búsqueda de icono
        self.icon_button = Gtk.Button()
        self.icon_button.set_label(get_string("search_icon"))  # Usar search_icon
        self.icon_button.set_use_underline(True)
        self.icon_button.connect("clicked", self.on_icon_clicked)
        self.icon_button.set_name(IDS['icon_button'])
        icon_box.pack_start(self.icon_button, False, True, 0)

        # Preview del icono
        icon_frame = Gtk.Frame()
        icon_frame.set_size_request(64, 64)
        icon_box.pack_start(icon_frame, False, True, 0)
        
        self.icon_preview = Gtk.Image()
        self.icon_preview.set_size_request(64, 64)
        self.icon_preview.set_name(IDS['icon_preview'])
        icon_frame.add(self.icon_preview)

        # Panel central con dos columnas
        central_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        main_box.pack_start(central_panel, True, True, 0)

        # Columna izquierda: Campos del formulario
        form_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        central_panel.pack_start(form_box, True, True, 0)

        # Campos del paquete - Corregir clavesiquetas
        self.package_name = self._create_entry_row(get_string("package_name"), form_box)
        self.package_name.set_name(IDS['package_name_entry'])
        self.version = self._create_entry_row(get_string("version"), form_box)
        self.version.set_name(IDS['version_entry'])
        
        self.description = self._create_entry_row(get_string("description"), form_box)
        self.description.set_name(IDS['description_entry'])

        # Eliminar el campo mantenedor antiguo ya que ahora usamos nombre y email separados
        # self.maintainer = self._create_entry_row("Mantenedor:", form_box)  # Eliminar esta línea

        # Mover los campos del mantenedor justo después de la descripción
        maintainer_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        form_box.pack_start(maintainer_box, False, True, 0)
        maintainer_box.set_name(IDS['maintainer_box'])
        
        # Guardar el label como atributo de la clase
        self.maintainer_label = Gtk.Label(label=get_string("maintainer"))
        self.maintainer_label.set_xalign(0)
        maintainer_box.pack_start(self.maintainer_label, False, True, 0)
        
        maintainer_fields = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        maintainer_box.pack_start(maintainer_fields, False, True, 0)
        
        self.maintainer_name = Gtk.Entry()
        self.maintainer_name.set_placeholder_text(get_string("name"))
        self.maintainer_name.set_name(IDS['maintainer_name'])
        
        # Cargar datos guardados del mantenedor
        if self.config['maintainer']['name']:
            self.maintainer_name.set_text(self.config['maintainer']['name'])
            
        maintainer_fields.pack_start(self.maintainer_name, True, True, 0)
        
        self.maintainer_email = Gtk.Entry()
        self.maintainer_email.set_placeholder_text(get_string("email"))
        self.maintainer_email.set_name(IDS['maintainer_email'])
        
        # Cargar email guardado del mantenedor
        if self.config['maintainer']['email']:
            self.maintainer_email.set_text(self.config['maintainer']['email'])
            
        maintainer_fields.pack_start(self.maintainer_email, True, True, 0)
        
        # Añadir checkbox para guardar datos del mantenedor
        self.save_maintainer_check = Gtk.CheckButton(label=get_string("save_maintainer_info"))
        self.save_maintainer_check.set_active(True if self.config['maintainer']['name'] else False)
        maintainer_box.pack_start(self.save_maintainer_check, False, True, 0)

        # Campo para ruta de salida (modificar esta sección)
        output_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        form_box.pack_start(output_box, False, True, 0)
        
        self.output_entry = Gtk.Entry()
        self.output_entry.set_placeholder_text(get_string("output_path"))
        output_box.pack_start(self.output_entry, True, True, 0)
        
        # Guardar referencia al botón de selección de salida
        self.output_button = Gtk.Button()
        self.output_button.set_label(get_string("select_btn"))  # Usar select_btn
        self.output_button.set_use_underline(True)
        self.output_button.connect("clicked", self.on_output_clicked)
        self.output_button.set_name(IDS['output_button'])
        output_box.pack_start(self.output_button, False, True, 0)
        
        # MOVIDO: Añadir checkbox para aplicaciones que requieren root DESPUÉS del campo de salida
        self.requires_root_check = Gtk.CheckButton(label=get_string("requires_root"))
        self.requires_root_check.set_tooltip_text(get_string("requires_root_tooltip"))
        self.requires_root_check.set_active(False)  # Asegurar que esté desactivado por defecto
        form_box.pack_start(self.requires_root_check, False, True, 0)

        # Cargar último directorio de salida si existe
        if self.config['last_output_dir'] and os.path.exists(self.config['last_output_dir']):
            self.output_entry.set_text(self.config['last_output_dir'])
            
        # Cargar idioma guardado
        if self.config['language']:
            self.language_combo.set_active_id(self.config['language'])

        # Columna derecha: Dependencias y preview
        right_column = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        central_panel.pack_start(right_column, True, True, 0)

        # Sección de dependencias - Usar get_string()
        self.deps_frame = Gtk.Frame()  # Guardar como atributo de la clase
        self.deps_frame.set_label(get_string("dependencies"))  # Cambiar aquí
        self.deps_frame.set_name(IDS['deps_frame'])
        right_column.pack_start(self.deps_frame, False, True, 0)

        deps_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        deps_box.set_margin_top(6)
        deps_box.set_margin_bottom(6)
        deps_box.set_margin_start(6)
        deps_box.set_margin_end(6)
        self.deps_frame.add(deps_box)

        # Lista de dependencias
        self.deps_store = Gtk.ListStore(str)
        self.deps_view = Gtk.TreeView(model=self.deps_store)
        self.deps_view.set_name(IDS['deps_view'])
        
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn(get_string("dependency"), renderer, text=0)
        self.deps_view.append_column(column)

        # Ajustar tamaño de la lista de dependencias
        deps_scroll = Gtk.ScrolledWindow()
        deps_scroll.set_size_request(-1, min(100, int(screen_height * 0.2)))  # Altura máxima de 100px o 20% de la pantalla
        deps_scroll.add(self.deps_view)
        deps_box.pack_start(deps_scroll, True, True, 0)

        # Botones para agregar/eliminar dependencias
        deps_buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        deps_box.pack_start(deps_buttons, False, True, 0)

        self.dep_entry = Gtk.Entry()
        self.dep_entry.set_placeholder_text(get_string("new_dependency"))
        self.dep_entry.set_name(IDS['dep_entry'])
        deps_buttons.pack_start(self.dep_entry, True, True, 0)

        # Corregir sección de botones de dependencias
        self.add_dep_button = Gtk.Button()
        self.add_dep_button.set_label(get_string("add_btn"))
        self.add_dep_button.connect("clicked", self.on_add_dep_clicked)
        deps_buttons.pack_start(self.add_dep_button, False, True, 0)

        self.remove_dep_button = Gtk.Button()
        self.remove_dep_button.set_label(get_string("remove_btn"))
        self.remove_dep_button.connect("clicked", self.on_remove_dep_clicked)
        deps_buttons.pack_start(self.remove_dep_button, False, True, 0)

        # Vista previa más compacta
        self.preview_frame = Gtk.Frame()  # Guardar como atributo de la clase
        self.preview_frame.set_label(get_string("preview"))  # Cambiar aquí
        self.preview_frame.set_size_request(-1, 120)
        right_column.pack_start(self.preview_frame, False, True, 0)

        # ScrolledWindow para la vista previa
        preview_scroll = Gtk.ScrolledWindow()
        preview_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.preview_frame.add(preview_scroll)

        preview_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        preview_box.set_margin_top(2)
        preview_box.set_margin_bottom(2)
        preview_box.set_margin_start(4)
        preview_box.set_margin_end(4)
        preview_scroll.add(preview_box)

        self.preview_label = Gtk.Label()
        self.preview_label.set_markup(get_string("preview_empty"))
        self.preview_label.set_line_wrap(True)
        self.preview_label.set_xalign(0)
        self.preview_label.set_selectable(True)
        preview_box.pack_start(self.preview_label, True, True, 0)

        # Panel inferior para botones
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        button_box.set_halign(Gtk.Align.END)
        button_box.set_margin_top(6)
        button_box.set_name(IDS['button_box'])
        main_box.pack_end(button_box, False, True, 0)

        # Botones al final - Guardar referencias como atributos de la clase
        self.close_button = Gtk.Button()
        self.close_button.set_label(get_string("close_btn"))
        self.close_button.set_use_underline(True)
        self.close_button.connect("clicked", self.on_close_clicked)
        self.close_button.set_name(IDS['close_button'])
        button_box.pack_start(self.close_button, False, True, 0)

        self.generate_button = Gtk.Button()
        self.generate_button.set_label(get_string("generate_btn"))
        self.generate_button.set_use_underline(True)
        self.generate_button.connect("clicked", self.on_generate_clicked)
        self.generate_button.get_style_context().add_class("suggested-action")
        self.generate_button.set_name(IDS['generate_button'])
        button_box.pack_start(self.generate_button, False, True, 0)

        # Spinner
        self.spinner = Gtk.Spinner()
        self.spinner.set_name(IDS['spinner'])
        button_box.pack_start(self.spinner, False, True, 0)

        # Conectar señales para actualizar la vista previa
        self.file_entry.connect("changed", lambda w: self._update_preview())
        self.package_name.connect("changed", lambda w: self._update_preview())
        self.version.connect("changed", lambda w: self._update_preview())
        self.description.connect("changed", lambda w: self._update_preview())
        self.maintainer_name.connect("changed", lambda w: self._update_preview())
        self.maintainer_email.connect("changed", lambda w: self._update_preview())

        # Asignar IDs únicos a cada widget principal
        for widget_name, widget_id in IDS.items():
            if hasattr(self, widget_name):
                widget = getattr(self, widget_name)
                widget.set_name(widget_id)

    def _create_entry_row(self, label_text, parent):
        """Crea una fila de entrada con etiqueta traducible"""
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        parent.pack_start(box, False, True, 0)

        # No traducir aquí, pasar ya la clave traducida
        label = Gtk.Label(label=label_text)
        label.set_xalign(0)
        label.set_size_request(150, -1)
        box.pack_start(label, False, True, 0)

        entry = Gtk.Entry()
        box.pack_start(entry, True, True, 0)
        return entry

    def _reset_fields(self):
        """Limpia todos los campos excepto el mantenedor"""
        # Limpiar campo de icono y su preview
        self.icon_entry.set_text("")
        self.icon_preview.clear()

        # Limpiar campos de texto
        self.version.set_text("")
        self.description.set_text("")
        self.output_entry.set_text("")

        # Limpiar lista de dependencias
        self.deps_store.clear()

    def on_file_clicked(self, button):
        # Obtener última carpeta de proyecto
        last_project_dir = get_config_value('last_project_dir', os.path.expanduser('~'))
        dialog = Gtk.FileChooserDialog(
            title=get_string("select_program_or_folder"),
            parent=self,
            action=Gtk.FileChooserAction.SELECT_FOLDER
        )
        dialog.add_buttons(
            get_string("close_btn"),
            Gtk.ResponseType.CANCEL,
            get_string("select_btn"),
            Gtk.ResponseType.ACCEPT
        )
        # Establecer carpeta inicial
        if last_project_dir and os.path.isdir(last_project_dir):
            dialog.set_current_folder(last_project_dir)

        # Configurar el diálogo
        dialog.set_select_multiple(False)
        dialog.set_create_folders(False)
        dialog.set_modal(True)

        response = dialog.run()
        if response == Gtk.ResponseType.ACCEPT:
            # Limpiar campos anteriores
            self._reset_fields()

            folder = dialog.get_filename()
            self.file_entry.set_text(folder)

            # Guardar la última carpeta de proyecto
            update_config('last_project_dir', folder)

            # Actualizar nombre del paquete
            package_name = os.path.basename(folder).lower().replace(" ", "-")
            self.package_name.set_text(package_name)

            # --- INTEGRACIÓN METAINFOS ---
            # Buscar metainfo.xml en la carpeta debian del proyecto
            metainfo_path = os.path.join(folder, "debian")
            if os.path.isdir(metainfo_path):
                for fname in os.listdir(metainfo_path):
                    if fname.endswith(".metainfo.xml"):
                        metainfo_file = os.path.join(metainfo_path, fname)
                        metainfo = get_metainfo_data(metainfo_file)
                        if metainfo['version']:
                            self.version.set_text(metainfo['version'])
                        if metainfo['description']:
                            self.description.set_text(metainfo['description'])
                        break
            # --- FIN INTEGRACIÓN METAINFOS ---

            # Buscar icono en la carpeta assets
            self._find_and_set_icon(folder)

            # Analizar dependencias automáticamente
            analyzer = DependencyAnalyzer(folder)
            dependencies = analyzer.analyze()

            # Actualizar lista de dependencias
            for dep in dependencies:
                self.deps_store.append([dep])

            self._update_preview()

        dialog.destroy()

    def _find_and_set_icon(self, project_folder):
        """Busca un icono en la carpeta assets del proyecto"""
        possible_paths = [
            os.path.join(project_folder, "assets", "icons"),
            os.path.join(project_folder, "assets"),
            os.path.join(project_folder, "src", "assets", "icons"),
            os.path.join(project_folder, "src", "assets"),
        ]
        icon_extensions = [".png", ".ico", ".svg"]
        project_name = os.path.basename(project_folder)
        
        # Crear nombre de icono específico para este proyecto
        specific_icon_name = f"com.{project_name.replace('-', '')}"
        
        for path in possible_paths:
            if os.path.exists(path):
                # Recolectar todos los iconos en la carpeta
                all_icons = []
                for file in os.listdir(path):
                    if any(file.endswith(ext) for ext in icon_extensions):
                        all_icons.append(file)
                        
                if not all_icons:
                    continue  # No hay iconos en esta carpeta
                    
                # Si hay iconos, seleccionar uno según prioridad
                selected_icon = None
                
                # 1. Primera prioridad: icono específico para este proyecto
                for icon in all_icons:
                    if icon.startswith(specific_icon_name):
                        selected_icon = icon
                        break
                
                # 2. Segunda prioridad: cualquier icono que no sea soplos-logo.png
                if not selected_icon:
                    for icon in all_icons:
                        if icon != "soplos-logo.png":
                            selected_icon = icon
                            break
                
                # 3. Última opción: usar soplos-logo.png si no hay alternativa
                if not selected_icon and "soplos-logo.png" in all_icons:
                    selected_icon = "soplos-logo.png"
                    
                # Si encontramos un icono, usarlo
                if selected_icon:
                    icon_path = os.path.join(path, selected_icon)
                    self.icon_entry.set_text(icon_path)
                    try:
                        pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                            icon_path, 
                            64, 64, 
                            True  # mantener proporción
                        )
                        self.icon_preview.set_from_pixbuf(pixbuf)
                    except Exception as e:
                        print(f"No se pudo cargar la vista previa del icono: {e}")
                    return

    def on_icon_clicked(self, button):
        dialog = Gtk.FileChooserDialog(
            title=get_string("select_icon_dialog"),
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            get_string("close_btn"),  # Usar close_btn en lugar de _Cancelar
            Gtk.ResponseType.CANCEL,
            get_string("open"),  # Usar open en lugar de _Abrir
            Gtk.ResponseType.ACCEPT
        )

        # Filtro para archivos de imagen
        filter_images = Gtk.FileFilter()
        filter_images.set_name(get_string("Imágenes"))
        filter_images.add_mime_type("image/png")
        dialog.add_filter(filter_images)

        dialog.connect("response", self._on_icon_dialog_response)
        dialog.show()

    def _on_icon_dialog_response(self, dialog, response):
        if response == Gtk.ResponseType.ACCEPT:
            file_path = dialog.get_filename()
            self.icon_entry.set_text(file_path)

            # Actualizar preview del icono
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                file_path, 
                64, 64, 
                True  # mantener proporción
            )
            self.icon_preview.set_from_pixbuf(pixbuf)

        dialog.destroy()

    def on_generate_clicked(self, button):
        """Función manejadora del botón generar"""
        errors = self._validate_fields()
        if errors:
            dialog = Gtk.MessageDialog(
                transient_for=self,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.NONE,
                text=get_string("validation_error")
            )
            dialog.add_button(get_string("ok_btn"), Gtk.ResponseType.OK)
            dialog.connect("response", lambda d, r: d.destroy())
            
            # Formatear los errores con viñetas
            error_text = "\n".join(f"• {error}" for error in errors)
            dialog.format_secondary_text(error_text)
            
            dialog.show_all()
            return

        # --- Comprobación de sobrescritura de paquete ---
        output_dir = self.output_entry.get_text() or os.getcwd()
        package_name = self.package_name.get_text()
        version = self.version.get_text()
        deb_filename = f"{package_name}_{version}_all.deb"
        deb_path = os.path.join(output_dir, deb_filename)
        if os.path.exists(deb_path):
            dialog = Gtk.MessageDialog(
                transient_for=self,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO,
                text=f"El paquete '{deb_filename}' ya existe en la carpeta de salida.\n¿Deseas sobrescribirlo?"
            )
            dialog.set_title("Sobrescribir paquete")
            response = dialog.run()
            dialog.destroy()
            if response != Gtk.ResponseType.YES:
                self.spinner.stop()
                button.set_sensitive(True)
                return
        # --- Fin comprobación de sobrescritura ---

        # Guardar configuración si está marcada la opción
        if self.save_maintainer_check.get_active():
            maintainer_config = {
                'name': self.maintainer_name.get_text(),
                'email': self.maintainer_email.get_text()
            }
            update_config('maintainer', maintainer_config)
            
        # Guardar directorio de salida 
        output_dir = self.output_entry.get_text()
        if output_dir and os.path.exists(output_dir):
            update_config('last_output_dir', output_dir)
            
        # Guardar idioma actual
        current_lang = get_current_language()
        update_config('language', current_lang)

        # Mostrar spinner
        self.spinner.start()
        button.set_sensitive(False)

        try:
            # Obtener lista de dependencias del TreeView
            dependencies = []
            self.deps_store.foreach(lambda model, path, iter: dependencies.append(model[iter][0]))

            # Mostrar en log si la aplicación requiere privilegios
            requires_root = self.requires_root_check.get_active()
            print(f"DEBUG - Generando paquete: {self.package_name.get_text()}. Requiere root: {requires_root}")

            # Crear el paquete
            packager = DebPackager(
                program_path=self.file_entry.get_text(),
                package_name=self.package_name.get_text(),
                version=self.version.get_text(),
                description=self.description.get_text(),
                maintainer=f"{self.maintainer_name.get_text()} <{self.maintainer_email.get_text()}>",
                output_dir=self.output_entry.get_text() or None,
                dependencies=dependencies,
                icon_path=self.icon_entry.get_text() or None,
                requires_root=requires_root  # Pasar el valor del checkbox
            )
            success, message = packager.create_package()
            
            if success:
                # Extraer solo la ruta del mensaje para la traducción
                path = message  # message ya es solo la ruta gracias a los cambios en debian.py
                success_text = get_string("success")
                # Quitar los {} del string de traducción
                message = f"{get_string('package_created')} {path}"
            else:
                success_text = get_string("error") 
                # Quitar los {} del string de traducción
                message = f"{get_string('package_error')} {message}"

            dialog = Gtk.MessageDialog(
                transient_for=self,
                message_type=Gtk.MessageType.INFO if success else Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.NONE,
                text=success_text
            )
            dialog.add_button(get_string("ok_btn"), Gtk.ResponseType.OK)
            dialog.format_secondary_text(message)
            dialog.connect("response", lambda d, r: d.destroy())
            dialog.show_all()
        finally:
            # Detener spinner
            self.spinner.stop()
            button.set_sensitive(True)

    def _update_preview(self):
        """Actualiza la vista previa del paquete"""
        program = GLib.markup_escape_text(self.file_entry.get_text())
        name = GLib.markup_escape_text(self.package_name.get_text())
        version = GLib.markup_escape_text(self.version.get_text())
        description = GLib.markup_escape_text(self.description.get_text())
        maintainer = GLib.markup_escape_text(self.maintainer_name.get_text())
        email = GLib.markup_escape_text(self.maintainer_email.get_text())

        dependencies = []
        def collect_deps(model, path, iter):
            dep = model[iter][0]
            # Escapar caracteres especiales en las dependencias, incluyendo < y >
            dep = GLib.markup_escape_text(dep)
            dependencies.append(f"• {dep}")
        self.deps_store.foreach(collect_deps)

        deps_str = "\n".join(dependencies)

        preview = f"""<b>{get_string("preview_package")}</b> {name}
<b>{get_string("preview_version")}</b> {version}
<b>{get_string("preview_program")}</b> {program}
<b>{get_string("preview_description")}</b> {description}
<b>{get_string("preview_maintainer")}</b> {maintainer} &lt;{email}&gt;
<b>{get_string("preview_dependencies")}</b>
{deps_str}
<b>{get_string("preview_structure")}</b>
/usr/local/bin/{os.path.basename(self.file_entry.get_text()) if self.file_entry.get_text() else ''}
/usr/share/applications/{self.package_name.get_text()}.desktop"""

        self.preview_label.set_markup(preview)

    def update_package_info(self, info):
        # Escapar los valores antes de construir el markup
        package_name = escape_markup(info.get('package', ''))
        version = escape_markup(info.get('version', ''))
        program = escape_markup(info.get('program', ''))
        description = escape_markup(info.get('description', ''))
        maintainer = escape_markup(info.get('maintainer', ''))
        dependencies = [escape_markup(dep) for dep in info.get('dependencies', [])]
        
        markup = f"""<b>Paquete:</b> {package_name}
<b>Versión:</b> {version}
<b>Programa:</b> {program}
<b>Descripción:</b> {description}
<b>Mantenedor:</b> {maintainer}
<b>Dependencias:</b>
"""
        if dependencies:
            markup += '\n'.join(f'• {dep}' for dep in dependencies)
            
        self.info_label.set_markup(markup)

    def on_output_clicked(self, button):
        # Obtener última carpeta de salida
        last_output_dir = get_config_value('last_output_dir', os.path.expanduser('~'))
        dialog = Gtk.FileChooserDialog(
            title=get_string("select_output_folder"),
            parent=self,
            action=Gtk.FileChooserAction.SELECT_FOLDER,
        )
        dialog.add_buttons(
            get_string("close_btn"),
            Gtk.ResponseType.CANCEL,
            get_string("select_btn"),
            Gtk.ResponseType.ACCEPT,
        )
        # Establecer carpeta inicial
        if last_output_dir and os.path.isdir(last_output_dir):
            dialog.set_current_folder(last_output_dir)
        dialog.connect("response", self._on_output_dialog_response)
        dialog.show_all()

    def _on_output_dialog_response(self, dialog, response):
        if response == Gtk.ResponseType.ACCEPT:
            folder = dialog.get_file()
            self.output_entry.set_text(folder.get_path())
            # Guardar la última carpeta de salida
            update_config('last_output_dir', folder.get_path())
        dialog.destroy()

    def on_add_dep_clicked(self, button):
        dep = self.dep_entry.get_text().strip()
        if dep:
            self.deps_store.append([dep])
            self.dep_entry.set_text("")
            self._update_preview()

    def on_remove_dep_clicked(self, button):
        selection = self.deps_view.get_selection()
        model, iter = selection.get_selected()
        if iter:
            model.remove(iter)
            self._update_preview()

    def _validate_fields(self):
        """Valida todos los campos del formulario"""
        errors = []

        if not self.file_entry.get_text():
            errors.append(get_string("must_select_program"))

        name = self.package_name.get_text()
        if not name:
            errors.append(get_string("package_name_required"))
        elif not name.islower() or ' ' in name:
            errors.append(get_string("package_name_format"))

        version = self.version.get_text()
        if not version:
            errors.append(get_string("version_required"))
        elif not self._is_valid_version(version):
            errors.append(get_string("version_format"))

        if not self.description.get_text():
            errors.append(get_string("description_required"))

        if not self.maintainer_name.get_text():
            errors.append(get_string("maintainer_name_required"))

        if not self.maintainer_email.get_text() or '@' not in self.maintainer_email.get_text():
            errors.append(get_string("maintainer_email_invalid"))

        return errors

    def _is_valid_version(self, version):
        """Valida el formato de versión X.Y.Z"""
        try:
            parts = version.split('.')
            return len(parts) == 3 and all(part.isdigit() for part in parts)
        except:
            return False

    def on_close_clicked(self, button):
        """Cierra la aplicación"""
        # Simular el evento delete-event al hacer clic en cerrar
        if not self.on_delete_event(None, None):
            self.get_application().quit()

    def on_delete_event(self, widget, event):
        """Manejador del evento delete-event"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=get_string("close_confirm")
        )
        
        # Agregar botones en orden inverso: primero No, luego Sí
        dialog.add_button(get_string("no_btn"), Gtk.ResponseType.NO)
        dialog.add_button(get_string("yes_btn"), Gtk.ResponseType.YES)
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            return False  # Procede con el cierre
        return True  # Cancela el cierre

    def on_language_changed(self, combo):
        """Maneja el cambio de idioma"""
        new_lang = combo.get_active_id()
        if new_lang != get_current_language():
            set_language(new_lang)
            # Guardar el idioma seleccionado en la configuración
            update_config('language', new_lang)
            GLib.idle_add(self._update_interface_strings)

    def _on_language_changed(self, _):
        """Manejador de señal de cambio de idioma"""
        GLib.idle_add(self._update_interface_strings)

    def _update_interface_strings(self):
        """Actualiza todos los textos de la interfaz"""
        try:
            # Actualizar título de la ventana
            self.set_title(get_string('window_title'))

            # Actualizar todos los widgets según su ID
            for widget_id, translation_key in self.widget_translations.items():
                if hasattr(self, widget_id):
                    widget = getattr(self, widget_id)
                    if isinstance(widget, Gtk.Entry):
                        widget.set_placeholder_text(get_string(translation_key))
                    elif isinstance(widget, Gtk.Label):
                        widget.set_text(get_string(translation_key))
                    elif isinstance(widget, Gtk.Button):
                        widget.set_label(get_string(translation_key))
                    elif isinstance(widget, Gtk.Frame):
                        widget.set_label(get_string(translation_key))

            # Actualizar TreeView de dependencias
            column = self.deps_view.get_column(0)
            if column:
                column.set_title(get_string('dependency'))

            # Actualizar vista previa
            self._update_preview()

            # Actualizar etiquetas de los campos del formulario
            self.package_name.get_parent().get_children()[0].set_text(get_string("package_name"))
            self.version.get_parent().get_children()[0].set_text(get_string("version"))
            self.description.get_parent().get_children()[0].set_text(get_string("description"))

            # Actualizar etiquetas de frames
            if hasattr(self, 'deps_frame'):
                self.deps_frame.set_label(get_string("dependencies"))
            if hasattr(self, 'preview_frame'):  
                self.preview_frame.set_label(get_string("preview"))

            # Actualizar botones principales
            if hasattr(self, 'close_button'):
                self.close_button.set_label(get_string("close_btn"))
            if hasattr(self, 'generate_button'):
                self.generate_button.set_label(get_string("generate_btn"))
            if hasattr(self, 'add_dep_button'):
                self.add_dep_button.set_label(get_string("add_btn"))
            if hasattr(self, 'remove_dep_button'):
                self.remove_dep_button.set_label(get_string("remove_btn"))

            # Actualizar botones de búsqueda y selección
            if hasattr(self, 'file_button'):
                self.file_button.set_label(get_string("search_program"))
            if hasattr(self, 'icon_button'):
                self.icon_button.set_label(get_string("search_icon"))
            if hasattr(self, 'output_button'):
                self.output_button.set_label(get_string("select_btn"))

            # Actualizar botones en diálogos
            for widget in self.get_all_children():
                if isinstance(widget, Gtk.Button):
                    if isinstance(widget.get_parent(), Gtk.FileChooserDialog):
                        label = widget.get_label()
                        if "_Cancel" in label or "_Cancelar" in label:
                            widget.set_label(get_string("close_btn"))
                        elif "_Select" in label or "_Seleccionar" in label:
                            widget.set_label(get_string("select_btn"))
                        elif "_Open" in label or "_Abrir" in label:
                            widget.set_label(get_string("open"))

            # Forzar redibujado
            self.queue_draw()

        except Exception:
            # Silenciar errores de actualización de interfaz
            pass
            
    def get_all_children(self, widget=None):
        """Obtiene recursivamente todos los widgets hijos"""
        if widget is None:  # Corregido 'es' por 'is'
            widget = self
        if hasattr(widget, 'get_children'):
            children = widget.get_children()
            result = [widget]
            for child in children:
                result.extend(self.get_all_children(child))
            return result
        return [widget]

    def destroy(self, *args, **kwargs):
        """Limpia callbacks antes de cerrar"""
        if hasattr(self, 'locale_handler_id'):
            locale_manager.disconnect(self.locale_handler_id)
        super().destroy(*args, **kwargs)

from src.utils.dependency_checker import check_dependencies

def main():
    """Entry point for the application"""
    try:
        locale.setlocale(locale.LC_ALL, '')
    except locale.Error:
        pass

    app = Gtk.Application(
        application_id='com.soplos.packager'  # Usar el ID correcto
    )

    def on_activate(app):
        win = MainWindow(application=app)
        win.connect("destroy", lambda w: app.quit())  # Así es como se cierra bien
        win.show_all()
    
    app.connect('activate', on_activate)
    app.run(None)

if __name__ == "__main__":
    main()