"""Sistema de traducciones para Soplos Packager"""
import os
import locale
from gi.repository import GObject

# Importar todos los diccionarios de traducciones
from .translations import (
    SPANISH, ENGLISH, FRENCH, PORTUGUESE, 
    GERMAN, ITALIAN, ROMANIAN, RUSSIAN
)

# Actualizar WIDGET_IDS con todos los IDs necesarios
WIDGET_IDS = {
    'main_window': 'main-window',
    'language_box': 'language-box',
    'language_combo': 'language-combo',
    'language_label': 'language-label',
    'file_entry': 'file-entry',
    'file_button': 'file-button',
    'program_button': 'program-button',  # Añadido este ID
    'icon_entry': 'icon-entry',
    'icon_button': 'icon-button',
    'icon_preview': 'icon-preview',
    'program_entry': 'file-entry',  # Alias para mantener compatibilidad
    'package_name_entry': 'package-name-entry',
    'version_entry': 'version-entry',
    'description_entry': 'description-entry',
    'maintainer_box': 'maintainer-box',
    'maintainer_label': 'maintainer-label',
    'maintainer_name': 'maintainer-name',
    'maintainer_email': 'maintainer-email',
    'output_entry': 'output-entry',
    'output_button': 'output-button',
    'deps_frame': 'deps-frame',
    'deps_view': 'deps-view',
    'deps_scroll': 'deps-scroll',
    'dep_entry': 'dep-entry',
    'add_dep_button': 'add-dep-button',
    'remove_dep_button': 'remove-dep-button',
    'preview_frame': 'preview-frame',
    'preview_label': 'preview-label',
    'button_box': 'button-box',
    'close_button': 'close-button',
    'generate_button': 'generate-button',
    'spinner': 'spinner',
    'app_id_prefix_label': 'app_id_prefix',
    'app_id_prefix_entry': 'enter_app_id_prefix'
}

LANGUAGE_NAMES = {
    'es': 'Español',
    'en': 'English',
    'fr': 'Français',
    'de': 'Deutsch',
    'pt': 'Português',
    'it': 'Italiano',
    'ro': 'Română',
    'ru': 'Русский'
}

TRANSLATIONS = {
    'es': SPANISH,
    'en': ENGLISH,
    'fr': FRENCH,
    'de': GERMAN,
    'pt': PORTUGUESE,
    'it': ITALIAN,
    'ro': ROMANIAN,
    'ru': RUSSIAN
}

class LocaleManager(GObject.GObject):
    """Gestiona el idioma y las traducciones"""
    __gsignals__ = {
        'language-changed': (GObject.SignalFlags.RUN_FIRST, None, ())
    }

    def __init__(self):
        GObject.GObject.__init__(self)
        self.current_lang = self._detect_system_language()
        
    def _detect_system_language(self):
        """Detecta el idioma del sistema"""
        try:
            # Primero intentar LANGUAGE
            lang = os.getenv('LANGUAGE')
            if lang:
                lang_code = lang.split(':')[0].split('_')[0].lower()
                if lang_code in LANGUAGE_NAMES:
                    return lang_code
            
            # Luego intentar LC_ALL y LANG
            for env_var in ('LC_ALL', 'LANG'):
                lang = os.getenv(env_var)
                if lang:
                    lang_code = lang.split('_')[0].lower()
                    if lang_code in LANGUAGE_NAMES:
                        return lang_code
            
            # Finalmente usar locale
            current_locale = locale.getlocale()[0]
            if current_locale:
                lang_code = current_locale.split('_')[0].lower()
                if lang_code in LANGUAGE_NAMES:
                    return lang_code
                    
        except Exception as e:
            print(f"Error detectando idioma: {e}")
            
        return 'en'

    def get_string(self, key):
        """Obtiene la traducción de una cadena con fallback inteligente"""
        try:
            # Primero intentar con el idioma actual
            if self.current_lang in TRANSLATIONS and key in TRANSLATIONS[self.current_lang]:
                return TRANSLATIONS[self.current_lang][key]
                
            # Si el idioma actual no tiene la traducción, usar inglés
            if key in TRANSLATIONS['en']:
                return TRANSLATIONS['en'][key]
                
            # Si no está en inglés, intentar con español
            if key in TRANSLATIONS['es']:
                return TRANSLATIONS['es'][key]
                
            # Si no se encuentra, devolver la clave silenciosamente
            return key
            
        except Exception as e:
            # En caso de error, imprimir y devolver la clave
            print(f"Error obteniendo traducción para '{key}': {e}")
            return key

    def set_language(self, lang):
        """Cambia el idioma actual con validación"""
        if lang not in LANGUAGE_NAMES:
            return False
            
        if lang == self.current_lang:
            return False
            
        self.current_lang = lang
        self.emit('language-changed')
        return True

    def get_language_name(self, lang_code):
        """Obtiene el nombre del idioma"""
        return LANGUAGE_NAMES.get(lang_code, lang_code)

# Instancia global del gestor de traducciones
locale_manager = LocaleManager()

# Funciones helper
def get_string(key):
    return locale_manager.get_string(key)

def set_language(lang):
    return locale_manager.set_language(lang)

def get_current_language():
    return locale_manager.current_lang

def get_available_languages():
    return LANGUAGE_NAMES

def get_language_name(lang_code):
    return locale_manager.get_language_name(lang_code)

# Agregar función para obtener la traducción con fallback a español o inglés
def get_translation(key, lang=None):
    """Obtener traducción con fallback inteligente"""
    if not lang:
        lang = get_system_language()
    
    try:
        # Intentar obtener del idioma solicitado
        if lang in TRANSLATIONS and key in TRANSLATIONS[lang]:
            return TRANSLATIONS[lang][key]
        
        # Fallback a inglés
        if key in TRANSLATIONS['en']:
            return TRANSLATIONS['en'][key]
        
        # Fallback a español
        if key in TRANSLATIONS['es']:
            return TRANSLATIONS['es'][key]
            
    except Exception as e:
        print(f"Error en get_translation('{key}', '{lang}'): {e}")
    
    # Si no hay traducción, devolver la clave
    return key

def get_system_language() -> str:
    """Detecta el idioma del sistema y retorna el código correspondiente"""
    try:
        # Primero intentar LANGUAGE que es más específico
        lang = os.getenv('LANGUAGE')
        if lang:
            lang_code = lang.split(':')[0].split('_')[0].lower()
            if lang_code in LANGUAGE_NAMES:
                return lang_code
        
        # Luego intentar LC_ALL
        lang = os.getenv('LC_ALL')
        if lang:
            lang_code = lang.split('_')[0].lower()
            if lang_code in LANGUAGE_NAMES:
                return lang_code
        
        # Luego LANG
        lang = os.getenv('LANG')
        if lang:
            lang_code = lang.split('_')[0].lower()
            if lang_code in LANGUAGE_NAMES:
                return lang_code
        
        # Finalmente usar locale
        try:
            current_locale = locale.getlocale()[0] or locale.getdefaultlocale()[0]
            if current_locale:
                lang_code = current_locale.split('_')[0].lower()
                if lang_code in LANGUAGE_NAMES:
                    return lang_code
        except:
            pass

    except Exception as e:
        print(f"Error detectando idioma del sistema: {e}")
    
    # Si todo falla, usar inglés por defecto
    return 'en'

def verify_translations():
    """Verifica que todas las claves existan en todos los idiomas"""
    # Esta función solo se usa durante el desarrollo
    pass

def analyze_translations():
    """Analiza y verifica las traducciones"""
    # Esta función solo se usa durante el desarrollo
    pass
