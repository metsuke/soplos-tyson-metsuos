# Usar el validador en lugar del unifier
from src.utils.id_unifier import IdValidator

# ...existing code...

class PackageBuilder:
    # ...existing code...
    
    def build_package(self, app_name, version, *args, prefix="", **kwargs):
        """
        Construye el paquete con los parámetros especificados
        
        Args:
            app_name (str): Nombre de la aplicación
            version (str): Versión del paquete
            prefix (str): Prefijo para el ID de la aplicación (ej. 'com')
            *args, **kwargs: Otros parámetros necesarios para la construcción
        """
        # ...existing code para preparar el paquete...
        
        # Crear directorio temporal para la construcción
        build_dir = self._create_temp_build_dir()
        
        # ...existing code para copiar archivos...
        
        # En lugar de unificar, solo verificar la consistencia si se especifica un app_id
        if prefix:
            try:
                app_id = f"{prefix}.{app_name.lower().replace('-', '')}"
                print(f"Verificando consistencia de IDs con app_id: {app_id}")
                validator = IdValidator(app_name, app_id)
                results = validator.verify_all(build_dir)
                if not results['valid']:
                    print("ADVERTENCIA: Problemas de consistencia encontrados:")
                    for issue in results['issues']:
                        print(f"  • {issue}")
            except Exception as e:
                print(f"Error al verificar IDs: {e}")
        
        # ...existing code para finalizar la construcción del paquete...