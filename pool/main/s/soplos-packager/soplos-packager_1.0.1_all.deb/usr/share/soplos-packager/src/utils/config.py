"""
Módulo para manejar la configuración persistente de Soplos Packager
"""
import os
import json
from pathlib import Path

CONFIG_DIR = os.path.expanduser("~/.config/soplos-packager")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

# Estructura de configuración por defecto
DEFAULT_CONFIG = {
    "maintainer": {
        "name": "",
        "email": ""
    },
    "last_output_dir": "",
    "last_project_dir": "",
    "language": ""
}


def ensure_config_dir():
    """Asegura que el directorio de configuración exista"""
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR, exist_ok=True)


def load_config():
    """Carga la configuración desde el archivo, o crea un archivo con valores por defecto"""
    ensure_config_dir()
    
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                
            # Asegurar que la configuración tiene todos los campos necesarios
            for key, value in DEFAULT_CONFIG.items():
                if key not in config:
                    config[key] = value
                    
            return config
        except Exception as e:
            print(f"Error al cargar la configuración: {e}")
    
    # Si no existe el archivo o hay error, crear uno nuevo con valores por defecto
    save_config(DEFAULT_CONFIG)
    return DEFAULT_CONFIG.copy()


def save_config(config):
    """Guarda la configuración en el archivo"""
    ensure_config_dir()
    
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        print(f"Error al guardar la configuración: {e}")
        return False


def update_config(key, value):
    """Actualiza un valor específico en la configuración"""
    config = load_config()
    
    # Manejo especial para datos anidados
    if isinstance(value, dict) and key in config and isinstance(config[key], dict):
        config[key].update(value)
    else:
        config[key] = value
    
    return save_config(config)


def get_config_value(key, default=None):
    """Obtiene un valor específico de la configuración"""
    config = load_config()
    return config.get(key, default)
