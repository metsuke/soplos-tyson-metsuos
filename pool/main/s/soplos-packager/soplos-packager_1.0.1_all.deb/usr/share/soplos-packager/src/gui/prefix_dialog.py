import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

class PrefixDialog(Gtk.Dialog):
    def __init__(self, parent):
        Gtk.Dialog.__init__(
            self, title="Configurar prefijo", transient_for=parent, flags=0
        )
        self.set_default_size(350, 200)
        
        # Crear área para contenido
        box = self.get_content_area()
        
        # Crear etiqueta explicativa
        label = Gtk.Label(
            label="Especifica un prefijo para la aplicación (ej. 'com').\n\n" +
                  "Esto actualizará automáticamente todos los IDs en\n" +
                  "desktop files, metainfo.xml e iconos para asegurar\n" +
                  "que la aplicación se muestre correctamente en el dock."
        )
        box.add(label)
        
        # Crear campo de entrada
        self.prefix_entry = Gtk.Entry()
        self.prefix_entry.set_placeholder_text("Prefijo (ej. com)")
        box.add(self.prefix_entry)
        
        # Botones
        self.add_button(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL)
        self.add_button(Gtk.STOCK_OK, Gtk.ResponseType.OK)
        
        self.show_all()
        
    def get_prefix(self):
        return self.prefix_entry.get_text()
