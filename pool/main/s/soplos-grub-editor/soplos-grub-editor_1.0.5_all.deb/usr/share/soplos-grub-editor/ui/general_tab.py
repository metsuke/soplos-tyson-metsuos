#!/usr/bin/env python3
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import os
from translations.strings import TRANSLATIONS

def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

class GeneralTab:
    def __init__(self, parent):
        self.parent = parent
        self.grub_config = parent.grub_config
        
        # Contenedor para la pestaña
        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.content.set_border_width(10)
        
        # Crear los widgets
        self._create_widgets()
        
        # Cargar la configuración actual
        self._load_config()
    
    def get_content(self):
        """Devolver el contenedor principal de esta pestaña"""
        return self.content
    
    def _create_widgets(self):
        """Crear los widgets de la pestaña"""
        # Tiempo de espera
        timeout_box = Gtk.Box(spacing=6)
        timeout_label = Gtk.Label(label=_('timeout_label'))
        self.timeout_spin = Gtk.SpinButton()
        self.timeout_spin.set_range(0, 60)
        self.timeout_spin.set_increments(1, 5)
        self.timeout_spin.set_value(5)
        timeout_box.pack_start(timeout_label, False, False, 0)
        timeout_box.pack_start(self.timeout_spin, False, False, 0)
        
        # Entrada predeterminada (cambiado a ComboBox)
        default_box = Gtk.Box(spacing=6)
        default_label = Gtk.Label(label=_('default_entry_label'))
        
        # Crear el modelo y el combo para las entradas
        self.default_entry_store = Gtk.ListStore(str, str)  # id, nombre
        self.default_entry_combo = Gtk.ComboBox.new_with_model(self.default_entry_store)
        renderer = Gtk.CellRendererText()
        self.default_entry_combo.pack_start(renderer, True)
        self.default_entry_combo.add_attribute(renderer, "text", 1)
        
        default_box.pack_start(default_label, False, False, 0)
        default_box.pack_start(self.default_entry_combo, True, True, 0)
        
        # Resolución de pantalla (modificado a ComboBox)
        resolution_box = Gtk.Box(spacing=6)
        resolution_label = Gtk.Label(label=_('resolution_label'))
        
        # Lista de resoluciones comunes
        self.resolution_store = Gtk.ListStore(str, str)  # value, display_text
        self.resolution_store.append(["", _('resolution_disabled')])
        self.resolution_store.append(["auto", _('resolution_auto')])
        resolutions = [
            "640x480", "800x600", "1024x768", "1280x720", "1280x1024",
            "1366x768", "1440x900", "1600x900", "1680x1050", "1920x1080",
            "2560x1440", "3840x2160"
        ]
        for res in resolutions:
            self.resolution_store.append([res, res])
        
        self.resolution_combo = Gtk.ComboBox.new_with_model(self.resolution_store)
        renderer = Gtk.CellRendererText()
        self.resolution_combo.pack_start(renderer, True)
        self.resolution_combo.add_attribute(renderer, "text", 1)
        self.resolution_combo.set_active(0)  # Desactivado por defecto
        
        # Conectar señal de cambio para resolución
        self.resolution_combo.connect("changed", self.on_resolution_changed)
        
        resolution_box.pack_start(resolution_label, False, False, 0)
        resolution_box.pack_start(self.resolution_combo, True, True, 0)
        
        # Opciones avanzadas
        adv_frame = Gtk.Frame(label=_('advanced_options'))
        adv_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        adv_box.set_border_width(10)
        
        # Verificar SO predeterminado
        self.check_os_prober = Gtk.CheckButton(label=_('os_prober_label'))
        adv_box.pack_start(self.check_os_prober, False, False, 0)
        
        # Mostrar menú
        self.check_show_menu = Gtk.CheckButton(label=_('show_menu_label'))
        adv_box.pack_start(self.check_show_menu, False, False, 0)
        
        # Modo de recuperación
        self.check_recovery = Gtk.CheckButton(label=_('recovery_label'))
        adv_box.pack_start(self.check_recovery, False, False, 0)
        
        adv_frame.add(adv_box)
        
        # Kernel parameters
        kernel_frame = Gtk.Frame(label=_('kernel_params_section'))
        kernel_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        kernel_box.set_border_width(10)
        
        kernel_label = Gtk.Label(label=_('kernel_params_label'))
        self.kernel_entry = Gtk.Entry()
        
        kernel_box.pack_start(kernel_label, False, False, 0)
        kernel_box.pack_start(self.kernel_entry, False, False, 0)
        
        kernel_frame.add(kernel_box)
        
        # Agregar todo al contenedor principal
        self.content.pack_start(timeout_box, False, False, 0)
        self.content.pack_start(default_box, False, False, 0)
        self.content.pack_start(resolution_box, False, False, 0)
        self.content.pack_start(adv_frame, False, False, 0)
        self.content.pack_start(kernel_frame, False, False, 0)
    
    def _load_config(self):
        """Cargar la configuración actual en los widgets"""
        config = self.grub_config.config
        
        # Timeout
        if 'GRUB_TIMEOUT' in config:
            try:
                self.timeout_spin.set_value(int(config['GRUB_TIMEOUT']))
            except ValueError:
                pass
        
        # Default entry - Actualizar el combo con las entradas disponibles
        self.default_entry_store.clear()
        current_default = config.get('GRUB_DEFAULT', '0')
        
        # Añadir opción "saved"
        self.default_entry_store.append(["saved", _('last_selection')])  # Cambiado de "Última selección"
        
        # Añadir las entradas del sistema
        active_idx = 0
        for idx, entry in enumerate(self.grub_config.entries):
            entry_id = str(idx)
            self.default_entry_store.append([entry_id, entry["name"]])
            if current_default == entry_id:
                active_idx = idx + 1  # +1 porque "saved" es el índice 0
        
        self.default_entry_combo.set_active(active_idx)
        
        # Resolución (actualizado para ComboBox)
        active_idx = 0  # Por defecto "Desactivado"
        if 'GRUB_GFXMODE' in config:
            resolution = config['GRUB_GFXMODE']
            # Buscar el índice de la resolución en el modelo
            for idx, row in enumerate(self.resolution_store):
                if row[0] == resolution:
                    active_idx = idx
                    break
        self.resolution_combo.set_active(active_idx)
        
        # Advanced options
        self.check_os_prober.set_active('GRUB_DISABLE_OS_PROBER' not in config or 
                                        config['GRUB_DISABLE_OS_PROBER'] != 'true')
        
        self.check_show_menu.set_active('GRUB_HIDDEN_TIMEOUT' not in config)
        
        self.check_recovery.set_active('GRUB_DISABLE_RECOVERY' not in config or 
                                      config['GRUB_DISABLE_RECOVERY'] != 'true')
        
        # Kernel parameters
        if 'GRUB_CMDLINE_LINUX_DEFAULT' in config:
            self.kernel_entry.set_text(config['GRUB_CMDLINE_LINUX_DEFAULT'])
    
    def on_resolution_changed(self, combo):
        """Manejar el cambio de resolución - Solo actualizar en memoria"""
        iter = combo.get_active_iter()
        if iter is not None:
            resolution_value = self.resolution_store[iter][0]
            if not resolution_value:  # Si está "Desactivado"
                # Solo eliminar de la configuración en memoria
                if 'GRUB_GFXMODE' in self.grub_config.config:
                    del self.grub_config.config['GRUB_GFXMODE']
            else:
                # Solo actualizar la configuración en memoria
                self.grub_config.config['GRUB_GFXMODE'] = resolution_value
            
            # NO GUARDAR - solo actualizar en memoria

    def update_config(self):
        """Actualizar la configuración con los valores de los widgets"""
        config = self.grub_config.config
        modified = False

        # Timeout
        config['GRUB_TIMEOUT'] = str(int(self.timeout_spin.get_value()))
        
        # Default entry
        iter = self.default_entry_combo.get_active_iter()
        if iter is not None:
            entry_id = self.default_entry_store[iter][0]
            config['GRUB_DEFAULT'] = entry_id
        
        # Resolución (actualizado para ComboBox)
        iter = self.resolution_combo.get_active_iter()
        if iter is not None:
            resolution_value = self.resolution_store[iter][0]
            if resolution_value:  # Si no está vacío (desactivado)
                config['GRUB_GFXMODE'] = resolution_value
            elif 'GRUB_GFXMODE' in config:
                del config['GRUB_GFXMODE']  # Eliminar si está desactivado
        
        # Advanced options
        if self.check_os_prober.get_active():
            if 'GRUB_DISABLE_OS_PROBER' in config:
                del config['GRUB_DISABLE_OS_PROBER']
        else:
            config['GRUB_DISABLE_OS_PROBER'] = 'true'
        
        if self.check_show_menu.get_active():
            if 'GRUB_HIDDEN_TIMEOUT' in config:
                del config['GRUB_HIDDEN_TIMEOUT']
        else:
            config['GRUB_HIDDEN_TIMEOUT'] = '0'
        
        if self.check_recovery.get_active():
            if 'GRUB_DISABLE_RECOVERY' in config:
                del config['GRUB_DISABLE_RECOVERY']
        else:
            config['GRUB_DISABLE_RECOVERY'] = 'true'
        
        # Kernel parameters
        config['GRUB_CMDLINE_LINUX_DEFAULT'] = self.kernel_entry.get_text()
        
        if modified:
            self.grub_config.save_config()