import os
import subprocess
import logging
import tempfile
import shutil
from pathlib import Path
import gi

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gtk, Gdk
from .system_utils import update_grub_config

# Importar sistema de traducciones
from translations.strings import TRANSLATIONS

# Obtener el idioma del sistema
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

# Configurar el sistema de logging
logging.basicConfig(
    level=logging.ERROR,
    format='%(levelname)s: %(message)s'
)
logger = logging.getLogger(__name__)

# Constantes
GRUB_FONT_KEY = "GRUB_FONT"

# Funciones de utilidad y validación
def check_permissions():
    """Verificar permisos de superusuario"""
    try:
        if os.geteuid() != 0:
            logger.error("Se requieren privilegios de administrador")
            return False
        return True
    except Exception as e:
        logger.error(f"Error al verificar permisos: {str(e)}")
        return False

def is_valid_font_file(font_path):
    """Verificar si el archivo es una fuente válida"""
    try:
        valid_extensions = {'.ttf', '.otf', '.pf2'}
        return Path(font_path).suffix.lower() in valid_extensions
    except Exception as e:
        logger.error(f"Error al validar el archivo de fuente: {str(e)}")
        return False

def restore_backup(config_manager=None):
    """Restaurar la última copia de seguridad"""
    try:
        if not check_permissions():
            return False, _('need_root')

        if config_manager is None:
            config_manager = GrubConfigManager()
        
        backup_path = f"{config_manager.grub_config_path}.bak"
        if not os.path.exists(backup_path):
            logger.error(_('no_backup_to_restore'))
            return False, _('no_backup_to_restore')
            
        shutil.copy2(backup_path, config_manager.grub_config_path)
        logger.info(_('config_restored_successfully'))
        
        # Recargar la configuración
        config_manager.load_config()
        
        # Actualizar GRUB
        result = subprocess.run(["update-grub"], capture_output=True, text=True)
        if result.returncode != 0:
            return False, f"Error al actualizar GRUB: {result.stderr}"
            
        return True, _('config_restored_successfully')
    except Exception as e:
        logger.error(f"Error al restaurar la copia de seguridad: {str(e)}")
        return False, str(e)

class GrubConfigManager:
    def __init__(self, grub_config_path="/etc/default/grub"):
        self.grub_config_path = grub_config_path
        self.config = {}
        self.config_lines = []
        # Definir la clave de fuente
        self.font_key = GRUB_FONT_KEY
        self.load_config()

    def load_config(self):
        """Cargar la configuración de GRUB desde el archivo"""
        try:
            with open(self.grub_config_path, 'r', encoding='utf-8') as f:
                self.config_lines = f.readlines()
            
            for line in self.config_lines:
                stripped_line = line.strip()
                if stripped_line and not stripped_line.startswith('#'):
                    if '=' in stripped_line:
                        key, value = stripped_line.split('=', 1)
                        self.config[key.strip()] = value.strip().strip('"\'')
                        
            logging.info(f"Configuración cargada desde {self.grub_config_path}")
            return True
        except Exception as e:
            logging.error(f"Error al cargar la configuración: {str(e)}")
            return False

    def save_config(self):
        """Guardar la configuración de GRUB preservando la estructura"""
        try:
            new_lines = []
            modified_keys = set(self.config.keys())
            
            for line in self.config_lines:
                original_line = line
                stripped_line = line.strip()
                
                if stripped_line and not stripped_line.startswith('#') and '=' in stripped_line:
                    key = stripped_line.split('=', 1)[0].strip()
                    
                    if key in self.config:
                        value = self.config[key]
                        # Manejo mejorado para GRUB_FONT
                        if key == GRUB_FONT_KEY:
                            # Limpiar cualquier comilla existente y añadir nuevas
                            clean_value = value.strip('"').strip("'")
                            value = f'"{clean_value}"'
                            new_lines.append(f"{key}={value}\n")
                        else:
                            # Mantener el formato original para otras claves
                            if not value.startswith('"'):
                                value = f'"{value}"'
                            new_lines.append(f"{key}={value}\n")
                        modified_keys.discard(key)
                    else:
                        new_lines.append(original_line)
                else:
                    new_lines.append(line)
            
            # Añadir nuevas configuraciones
            if modified_keys:
                if new_lines and new_lines[-1].strip():
                    new_lines.append("\n")
                for key in modified_keys:
                    value = self.config[key]
                    if key == GRUB_FONT_KEY:
                        clean_value = value.strip('"').strip("'")
                        new_lines.append(f'{key}="{clean_value}"\n')
                    else:
                        new_lines.append(f'{key}="{value}"\n')
            
            # Crear copia de seguridad antes de guardar
            if os.path.exists(self.grub_config_path):
                backup_path = f"{self.grub_config_path}.bak"
                shutil.copy2(self.grub_config_path, backup_path)
            
            with open(self.grub_config_path, 'w') as f:
                f.writelines(new_lines)
            
            return True
        except Exception as e:
            logger.error(f"Error al guardar la configuración: {str(e)}")
            return False

    def _parse_grub_color(self, color_str):
        """Convertir un color de GRUB a Gdk.RGBA"""
        try:
            fg, bg = color_str.split('/')
            r, g, b = [int(fg[i:i+2], 16) for i in range(0, 6, 2)]
            return Gdk.RGBA(r/255.0, g/255.0, b/255.0, 1.0)
        except Exception as e:
            logging.warning(f"Error al parsear el color: {str(e)}")
            return None

def convert_font_for_grub(font_path, size=16):
    """
    Convierte una fuente TTF/OTF al formato de GRUB usando grub-mkfont.
    """
    try:
        if not check_permissions():
            return False, _('need_root')
            
        if not is_valid_font_file(font_path):
            return False, _('invalid_font_file')

        if not os.path.exists(font_path):
            return False, _('font_not_exists').format(font_path)

        font_name = os.path.basename(font_path).rsplit('.', 1)[0]
        output_path = f"/boot/grub/fonts/{font_name}_{size}.pf2"

        os.makedirs("/boot/grub/fonts", exist_ok=True)

        with tempfile.NamedTemporaryFile(delete=False, suffix='.pf2') as temp_file:
            temp_path = temp_file.name

        cmd = f"grub-mkfont --output={temp_path} --size={size} {font_path}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

        if result.returncode != 0:
            os.unlink(temp_path)
            return False, _('font_convert_error').format(result.stderr)

        move_cmd = f"sudo mv {temp_path} {output_path}"
        move_result = subprocess.run(move_cmd, shell=True, capture_output=True, text=True)

        if move_result.returncode != 0:
            os.unlink(temp_path)
            return False, _('font_install_error').format(move_result.stderr)

        chmod_cmd = f"sudo chmod 644 {output_path}"
        subprocess.run(chmod_cmd, shell=True)

        return True, output_path
    except Exception as e:
        logger.error(_('font_convert_exception').format(str(e)))
        return False, str(e)

def list_installed_grub_fonts():
    """
    Lista las fuentes instaladas para GRUB.
    """
    try:
        font_path = Path("/boot/grub/fonts")
        if not font_path.exists():
            return []

        return [str(f) for f in font_path.glob("*.pf2")]
    except Exception as e:
        logger.error(f"Error al listar fuentes: {str(e)}")
        return []

def set_grub_font(font_path, config_manager=None):
    """Configura una fuente para GRUB"""
    try:
        if not os.path.exists(font_path):
            return False, _('font_not_exists').format(font_path)

        if config_manager is None:
            config_manager = GrubConfigManager()

        config_manager.config[GRUB_FONT_KEY] = font_path

        if not config_manager.save_config():
            return False, _('config_save_error')

        success, message = update_grub_config()
        if not success:
            return False, _('grub_update_error').format(message)

        return True, _('font_applied_successfully')

    except Exception as e:
        logger.error(_('font_set_error').format(str(e)))
        return False, str(e)

def remove_grub_font(config_manager=None):
    """Elimina la configuración de fuente"""
    try:
        if config_manager is None:
            config_manager = GrubConfigManager()

        if GRUB_FONT_KEY in config_manager.config:
            del config_manager.config[GRUB_FONT_KEY]
            if config_manager.save_config():
                subprocess.run(["update-grub"])
                return True, _('font_removed_successfully')
            return False, _('config_save_error')
        return True, "No había fuente configurada"

    except Exception as e:
        logger.error(_('font_remove_error').format(str(e)))
        return False, str(e)

def delete_font_file(font_path):
    """Elimina físicamente un archivo de fuente de /boot/grub/fonts/"""
    try:
        if not check_permissions():
            return False, _('need_root')

        if not os.path.exists(font_path):
            return False, _('font_file_not_exists')

        if not font_path.startswith('/boot/grub/fonts/'):
            return False, _('font_not_in_grub_dir')

        if not font_path.endswith('.pf2'):
            return False, _('only_pf2_files_allowed')

        try:
            os.remove(font_path)
            logger.info(_('font_deleted').format(font_path))
            return True, _('font_deleted_successfully')
        except OSError as e:
            logger.error(_('font_delete_error').format(str(e)))
            return False, _('font_delete_error').format(str(e))

    except Exception as e:
        logger.error(_('font_delete_exception').format(str(e)))
        return False, str(e)