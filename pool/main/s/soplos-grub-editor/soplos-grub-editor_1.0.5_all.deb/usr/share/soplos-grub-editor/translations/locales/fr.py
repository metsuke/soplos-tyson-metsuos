"""
Traductions françaises pour Soplos GRUB Editor
"""

STRINGS = {
    # Titres et en-têtes
    'app_name': 'Soplos GRUB Editor',
    'general_tab': 'Configuration générale',
    'entries_tab': 'Entrées de démarrage',
    'appearance_tab': 'Apparence',
    
    # Boutons communs
    'save_button': 'Enregistrer',
    'apply_button': 'Appliquer',
    'close_button': 'Fermer',
    'cancel_button': 'Annuler',
    'ok_button': 'OK',
    
    # Titres des dialogues
    'error_title': 'Erreur',
    'info_title': 'Information',
    'warning_title': 'Avertissement',
    'confirm_title': 'Confirmer',
    'question_title': 'Question',
    
    # Messages généraux
    'changes_saved': 'Modifications enregistrées avec succès',
    'changes_error': 'Erreur lors de l\'enregistrement',
    'need_root': 'Privilèges administrateur requis',
    'confirm_exit': 'Voulez-vous vraiment quitter ?',
    'unsaved_changes': 'Les modifications non sauvegardées seront perdues.',
    
    # Onglet Général
    'timeout_label': 'Délai d\'attente (secondes) :',
    'default_entry_label': 'Entrée par défaut :',
    'resolution_label': 'Résolution de l\'écran :',
    'kernel_params_label': 'Paramètres du noyau :',
    'os_prober_label': 'Détecter d\'autres systèmes d\'exploitation',
    'show_menu_label': 'Afficher le menu de démarrage',
    'recovery_label': 'Inclure les options de récupération',
    'advanced_options': 'Options avancées',
    'kernel_params_section': 'Paramètres du noyau',
    
    # Onglet Apparence
    'theme_section': 'Thème',
    'font_section': 'Polices',
    'colors_section': 'Couleurs',
    'background_section': 'Arrière-plan',
    'preview_label': 'Aperçu',
    'install_theme': 'Installer le thème...',
    'remove_theme': 'Supprimer le thème',
    'disable_theme': 'Désactiver le thème',
    'select_font': 'Sélectionner la police...',
    'remove_font': 'Supprimer la police',
    'font_size': 'Taille de la police :',
    'text_color': 'Couleur du texte :',
    'background_color': 'Couleur de l\'arrière-plan :',
    'select_background': 'Sélectionner l\'arrière-plan...',
    'remove_background': 'Supprimer l\'arrière-plan',
    'highlight_text_color': 'Couleur du texte en surbrillance :',
    'highlight_background_color': 'Couleur de l\'arrière-plan en surbrillance :',
    'apply_theme_button': 'Appliquer le thème',
    
    # Onglet Entrées
    'add_entry': 'Ajouter une entrée',
    'edit_entry': 'Modifier l\'entrée',
    'remove_entry': 'Supprimer l\'entrée',
    'entry_name': 'Nom :',
    'entry_type': 'Type :',
    'entry_kernel': 'Noyau :',
    'entry_initrd': 'Initrd :',
    'entry_params': 'Paramètres :',
    'entry_path': 'Chemin',
    'entry_enabled': 'Activé',
    
    # Messages de statut
    'ready': 'Prêt',
    'saving': 'Enregistrement...',
    'applying': 'Application des modifications...',
    'loading': 'Chargement...',
    'updating': 'Mise à jour de GRUB...',
    'grub_updated': 'GRUB mis à jour avec succès',
    
    # Dialogues spécifiques
    'select_font_dialog': 'Sélectionner la police',
    'select_theme_dialog': 'Sélectionner le thème',
    'select_background_dialog': 'Sélectionner l\'image de fond',
    'font_filter': 'Polices',
    'theme_filter': 'Fichiers de thème',
    'image_filter': 'Images',
    'all_files': 'Tous les fichiers',
    'open_button': 'Ouvrir',
    
    # Textes de résolution
    'resolution_disabled': 'Désactivé',
    'resolution_auto': 'Automatique',
    
    # Textes des entrées
    'last_selection': 'Dernière sélection',
    'default_entry_saved': 'Dernière sélection',
    
    # Aide et contrôles de police
    'font_help': 'Cette méthode évite les problèmes avec update-grub en modifiant directement la configuration.',
    'font_select_help': 'Sélectionnez un fichier de police TTF ou OTF',
    'browse_button': 'Parcourir...',
    'install_font_button': 'Installer la police',
    'apply_font_button': 'Appliquer la police sélectionnée',
    'remove_font_button': 'Supprimer la police sélectionnée',
    'delete_font_file_button': 'Supprimer le fichier',
    
    # Avertissements et confirmations
    'delete_font_confirm': 'Êtes-vous sûr de vouloir supprimer cette police ?',
    'delete_font_warning': 'Le fichier sera supprimé : {}\nCette action ne peut pas être annulée.',
    'apply_font_confirm': 'Voulez-vous appliquer cette police ?',
    'apply_font_message': 'La police sera appliquée : {}',
    'remove_theme_confirm': 'Supprimer le thème \'{}\' ?',
    'disable_theme_confirm': 'Voulez-vous supprimer le thème actuel ?',
    'disable_theme_message': 'Le thème sera désactivé mais ne sera pas supprimé du système',
    'update_grub_title': 'Mettre à jour GRUB',
    'update_grub_message': 'update-grub sera exécuté pour appliquer les modifications.',
    'apply_changes_title': 'Appliquer les modifications ?',
    'apply_changes_message': 'update-grub sera exécuté pour appliquer les modifications.',
    
    # Messages de succès
    'font_installed': 'Police installée avec succès à : {}',
    'font_removed': 'Police supprimée avec succès',
    'font_removed_successfully': 'Police supprimée avec succès',
    'font_deleted_successfully': 'Police supprimée avec succès',
    'font_applied_successfully': 'Police appliquée avec succès',
    'theme_installed': 'Thème installé avec succès',
    'theme_applied': 'Thème appliqué avec succès',
    'grub_theme_applied': 'Thème GRUB appliqué avec succès',
    'background_applied': 'Fond d\'écran configuré avec succès',
    'background_removed': 'Fond d\'écran supprimé avec succès',
    'entry_added': 'Entrée ajoutée avec succès',
    'entry_removed': 'Entrée supprimée avec succès',
    'changes_applied': 'Modifications appliquées avec succès',
    'config_saved_successfully': 'Configuration sauvegardée avec succès dans custom.cfg',
    
    # Messages d'erreur
    'error_save': 'Erreur lors de l\'enregistrement de la configuration',
    'error_load': 'Erreur lors du chargement de la configuration',
    'error_apply': 'Erreur lors de l\'application des modifications',
    'error_update': 'Erreur lors de la mise à jour de GRUB',
    'error_permission': 'Erreur de permission',
    'error_missing_deps': 'Dépendances requises manquantes',
    'invalid_font': 'Veuillez sélectionner un fichier de police valide',
    'font_error': 'Erreur lors de l\'installation de la police : {}',
    'theme_error': 'Erreur lors de l\'installation du thème : {}',
    'background_error': 'Erreur lors du chargement de l\'image : {}',
    'entry_error': 'Erreur lors de l\'ajout de l\'entrée : {}',
    'entry_add_error': 'Erreur lors de l\'ajout de l\'entrée',
    'entry_name_kernel_required': 'Le nom et le noyau sont obligatoires',
    'entry_remove_error': 'Erreur lors de la suppression de l\'entrée',
    'no_entry_selected': 'Aucune entrée sélectionnée',
    'no_font_installed': 'Aucune police installée dans GRUB',
    'no_background_configured': 'Aucun arrière-plan configuré',
    'config_save_error': 'Erreur lors de l\'enregistrement de la configuration',
    'config_save_error_path': 'Erreur lors de l\'enregistrement de la configuration dans {} : {}',
    'colors_cannot_be_same': 'La couleur du texte et la couleur de l\'arrière-plan ne peuvent pas être identiques.',
    'highlight_colors_cannot_be_same': 'La couleur du texte en surbrillance et la couleur de l\'arrière-plan en surbrillance ne peuvent pas être identiques.',
    
    # Erreurs spécifiques au système
    'pkexec_error': 'Erreur : Impossible d\'obtenir les privilèges d\'administrateur.',
    'relaunch_error': 'Erreur lors du redémarrage en tant que root : {}',
    'grub_config_not_found': 'Fichier de configuration GRUB introuvable',
    'insufficient_permissions': 'Permissions insuffisantes pour accéder à la configuration GRUB',
    'initialization_error': 'Erreur lors de l\'initialisation : {}',
    'update_grub_error': 'Erreur lors de l\'exécution d\'update-grub : {}',
    'cache_cleanup_error': 'Erreur lors du nettoyage du cache : {}',
    'background_remove_error': 'Erreur lors de la suppression de l\'arrière-plan : {}',
    'font_load_error': 'Erreur lors du chargement des polices installées : {}',
    
    # Confirmations de sortie
    'confirm_exit_title': 'Voulez-vous vraiment quitter ?',
    'confirm_exit_message': 'Les modifications non sauvegardées seront perdues.',
    
    # Erreurs de police
    'invalid_font_file': 'Le fichier n\'est pas une police valide',
    'font_not_exists': 'La police {} n\'existe pas',
    'font_convert_error': 'Erreur lors de la conversion de la police : {}',
    'font_install_error': 'Erreur lors de l\'installation de la police : {}',
    'font_convert_exception': 'Erreur lors de la conversion de la police : {}',
    'font_set_error': 'Erreur lors de la configuration de la police : {}',
    'font_remove_error': 'Erreur lors de la suppression de la police : {}',
    'font_file_not_exists': 'Le fichier de police n\'existe pas',
    'font_not_in_grub_dir': 'La police n\'est pas dans le répertoire des polices GRUB',
    'only_pf2_files_allowed': 'Seuls les fichiers de police .pf2 peuvent être supprimés',
    'font_deleted': 'Police supprimée : {}',
    'font_delete_error': 'Erreur lors de la suppression de la police : {}',
    'font_delete_exception': 'Erreur lors de la suppression de la police : {}',
    
    # Raccourcis clavier
    'shortcut_save': 'Ctrl+S',
    'shortcut_apply': 'Alt+A',
    'shortcut_close': 'Alt+C',
    'keyboard_shortcuts': 'Raccourcis clavier',
    'shortcut_titles': {
        'save': 'Enregistrer (Ctrl+S)',
        'apply': 'Appliquer (Alt+A)',
        'close': 'Fermer (Alt+C)',
        'browse': 'Parcourir (Alt+B)',
        'install': 'Installer (Alt+I)',
        'remove': 'Supprimer (Alt+R)',
        'delete': 'Supprimer (Suppr)',
        'add': 'Ajouter (Alt+N)',
        'edit': 'Modifier (Alt+E)'
    },
    
    # États du système
    'no_theme_selected': 'Aucun thème sélectionné',
    'theme_preview_error': 'Erreur lors de la génération de l\'aperçu du thème',
    'grub_theme_disabled': 'Thème GRUB désactivé',
    'custom_entry_saved': 'Entrée personnalisée sauvegardée',
    'system_entry': 'Entrée système',
    'custom_entry': 'Entrée personnalisée',
    'entries_loaded': 'Entrées chargées : {}',
    'grub_config_loaded': 'Configuration GRUB chargée',
    'backup_created': 'Sauvegarde créée',
    'backup_restored': 'Sauvegarde restaurée',
    'permission_denied': 'Permission refusée',
    'file_not_found': 'Fichier introuvable',
    'invalid_configuration': 'Configuration invalide',
    'theme_installation_success': 'Thème installé avec succès dans : {}',
    'theme_removal_success': 'Thème supprimé avec succès',
    'operation_completed': 'Opération terminée',
    'operation_failed': 'Opération échouée',
    
    # Messages techniques et de log (NOUVEAU)
    'log_levelname_message': '%(levelname)s: %(message)s',
    'icon_set_error': 'Erreur lors de la définition de l\'icône par nom : {}',
    'program_class_error': 'Erreur lors de la définition de program_class : {}',
    'directory_cleaned': 'Répertoire nettoyé : {}',
    'directory_clean_error': 'Erreur lors du nettoyage de {} : {}',
    
    # Messages de utils/theme_utils.py (NOUVEAU)
    'file_format_not_supported': 'Format de fichier non pris en charge. Utilisez .tar.gz, .tgz, .tar.xz ou .zip',
    'theme_directory_invalid': 'Le répertoire du thème ne contient pas theme.txt',
    'invalid_path': 'Le chemin spécifié n\'est pas valide',
    'theme_disabled_successfully': 'Thème désactivé avec succès',
    'theme_preview_generation_error': 'Impossible de générer l\'aperçu : {}',
    'theme_txt_not_found': 'theme.txt introuvable',
    'theme_decompress_error': 'Erreur lors de la décompression du thème : {}',
    'theme_preview_generation_failed': 'Impossible de générer l\'aperçu',
    
    # Messages de utils/system_utils.py (NOUVEAU)
    'font_path_not_exists': 'La police {} n\'existe pas',
    'font_convert_stderr': 'Erreur lors de la conversion de la police : {}',
    'grub_config_updated': 'Configuration GRUB mise à jour avec succès',
    
    # Messages de utils/font_utils.py (NOUVEAU)
    'config_module_deprecated': 'Le module \'config\' est obsolète. Utilisez \'app_paths\' à la place.',
    'no_backup_to_restore': 'Aucune sauvegarde à restaurer',
    'config_restored_successfully': 'Configuration restaurée avec succès',
    
    # Commentaires de code généré (NOUVEAU)
    'disabled_by_soplos_grub_editor': '# Désactivé par Soplos GRUB Editor',
    'custom_grub_header': '#!/bin/sh\nexec tail -n +3 $0\n# Ce fichier fournit des entrées personnalisées pour GRUB\n\n',
}
