#!/usr/bin/env python3
import os
import re
import subprocess
import logging
import shutil
from datetime import datetime
from utils.system_utils import update_grub_config

# Importar sistema de traducciones
from translations.strings import TRANSLATIONS

# Obtener el idioma del sistema
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

class GrubConfig:
    """Clase para manejar la configuración de GRUB"""
    
    def __init__(self, config_path=None, entries_path=None, custom_entries_path=None):
        # Rutas a los archivos de configuración de GRUB
        self.grub_config_path = config_path or '/etc/default/grub'
        self.grub_entries_path = entries_path or '/boot/grub/grub.cfg'
        self.custom_entries_path = custom_entries_path or '/etc/grub.d/40_custom'
        
        # Valores predeterminados
        self.config = {}
        self.config_lines = []  # Para preservar comentarios y estructura
        self.entries = []
        self.custom_entries = []
        
        # Clave única para fuentes - eliminar la duplicación
        self.font_key = "GRUB_FONT"
        
        # Claves de configuración soportadas
        self.supported_keys = {
            self.font_key,
            "GRUB_DEFAULT",
            "GRUB_TIMEOUT",
            "GRUB_DISTRIBUTOR",
            "GRUB_CMDLINE_LINUX_DEFAULT",
            "GRUB_CMDLINE_LINUX"
        }
        
        # Configurar logging básico si no está configurado
        if not logging.getLogger().handlers:
            logging.basicConfig(
                level=logging.ERROR,
                format='%(levelname)s: %(message)s'
            )
        
        # Cargar la configuración
        self.load_config()
        self.load_entries()
    
    def load_config(self):
        """Cargar la configuración actual de GRUB preservando comentarios y estructura"""
        try:
            if os.path.exists(self.grub_config_path):
                with open(self.grub_config_path, 'r', encoding='utf-8') as f:
                    self.config_lines = f.readlines()
                
                # Extraer valores actuales sin perder la estructura
                for line in self.config_lines:
                    stripped_line = line.strip()
                    if stripped_line and not stripped_line.startswith('#'):
                        if ('=' in stripped_line):
                            key, value = stripped_line.split('=', 1)
                            # Eliminar comillas si están presentes
                            clean_value = value.strip().strip('"\'')
                            self.config[key.strip()] = clean_value
                logging.info(_('grub_config_loaded'))  # Usar traducción
                return True
            else:
                logging.error(_('file_not_found') + f": {self.grub_config_path}")  # Usar traducción
                return False
        except Exception as e:
            logging.error(_('error_load') + f": {str(e)}")  # Usar traducción
            return False
    
    def clean_config_lines(self):
        """Limpiar líneas duplicadas y comentadas innecesarias"""
        new_lines = []
        active_keys = set()
        last_was_empty = False
        
        # Primera pasada: mantener solo líneas únicas y comentarios importantes
        for line in self.config_lines:
            stripped = line.strip()
            
            # Manejar líneas vacías
            if not stripped:
                if not last_was_empty and new_lines:  # Evitar líneas vacías al inicio
                    new_lines.append(line)
                    last_was_empty = True
                continue
            last_was_empty = False
            
            # Ignorar líneas de configuración comentadas obsoletas
            if stripped.startswith('#') and '=' in stripped:
                key = stripped.split('=', 1)[0].strip('# ')
                if key in self.config:
                    continue
            
            # Procesar líneas de configuración activas
            if not stripped.startswith('#') and '=' in stripped:
                key = stripped.split('=', 1)[0].strip()
                if key in self.config:
                    if key not in active_keys:
                        value = self.config[key]
                        if not value.startswith('"'):
                            value = f'"{value}"'
                        new_lines.append(f"{key}={value}\n")
                        active_keys.add(key)
                    continue
            
            # Mantener otros comentarios y líneas
            new_lines.append(line)
        
        # Añadir configuraciones faltantes
        missing_keys = set(self.config.keys()) - active_keys
        if missing_keys:
            if new_lines and not new_lines[-1].strip():
                new_lines.pop()  # Eliminar última línea vacía si existe
            new_lines.append("\n")  # Añadir una línea vacía antes de las nuevas configuraciones
            
            for key in sorted(missing_keys):  # Ordenar las claves para consistencia
                value = self.config[key]
                if not value.startswith('"'):
                    value = f'"{value}"'
                new_lines.append(f"{key}={value}\n")
        
        # Asegurar que termine con una nueva línea
        if new_lines and not new_lines[-1].endswith('\n'):
            new_lines.append('\n')
        
        self.config_lines = new_lines
    
    def save_config(self):
        """Guardar la configuración SIN ejecutar update-grub"""
        try:
            # Limpiar configuración antes de guardar
            self.clean_config_lines()
            
            # Crear copia de seguridad
            if os.path.exists(self.grub_config_path):
                backup_path = f"{self.grub_config_path}.bak"
                shutil.copy2(self.grub_config_path, backup_path)
                logging.info(_('backup_created'))  # Usar traducción
            
            # Guardar la configuración limpia
            with open(self.grub_config_path, 'w') as f:
                f.writelines(self.config_lines)

            # NO ejecutar update-grub aquí
            return True
        except Exception as e:
            logging.error(_('error_save') + f": {str(e)}")  # Usar traducción
            return False
    
    def apply_changes(self):
        """Guardar la configuración Y ejecutar update-grub"""
        try:
            # Guardar la configuración primero
            if not self.save_config():
                return False
            
            # Ejecutar update-grub
            result = subprocess.run(['update-grub'], check=True, capture_output=True, text=True)
            if result.returncode != 0:
                logging.error(f"Error en update-grub: {result.stderr}")
                return False
                
            return True
        except Exception as e:
            logging.error(f"Error al aplicar cambios: {str(e)}")
            return False

    def load_entries(self):
        """Cargar las entradas de GRUB desde el archivo grub.cfg"""
        self.entries = []
        
        try:
            # Verificar si el archivo de entradas existe
            if not os.path.exists(self.grub_entries_path):
                logging.warning(_('file_not_found') + f": {self.grub_entries_path}")  # Usar traducción
                return False
            
            # Parsear el archivo grub.cfg para extraer las entradas de arranque
            current_entry = None
            with open(self.grub_entries_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    
                    # Buscar líneas que definen una nueva entrada
                    if line.startswith('menuentry '):
                        # Si hay una entrada anterior, guardarla
                        if current_entry:
                            self.entries.append(current_entry)
                        
                        # Extraer el nombre de la entrada (entre comillas)
                        name_match = re.search(r'menuentry [\'"](.+?)[\'"]', line)
                        if name_match:
                            entry_name = name_match.group(1)
                            current_entry = {
                                "name": entry_name,
                                "type": "system",
                                "path": "",
                                "enabled": True,
                                "full_entry": line
                            }
                    
                    # Buscar la ruta del kernel (linux /boot/...)
                    elif current_entry:
                        if line.startswith('linux '):
                            path_parts = line.split(' ')
                            if len(path_parts) > 1:
                                current_entry["path"] = path_parts[1]
                                # Guardar también los parámetros del kernel
                                if len(path_parts) > 2:
                                    current_entry["params"] = ' '.join(path_parts[2:])
                        
                        # Guardar también la línea initrd
                        elif line.startswith('initrd '):
                            path_parts = line.split(' ')
                            if len(path_parts) > 1:
                                current_entry["initrd"] = ' '.join(path_parts[1:])
            
            # Agregar la última entrada si existe
            if current_entry:
                self.entries.append(current_entry)
            
            # Cargar también las entradas personalizadas
            self.load_custom_entries()
            
            logging.info(_('entries_loaded').format(len(self.entries)))  # Usar traducción
            return True
        except Exception as e:
            logging.error(_('error_load') + f": {str(e)}")  # Usar traducción
            return False

    def load_custom_entries(self):
        """Cargar entradas personalizadas desde el archivo 40_custom"""
        try:
            # Verificar si el archivo de entradas personalizadas existe
            if not os.path.exists(self.custom_entries_path):
                logging.warning(f"El archivo de entradas personalizadas {self.custom_entries_path} no existe")
                return
            
            current_entry = None
            entry_lines = []
            in_entry = False
            
            with open(self.custom_entries_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line_stripped = line.strip()
                    
                    # Buscar líneas que definen una nueva entrada personalizada
                    if line_stripped.startswith('menuentry '):
                        # Si hay una entrada anterior, guardarla
                        if current_entry:
                            current_entry["content"] = "".join(entry_lines)
                            self.entries.append(current_entry)
                            self.custom_entries.append(current_entry)
                        
                        # Extraer el nombre de la entrada (entre comillas)
                        name_match = re.search(r'menuentry [\'"](.+?)[\'"]', line_stripped)
                        if name_match:
                            entry_name = name_match.group(1)
                            current_entry = {
                                "name": entry_name,
                                "type": "custom",
                                "path": "",
                                "initrd": "",
                                "params": "",
                                "enabled": True,
                                "full_entry": line
                            }
                            entry_lines = [line]
                            in_entry = True
                    
                    elif in_entry:
                        entry_lines.append(line)
                        
                        # Buscar la ruta del kernel (linux /boot/...)
                        if line_stripped.startswith('linux '):
                            path_parts = line_stripped.split(' ')
                            if len(path_parts) > 1:
                                current_entry["path"] = path_parts[1]
                                # Guardar también los parámetros del kernel
                                if len(path_parts) > 2:
                                    current_entry["params"] = ' '.join(path_parts[2:])
                        
                        # Buscar la línea initrd
                        elif line_stripped.startswith('initrd '):
                            path_parts = line_stripped.split(' ')
                            if len(path_parts) > 1:
                                current_entry["initrd"] = ' '.join(path_parts[1:])
                        
                        # Detectar fin de entrada
                        elif line_stripped == '}':
                            in_entry = False
            
            # Agregar la última entrada si existe
            if current_entry and not in_entry:
                current_entry["content"] = "".join(entry_lines)
                self.entries.append(current_entry)
                self.custom_entries.append(current_entry)
                
            logging.info(f"Cargadas {len(self.custom_entries)} entradas personalizadas de GRUB")
        except Exception as e:
            logging.error(f"Error al cargar entradas personalizadas: {str(e)}")

    def add_custom_entry(self, name, kernel, initrd='', params=''):
        """Añadir una entrada personalizada al archivo 40_custom"""
        try:
            # Verificar si el archivo existe, si no, crearlo
            if not os.path.exists(self.custom_entries_path):
                directory = os.path.dirname(self.custom_entries_path)
                if not os.path.exists(directory):
                    os.makedirs(directory)
                with open(self.custom_entries_path, 'w', encoding='utf-8') as f:
                    f.write(_('custom_grub_header'))
                logging.info(f"Creado nuevo archivo de entradas personalizadas {self.custom_entries_path}")
            
            # Construir el contenido de la entrada
            entry_content = f"menuentry '{name}' {{\n"
            entry_content += f"    linux {kernel} {params}\n"
            if initrd:
                entry_content += f"    initrd {initrd}\n"
            entry_content += "}\n"
            
            # Crear una nueva entrada para nuestras listas
            new_entry = {
                "name": name,
                "type": "custom",
                "path": kernel,
                "initrd": initrd,
                "params": params,
                "enabled": True,
                "content": entry_content
            }
            
            # Añadirla a las listas
            self.entries.append(new_entry)
            self.custom_entries.append(new_entry)
            
            # Actualizar el archivo 40_custom
            with open(self.custom_entries_path, 'a', encoding='utf-8') as f:
                # Aseguramos que haya una línea en blanco antes de añadir la entrada
                f.write("\n" + entry_content)
            
            logging.info(_('custom_entry_saved') + f": '{name}'")  # Usar traducción
            return True
        except Exception as e:
            logging.error(_('operation_failed') + f": {str(e)}")  # Usar traducción
            return False

    def remove_custom_entry(self, name):
        """Eliminar una entrada personalizada"""
        try:
            # Buscar la entrada en la lista
            entry_to_remove = None
            for entry in list(self.custom_entries):
                if entry["name"] == name:
                    entry_to_remove = entry
                    self.custom_entries.remove(entry)
                    if entry in self.entries:
                        self.entries.remove(entry)
            
            if not entry_to_remove:
                logging.warning(f"No se encontró ninguna entrada con el nombre '{name}'")
                return False
            
            # Reescribir el archivo 40_custom
            with open(self.custom_entries_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            new_lines = []
            skip_mode = False
            
            for line in lines:
                # Detectar inicio de entrada a eliminar
                if f"menuentry '{name}'" in line or f'menuentry "{name}"' in line:
                    skip_mode = True
                    continue
                
                # Detectar fin de entrada a eliminar
                if skip_mode and line.strip() == '}':
                    skip_mode = False
                    continue
                
                # Añadir línea si no estamos saltando una entrada
                if not skip_mode:
                    new_lines.append(line)
            
            with open(self.custom_entries_path, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)
            
            logging.info(f"Eliminada entrada personalizada '{name}' de {self.custom_entries_path}")
            return True
        except Exception as e:
            logging.error(f"Error al eliminar entrada personalizada: {str(e)}")
            return False

    def update_custom_entry(self, old_name, new_name, kernel=None, initrd=None, params=None):
        """Actualizar una entrada personalizada existente"""
        try:
            # Primero encontrar la entrada
            entry_found = False
            for entry in self.custom_entries:
                if entry["name"] == old_name:
                    entry_found = True
                    break
            
            if not entry_found:
                logging.warning(f"No se encontró la entrada '{old_name}' para actualizar")
                return False
            
            # Eliminar la entrada existente
            self.remove_custom_entry(old_name)
            
            # Obtener los valores actuales para los parámetros no especificados
            if kernel is None:
                kernel = entry.get("path", "")
            if initrd is None:
                initrd = entry.get("initrd", "")
            if params is None:
                params = entry.get("params", "")
            
            # Crear una nueva entrada con los valores actualizados
            return self.add_custom_entry(new_name, kernel, initrd, params)
        except Exception as e:
            logging.error(f"Error al actualizar entrada personalizada: {str(e)}")
            return False
            
    def apply_changes(self):
        """Aplicar los cambios ejecutando el método de actualización apropiado"""
        try:
            # Guardar la configuración primero
            if not self.save_config():
                return False
            
            # Usar el nuevo método de actualización
            success, message = update_grub_config()
            if not success:
                logging.error(message)
                return False
            
            logging.info("Cambios aplicados correctamente")
            return True
        except Exception as e:
            logging.error(f"Error al aplicar cambios: {str(e)}")
            return False

    def get_entry_by_name(self, name):
        """Obtener una entrada por su nombre"""
        for entry in self.entries:
            if entry["name"] == name:
                return entry
        return None

    def get_grub_setting(self, key, default=None):
        """Obtener un valor de configuración de GRUB"""
        return self.config.get(key, default)

    def set_grub_setting(self, key, value):
        """Establecer un valor de configuración de GRUB"""
        self.config[key] = value
        return True

    def get_default_entry(self):
        """Obtener la entrada predeterminada de GRUB"""
        try:
            default_setting = self.get_grub_setting("GRUB_DEFAULT", "0")
            
            # Si es un número, devolver la entrada correspondiente
            if default_setting.isdigit():
                index = int(default_setting)
                if 0 <= index < len(self.entries):
                    return self.entries[index]
                return None
            
            # Si es "saved", intentar obtener la última entrada guardada
            elif default_setting == "saved":
                return {"name": "saved", "type": "saved"}
            
            # Si es un nombre específico, buscar la entrada
            else:
                return self.get_entry_by_name(default_setting)
        except Exception as e:
            logging.error(f"Error al obtener la entrada predeterminada: {str(e)}")
            return None

    def set_default_entry(self, entry_name_or_index):
        """Establecer la entrada predeterminada de GRUB"""
        try:
            self.config["GRUB_DEFAULT"] = str(entry_name_or_index)
            logging.info(f"Entrada predeterminada actualizada a: {entry_name_or_index}")
            return True
        except Exception as e:
            logging.error(f"Error al establecer la entrada predeterminada: {str(e)}")
            return False

    def get_timeout(self):
        """Obtener el tiempo de espera de GRUB"""
        return self.get_grub_setting("GRUB_TIMEOUT", "5")

    def set_timeout(self, seconds):
        """Establecer el tiempo de espera de GRUB"""
        try:
            seconds_str = str(int(seconds))  # Asegurarse de que es un número entero válido
            self.config["GRUB_TIMEOUT"] = seconds_str
            logging.info(f"Tiempo de espera actualizado a: {seconds_str} segundos")
            return True
        except ValueError:
            logging.error(f"El valor de tiempo de espera debe ser un número entero: {seconds}")
            return False
        except Exception as e:
            logging.error(f"Error al establecer el tiempo de espera: {str(e)}")
            return False