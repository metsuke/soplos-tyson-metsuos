"""
English translations for Soplos GRUB Editor
"""

STRINGS = {
    # Titles and headers
    'app_name': 'Soplos GRUB Editor',
    'general_tab': 'General Settings',
    'entries_tab': 'Boot Entries',
    'appearance_tab': 'Appearance',
    
    # Common buttons
    'save_button': 'Save',
    'apply_button': 'Apply',
    'close_button': 'Close',
    'cancel_button': 'Cancel',
    'ok_button': 'OK',
    
    # Dialog titles
    'error_title': 'Error',
    'info_title': 'Information',
    'warning_title': 'Warning',
    'confirm_title': 'Confirm',
    'question_title': 'Question',
    
    # General messages
    'changes_saved': 'Changes saved successfully',
    'changes_error': 'Error saving changes',
    'need_root': 'Administrator privileges required',
    'confirm_exit': 'Are you sure you want to exit?',
    'unsaved_changes': 'Unsaved changes will be lost.',
    
    # General tab
    'timeout_label': 'Timeout (seconds):',
    'default_entry_label': 'Default entry:',
    'resolution_label': 'Screen resolution:',
    'kernel_params_label': 'Kernel parameters:',
    'os_prober_label': 'Detect other operating systems',
    'show_menu_label': 'Show boot menu',
    'recovery_label': 'Include recovery options',
    'advanced_options': 'Advanced Options',
    'kernel_params_section': 'Kernel Parameters',
    
    # Appearance tab
    'theme_section': 'Theme',
    'font_section': 'Fonts',
    'colors_section': 'Colors',
    'background_section': 'Background',
    'preview_label': 'Preview',
    'install_theme': 'Install theme...',
    'remove_theme': 'Remove theme',
    'disable_theme': 'Disable theme',
    'select_font': 'Select font...',
    'remove_font': 'Remove font',
    'font_size': 'Font size:',
    'text_color': 'Text color:',
    'background_color': 'Background color:',
    'select_background': 'Select background...',
    'remove_background': 'Remove background',
    'highlight_text_color': 'Highlight text color:',
    'highlight_background_color': 'Highlight background color:',
    'apply_theme_button': 'Apply theme',
    
    # Entries tab
    'add_entry': 'Add entry',
    'edit_entry': 'Edit entry',
    'remove_entry': 'Remove entry',
    'entry_name': 'Name:',
    'entry_type': 'Type:',
    'entry_kernel': 'Kernel:',
    'entry_initrd': 'Initrd:',
    'entry_params': 'Parameters:',
    'entry_path': 'Path',
    'entry_enabled': 'Enabled',
    
    # Status messages
    'ready': 'Ready',
    'saving': 'Saving...',
    'applying': 'Applying changes...',
    'loading': 'Loading...',
    'updating': 'Updating GRUB...',
    'grub_updated': 'GRUB successfully updated',
    
    # Specific dialogs
    'select_font_dialog': 'Select Font',
    'select_theme_dialog': 'Select Theme',
    'select_background_dialog': 'Select Background Image',
    'font_filter': 'Fonts',
    'theme_filter': 'Theme Files',
    'image_filter': 'Images',
    'all_files': 'All Files',
    'open_button': 'Open',
    
    # Resolution texts
    'resolution_disabled': 'Disabled',
    'resolution_auto': 'Automatic',
    
    # Entry texts
    'last_selection': 'Last Selection',
    'default_entry_saved': 'Last Selection',
    
    # Font help and controls
    'font_help': 'This method avoids issues with update-grub by directly modifying the configuration.',
    'font_select_help': 'Select a TTF or OTF font file',
    'browse_button': 'Browse...',
    'install_font_button': 'Install Font',
    'apply_font_button': 'Apply Selected Font',
    'remove_font_button': 'Remove Selected Font',
    'delete_font_file_button': 'Delete File',
    
    # Warnings and confirmations
    'delete_font_confirm': 'Are you sure you want to delete this font?',
    'delete_font_warning': 'The file will be deleted: {}\nThis action cannot be undone.',
    'apply_font_confirm': 'Do you want to apply this font?',
    'apply_font_message': 'The font will be applied: {}',
    'remove_theme_confirm': 'Remove the theme \'{}\'?',
    'disable_theme_confirm': 'Do you want to remove the current theme?',
    'disable_theme_message': 'The theme will be disabled but not removed from the system',
    'update_grub_title': 'Update GRUB',
    'update_grub_message': 'update-grub will be executed to apply the changes.',
    'apply_changes_title': 'Apply changes?',
    'apply_changes_message': 'update-grub will be executed to apply changes.',
    
    # Success messages
    'font_installed': 'Font installed successfully at: {}',
    'font_removed': 'Font removed successfully',
    'font_removed_successfully': 'Font removed successfully',
    'font_deleted_successfully': 'Font deleted successfully',
    'font_applied_successfully': 'Font applied successfully',
    'theme_installed': 'Theme installed successfully',
    'theme_applied': 'Theme applied successfully',
    'grub_theme_applied': 'GRUB theme applied successfully',
    'background_applied': 'Background set successfully',
    'background_removed': 'Background removed successfully',
    'entry_added': 'Entry added successfully',
    'entry_removed': 'Entry removed successfully',
    'changes_applied': 'Changes applied successfully',
    'config_saved_successfully': 'Configuration saved successfully in custom.cfg',
    
    # Error messages
    'error_save': 'Error saving configuration',
    'error_load': 'Error loading configuration',
    'error_apply': 'Error applying changes',
    'error_update': 'Error updating GRUB',
    'error_permission': 'Permission error',
    'error_missing_deps': 'Missing required dependencies',
    'invalid_font': 'Please select a valid font file',
    'font_error': 'Error installing the font: {}',
    'theme_error': 'Error installing the theme: {}',
    'background_error': 'Error loading the image: {}',
    'entry_error': 'Error adding the entry: {}',
    'entry_add_error': 'Error adding entry',
    'entry_name_kernel_required': 'Name and kernel are required',
    'entry_remove_error': 'Error removing entry',
    'no_entry_selected': 'No entry selected',
    'no_font_installed': 'No fonts installed in GRUB',
    'no_background_configured': 'No background is configured',
    'config_save_error': 'Error saving configuration',
    'config_save_error_path': 'Error saving configuration to {}: {}',
    'colors_cannot_be_same': 'Text color and background color cannot be the same.',
    'highlight_colors_cannot_be_same': 'Highlight text color and highlight background color cannot be the same.',
    
    # System-specific errors
    'pkexec_error': 'Error: Could not obtain administrator privileges.',
    'relaunch_error': 'Error relaunching as root: {}',
    'grub_config_not_found': 'GRUB configuration file not found',
    'insufficient_permissions': 'Insufficient permissions to access GRUB configuration',
    'initialization_error': 'Error during initialization: {}',
    'update_grub_error': 'Error executing update-grub: {}',
    'cache_cleanup_error': 'Error cleaning cache: {}',
    'background_remove_error': 'Error removing background: {}',
    'font_load_error': 'Error loading installed fonts: {}',
    
    # Exit confirmations
    'confirm_exit_title': 'Are you sure you want to exit?',
    'confirm_exit_message': 'Unsaved changes will be lost.',
    
    # Font errors
    'invalid_font_file': 'The file is not a valid font',
    'font_not_exists': 'The font {} does not exist',
    'font_convert_error': 'Error converting font: {}',
    'font_install_error': 'Error installing font: {}',
    'font_convert_exception': 'Error converting font: {}',
    'font_set_error': 'Error setting font: {}',
    'font_remove_error': 'Error removing font: {}',
    'font_file_not_exists': 'Font file does not exist',
    'font_not_in_grub_dir': 'Font is not in GRUB fonts directory',
    'only_pf2_files_allowed': 'Only .pf2 font files can be deleted',
    'font_deleted': 'Font deleted: {}',
    'font_delete_error': 'Error deleting font: {}',
    'font_delete_exception': 'Error deleting font: {}',
    
    # Keyboard shortcuts
    'shortcut_save': 'Ctrl+S',
    'shortcut_apply': 'Alt+A',
    'shortcut_close': 'Alt+C',
    'keyboard_shortcuts': 'Keyboard Shortcuts', 
    'shortcut_titles': {
        'save': 'Save (Ctrl+S)',
        'apply': 'Apply (Alt+A)',
        'close': 'Close (Alt+C)', 
        'browse': 'Browse (Alt+B)',
        'install': 'Install (Alt+I)',
        'remove': 'Remove (Alt+R)',
        'delete': 'Delete (Del)',
        'add': 'Add (Alt+N)',
        'edit': 'Edit (Alt+E)'
    },
    
    # System states
    'no_theme_selected': 'No theme selected',
    'theme_preview_error': 'Error generating theme preview',
    'grub_theme_disabled': 'GRUB theme disabled',
    'custom_entry_saved': 'Custom entry saved',
    'system_entry': 'System entry',
    'custom_entry': 'Custom entry',
    'entries_loaded': 'Entries loaded: {}',
    'grub_config_loaded': 'GRUB configuration loaded',
    'backup_created': 'Backup created',
    'backup_restored': 'Backup restored',
    'permission_denied': 'Permission denied',
    'file_not_found': 'File not found',
    'invalid_configuration': 'Invalid configuration',
    'theme_installation_success': 'Theme installed successfully at: {}',
    'theme_removal_success': 'Theme removed successfully',
    'operation_completed': 'Operation completed',
    'operation_failed': 'Operation failed',
    
    # Log and technical messages (NEW)
    'log_levelname_message': '%(levelname)s: %(message)s',
    'icon_set_error': 'Error setting icon by name: {}',
    'program_class_error': 'Error setting program_class: {}',
    'directory_cleaned': 'Directory cleaned: {}',
    'directory_clean_error': 'Error cleaning {}: {}',
    
    # Messages from utils/theme_utils.py (NEW)
    'file_format_not_supported': 'File format not supported. Use .tar.gz, .tgz, .tar.xz or .zip',
    'theme_directory_invalid': 'Theme directory does not contain theme.txt',
    'invalid_path': 'The specified path is not valid',
    'theme_disabled_successfully': 'Theme disabled successfully',
    'theme_preview_generation_error': 'Could not generate preview: {}',
    'theme_txt_not_found': 'theme.txt not found',
    'theme_decompress_error': 'Error decompressing theme: {}',
    'theme_preview_generation_failed': 'Could not generate preview',
    
    # Messages from utils/system_utils.py (NEW)
    'font_path_not_exists': 'Font {} does not exist',
    'font_convert_stderr': 'Error converting font: {}',
    'grub_config_updated': 'GRUB configuration updated successfully',
    
    # Messages from utils/font_utils.py (NEW)
    'config_module_deprecated': 'The \'config\' module is deprecated. Use \'app_paths\' instead.',
    'no_backup_to_restore': 'No backup exists to restore',
    'config_restored_successfully': 'Configuration restored successfully',
    
    # Generated code comments (NEW)
    'disabled_by_soplos_grub_editor': '# Disabled by Soplos GRUB Editor',
    'custom_grub_header': '#!/bin/sh\nexec tail -n +3 $0\n# This file provides custom entries for GRUB\n\n',
}
