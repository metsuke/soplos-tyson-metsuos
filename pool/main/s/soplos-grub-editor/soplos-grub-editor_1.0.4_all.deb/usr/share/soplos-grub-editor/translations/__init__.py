"""
Sistema de traducciones para Soplos GRUB Editor
"""

from .strings import TRANSLATIONS, get_system_language, _

__all__ = ['TRANSLATIONS', 'get_system_language', '_']
