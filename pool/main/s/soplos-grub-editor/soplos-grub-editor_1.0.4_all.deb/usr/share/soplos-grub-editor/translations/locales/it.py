"""
Traduzioni italiane per Soplos GRUB Editor
"""

STRINGS = {
    # Titoli e intestazioni
    'app_name': 'Soplos GRUB Editor',
    'general_tab': 'Impostazioni generali',
    'entries_tab': 'Voci di avvio',
    'appearance_tab': 'Aspetto',
    
    # Pulsanti comuni
    'save_button': 'Salva',
    'apply_button': 'Applica',
    'close_button': 'Chiudi',
    'cancel_button': 'Annulla',
    'ok_button': 'OK',
    
    # Titoli dei dialoghi
    'error_title': 'Errore',
    'info_title': 'Informazione',
    'warning_title': 'Avviso',
    'confirm_title': 'Conferma',
    'question_title': 'Domanda',
    
    # Messaggi generali
    'changes_saved': 'Modifiche salvate con successo',
    'changes_error': 'Errore durante il salvataggio delle modifiche',
    'need_root': 'Privilegi di amministratore richiesti',
    'confirm_exit': 'Sei sicuro di voler uscire?',
    'unsaved_changes': 'Le modifiche non salvate andranno perse.',
    
    # Scheda Generale
    'timeout_label': 'Timeout (secondi):',
    'default_entry_label': 'Voce predefinita:',
    'resolution_label': 'Risoluzione dello schermo:',
    'kernel_params_label': 'Parametri del kernel:',
    'os_prober_label': 'Rileva altri sistemi operativi',
    'show_menu_label': 'Mostra menu di avvio',
    'recovery_label': 'Includi opzioni di ripristino',
    'advanced_options': 'Opzioni avanzate',
    'kernel_params_section': 'Parametri del kernel',
    
    # Scheda Aspetto
    'theme_section': 'Tema',
    'font_section': 'Font',
    'colors_section': 'Colori',
    'background_section': 'Sfondo',
    'preview_label': 'Anteprima',
    'install_theme': 'Installa tema...',
    'remove_theme': 'Rimuovi tema',
    'disable_theme': 'Disabilita tema',
    'select_font': 'Seleziona font...',
    'remove_font': 'Rimuovi font',
    'font_size': 'Dimensione del font:',
    'text_color': 'Colore del testo:',
    'background_color': 'Colore dello sfondo:',
    'select_background': 'Seleziona sfondo...',
    'remove_background': 'Rimuovi sfondo',
    'highlight_text_color': 'Colore del testo evidenziato:',
    'highlight_background_color': 'Colore dello sfondo evidenziato:',
    'apply_theme_button': 'Applica tema',
    
    # Scheda Voci
    'add_entry': 'Aggiungi voce',
    'edit_entry': 'Modifica voce',
    'remove_entry': 'Rimuovi voce',
    'entry_name': 'Nome:',
    'entry_type': 'Tipo:',
    'entry_kernel': 'Kernel:',
    'entry_initrd': 'Initrd:',
    'entry_params': 'Parametri:',
    'entry_path': 'Percorso',
    'entry_enabled': 'Abilitato',
    
    # Messaggi di stato
    'ready': 'Pronto',
    'saving': 'Salvataggio...',
    'applying': 'Applicazione delle modifiche...',
    'loading': 'Caricamento...',
    'updating': 'Aggiornamento di GRUB...',
    'grub_updated': 'GRUB aggiornato correttamente',
    
    # Dialoghi specifici
    'select_font_dialog': 'Seleziona font',
    'select_theme_dialog': 'Seleziona tema',
    'select_background_dialog': 'Seleziona immagine di sfondo',
    'font_filter': 'Font',
    'theme_filter': 'File di tema',
    'image_filter': 'Immagini',
    'all_files': 'Tutti i file',
    'open_button': 'Apri',
    
    # Testi di risoluzione
    'resolution_disabled': 'Disabilitato',
    'resolution_auto': 'Automatico',
    
    # Testi delle voci
    'last_selection': 'Ultima selezione',
    'default_entry_saved': 'Ultima selezione',
    
    # Aiuto e controlli font
    'font_help': 'Questo metodo evita problemi con update-grub modificando direttamente la configurazione.',
    'font_select_help': 'Seleziona un file di font TTF o OTF',
    'browse_button': 'Sfoglia...',
    'install_font_button': 'Installa font',
    'apply_font_button': 'Applica font selezionato',
    'remove_font_button': 'Rimuovi font selezionato',
    'delete_font_file_button': 'Elimina file',
    
    # Avvisi e conferme
    'delete_font_confirm': 'Sei sicuro di voler eliminare questo font?',
    'delete_font_warning': 'Il file verrà eliminato: {}\nQuesta azione non può essere annullata.',
    'apply_font_confirm': 'Vuoi applicare questo font?',
    'apply_font_message': 'Il font verrà applicato: {}',
    'remove_theme_confirm': 'Rimuovere il tema \'{}\'?',
    'disable_theme_confirm': 'Vuoi rimuovere il tema attuale?',
    'disable_theme_message': 'Il tema verrà disabilitato ma non rimosso dal sistema',
    'update_grub_title': 'Aggiorna GRUB',
    'update_grub_message': 'update-grub verrà eseguito per applicare le modifiche.',
    'apply_changes_title': 'Applicare le modifiche?',
    'apply_changes_message': 'update-grub verrà eseguito per applicare le modifiche.',
    
    # Messaggi di successo
    'font_installed': 'Font installato con successo in: {}',
    'font_removed': 'Font rimosso con successo',
    'font_removed_successfully': 'Font rimosso con successo',
    'font_deleted_successfully': 'Font eliminato con successo',
    'font_applied_successfully': 'Font applicato con successo',
    'theme_installed': 'Tema installato con successo',
    'theme_applied': 'Tema applicato con successo',
    'grub_theme_applied': 'Tema GRUB applicato con successo',
    'background_applied': 'Sfondo configurato con successo',
    'background_removed': 'Sfondo rimosso con successo',
    'entry_added': 'Voce aggiunta con successo',
    'entry_removed': 'Voce rimossa con successo',
    'changes_applied': 'Modifiche applicate con successo',
    'config_saved_successfully': 'Configurazione salvata con successo in custom.cfg',
    
    # Messaggi di errore
    'error_save': 'Errore durante il salvataggio della configurazione',
    'error_load': 'Errore durante il caricamento della configurazione',
    'error_apply': 'Errore durante l\'applicazione delle modifiche',
    'error_update': 'Errore durante l\'aggiornamento di GRUB',
    'error_permission': 'Errore di autorizzazione',
    'error_missing_deps': 'Dipendenze richieste mancanti',
    'invalid_font': 'Seleziona un file di font valido',
    'font_error': 'Errore durante l\'installazione del font: {}',
    'theme_error': 'Errore durante l\'installazione del tema: {}',
    'background_error': 'Errore durante il caricamento dell\'immagine: {}',
    'entry_error': 'Errore durante l\'aggiunta della voce: {}',
    'entry_add_error': 'Errore durante l\'aggiunta della voce',
    'entry_name_kernel_required': 'Nome e kernel sono obbligatori',
    'entry_remove_error': 'Errore durante la rimozione della voce',
    'no_entry_selected': 'Nessuna voce selezionata',
    'no_font_installed': 'Nessun font installato in GRUB',
    'no_background_configured': 'Nessuno sfondo è configurato',
    'config_save_error': 'Errore durante il salvataggio della configurazione',
    'config_save_error_path': 'Errore durante il salvataggio della configurazione in {}: {}',
    'colors_cannot_be_same': 'Il colore del testo e il colore dello sfondo non possono essere uguali.',
    'highlight_colors_cannot_be_same': 'Il colore del testo evidenziato e il colore dello sfondo evidenziato non possono essere uguali.',
    
    # Errori specifici del sistema
    'pkexec_error': 'Errore: Impossibile ottenere i privilegi di amministratore.',
    'relaunch_error': 'Errore durante il riavvio come root: {}',
    'grub_config_not_found': 'File di configurazione GRUB non trovato',
    'insufficient_permissions': 'Permessi insufficienti per accedere alla configurazione GRUB',
    'initialization_error': 'Errore durante l\'inizializzazione: {}',
    'update_grub_error': 'Errore durante l\'esecuzione di update-grub: {}',
    'cache_cleanup_error': 'Errore durante la pulizia della cache: {}',
    'background_remove_error': 'Errore durante la rimozione dello sfondo: {}',
    'font_load_error': 'Errore durante il caricamento dei font installati: {}',
    
    # Conferme di uscita
    'confirm_exit_title': 'Sei sicuro di voler uscire?',
    'confirm_exit_message': 'Le modifiche non salvate andranno perse.',
    
    # Errori di font
    'invalid_font_file': 'Il file non è un font valido',
    'font_not_exists': 'Il font {} non esiste',
    'font_convert_error': 'Errore nella conversione del font: {}',
    'font_install_error': 'Errore nell\'installazione del font: {}',
    'font_convert_exception': 'Errore nella conversione del font: {}',
    'font_set_error': 'Errore nell\'impostazione del font: {}',
    'font_remove_error': 'Errore nella rimozione del font: {}',
    'font_file_not_exists': 'Il file del font non esiste',
    'font_not_in_grub_dir': 'Il font non è nella directory dei font GRUB',
    'only_pf2_files_allowed': 'Solo i file di font .pf2 possono essere eliminati',
    'font_deleted': 'Font eliminato: {}',
    'font_delete_error': 'Errore nell\'eliminazione del font: {}',
    'font_delete_exception': 'Errore nell\'eliminazione del font: {}',
    
    # Scorciatoie da tastiera
    'shortcut_save': 'Ctrl+S',
    'shortcut_apply': 'Alt+A',
    'shortcut_close': 'Alt+C',
    'keyboard_shortcuts': 'Scorciatoie da tastiera',
    'shortcut_titles': {
        'save': 'Salva (Ctrl+S)',
        'apply': 'Applica (Alt+A)',
        'close': 'Chiudi (Alt+C)',
        'browse': 'Sfoglia (Alt+B)',
        'install': 'Installa (Alt+I)',
        'remove': 'Rimuovi (Alt+R)',
        'delete': 'Elimina (Del)',
        'add': 'Aggiungi (Alt+N)',
        'edit': 'Modifica (Alt+E)'
    },
    
    # Stati del sistema
    'no_theme_selected': 'Nessun tema selezionato',
    'theme_preview_error': 'Errore nella generazione dell\'anteprima del tema',
    'grub_theme_disabled': 'Tema GRUB disabilitato',
    'custom_entry_saved': 'Voce personalizzata salvata',
    'system_entry': 'Voce di sistema',
    'custom_entry': 'Voce personalizzata',
    'entries_loaded': 'Voci caricate: {}',
    'grub_config_loaded': 'Configurazione GRUB caricata',
    'backup_created': 'Backup creato',
    'backup_restored': 'Backup ripristinato',
    'permission_denied': 'Permesso negato',
    'file_not_found': 'File non trovato',
    'invalid_configuration': 'Configurazione non valida',
    'theme_installation_success': 'Tema installato con successo in: {}',
    'theme_removal_success': 'Tema rimosso con successo',
    'operation_completed': 'Operazione completata',
    'operation_failed': 'Operazione fallita',
    
    # Messaggi tecnici e di log (NUOVO)
    'log_levelname_message': '%(levelname)s: %(message)s',
    'icon_set_error': 'Errore nell\'impostazione dell\'icona per nome: {}',
    'program_class_error': 'Errore nell\'impostazione di program_class: {}',
    'directory_cleaned': 'Directory pulita: {}',
    'directory_clean_error': 'Errore nella pulizia di {}: {}',
    
    # Messaggi da utils/theme_utils.py (NUOVO)
    'file_format_not_supported': 'Formato file non supportato. Utilizzare .tar.gz, .tgz, .tar.xz o .zip',
    'theme_directory_invalid': 'La directory del tema non contiene theme.txt',
    'invalid_path': 'Il percorso specificato non è valido',
    'theme_disabled_successfully': 'Tema disabilitato con successo',
    'theme_preview_generation_error': 'Impossibile generare l\'anteprima: {}',
    'theme_txt_not_found': 'theme.txt non trovato',
    'theme_decompress_error': 'Errore nella decompressione del tema: {}',
    'theme_preview_generation_failed': 'Impossibile generare l\'anteprima',
    
    # Messaggi da utils/system_utils.py (NUOVO)
    'font_path_not_exists': 'Il font {} non esiste',
    'font_convert_stderr': 'Errore nella conversione del font: {}',
    'grub_config_updated': 'Configurazione GRUB aggiornata con successo',
    
    # Messaggi da utils/font_utils.py (NUOVO)
    'config_module_deprecated': 'Il modulo \'config\' è obsoleto. Utilizzare \'app_paths\' invece.',
    'no_backup_to_restore': 'Nessun backup da ripristinare',
    'config_restored_successfully': 'Configurazione ripristinata con successo',
    
    # Commenti del codice generato (NUOVO)
    'disabled_by_soplos_grub_editor': '# Disabilitato da Soplos GRUB Editor',
    'custom_grub_header': '#!/bin/sh\nexec tail -n +3 $0\n# Questo file fornisce voci personalizzate per GRUB\n\n',
}
