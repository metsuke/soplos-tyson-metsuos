"""
Deutsche Übersetzungen für Soplos GRUB Editor
"""

STRINGS = {
    # Titel und Kopfzeilen
    'app_name': 'Soplos GRUB Editor',
    'general_tab': 'Allgemeine Einstellungen',
    'entries_tab': 'Boot-Einträge',
    'appearance_tab': 'Erscheinungsbild',
    
    # Gemeinsame Schaltflächen
    'save_button': 'Speichern',
    'apply_button': 'Anwenden',
    'close_button': 'Schließen',
    'cancel_button': 'Abbrechen',
    'ok_button': 'OK',
    
    # Dialogtitel
    'error_title': 'Fehler',
    'info_title': 'Information',
    'warning_title': 'Warnung',
    'confirm_title': 'Bestätigen',
    'question_title': 'Frage',
    
    # Allgemeine Nachrichten
    'changes_saved': 'Änderungen erfolgreich gespeichert',
    'changes_error': 'Fehler beim Speichern der Änderungen',
    'need_root': 'Administratorrechte erforderlich',
    'confirm_exit': 'Möchten Sie wirklich beenden?',
    'unsaved_changes': 'Nicht gespeicherte Änderungen gehen verloren.',
    
    # Allgemeine Registerkarte
    'timeout_label': 'Timeout (Sekunden):',
    'default_entry_label': 'Standard-Eintrag:',
    'resolution_label': 'Bildschirmauflösung:',
    'kernel_params_label': 'Kernel-Parameter:',
    'os_prober_label': 'Andere Betriebssysteme erkennen',
    'show_menu_label': 'Boot-Menü anzeigen',
    'recovery_label': 'Wiederherstellungsoptionen einbeziehen',
    'advanced_options': 'Erweiterte Optionen',
    'kernel_params_section': 'Kernel-Parameter',
    
    # Erscheinungsbild Registerkarte
    'theme_section': 'Thema',
    'font_section': 'Schriftarten',
    'colors_section': 'Farben',
    'background_section': 'Hintergrund',
    'preview_label': 'Vorschau',
    'install_theme': 'Thema installieren...',
    'remove_theme': 'Thema entfernen',
    'disable_theme': 'Thema deaktivieren',
    'select_font': 'Schriftart auswählen...',
    'remove_font': 'Schriftart entfernen',
    'font_size': 'Schriftgröße:',
    'text_color': 'Textfarbe:',
    'background_color': 'Hintergrundfarbe:',
    'select_background': 'Hintergrund auswählen...',
    'remove_background': 'Hintergrund entfernen',
    'highlight_text_color': 'Hervorhebungsfarbe des Textes:',
    'highlight_background_color': 'Hervorhebungsfarbe des Hintergrunds:',
    'apply_theme_button': 'Thema anwenden',
    
    # Einträge Registerkarte
    'add_entry': 'Eintrag hinzufügen',
    'edit_entry': 'Eintrag bearbeiten',
    'remove_entry': 'Eintrag entfernen',
    'entry_name': 'Name:',
    'entry_type': 'Typ:',
    'entry_kernel': 'Kernel:',
    'entry_initrd': 'Initrd:',
    'entry_params': 'Parameter:',
    'entry_path': 'Pfad',
    'entry_enabled': 'Aktiviert',
    
    # Statusmeldungen
    'ready': 'Bereit',
    'saving': 'Speichern...',
    'applying': 'Änderungen anwenden...',
    'loading': 'Laden...',
    'updating': 'GRUB aktualisieren...',
    'grub_updated': 'GRUB erfolgreich aktualisiert',
    
    # Spezifische Dialoge
    'select_font_dialog': 'Schriftart auswählen',
    'select_theme_dialog': 'Thema auswählen',
    'select_background_dialog': 'Hintergrundbild auswählen',
    'font_filter': 'Schriftarten',
    'theme_filter': 'Themen-Dateien',
    'image_filter': 'Bilder',
    'all_files': 'Alle Dateien',
    'open_button': 'Öffnen',
    
    # Auflösungstexte
    'resolution_disabled': 'Deaktiviert',
    'resolution_auto': 'Automatisch',
    
    # Eintragstexte
    'last_selection': 'Letzte Auswahl',
    'default_entry_saved': 'Letzte Auswahl',
    
    # Schriftarten-Hilfe und -Steuerungen
    'font_help': 'Diese Methode vermeidet Probleme mit update-grub, indem die Konfiguration direkt geändert wird.',
    'font_select_help': 'Wählen Sie eine TTF- oder OTF-Schriftartdatei aus',
    'browse_button': 'Durchsuchen...',
    'install_font_button': 'Schriftart installieren',
    'apply_font_button': 'Ausgewählte Schriftart anwenden',
    'remove_font_button': 'Ausgewählte Schriftart entfernen',
    'delete_font_file_button': 'Datei löschen',
    
    # Warnungen und Bestätigungen
    'delete_font_confirm': 'Möchten Sie diese Schriftart wirklich löschen?',
    'delete_font_warning': 'Die Datei wird gelöscht: {}\nDiese Aktion kann nicht rückgängig gemacht werden.',
    'apply_font_confirm': 'Möchten Sie diese Schriftart anwenden?',
    'apply_font_message': 'Die Schriftart wird angewendet: {}',
    'remove_theme_confirm': 'Das Thema \'{}\' entfernen?',
    'disable_theme_confirm': 'Möchten Sie das aktuelle Thema entfernen?',
    'disable_theme_message': 'Das Thema wird deaktiviert, aber nicht vom System entfernt',
    'update_grub_title': 'GRUB aktualisieren',
    'update_grub_message': 'update-grub wird ausgeführt, um die Änderungen anzuwenden.',
    'apply_changes_title': 'Änderungen anwenden?',
    'apply_changes_message': 'update-grub wird ausgeführt, um die Änderungen anzuwenden.',
    
    # Erfolgsmeldungen
    'font_installed': 'Schriftart erfolgreich installiert unter: {}',
    'font_removed': 'Schriftart erfolgreich entfernt',
    'font_removed_successfully': 'Schriftart erfolgreich entfernt',
    'font_deleted_successfully': 'Schriftart erfolgreich gelöscht',
    'font_applied_successfully': 'Schriftart erfolgreich angewendet',
    'theme_installed': 'Thema erfolgreich installiert',
    'theme_applied': 'Thema erfolgreich angewendet',
    'grub_theme_applied': 'GRUB-Thema erfolgreich angewendet',
    'background_applied': 'Hintergrund erfolgreich eingestellt',
    'background_removed': 'Hintergrund erfolgreich entfernt',
    'entry_added': 'Eintrag erfolgreich hinzugefügt',
    'entry_removed': 'Eintrag erfolgreich entfernt',
    'changes_applied': 'Änderungen erfolgreich angewendet',
    'config_saved_successfully': 'Konfiguration erfolgreich in custom.cfg gespeichert',
    
    # Fehlermeldungen
    'error_save': 'Fehler beim Speichern der Konfiguration',
    'error_load': 'Fehler beim Laden der Konfiguration',
    'error_apply': 'Fehler beim Anwenden der Änderungen',
    'error_update': 'Fehler beim Aktualisieren von GRUB',
    'error_permission': 'Berechtigungsfehler',
    'error_missing_deps': 'Fehlende erforderliche Abhängigkeiten',
    'invalid_font': 'Bitte wählen Sie eine gültige Schriftartdatei aus',
    'font_error': 'Fehler bei der Installation der Schriftart: {}',
    'theme_error': 'Fehler bei der Installation des Themas: {}',
    'background_error': 'Fehler beim Laden des Bildes: {}',
    'entry_error': 'Fehler beim Hinzufügen des Eintrags: {}',
    'entry_add_error': 'Fehler beim Hinzufügen des Eintrags',
    'entry_name_kernel_required': 'Name und Kernel sind erforderlich',
    'entry_remove_error': 'Fehler beim Entfernen des Eintrags',
    'no_entry_selected': 'Kein Eintrag ausgewählt',
    'no_font_installed': 'Keine Schriftarten in GRUB installiert',
    'no_background_configured': 'Kein Hintergrund konfiguriert',
    'config_save_error': 'Fehler beim Speichern der Konfiguration',
    'config_save_error_path': 'Fehler beim Speichern der Konfiguration in {}: {}',
    'colors_cannot_be_same': 'Textfarbe und Hintergrundfarbe können nicht identisch sein.',
    'highlight_colors_cannot_be_same': 'Hervorhebungsfarbe des Textes und Hervorhebungsfarbe des Hintergrunds können nicht identisch sein.',
    
    # Systemspezifische Fehler
    'pkexec_error': 'Fehler: Administratorrechte konnten nicht erhalten werden.',
    'relaunch_error': 'Fehler beim Neustart als Root: {}',
    'grub_config_not_found': 'GRUB-Konfigurationsdatei nicht gefunden',
    'insufficient_permissions': 'Unzureichende Berechtigungen für den Zugriff auf die GRUB-Konfiguration',
    'initialization_error': 'Fehler bei der Initialisierung: {}',
    'update_grub_error': 'Fehler beim Ausführen von update-grub: {}',
    'cache_cleanup_error': 'Fehler beim Bereinigen des Caches: {}',
    'background_remove_error': 'Fehler beim Entfernen des Hintergrunds: {}',
    'font_load_error': 'Fehler beim Laden der installierten Schriftarten: {}',
    
    # Bestätigungen beim Beenden
    'confirm_exit_title': 'Möchten Sie wirklich beenden?',
    'confirm_exit_message': 'Nicht gespeicherte Änderungen gehen verloren.',
    
    # Schriftarten-Fehler
    'invalid_font_file': 'Die Datei ist keine gültige Schriftart',
    'font_not_exists': 'Die Schriftart {} existiert nicht',
    'font_convert_error': 'Fehler beim Konvertieren der Schriftart: {}',
    'font_install_error': 'Fehler bei der Installation der Schriftart: {}',
    'font_convert_exception': 'Fehler beim Konvertieren der Schriftart: {}',
    'font_set_error': 'Fehler beim Festlegen der Schriftart: {}',
    'font_remove_error': 'Fehler beim Entfernen der Schriftart: {}',
    'font_file_not_exists': 'Schriftartdatei existiert nicht',
    'font_not_in_grub_dir': 'Schriftart befindet sich nicht im GRUB-Schriftartenverzeichnis',
    'only_pf2_files_allowed': 'Nur .pf2-Schriftartdateien können gelöscht werden',
    'font_deleted': 'Schriftart gelöscht: {}',
    'font_delete_error': 'Fehler beim Löschen der Schriftart: {}',
    'font_delete_exception': 'Fehler beim Löschen der Schriftart: {}',
    
    # Tastenkombinationen
    'shortcut_save': 'Strg+S',
    'shortcut_apply': 'Alt+A',
    'shortcut_close': 'Alt+C',
    'keyboard_shortcuts': 'Tastenkombinationen',
    'shortcut_titles': {
        'save': 'Speichern (Strg+S)',
        'apply': 'Anwenden (Alt+A)',
        'close': 'Schließen (Alt+C)',
        'browse': 'Durchsuchen (Alt+B)',
        'install': 'Installieren (Alt+I)', 
        'remove': 'Entfernen (Alt+R)',
        'delete': 'Löschen (Entf)',
        'add': 'Hinzufügen (Alt+N)',
        'edit': 'Bearbeiten (Alt+E)'
    },
    
    # Systemzustände
    'no_theme_selected': 'Kein Thema ausgewählt',
    'theme_preview_error': 'Fehler beim Generieren der Themenvorschau',
    'grub_theme_disabled': 'GRUB-Thema deaktiviert',
    'custom_entry_saved': 'Benutzerdefinierter Eintrag gespeichert',
    'system_entry': 'Systemeintrag',
    'custom_entry': 'Benutzerdefinierter Eintrag',
    'entries_loaded': 'Einträge geladen: {}',
    'grub_config_loaded': 'GRUB-Konfiguration geladen',
    'backup_created': 'Sicherung erstellt',
    'backup_restored': 'Sicherung wiederhergestellt',
    'permission_denied': 'Berechtigung verweigert',
    'file_not_found': 'Datei nicht gefunden',
    'invalid_configuration': 'Ungültige Konfiguration',
    'theme_installation_success': 'Thema erfolgreich installiert unter: {}',
    'theme_removal_success': 'Thema erfolgreich entfernt',
    'operation_completed': 'Vorgang abgeschlossen',
    'operation_failed': 'Vorgang fehlgeschlagen',
    
    # Technische und Log-Nachrichten (NEU)
    'log_levelname_message': '%(levelname)s: %(message)s',
    'icon_set_error': 'Fehler beim Setzen des Icons nach Name: {}',
    'program_class_error': 'Fehler beim Setzen von program_class: {}',
    'directory_cleaned': 'Verzeichnis bereinigt: {}',
    'directory_clean_error': 'Fehler beim Bereinigen von {}: {}',
    
    # Nachrichten von utils/theme_utils.py (NEU)
    'file_format_not_supported': 'Dateiformat nicht unterstützt. Verwenden Sie .tar.gz, .tgz, .tar.xz oder .zip',
    'theme_directory_invalid': 'Das Theme-Verzeichnis enthält keine theme.txt',
    'invalid_path': 'Der angegebene Pfad ist nicht gültig',
    'theme_disabled_successfully': 'Theme erfolgreich deaktiviert',
    'theme_preview_generation_error': 'Vorschau konnte nicht generiert werden: {}',
    'theme_txt_not_found': 'theme.txt nicht gefunden',
    'theme_decompress_error': 'Fehler beim Entpacken des Themes: {}',
    'theme_preview_generation_failed': 'Vorschau konnte nicht generiert werden',
    
    # Nachrichten von utils/system_utils.py (NEU)
    'font_path_not_exists': 'Die Schriftart {} existiert nicht',
    'font_convert_stderr': 'Fehler beim Konvertieren der Schriftart: {}',
    'grub_config_updated': 'GRUB-Konfiguration erfolgreich aktualisiert',
    
    # Nachrichten von utils/font_utils.py (NEU)
    'config_module_deprecated': 'Das \'config\'-Modul ist veraltet. Verwenden Sie stattdessen \'app_paths\'.',
    'no_backup_to_restore': 'Keine Sicherung zum Wiederherstellen vorhanden',
    'config_restored_successfully': 'Konfiguration erfolgreich wiederhergestellt',
    
    # Generierte Code-Kommentare (NEU)
    'disabled_by_soplos_grub_editor': '# Deaktiviert von Soplos GRUB Editor',
    'custom_grub_header': '#!/bin/sh\nexec tail -n +3 $0\n# Diese Datei stellt benutzerdefinierte Einträge für GRUB bereit\n\n',
}
