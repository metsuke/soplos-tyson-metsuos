# Changelog

Todos los cambios notables de este proyecto se documentarán en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto se adhiere a [Semantic Versioning](https://semver.org/lang/es/).

## [1.0.2] - 2025-07-13

### 🌍 Añadido - Internacionalización Completa
- **Sistema de traducciones dinámico** con carga bajo demanda
- **8 idiomas completamente soportados**:
  - 🇪🇸 Español (es) - 100%
  - 🇺🇸 English (en) - 100%
  - 🇫🇷 Français (fr) - 100%
  - 🇵🇹 Português (pt) - 100%
  - 🇩🇪 Deutsch (de) - 100%
  - 🇮🇹 Italiano (it) - 100%
  - 🇷🇺 Русский (ru) - 100%
  - 🇷🇴 Română (ro) - 100%
- **Detección automática** del idioma del sistema basada en `$LANG`
- **Sistema de fallback robusto** con inglés como respaldo
- **API de traducción mejorada** con función `_()` optimizada
- **Función `set_language()`** para cambio dinámico de idioma
- **Función `get_available_languages()`** para listar idiomas disponibles

### 🔧 Mejorado - Sistema de Traducciones
- **Reestructuración completa** del módulo `translations/`
- **Carga optimizada** de traducciones por idioma
- **Gestión mejorada de memoria** - solo carga idiomas necesarios
- **Validación robusta** de claves de traducción
- **Logging mejorado** para errores de traducción
- **Compatibilidad mantenida** con código existente

### 🐛 Corregido - Internacionalización
- **Cadenas hardcodeadas** completamente eliminadas
- **Errores de logging** ahora traducidos
- **Mensajes técnicos** internacionalizados
- **Comentarios de código generado** traducidos
- **Configuración `_()` antes de uso** en `main.py`
- **Importaciones de traducción** optimizadas

### 📁 Cambiado - Estructura de Archivos
- **Directorio `locale/` eliminado** para evitar conflictos
- **Nuevo sistema `translations/`** más robusto
- **Archivo `strings.py` centralizado** para gestión
- **Módulos de idioma separados** en `locales/`
- **Configuración modular** mejorada

### 🚀 Rendimiento
- **Carga bajo demanda** de idiomas
- **Menos uso de memoria** (solo idioma activo)
- **Arranque más rápido** de la aplicación
- **Gestión eficiente** de traducciones

### 📝 Documentación
- **README.md actualizado** con información de idiomas
- **Metainfo.xml expandido** con traducciones completas
- **Changelog creado** con historial detallado
- **Comentarios de código** mejorados
- **Documentación de API** para traducciones
- **Compatibilidad mejorada con Plasma Discover**: el paquete ahora es visible y accesible desde Plasma Discover
- **Metainfo actualizado para compatibilidad total con Discover/AppStream**

### 🛠️ Desarrollo
- **Sistema de desarrollo** simplificado para traducciones
- **Validación automática** de completitud de idiomas
- **Herramientas de verificación** para traducciones
- **Estructura consistente** entre idiomas

## [1.0.1] - 2025-06-15

### 🔧 Mejorado
- **Sistema de conversión de fuentes** más robusto
- **Gestión de errores** mejorada en instalación de fuentes
- **Interfaz de usuario** más responsiva
- **Instalación de temas** optimizada

### 🐛 Corregido
- Errores en conversión TTF/OTF a PF2
- Problemas de permisos en `/boot/grub/fonts/`
- Fallos de UI al cargar temas grandes
- Errores de memoria al procesar fuentes

### 📁 Cambiado
- Mejora en la estructura de módulos `utils/`
- Optimización de imports
- Limpieza de código duplicado

## [1.0.0] - 2025-06-13

### 🎉 Lanzamiento Inicial
- **Editor gráfico completo** para configuración GRUB2
- **Interfaz GTK3 intuitiva** con pestañas organizadas
- **Gestión de temas GRUB** - instalación y aplicación
- **Conversión de fuentes** TTF/OTF → PF2
- **Configuración de fondos** de pantalla
- **Gestión de entradas** de arranque personalizadas
- **Configuración avanzada** del kernel
- **Detección automática** de otros sistemas operativos
- **Sistema de copias de seguridad** automático
- **Integración segura** con update-grub

### 🌟 Características Principales
- **Pestaña General**: Timeout, entrada predeterminada, resolución, parámetros kernel
- **Pestaña Apariencia**: Temas, fuentes, colores, fondos
- **Pestaña Entradas**: Gestión de entradas de arranque personalizadas
- **Atajos de teclado** intuitivos
- **Validación de configuración** antes de aplicar
- **Logging detallado** para depuración

### 🔒 Seguridad
- **Privilegios mínimos** - solo root cuando necesario
- **Validación de entrada** robusta
- **Copias de seguridad automáticas** antes de cambios
- **Verificación de integridad** de archivos

### 📦 Empaquetado
- **Paquete Debian** listo para producción
- **Archivos .desktop** con iconos
- **Metadatos AppStream** completos
- **Integración con package managers**

### 🎯 Compatibilidad
- **Soplos Linux** (distribución principal)
- **Ubuntu/Debian** y derivados
- **GRUB 2.x** en todas las versiones
- **Python 3.8+** con PyGObject

---

## Tipos de Cambios

- **Añadido** para nuevas características
- **Cambiado** para cambios en funcionalidad existente
- **Obsoleto** para características que serán eliminadas
- **Eliminado** para características eliminadas
- **Corregido** para corrección de errores
- **Seguridad** para vulnerabilidades

## Enlaces

- [1.0.2]: https://github.com/SoplosLinux/tyron/compare/v1.0.1...v1.0.2
- [1.0.1]: https://github.com/SoplosLinux/tyron/compare/v1.0.0...v1.0.1
- [1.0.0]: https://github.com/SoplosLinux/tyron/releases/tag/v1.0.0

## Contribuir

Para reportar errores o solicitar características:
- **Issues**: https://github.com/SoplosLinux/tyron/issues
- **Discusiones**: https://github.com/SoplosLinux/tyron/discussions
- **Email**: info@soploslinux.com

Para contribuir con traducciones:
1. Crear archivo `translations/locales/XX.py` (XX = código idioma)
2. Copiar estructura de `translations/locales/en.py`
3. Traducir todas las cadenas `STRINGS`
4. Añadir idioma a `SUPPORTED_LANGUAGES` en `strings.py`
5. Enviar Pull Request

## Soporte

- **Documentación**: https://soploslinux.com/docs/soplos-grub-editor
- **Comunidad**: https://soploslinux.com/community
- **Support**: support@soploslinux.com
