# MSI Keyboard RGB Controller

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.7-green.svg)]()

Controlador gráfico para teclados MSI RGB compatible con XFCE, Plasma y GNOME.

*Graphical RGB controller for MSI keyboards compatible with XFCE, Plasma and GNOME*

## 📝 Descripción

Una interfaz gráfica GTK3 para configurar la iluminación RGB de teclados MSI, permitiendo seleccionar colores por zonas, ajustar intensidad y cambiar modos de iluminación.

## ✨ Características

- 🎨 Configuración visual de colores por zonas
- 💡 Control de intensidad de iluminación
- 🔄 Múltiples modos de iluminación (normal, gaming, breathe, demo, wave)
- 💾 Guardado y carga de configuraciones
- 🌍 Soporte multiidioma (8 idiomas)
- 🖥️ Compatible con XFCE, Plasma y GNOME
- 🌊 **Soporte completo para Wayland y X11**
- 🎨 **Detección automática de temas del sistema**

## 🛠️ Requisitos

- Python 3.8+
- GTK 3.0
- Comando `msi-keyboard` instalado
- Teclado MSI compatible

## 📥 Instalación

```bash
# Dependencias
sudo apt install python3-gi gir1.2-gtk-3.0 python3-gi-cairo

# Instalación
sudo pip3 install .
```

## 🚀 Uso

```bash
# Ejecutar la aplicación
msi-keyboard-gui

# O usar el script directo
python3 run.py
```

## 🌊 Compatibilidad con Wayland

La aplicación es **totalmente compatible con Wayland** y funciona perfectamente en:

- **Plasma 6 + Wayland** (Soplos Linux Tyson)
- **GNOME + Wayland**
- **Sway** y otros compositores Wayland
- **X11** (todos los entornos tradicionales)

### Características específicas de Wayland:
- ✅ Detección automática del protocolo de ventanas
- ✅ Aplicación automática de temas (incluyendo tema oscuro en Plasma 6)
- ✅ Escalado correcto en monitores HiDPI
- ✅ Integración nativa con el compositor

### Resolución de problemas de temas:

Si la aplicación no usa el tema correcto:

```bash
# Forzar tema oscuro
GTK_THEME=Adwaita:dark msi-keyboard-gui

# Forzar tema claro
GTK_THEME=Adwaita msi-keyboard-gui

# Para Plasma con tema Breeze
GTK_THEME=Breeze-Dark msi-keyboard-gui
```

## 🎮 Características del teclado

### Zonas configurables:
- **Izquierda**: Zona izquierda del teclado
- **Centro**: Zona central del teclado  
- **Derecha**: Zona derecha del teclado

### Colores disponibles:
- Apagado (off)
- Rojo (red)
- Naranja (orange)
- Amarillo (yellow)
- Verde (green)
- Cian (sky)
- Azul (blue)
- Púrpura (purple)
- Blanco (white)

### Intensidades:
- Ligera (light)
- Baja (low)
- Media (med)
- Alta (high)

### Modos de iluminación:
- Normal
- Gaming
- Breathe (respiración)
- Demo
- Wave (onda)

## 🌐 Idiomas soportados

- 🇪🇸 Español
- 🇺🇸 English
- 🇵🇹 Português
- 🇫🇷 Français
- 🇩🇪 Deutsch
- 🇮🇹 Italiano
- 🇷🇴 Română
- 🇷🇺 Русский

## 🐧 Compatibilidad con distribuciones

- ✅ **Soplos Linux Tyson** (Plasma 6 + Wayland)
- ✅ Ubuntu/Debian (GNOME/X11/Wayland)
- ✅ Fedora (GNOME/KDE/Wayland)
- ✅ Arch Linux (cualquier DE)
- ✅ openSUSE (KDE/GNOME)

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos Linux](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/msi-keyboard-rgb/issues)


## 🆕 Novedades en la versión 1.0.8 (15 de julio de 2025)

- Mejoras en el metainfo para validación AppStream/DEP11
- Implementados los iconos del programa en 48x48, 64x64 y 128x128 para integración con centros de software

## 🆕 Novedades en la versión 1.0.7 (14 de julio de 2025)

- Correcciones finales en el metainfo para garantizar la aparición en centros de software (AppStream/Discover/GNOME Software).

## 🆕 Novedades en la versión 1.0.6 (13 de julio de 2025)

- Corregidos los datos del metainfo para que se muestren de forma correcta en AppStream/Discover.

## 🆕 Novedades en la versión 1.0.5 (5 de julio de 2025)

- Script unificado para todas las operaciones systemd con una sola autenticación pkexec.
- Eliminación automática de archivos temporales después de crear servicios.
- Mejoras en el manejo de errores y estabilidad general del sistema.

## 🆕 Novedades en la versión 1.0.4 (5 de julio de 2025)

- Uso de pkexec para autenticación gráfica al crear servicios systemd (soluciona problemas de permisos en GUI).
- Mejor manejo de cancelación de autenticación por parte del usuario.
- Correcciones menores y mejoras de estabilidad.

## 🆕 Novedades en la versión 1.0.3 (26 de junio de 2025)

- Generación y actualización automática del servicio systemd al aplicar la configuración desde la interfaz gráfica.
- El servicio systemd se habilita para aplicar la configuración RGB al arrancar el sistema.
- Correcciones menores y mejoras de integración.

## 🆕 Novedades en la versión 1.0.2 (24 de junio de 2025)

- Actualización de versión y metadatos
- Mejoras menores

## 🆕 Novedades en la versión 1.0.1 (24 de junio de 2025)

- Ahora la aplicación es visible en Discover y otras tiendas AppStream
- Mejoras en los metadatos AppStream
