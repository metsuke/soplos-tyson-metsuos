#!/usr/bin/env python3
"""
Script para ejecutar MSI Keyboard RGB Controller
"""
import os
import sys

# Añadir el directorio del proyecto al path
project_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_dir)

# Cambiar al directorio del proyecto para que las rutas relativas funcionen
os.chdir(project_dir)

# Ejecutar la aplicación
from main import main

if __name__ == '__main__':
    main()
