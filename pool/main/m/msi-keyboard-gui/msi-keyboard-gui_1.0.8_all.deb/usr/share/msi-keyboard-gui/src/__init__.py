"""Módulo principal para MSI Keyboard RGB Controller"""
