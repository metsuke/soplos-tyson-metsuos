"""Utilidades para MSI Keyboard RGB Controller"""
