from setuptools import setup, find_packages

setup(
    name="msi-keyboard-rgb",
    version="1.0.5",
    packages=find_packages(),
    install_requires=[
        "PyGObject>=3.0.0",
        "python-gi>=3.0",
        "setuptools>=40.0",
    ],
    data_files=[
        ('share/applications', ['assets/com.soplos.msi-keyboard.desktop']),
        ('share/icons/hicolor/128x128/apps', [
            'assets/icons/com.soplos.msi-keyboard.png',
        ]),
        ('share/icons/hicolor/32x32/apps', [
            'assets/icons/soplos-logo.png',
        ]),
        ('share/metainfo', ['assets/com.soplos.msi-keyboard.metainfo.xml']),
        # CORREGIDO: Instalar assets en la ubicación correcta
        ('share/msi-keyboard', ['assets/keyboard.png']),
        ('share/msi-keyboard/icons', [
            'assets/icons/com.soplos.msi-keyboard.png',
            'assets/icons/soplos-logo.png'
        ]),
    ],
    package_data={
        '': [
            'assets/icons/*.png',
            'assets/*.desktop',
            'assets/*.xml',
            'assets/keyboard.png',
        ],
    },
    entry_points={
        'console_scripts': [
            'msi-keyboard-gui=main:main',
        ],
    },
    author="Soplos Team",
    author_email="info@soploslinux.com",
    description="MSI Keyboard RGB Controller - Interfaz gráfica para configurar teclados MSI RGB",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://github.com/soplos/msi-keyboard-rgb",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: POSIX :: Linux",
        "Environment :: X11 Applications :: GTK",
    ],
    python_requires='>=3.8',
)
