import gi
import os
import shutil
import sys
import atexit
import locale as stdlib_locale  # Importar con alias para evitar conflictos
from pathlib import Path

# Definir las constantes de identificación de manera consistente
APP_ID = "com.soplos.msi-keyboard"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

# NUEVO: Configuración específica para Wayland
def setup_wayland_compatibility():
    """Configura compatibilidad específica para Wayland"""
    # Detectar si estamos en Wayland
    wayland_display = os.environ.get('WAYLAND_DISPLAY')
    xdg_session_type = os.environ.get('XDG_SESSION_TYPE')
    
    if wayland_display or xdg_session_type == 'wayland':
        print("🌊 Detectado entorno Wayland - aplicando configuraciones específicas")
        
        # Forzar backend de GDK para Wayland
        os.environ['GDK_BACKEND'] = 'wayland'
        
        # Configurar escalado si es necesario
        if not os.environ.get('GDK_SCALE'):
            os.environ['GDK_SCALE'] = '1'
        
        # Configurar tema GTK para Wayland (forzar tema oscuro en Plasma)
        desktop_env = os.environ.get('XDG_CURRENT_DESKTOP', '').lower()
        if 'kde' in desktop_env or 'plasma' in desktop_env:
            # En Plasma 6 con Wayland, forzar tema oscuro
            os.environ['GTK_THEME'] = 'Adwaita:dark'
            # También configurar tema de Qt si es necesario
            if not os.environ.get('QT_STYLE_OVERRIDE'):
                os.environ['QT_STYLE_OVERRIDE'] = 'adwaita-dark'
        
        return True
    return False

# NUEVO: Configuración de temas mejorada
def setup_theme_support():
    """Configura soporte mejorado para temas"""
    try:
        # Detectar tema del sistema
        desktop_env = os.environ.get('XDG_CURRENT_DESKTOP', '').lower()
        
        # Configuraciones específicas por entorno de escritorio
        if 'kde' in desktop_env or 'plasma' in desktop_env:
            # Plasma: intentar detectar si usa tema oscuro
            try:
                import subprocess
                result = subprocess.run(['kreadconfig5', '--file', 'kdeglobals', '--group', 'General', '--key', 'ColorScheme'], 
                                      capture_output=True, text=True, timeout=2)
                if result.returncode == 0 and 'dark' in result.stdout.lower():
                    os.environ['GTK_THEME'] = 'Adwaita:dark'
                    print("🎨 Aplicando tema oscuro para Plasma")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                # Fallback: usar tema oscuro por defecto en Plasma 6
                plasma_version = os.environ.get('KDE_SESSION_VERSION', '6')
                if plasma_version == '6':
                    os.environ['GTK_THEME'] = 'Adwaita:dark'
                    print("🎨 Aplicando tema oscuro por defecto para Plasma 6")
        
        elif 'gnome' in desktop_env:
            # GNOME: usar gsettings para detectar tema
            try:
                import subprocess
                result = subprocess.run(['gsettings', 'get', 'org.gnome.desktop.interface', 'gtk-theme'], 
                                      capture_output=True, text=True, timeout=2)
                if result.returncode == 0 and result.stdout.strip():
                    theme = result.stdout.strip().strip("'\"")
                    os.environ['GTK_THEME'] = theme
                    print(f"🎨 Usando tema GNOME: {theme}")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass
        
        elif 'xfce' in desktop_env:
            # XFCE: usar xfconf-query
            try:
                import subprocess
                result = subprocess.run(['xfconf-query', '-c', 'xsettings', '-p', '/Net/ThemeName'], 
                                      capture_output=True, text=True, timeout=2)
                if result.returncode == 0 and result.stdout.strip():
                    theme = result.stdout.strip()
                    os.environ['GTK_THEME'] = theme
                    print(f"🎨 Usando tema XFCE: {theme}")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass
        
        # Configurar variables adicionales para consistencia
        if 'GTK_THEME' in os.environ:
            # Aplicar también a Qt si es posible
            gtk_theme = os.environ['GTK_THEME'].lower()
            if 'dark' in gtk_theme:
                os.environ['QT_STYLE_OVERRIDE'] = 'adwaita-dark'
                os.environ['QT_QPA_PLATFORMTHEME'] = 'gtk3'
        
    except Exception as e:
        print(f"⚠️ Error configurando temas: {e}")

# Importaciones de biblioteca
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

def setup_application():
    """Configura los parámetros de la aplicación"""
    # NUEVO: Configurar Wayland y temas ANTES de GTK
    is_wayland = setup_wayland_compatibility()
    setup_theme_support()
    
    # Establecer identificadores de aplicación globales
    GLib.set_prgname(APP_ID)
    GLib.set_application_name("MSI Keyboard RGB Controller")  # Nombre legible para humanos

    # Establecer icono predeterminado para todas las ventanas
    try:
        Gtk.Window.set_default_icon_name(APP_ID)
    except:
        pass

    # Configuración para asegurar que GDK use el WMCLASS correcto
    try:
        if hasattr(Gdk, 'set_program_class'):
            Gdk.set_program_class(WMCLASS)
    except:
        pass

    # Deshabilitar warnings de accesibilidad
    os.environ['NO_AT_BRIDGE'] = '1'
    
    # NUEVO: Configuraciones específicas de Wayland
    if is_wayland:
        print("✅ Configuración de Wayland completada")

from gi.repository import Gio, GdkPixbuf
from src.gui.window import MainWindow
from src.utils.paths import get_icon_path

def clean_pycache_files(verbose=False):
    """Limpia los archivos __pycache__ de manera más exhaustiva y silenciosa"""
    try:
        # Usar una ruta absoluta fija en lugar de depender de __file__
        base_dir = "/usr/local/bin/msi-keyboard"
        if not os.path.exists(base_dir):
            # Intentar obtener la ruta del script actual si no se encuentra la ruta fija
            try:
                base_dir = os.path.dirname(os.path.abspath(__file__))
            except NameError:
                # Si __file__ no está disponible (como en atexit), usar el directorio de trabajo actual
                base_dir = os.getcwd()
    
        # Primera pasada: intentar eliminar directorios completos de manera silenciosa
        for root, dirs, _ in os.walk(base_dir):
            for d in dirs:
                if d == "__pycache__":
                    path = os.path.join(root, d)
                    try:
                        shutil.rmtree(path, ignore_errors=True)
                        if verbose:
                            print(f"Eliminado directorio: {path}")
                    except Exception:
                        pass  # Ignorar errores silenciosamente
    
        # Segunda pasada: eliminar archivos .pyc individualmente por si quedan algunos
        for root, _, files in os.walk(base_dir):
            for file in files:
                if file.endswith('.pyc') or file.endswith('.pyo'):
                    try:
                        path = os.path.join(root, file)
                        os.remove(path)
                        if verbose:
                            print(f"Eliminado archivo: {path}")
                    except Exception:
                        pass  # Ignorar errores silenciosamente
    except Exception:
        pass  # Capturar cualquier error en la función completa para asegurar ejecución silenciosa

# Registrar limpieza al salir - con verbose=False para no mostrar mensajes
atexit.register(lambda: clean_pycache_files(verbose=False))

# Limpiar al inicio también - con verbose=False para no mostrar mensajes
clean_pycache_files(verbose=False)

class MSIKeyboardApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                        flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        window = MainWindow(application=self)
        
        # NUEVO: Configuraciones adicionales para Wayland
        self._setup_window_wayland_properties(window)
        
        # Establecer el WM_CLASS usando métodos modernos
        try:
            # Método moderno preferido: usar set_role y propiedades de aplicación
            window.set_role(WMCLASS)
            window.set_title("MSI Keyboard RGB Controller")
            
            # Para aplicaciones GTK3 modernas, el application_id debería ser suficiente
            # pero podemos establecer propiedades adicionales
            if hasattr(window, 'set_startup_id'):
                window.set_startup_id(APP_ID)
                
        except Exception:
            # Fallback para versiones más antiguas (silenciar warning)
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", DeprecationWarning)
                window.set_wmclass(WMCLASS, WMCLASS)
        
        # Establecer el icono de la aplicación usando sistema de rutas
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                # Intentar cargar el icono por nombre - debe coincidir con .desktop
                icon = icon_theme.load_icon(APP_ID, 128, 0)
                window.set_icon(icon)
            except:
                # Fallar a la ruta del archivo usando sistema de rutas
                icon_path = get_icon_path('com.soplos.msi-keyboard.png')
                if os.path.exists(icon_path):
                    icon = GdkPixbuf.Pixbuf.new_from_file(icon_path)
                    window.set_icon(icon)
                    Gtk.Window.set_default_icon(icon)
        except Exception as e:
            print(f"Error al cargar el icono: {e}")
            
        # Forzar actualización de propiedades de ventana antes de mostrar
        window.realize()

        # Conectar la señal delete-event
        window.connect('delete-event', self.on_window_delete)
        window.show_all()
    
    def _setup_window_wayland_properties(self, window):
        """Configura propiedades específicas de ventana para Wayland"""
        try:
            # Configurar hints de ventana para Wayland
            window.set_type_hint(Gdk.WindowTypeHint.NORMAL)
            
            # Asegurar que la ventana sea redimensionable
            window.set_resizable(True)
            
            # Configurar decoraciones de ventana
            if hasattr(window, 'set_decorated'):
                window.set_decorated(True)
            
            # Configurar propiedades de aplicación Wayland
            if hasattr(window, 'set_application'):
                window.set_application(self)
            
            print("🪟 Propiedades de ventana Wayland configuradas")
            
        except Exception as e:
            print(f"⚠️ Error configurando propiedades Wayland: {e}")

    def on_window_delete(self, widget, event):
        # CORREGIDO: Usar localization en lugar de locale
        from src.localization.strings import get_string
        
        dialog = Gtk.MessageDialog(
            transient_for=widget,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=get_string("confirm_close")
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            return False  # Proceder con el cierre
        return True  # Cancelar el cierre

def main():
    """Entry point for the application"""
    
    # Configurar la aplicación una sola vez
    setup_application()
    
    # CORREGIDO: Inicializar idioma desde configuración antes de crear ventanas
    try:
        from src.localization.strings import init_language_from_config
        init_language_from_config()
    except Exception as e:
        print(f"Error inicializando idioma: {e}")
    
    try:
        # Usar setlocale() en lugar de getdefaultlocale()
        stdlib_locale.setlocale(stdlib_locale.LC_ALL, '')
        current_lang = stdlib_locale.getlocale()[0]
        if current_lang:
            lang = current_lang.split('_')[0]
        else:
            lang = 'en'
    except stdlib_locale.Error:
        lang = 'en'
    
    os.environ['LANGUAGE'] = lang
    os.environ['LANG'] = f"{lang}.UTF-8"
    
    # Limpiar __pycache__ al inicio
    clean_pycache_files()
    
    app = MSIKeyboardApp()
    return app.run(None)

if __name__ == '__main__':
    main()
