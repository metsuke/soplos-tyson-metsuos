import os
import sys
import subprocess
import json

# Añadir el directorio raíz al PYTHONPATH
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, root_dir)

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GdkPixbuf, GLib

# CORREGIDO: Usar localization en lugar de locale
from src.localization.strings import get_string, set_language, get_available_languages, get_current_language
from src.utils.config import load_config, save_config
from src.utils.paths import get_icon_path
from src.widgets.keyboard_widget import KeyboardWidget

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Establecer propiedades de ventana modernas
        self.set_role("msi-keyboard-main")
        
        # Configuración inicial
        self.config_file = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")
        self.zones = {
            'left': {'color': 'red', 'intensity': 'high'},
            'middle': {'color': 'red', 'intensity': 'high'},
            'right': {'color': 'red', 'intensity': 'high'}
        }
        self.mode = 'normal'
        
        # Colores disponibles
        self.colors = {
            'off': '#000000',
            'red': '#ff0000',
            'orange': '#ff8000',
            'yellow': '#ffff00',
            'green': '#00ff00',
            'sky': '#00ffff',
            'blue': '#0000ff',
            'purple': '#8000ff',
            'white': '#ffffff'
        }
        
        self.intensities = ['light', 'low', 'med', 'high']
        self.modes = ['normal', 'gaming', 'breathe', 'demo', 'wave']
        
        self.load_config()
        self.setup_ui()
        
        # NUEVO: Aplicar automáticamente la configuración cargada al iniciar
        GLib.timeout_add(500, self._auto_apply_saved_config)
        
    def _auto_apply_saved_config(self):
        """Aplica automáticamente la configuración guardada al iniciar"""
        try:
            if os.path.exists(self.config_file):
                print(f"🔄 {get_string('applying_saved_config')}")
                self._execute_msi_command(show_message=False)
                print(f"✅ {get_string('config_applied_auto')}")
        except Exception as e:
            print(f"⚠️ {get_string('auto_config_error')}: {e}")
        return False  # Solo ejecutar una vez

    def setup_ui(self):
        self.set_title(get_string("window_title"))
        self.set_default_size(900, 500)  # Más pequeña sin controles inferiores
        self.set_border_width(10)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_size_request(750, 400)  # Más pequeña también
        
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(vbox)
        
        # NUEVO: Fila separada para el logo de MSI
        self.create_logo_bar(vbox)
        
        # Barra superior con selector de idioma (sin logo)
        self.create_header_bar(vbox)
        
        # Título
        title = Gtk.Label()
        title.set_markup('<span size="large" weight="bold">MSI Keyboard RGB Controller</span>')
        vbox.pack_start(title, False, False, 0)
        
        # Selector de modo
        self.create_mode_selector(vbox)
        
        # Widget del teclado (ahora ocupa más espacio)
        self.create_keyboard_widget(vbox)
        
        # ELIMINADO: Panel de configuración de zona
        # ELIMINADO: create_zone_config()
        
        # Botones simplificados
        self.create_buttons(vbox)
        
        self.selected_zone = 'left'

    def create_logo_bar(self, parent):
        """Crea una barra separada solo para el logo de MSI"""
        logo_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        logo_box.set_margin_top(5)
        logo_box.set_margin_bottom(5)
        logo_box.set_halign(Gtk.Align.CENTER)
        parent.pack_start(logo_box, False, False, 0)
        
        # Logo de MSI centrado
        try:
            logo_path = get_icon_path('com.soplos.msi-keyboard.png')
            if os.path.exists(logo_path):
                logo_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(logo_path, 64, 64, True)
                logo_image = Gtk.Image.new_from_pixbuf(logo_pixbuf)
                logo_box.pack_start(logo_image, False, False, 0)
                print(f"{get_string('logo_loaded')}: {logo_path}")
            else:
                print(f"{get_string('logo_not_found')}: {logo_path}")
        except Exception as e:
            print(f"{get_string('logo_load_error')}: {e}")

    def create_header_bar(self, parent):
        """Crea la barra superior SOLO con selector de idioma"""
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        header_box.set_margin_top(5)
        header_box.set_margin_bottom(5)
        parent.pack_start(header_box, False, False, 0)
        
        # Espaciador para empujar el selector de idioma hacia la derecha
        spacer = Gtk.Box()
        header_box.pack_start(spacer, True, True, 0)
        
        # Contenedor para el selector de idioma (derecha)
        language_container = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        language_container.set_halign(Gtk.Align.END)
        
        # Label de idioma
        self.language_label = Gtk.Label(label=get_string("language") + ":")
        language_container.pack_start(self.language_label, False, False, 0)
        
        # ComboBox para idiomas
        self.language_combo = Gtk.ComboBoxText()
        languages = get_available_languages()
        current_lang = get_current_language()
        
        for code, name in languages.items():
            self.language_combo.append(code, name)
            if code == current_lang:
                self.language_combo.set_active_id(code)
        
        self.language_combo.connect('changed', self.on_language_changed)
        language_container.pack_start(self.language_combo, False, False, 0)
        
        header_box.pack_end(language_container, False, False, 0)

    def create_mode_selector(self, parent):
        """Crea el selector de modo del teclado"""
        mode_frame = Gtk.Frame(label=get_string("keyboard_mode"))
        mode_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        mode_box.set_border_width(10)
        
        self.mode_combo = Gtk.ComboBoxText()
        # CORREGIDO: Mostrar nombres traducidos pero mantener valores en inglés
        for mode in self.modes:
            self.mode_combo.append(mode, get_string(mode))
        self.mode_combo.set_active_id(self.mode)  # Usar set_active_id en lugar de set_active
        self.mode_combo.connect("changed", self.on_mode_changed)
        
        mode_box.pack_start(Gtk.Label(get_string("mode") + ":"), False, False, 0)
        mode_box.pack_start(self.mode_combo, False, False, 0)
        mode_frame.add(mode_box)
        parent.pack_start(mode_frame, False, False, 0)
        
    def create_keyboard_widget(self, parent):
        """Crea el widget visual del teclado"""
        keyboard_frame = Gtk.Frame(label=get_string("zone_configuration"))
        
        # Optimizado para el nuevo tamaño
        self.keyboard_widget = KeyboardWidget(self.zones, self.colors, self.on_zone_clicked)
        
        # Configurar para que se expanda apropiadamente
        self.keyboard_widget.set_hexpand(True)
        self.keyboard_widget.set_vexpand(True)
        
        # Contenedor con padding optimizado
        container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        container.set_border_width(8)  # Era 10, ahora 8 para ahorrar espacio
        container.pack_start(self.keyboard_widget, True, True, 0)
        
        keyboard_frame.add(container)
        # Dar peso apropiado al frame del teclado
        parent.pack_start(keyboard_frame, True, True, 5)  # Era 10, ahora 5

    def create_buttons(self, parent):
        """Crea los botones de acción simplificados"""
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        button_box.set_halign(Gtk.Align.CENTER)
        
        apply_btn = Gtk.Button(label=get_string("apply"))
        apply_btn.connect("clicked", self.apply_config)
        apply_btn.get_style_context().add_class("suggested-action")
        
        save_btn = Gtk.Button(label=get_string("save"))
        save_btn.connect("clicked", self.save_config)
        
        reset_btn = Gtk.Button(label=get_string("reset"))
        reset_btn.connect("clicked", self.reset_config)
        reset_btn.get_style_context().add_class("destructive-action")
        
        button_box.pack_start(apply_btn, False, False, 0)
        button_box.pack_start(save_btn, False, False, 0)
        button_box.pack_start(reset_btn, False, False, 0)
        
        parent.pack_start(button_box, False, False, 0)

    def on_zone_clicked(self, zone):
        """Maneja la selección de zona - ahora solo actualiza la selección visual"""
        self.selected_zone = zone
        self.keyboard_widget.set_selected_zone(zone)

    def on_mode_changed(self, combo):
        """Maneja el cambio de modo"""
        # CORREGIDO: Obtener el ID/valor, no el texto mostrado
        self.mode = combo.get_active_id()

    def apply_config(self, button):
        """Aplica la configuración al teclado y actualiza el servicio systemd"""
        self._execute_msi_command(show_message=True)
        self._create_or_update_systemd_service()

    def _create_or_update_systemd_service(self):
        """
        Crea o actualiza el servicio systemd para aplicar la configuración al inicio.
        Requiere privilegios de administrador.
        """
        import getpass
        import tempfile

        # Construir el comando actual
        cmd = ['msi-keyboard', '-m', self.mode]
        for zone, config in self.zones.items():
            cmd.extend(['-c', f"{zone},{config['color']},{config['intensity']}"])
        cmd_str = " ".join(cmd)

        # Determinar ruta real de msi-keyboard
        import shutil
        msi_keyboard_path = shutil.which('msi-keyboard') or '/usr/bin/msi-keyboard'
        if not os.path.exists(msi_keyboard_path):
            self.show_message("msi-keyboard no encontrado en el sistema.", Gtk.MessageType.ERROR)
            return

        # Reemplazar el comando por la ruta absoluta
        cmd_str = cmd_str.replace('msi-keyboard', msi_keyboard_path, 1)

        # Definir el contenido del servicio
        service_content = f"""[Unit]
Description=Configura teclado MSI al iniciar
After=multi-user.target

[Service]
Type=oneshot
ExecStart={cmd_str}
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
"""

        service_path = "/etc/systemd/system/msi-keyboard.service"

        # Escribir el archivo temporalmente y luego moverlo con sudo
        try:
            # Guardar el servicio en un archivo temporal
            with tempfile.NamedTemporaryFile("w", delete=False) as tmpf:
                tmpf.write(service_content)
                tmpf_path = tmpf.name

            # Copiar el archivo al destino con sudo
            import subprocess
            cp_cmd = ["sudo", "cp", tmpf_path, service_path]
            result = subprocess.run(cp_cmd, capture_output=True, text=True)
            if result.returncode != 0:
                self.show_message(f"Error al instalar el servicio systemd:\n{result.stderr}", Gtk.MessageType.ERROR)
                return

            # Recargar systemd y habilitar el servicio
            subprocess.run(["sudo", "systemctl", "daemon-reload"])
            subprocess.run(["sudo", "systemctl", "enable", "msi-keyboard.service"])

            self.show_message("Servicio systemd actualizado y habilitado correctamente.", Gtk.MessageType.INFO)
        except Exception as e:
            self.show_message(f"Error creando el servicio systemd:\n{e}", Gtk.MessageType.ERROR)

    def _execute_msi_command(self, show_message=True):
        """Ejecuta el comando msi-keyboard (método separado para reutilizar)"""
        try:
            # Verificar comando
            cmd_check = subprocess.run(['which', 'msi-keyboard'], 
                                     capture_output=True, text=True)
            
            if cmd_check.returncode != 0:
                help_check = subprocess.run(['msi-keyboard', '--help'], 
                                          capture_output=True, text=True)
                if help_check.returncode != 0:
                    raise FileNotFoundError("msi-keyboard command not found")
            
            # Construir comando
            cmd = ['msi-keyboard']
            cmd.extend(['-m', self.mode])
            
            for zone, config in self.zones.items():
                cmd.extend(['-c', f"{zone},{config['color']},{config['intensity']}"])
            
            print(f"🚀 {get_string('executing_command')}: {' '.join(cmd)}")
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                if show_message:
                    self.show_message(get_string("config_applied"), Gtk.MessageType.INFO)
                print(f"✅ {get_string('command_success')}: {result.stdout}")
                return True
            else:
                error_msg = result.stderr or result.stdout or get_string('unknown_error')
                if show_message:
                    self.show_message(f"{get_string('error')}: {error_msg}", Gtk.MessageType.ERROR)
                print(f"❌ {get_string('command_error')}: {error_msg}")
                return False
                
        except FileNotFoundError:
            if show_message:
                self.show_message(get_string("msi_keyboard_not_found"), Gtk.MessageType.ERROR)
            print(f"❌ {get_string('msi_not_installed')}")
            return False
        except Exception as e:
            if show_message:
                self.show_message(f"{get_string('error')}: {str(e)}", Gtk.MessageType.ERROR)
            print(f"❌ {get_string('unexpected_error')}: {str(e)}")
            return False

    def save_config(self, button):
        """Guarda la configuración Y la aplica inmediatamente"""
        try:
            config = {
                'mode': self.mode,
                'zones': self.zones,
                'language': get_current_language()  # NUEVO: Guardar idioma actual
            }
            
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
                
            # Aplicar automáticamente después de guardar
            self._execute_msi_command(show_message=False)
            
            self.show_message(get_string("config_saved_and_applied"), Gtk.MessageType.INFO)
        except Exception as e:
            self.show_message(f"{get_string('save_error')}: {str(e)}", Gtk.MessageType.ERROR)

    def load_config(self):
        """Carga la configuración guardada"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.mode = config.get('mode', 'normal')
                    self.zones = config.get('zones', self.zones)
                    
                    # NUEVO: Cargar y aplicar idioma guardado
                    saved_lang = config.get('language', 'es')
                    if saved_lang != get_current_language():
                        set_language(saved_lang)
        except Exception as e:
            print(f"{get_string('config_load_error')}: {e}")

    def reset_config(self, button):
        """Resetea la configuración a valores por defecto"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=get_string("reset_confirm"),
        )
        dialog.format_secondary_text(get_string("reset_warning"))
        
        response = dialog.run()
        if response == Gtk.ResponseType.YES:
            self.zones = {
                'left': {'color': 'red', 'intensity': 'high'},
                'middle': {'color': 'red', 'intensity': 'high'},
                'right': {'color': 'red', 'intensity': 'high'}
            }
            self.mode = 'normal'
            # CORREGIDO: Usar set_active_id en lugar de set_active
            self.mode_combo.set_active_id('normal')
            self.keyboard_widget.reset_colors(self.zones)
            
        dialog.destroy()

    def show_message(self, message, message_type):
        """Muestra un mensaje al usuario"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=message_type,
            buttons=Gtk.ButtonsType.OK,
            text=message,
        )
        dialog.run()
        dialog.destroy()
        
    def on_language_changed(self, combo):
        """Maneja el cambio de idioma"""
        new_lang = combo.get_active_id()
        if new_lang != get_current_language():
            set_language(new_lang)
            self.update_interface_strings()
            # NUEVO: Guardar idioma inmediatamente
            from src.utils.config import update_config
            update_config('language', new_lang)
            
    def update_interface_strings(self):
        """Actualiza todas las cadenas de la interfaz"""
        try:
            self.set_title(get_string("window_title"))
            self.language_label.set_text(get_string("language") + ":")
            
            # NUEVO: Actualizar labels de marcos y botones
            def update_widgets_text(widget):
                if isinstance(widget, Gtk.Frame):
                    label = widget.get_label()
                    if label:
                        # Actualizar marcos por contenido conocido
                        if "Modo" in label or "Mode" in label:
                            widget.set_label(get_string("keyboard_mode"))
                        elif "Zona" in label or "Zone" in label:
                            widget.set_label(get_string("zone_configuration"))
                elif isinstance(widget, Gtk.Button):
                    label = widget.get_label()
                    if label:
                        # Actualizar botones por contenido conocido
                        if "Aplicar" in label or "Apply" in label:
                            widget.set_label(get_string("apply"))
                        elif "Guardar" in label or "Save" in label:
                            widget.set_label(get_string("save"))
                        elif "Reset" in label or "Resetear" in label:
                            widget.set_label(get_string("reset"))
                elif isinstance(widget, Gtk.Label):
                    text = widget.get_text()
                    if text and ":" in text:
                        # Actualizar labels de configuración
                        if "Modo" in text or "Mode" in text:
                            widget.set_text(get_string("mode") + ":")
                elif isinstance(widget, Gtk.Container):
                    widget.foreach(update_widgets_text)
            
            update_widgets_text(self)
            
            # NUEVO: Recrear combos para mostrar texto traducido
            self._refresh_mode_combo()
            
        except Exception as e:
            print(f"Error actualizando interfaz: {e}")
    
    def _refresh_mode_combo(self):
        """Refresca el combo de modos con textos traducidos"""
        try:
            current_mode = self.mode_combo.get_active_id()
            self.mode_combo.remove_all()
            for mode in self.modes:
                self.mode_combo.append(mode, get_string(mode))
            self.mode_combo.set_active_id(current_mode)
        except:
            pass