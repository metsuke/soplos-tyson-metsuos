import os
import json
from pathlib import Path

CONFIG_DIR = os.path.expanduser("~/.config/msi-keyboard")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

DEFAULT_CONFIG = {
    'mode': 'normal',
    'zones': {
        'left': {'color': 'red', 'intensity': 'high'},
        'middle': {'color': 'red', 'intensity': 'high'},
        'right': {'color': 'red', 'intensity': 'high'}
    },
    'language': 'es',  # Idioma por defecto
    'last_used': None
}

def load_config():
    """Carga la configuración desde el archivo"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = json.load(f)
                # Mezclar con configuración por defecto para campos faltantes
                for key, value in DEFAULT_CONFIG.items():
                    if key not in config:
                        config[key] = value
                        
                # Validar idioma soportado
                supported_langs = ['es', 'en', 'pt', 'fr', 'de', 'it', 'ro', 'ru']
                if config.get('language') not in supported_langs:
                    config['language'] = 'es'
                    
                return config
    except Exception as e:
        print(f"Error al cargar configuración: {e}")
    
    return DEFAULT_CONFIG.copy()

def save_config(config):
    """Guarda la configuración al archivo"""
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Error al guardar configuración: {e}")
        return False

def get_config_value(key, default=None):
    """Obtiene un valor específico de la configuración"""
    config = load_config()
    return config.get(key, default)

def update_config(key, value):
    """Actualiza un valor específico en la configuración"""
    config = load_config()
    config[key] = value
    return save_config(config)
