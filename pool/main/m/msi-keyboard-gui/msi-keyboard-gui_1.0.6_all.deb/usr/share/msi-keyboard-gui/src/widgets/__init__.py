"""Widgets personalizados para MSI Keyboard RGB Controller"""
